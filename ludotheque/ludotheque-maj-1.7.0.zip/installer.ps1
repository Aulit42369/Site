﻿# Installe la Ludothèque pour l'utilisateur courant (sans droits administrateur) :
# copie dans %LOCALAPPDATA%\Programs\Ludotheque, raccourcis Bureau + menu Démarrer.
# -Desinstaller : retire l'appli et les raccourcis ; les données (%APPDATA%\Ludotheque) sont gardées.
param([switch]$Desinstaller)
$ErrorActionPreference = 'Stop'
$cible = Join-Path $env:LOCALAPPDATA 'Programs\Ludotheque'
$raccourcis = @(
  (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Ludothèque.lnk'),
  (Join-Path ([Environment]::GetFolderPath('Programs')) 'Ludothèque.lnk')
)

Get-Process Ludotheque, ludotheque-serveur -ErrorAction SilentlyContinue | Where-Object { $_.Path -like "$cible\*" } | Stop-Process -Force
Start-Sleep -Milliseconds 500

if ($Desinstaller) {
  $raccourcis | ForEach-Object { Remove-Item $_ -Force -ErrorAction SilentlyContinue }
  Remove-Item $cible -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Ludotheque' -Recurse -Force -ErrorAction SilentlyContinue
  Write-Host "Ludothèque désinstallée. Tes données restent dans $env:APPDATA\Ludotheque."
  exit 0
}

$source = $PSScriptRoot
if ((Resolve-Path $source).Path -ne $cible) {
  New-Item -ItemType Directory -Force $cible | Out-Null
  Copy-Item (Join-Path $source '*') $cible -Recurse -Force
}
$sh = New-Object -ComObject WScript.Shell
foreach ($r in $raccourcis) {
  $l = $sh.CreateShortcut($r)
  $l.TargetPath = Join-Path $cible 'Ludotheque.exe'
  $l.WorkingDirectory = $cible
  $l.IconLocation = (Join-Path $cible 'Ludotheque.exe') + ',0'
  $l.Description = 'Tous tes jeux du PC au même endroit'
  $l.Save()
}
Write-Host "Ludothèque installée dans $cible, raccourcis créés sur le Bureau et dans le menu Démarrer."
Start-Process (Join-Path $cible 'Ludotheque.exe')
