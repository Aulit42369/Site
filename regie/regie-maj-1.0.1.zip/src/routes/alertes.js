// ============================================================
//  Routes : tester une alerte à l’écran
// ------------------------------------------------------------
//  « Tester une alerte » (onglet Twitch, événements) fait afficher une
//  alerte d’essai par le pont d’alertes OBS de ce PC
//  (Script OBS\twitch-alerts-bridge, GET /test/<type>).
//  C’est le pont de la régie qui l’appelle, jamais le navigateur :
//  le pont d’alertes n’accepte que ce PC, sans page web autour
//  (voir son garde-http.js). Appelé par src/routes/index.js, une
//  fois les barrières passées : comme toute action de la régie.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  traiter,
};

const parametres = require('../parametres.js');
const outilsHttp = require('../http-outils.js');

// Les seuls types envoyés : jamais « raidout », qui écrit raid_out.txt et
// coupe le stream chez le pont d'alertes.
const TYPES_ALERTE_TEST = ['follow', 'sub', 'bits', 'don', 'raid'];

const PAS_DE_REPONSE = 'Le pont d’alertes ne répond pas. Lance demarrer.bat dans Script OBS → twitch-alerts-bridge, puis réessaie.';

async function traiter(req, res, url) {
  if (req.method !== 'POST' || url.pathname !== '/api/alertes/test') return false;
  let type = '';
  try { type = String((await outilsHttp.readJsonBody(req)).type || ''); } catch (e) { /* refusé ci-dessous */ }
  if (!TYPES_ALERTE_TEST.includes(type)) {
    outilsHttp.sendJson(res, 400, { ok: false, error: 'Type d’alerte inconnu.' });
    return true;
  }
  try {
    const r = await fetch(parametres.PONT_ALERTES + '/test/' + type, { signal: AbortSignal.timeout(4000) });
    const texte = (await r.text()).slice(0, 200);
    if (r.ok) outilsHttp.sendJson(res, 200, { ok: true, type });
    else if (r.status === 403) outilsHttp.sendJson(res, 200, { ok: false, error: 'Le pont d’alertes a refusé l’essai : ' + texte });
    else outilsHttp.sendJson(res, 200, { ok: false, error: 'Le pont d’alertes a répondu ' + r.status + ' : ' + texte + ' — il est peut-être trop ancien.' });
  } catch (e) {
    outilsHttp.sendJson(res, 200, { ok: false, injoignable: true, error: PAS_DE_REPONSE });
  }
  return true;
}
