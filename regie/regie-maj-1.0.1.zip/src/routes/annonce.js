// ============================================================
//  Routes : image d’annonce et son fond, publication, Bluesky, imgbb
// ------------------------------------------------------------
//  Appelé par src/routes/index.js, une fois les barrières passées
//  (voir src/securite.js). « acces » dit qui appelle.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  traiter,
};

const fs = require('fs');
const path = require('path');

const etatRegie = require('../etat-regie.js');
const imageAnnonce = require('../image-annonce.js');
const outilsHttp = require('../http-outils.js');
const stockage = require('../stockage.js');
const reglagesRegie = require('../reglages-regie.js');
const annonces = require('../annonces.js');
const bluesky = require('../bluesky.js');
const instagram = require('../instagram.js');
const fabriqueKit = require('../kit.js');

// Une publication (tout de suite ou programmée) qui vise Instagram dans une
// régie reçue en kit : refusée en entier, avec la raison, plutôt que de
// partir à moitié (voir instagram.refuserDansUnKit).
function visesInstagramDansUnKit(body) {
  return Array.isArray(body && body.targets) && body.targets.includes('instagram') && fabriqueKit.dansUnKit();
}

// Un envoi de fond à la fois (voir POST /api/reel/background).
let envoiFondEnCours = false;

// Le fond tel qu'il est sur le disque, plus le choix retenu (« choix » :
// le changer). Diffusé à tous les appareils s'il a bougé ; le choix est
// écrit dans tokens.json (reglagesRegie.persistExtras). Rend l'état.
function majFond(choix) {
  const actuel = etatRegie.obsState.fondAnnonce || {};
  const fond = { ...imageAnnonce.etatFond(), choix: choix || actuel.choix || 'default' };
  if (JSON.stringify(fond) !== JSON.stringify(actuel)) {
    etatRegie.setState({ fondAnnonce: fond });
    if (fond.choix !== actuel.choix) reglagesRegie.persistExtras();
  }
  return fond;
}

// Rend vrai si la demande a été traitée ici.
async function traiter(req, res, url, acces) {
  if (req.method === 'POST' && url.pathname === '/api/reel/generate') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      const jpg = await imageAnnonce.generateReelImage({
        eyebrow: body.eyebrow, titleLine1: body.titleLine1, titleLine2: body.titleLine2,
        subtitle: body.subtitle, handle: body.handle, platform: body.platform,
        background: body.background, accent: body.accent, accent2: body.accent2,
      });
      outilsHttp.sendJson(res, 200, { ok: true, image: 'data:image/jpeg;base64,' + jpg.toString('base64') });
    } catch (e) {
      outilsHttp.sendJson(res, 200, { ok: false, error: e.message });
    }
    return true;
  }

  if (req.method === 'GET' && url.pathname === '/api/reel/backgrounds') {
    // Relu sur le disque : un custom.jpg déposé à la main pendant que le
    // pont tourne apparaît ici (et chez les autres appareils).
    const fond = majFond();
    outilsHttp.sendJson(res, 200, { ok: true, ...fond });
    return true;
  }

  // L'aperçu du fond perso, pour la vignette « Image perso ». Mêmes accès
  // que la régie : un overlay ou un autre site est arrêté par le verrou de
  // routes/index.js (cette route n'est pas dans LECTURES_OUVERTES), un
  // appareil non relié par la barrière 3. Type lu dans le contenu.
  if (req.method === 'GET' && url.pathname === '/api/reel/background') {
    let fond = null;
    try { fond = imageAnnonce.fondPerso(); } catch (e) { /* illisible : comme absent */ }
    if (!fond) {
      outilsHttp.sendJson(res, 404, { ok: false, error: 'Aucun fond perso.' });
      return true;
    }
    res.writeHead(200, { 'Content-Type': fond.type, 'Content-Length': fond.octets.length, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
    res.end(fond.octets);
    return true;
  }

  // Le fond perso, choisi dans l'onglet Annonce (téléphone ou PC). Mêmes
  // règles que toute commande : la régie seulement — un overlay ou un autre
  // site est arrêté par le verrou de routes/index.js, un appareil non relié
  // par la barrière 3. Le pont choisit seul le nom du fichier. Un seul envoi
  // à la fois (409) : deux remplacements mêlés laisseraient une copie
  // « précédente » qui n'est ni l'une ni l'autre.
  if (req.method === 'POST' && url.pathname === '/api/reel/background') {
    if (envoiFondEnCours) {
      res.setHeader('Connection', 'close'); // la demande n'est pas lue
      outilsHttp.sendJson(res, 409, { ok: false, error: 'Un autre fond est en cours d’envoi : réessaie dans un instant.' });
      return true;
    }
    envoiFondEnCours = true;
    try {
      let body;
      try {
        // 8 Mo d'image au plus, donc 4/3 de plus en base64, et la marge du JSON.
        body = await outilsHttp.readJsonBody(req, { max: Math.ceil(imageAnnonce.TAILLE_MAX_FOND * 4 / 3) + 64 * 1024 });
      } catch (e) {
        // Le reste de la demande n'est pas lu : la connexion ne peut pas
        // resservir (la suivante y lirait ces octets).
        if (e.tropGros) res.setHeader('Connection', 'close');
        outilsHttp.sendJson(res, e.tropGros ? 413 : 400, { ok: false, error: e.tropGros ? 'Image trop lourde : 8 Mo au plus.' : 'Requête invalide.' });
        return true;
      }
      try {
        const nom = imageAnnonce.enregistrerFondPerso(body.image);
        console.log('[annonce] Nouveau fond perso : reel/backgrounds/' + nom + '.');
        outilsHttp.sendJson(res, 200, { ok: true, ...majFond('custom') });
      } catch (e) {
        if (!e.statut) {
          console.warn('[annonce] Fond perso non enregistré : ' + e.message);
          majFond(); // l'état diffusé suit le disque, même après un échec à mi-chemin
        }
        outilsHttp.sendJson(res, e.statut || 500, { ok: false, error: e.statut ? e.message : 'Le fond n’a pas pu être enregistré dans reel/backgrounds/ (voir data/pont.log).' });
      }
    } finally {
      envoiFondEnCours = false;
    }
    return true;
  }

  // « Modèle » ou « Image perso » : un réglage de la régie, retenu dans
  // tokens.json et partagé par tous les appareils.
  if (req.method === 'POST' && url.pathname === '/api/reel/background/choix') {
    let body;
    try { body = await outilsHttp.readJsonBody(req); } catch (e) { body = {}; }
    if (body.choix !== 'default' && body.choix !== 'custom') {
      outilsHttp.sendJson(res, 400, { ok: false, error: 'Choix attendu : default ou custom.' });
      return true;
    }
    if (body.choix === 'custom' && !imageAnnonce.etatFond().hasCustom) {
      outilsHttp.sendJson(res, 409, { ok: false, error: 'Aucune image perso : choisis-en une d’abord.' });
      return true;
    }
    outilsHttp.sendJson(res, 200, { ok: true, ...majFond(body.choix) });
    return true;
  }

  // « Revenir à l'image précédente » (voir imageAnnonce.revenirAuFondPrecedent).
  if (req.method === 'POST' && url.pathname === '/api/reel/background/precedent') {
    if (envoiFondEnCours) {
      outilsHttp.sendJson(res, 409, { ok: false, error: 'Un fond est en cours d’envoi : réessaie dans un instant.' });
      return true;
    }
    try {
      const nom = imageAnnonce.revenirAuFondPrecedent();
      console.log('[annonce] Fond perso : retour à l’image précédente (reel/backgrounds/' + nom + ').');
      outilsHttp.sendJson(res, 200, { ok: true, ...majFond('custom') });
    } catch (e) {
      if (!e.statut) {
        console.warn('[annonce] Retour à l’image précédente impossible : ' + e.message);
        majFond();
      }
      outilsHttp.sendJson(res, e.statut || 500, { ok: false, error: e.statut ? e.message : 'Le retour à l’image précédente a échoué (voir data/pont.log).' });
    }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/bluesky/credentials') {
    // On ESSAIE les nouveaux identifiants avant de remplacer les anciens.
    // Écrire d'abord puis valider était un piège discret : une faute de
    // frappe écrasait en mémoire des identifiants qui marchaient, sans les
    // enregistrer sur le disque — donc l'appli continuait d'afficher
    // « connecté » alors que toute publication Bluesky échouait jusqu'au
    // redémarrage du pont, sans que rien n'explique pourquoi.
    const precedents = stockage.platformTokens.bluesky;
    try {
      const body = await outilsHttp.readJsonBody(req);
      const candidats = { handle: bluesky.normaliserIdentifiantBluesky(body.handle), appPassword: String(body.appPassword || '').trim() };
      if (!candidats.handle || !candidats.appPassword) throw new Error('Indique ton pseudo Bluesky et le mot de passe d’application.');
      stockage.platformTokens.bluesky = candidats;
      const session = await bluesky.blueskyLogin();
      // Le pseudo tel que Bluesky l'écrit, pour l'affichage (on a pu se
      // connecter avec un e-mail).
      if (session.handle) candidats.pseudo = session.handle;
      stockage.saveTokens();
      etatRegie.setState({ blueskyConnected: true, blueskyHandle: candidats.pseudo || candidats.handle });
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      stockage.platformTokens.bluesky = precedents; // on rend ce qui fonctionnait
      outilsHttp.sendJson(res, 200, { ok: false, error: e.message });
    }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/bluesky/disconnect') {
    stockage.platformTokens.bluesky = null;
    stockage.saveTokens();
    etatRegie.setState({ blueskyConnected: false, blueskyHandle: '' });
    outilsHttp.sendJson(res, 200, { ok: true });
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/imgbb/credentials') {
    // imgbb ne sert qu'à la publication Instagram : rien à enregistrer dans
    // une régie reçue en kit.
    if (fabriqueKit.dansUnKit()) {
      outilsHttp.sendJson(res, 403, { ok: false, dansUnKit: true, error: instagram.REFUS_KIT });
      return true;
    }
    try {
      const body = await outilsHttp.readJsonBody(req);
      stockage.platformTokens.imgbb = { apiKey: (body.apiKey || '').trim() };
      stockage.saveTokens();
      etatRegie.setState({ imgbbConfigured: !!stockage.platformTokens.imgbb.apiKey });
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false, error: 'Requête invalide.' });
    }
    return true;
  }

  // Publication immédiate — le comportement par défaut, inchangé.
  if (req.method === 'POST' && url.pathname === '/api/reel/publish') {
    let body;
    try {
      body = await outilsHttp.readJsonBody(req);
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false, error: 'Requête invalide.' });
      return true;
    }
    if (visesInstagramDansUnKit(body)) {
      outilsHttp.sendJson(res, 403, { ok: false, dansUnKit: true, error: instagram.REFUS_KIT });
      return true;
    }
    try {
      const results = await annonces.publierPartout(body);
      outilsHttp.sendJson(res, 200, { ok: true, results });
    } catch (e) {
      // Distinguer les deux échecs : « Requête invalide » pour un problème de
      // publication envoyait chercher une erreur de saisie là où il n'y en
      // avait pas, et cachait le vrai message.
      outilsHttp.sendJson(res, 200, { ok: false, error: e.message || String(e) });
    }
    return true;
  }

  // Publication différée — même contenu, même chemin de publication,
  // simplement déclenché plus tard par le pont.
  if (req.method === 'POST' && url.pathname === '/api/reel/schedule') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      if (visesInstagramDansUnKit(body)) {
        outilsHttp.sendJson(res, 403, { ok: false, dansUnKit: true, error: instagram.REFUS_KIT });
        return true;
      }
      const quand = Number(body.quand);
      if (!quand || !isFinite(quand)) {
        outilsHttp.sendJson(res, 400, { ok: false, error: 'Heure de publication manquante.' });
        return true;
      }
      if (quand < Date.now() - 60000) {
        outilsHttp.sendJson(res, 400, { ok: false, error: 'Cette heure est déjà passée.' });
        return true;
      }
      const id = 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
      const fichierImage = annonces.ecrireImageAnnonce(id, body.image);
      if (!fichierImage) {
        outilsHttp.sendJson(res, 500, { ok: false, error: "L'image n'a pas pu être enregistrée dans data/annonces/." });
        return true;
      }
      const p = {
        id,
        quand,
        creeeA: Date.now(),
        statut: 'attente',
        // L'appareil qui l'a programmée (vide pour le PC) : la retirer avec lui.
        par: acces && acces.appareil ? acces.appareil.id : '',
        apercu: {
          caption: String(body.caption || '').slice(0, 160),
          targets: Array.isArray(body.targets) ? body.targets : [],
        },
        contenu: {
          // Le NOM du fichier, pas l'image : tokens.json reste petit.
          image: fichierImage,
          targets: body.targets,
          caption: body.caption,
          liveDurationMinutes: body.liveDurationMinutes,
          twitchUrl: body.twitchUrl,
        },
      };
      annonces.publicationsProgrammees.push(p);
      annonces.publicationsProgrammees.sort((a, b) => a.quand - b.quand);
      reglagesRegie.persistExtras();
      annonces.diffuserProgrammations();
      outilsHttp.sendJson(res, 200, { ok: true, id: p.id });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false, error: 'Requête invalide.' });
    }
    return true;
  }

  if (req.method === 'GET' && url.pathname === '/api/reel/schedule') {
    // L'image en base64 pèse ~100 Ko par programmation : on ne renvoie
    // que de quoi afficher la liste, pas les images elles-mêmes.
    outilsHttp.sendJson(res, 200, {
      ok: true,
      publications: annonces.publicationsProgrammees.map(({ contenu, ...reste }) => reste),
    });
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/reel/schedule/cancel') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      const avant = annonces.publicationsProgrammees.length;
      const annulee = annonces.publicationsProgrammees.find((p) => p.id === body.id);
      if (annulee) annonces.supprimerImageAnnonce(annulee.contenu && annulee.contenu.image);
      annonces.publicationsProgrammees = annonces.publicationsProgrammees.filter((p) => p.id !== body.id);
      if (annonces.publicationsProgrammees.length === avant) {
        outilsHttp.sendJson(res, 404, { ok: false, error: 'Programmation introuvable.' });
        return true;
      }
      reglagesRegie.persistExtras();
      annonces.diffuserProgrammations();
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false, error: 'Requête invalide.' });
    }
    return true;
  }

  // ---------- Modèles d'annonce ----------
  if (req.method === 'POST' && url.pathname === '/api/reel/templates') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      if (!Array.isArray(body.modeles)) {
        outilsHttp.sendJson(res, 400, { ok: false, error: 'Format attendu : { modeles: [...] }' });
        return true;
      }
      etatRegie.obsState.reelTemplates = body.modeles.slice(0, 30);
      reglagesRegie.persistExtras();
      etatRegie.broadcastPatch({ reelTemplates: etatRegie.obsState.reelTemplates });
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false, error: 'Requête invalide.' });
    }
    return true;
  }
  return false;
}
