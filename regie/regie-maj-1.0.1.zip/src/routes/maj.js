// ============================================================
//  Routes : mise à jour signée de la régie (voir src/maj.js)
// ------------------------------------------------------------
//  Appelé par src/routes/index.js, une fois les barrières passées :
//  le PC et les appareils reliés seulement (un appareil inconnu,
//  barrière 3, et une page d'une autre origine, verrou central, sont
//  refusés avant d'arriver ici). Publier : PC seulement
//  (securite.reserveAuPc).
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  traiter,
};

const fs = require('fs');

const outilsHttp = require('../http-outils.js');
const securite = require('../securite.js');
const maj = require('../maj.js');

async function repondre(res, action) {
  try {
    outilsHttp.sendJson(res, 200, await action());
  } catch (e) {
    outilsHttp.sendJson(res, 200, { ok: false, error: e.message, miseAJour: maj.etat() });
  }
}

async function traiter(req, res, url) {
  const p = url.pathname;
  if (req.method === 'GET' && p === '/api/maj') { outilsHttp.sendJson(res, 200, { ok: true, miseAJour: maj.etat() }); return true; }
  if (req.method === 'POST' && p === '/api/maj/verifier') { await repondre(res, async () => ({ ok: true, miseAJour: await maj.verifier() })); return true; }
  if (req.method === 'POST' && p === '/api/maj/installer') { await repondre(res, () => maj.installer()); return true; }
  if (req.method === 'POST' && p === '/api/maj/revenir') { await repondre(res, async () => maj.revenir()); return true; }

  if (p === '/api/maj/publier' && (req.method === 'GET' || req.method === 'POST')) {
    if (securite.estAutreOrigine(req)) { outilsHttp.sendJson(res, 403, { ok: false, error: 'Réservé aux pages servies par le pont.' }); return true; }
    if (req.method === 'GET') { outilsHttp.sendJson(res, 200, { ok: true, ...maj.infosPublication() }); return true; }
    await repondre(res, async () => maj.publier(await outilsHttp.readJsonBody(req)));
    return true;
  }

  // L'APK de l'appli téléphone, seulement si elle a l'empreinte annoncée
  // par la mise à jour signée (regie-mobile.apk.json).
  if ((req.method === 'GET' || req.method === 'HEAD') && p === '/regie-mobile.apk') {
    const chemin = maj.cheminApkVerifiee();
    if (!chemin) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8', 'X-Content-Type-Options': 'nosniff' });
      res.end('Aucune appli téléphone vérifiée sur ce PC.');
      return true;
    }
    res.writeHead(200, {
      'Content-Type': 'application/vnd.android.package-archive',
      'Content-Disposition': 'attachment; filename="regie-mobile.apk"',
      'Content-Length': fs.statSync(chemin).size,
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
    });
    if (req.method === 'HEAD') res.end();
    else fs.createReadStream(chemin).pipe(res);
    return true;
  }
  return false;
}
