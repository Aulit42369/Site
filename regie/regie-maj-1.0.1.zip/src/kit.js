// ============================================================
//  Le kit à donner à quelqu’un
// ------------------------------------------------------------
//  Fabriqué à partir d’une liste blanche : aucun accès ne part avec.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  get HORS_MISE_A_JOUR() { return HORS_MISE_A_JOUR; },
  get JAMAIS_DANS_UN_ZIP() { return JAMAIS_DANS_UN_ZIP; },
  dansUnKit,
  ecrireKit,
  ecrirePreparationKit,
  raidCabaneActif,
  lireKit,
  lirePreparationKit,
  fabriquerKit,
  sourceNodeDuKit,
  sourceWkhtmlDuKit,
};

const fs = require('fs');
const path = require('path');

const parametres = require('./parametres.js');
const wkhtml = require('./wkhtml.js');
const outilsHttp = require('./http-outils.js');

// ---------- Le kit ----------
// Deux fichiers, deux rôles, à ne jamais mélanger :
//
//  • kit.json : ce que CETTE régie a reçu. Le Client ID Twitch, le
//    contact de la personne qui aide, le pseudo de qui streame ici. Il
//    arrive dans le kit (ou se crée à la main d'après kit.exemple.json)
//    et n'est PAS livré dans les mises à jour : sinon chaque mise à
//    jour l'effacerait.
//
//  • data/kit-a-preparer.json : ce qu'on saisit sur la page /kit pour
//    la régie de QUELQU'UN D'AUTRE (son pseudo, son propre contact, le
//    Client ID à lui donner). Rangé à part : préparer le kit de Léa ne
//    doit mettre ni son pseudo dans TA régie, ni ton propre contact sur
//    TA page « Mon installation ». Étant dans data/, il ne part dans
//    aucun zip.
//
// Un Client ID Twitch : une trentaine de caractères alphanumériques. On
// refuse le reste plutôt que d'envoyer n'importe quoi à Twitch.
// ---------- Ce qui ne part jamais dans un zip ----------
// Les deux listes uniques, lues par le kit (fabriquerKit), la mise à jour
// (maj.js : fabrication ET installation) et les contrôles.
//  • JAMAIS_DANS_UN_ZIP : accès, données, certificats, fonds perso (la photo
//    de quelqu'un), clé privée de mise à jour, sauvegarde de la version
//    précédente. Ni kit, ni mise à jour.
//  • HORS_MISE_A_JOUR : ce qui appartient à chaque régie et qu'une mise à
//    jour ne doit pas écraser, même décompressée à la main par une ancienne
//    régie : son kit.json, sa notice (celle d'un kit est sans Instagram), son
//    pseudo par défaut, ses outils, le lanceur (verrouillé pendant qu'il
//    tourne), les journaux.
const JAMAIS_DANS_UN_ZIP = /(^|\/)(tokens\.json|data\/|certs\/|.*\.pem$|ca\.crt$|\.env$|cle-mise-a-jour\/|maj-precedente\/)|^reel\/backgrounds\/custom(-precedent)?\./i;
const HORS_MISE_A_JOUR = /^(kit\.json|node\/|wkhtmltopdf\/|node_modules\/|LISEZ-MOI\.txt|COMMENCER-ICI\.txt|public\/config\.js|Regie mobile\.exe|lanceur\/|outils\/)|\.log$/i;

const FORMAT_CLIENT_ID =/^[a-z0-9]{10,64}$/i;
const ERREUR_CLIENT_ID = 'Ce Client ID ne ressemble pas à un Client ID Twitch (lettres et chiffres, une trentaine).';

function nettoyerKit(brut) {
  const objet = brut && typeof brut === 'object' ? brut : {};
  const texte = (v, max) => (typeof v === 'string' ? v.trim().slice(0, max) : '');
  const clientId = texte(objet.twitchClientId, 200);
  return {
    twitchClientId: FORMAT_CLIENT_ID.test(clientId) ? clientId : '',
    twitchClientIdInvalide: !!clientId && !FORMAT_CLIENT_ID.test(clientId),
    contact: texte(objet.contact, 200),
    pseudo: texte(objet.pseudo, 40),
  };
}

// Les valeurs envoyées remplacent les actuelles ; une valeur absente garde
// l'actuelle.
function fusionnerKit(actuel, valeurs) {
  const prendre = (cle) => String(valeurs[cle] !== undefined && valeurs[cle] !== null ? valeurs[cle] : actuel[cle] || '').trim();
  const kit = {
    twitchClientId: prendre('twitchClientId'),
    contact: prendre('contact').slice(0, 200),
    pseudo: prendre('pseudo').slice(0, 40),
  };
  if (kit.twitchClientId && !FORMAT_CLIENT_ID.test(kit.twitchClientId)) throw new Error(ERREUR_CLIENT_ID);
  return kit;
}

function ecrireJson(chemin, objet) {
  const texte = JSON.stringify(objet, null, 2) + '\n';
  const tmp = chemin + '.tmp';
  fs.writeFileSync(tmp, texte);
  try {
    fs.renameSync(tmp, chemin);
  } catch (e) {
    // Windows : un antivirus qui lit le fichier au même instant fait
    // échouer le renommage. On écrit alors directement.
    fs.writeFileSync(chemin, texte);
    try { fs.unlinkSync(tmp); } catch (e2) { /* sans importance */ }
  }
}

function lireKit(dossier) {
  const chemin = path.join(dossier, 'kit.json');
  let brut;
  try {
    brut = JSON.parse(fs.readFileSync(chemin, 'utf8').replace(/^﻿/, ''));
  } catch (e) {
    return { present: false, dansUnKit: false, raidCabane: true, twitchClientId: '', twitchClientIdInvalide: false, contact: '', pseudo: '', erreur: fs.existsSync(chemin) ? 'kit.json illisible : ' + e.message : '' };
  }
  // « recuDansUnKit » : posé par fabriquerKit, et par lui seul. La simple
  // présence de kit.json ne prouve rien : la régie d'Olivier en a un aussi
  // (son Client ID, repris par ecrirePreparationKit).
  const recu = !!(brut && brut.recuDansUnKit === true);
  // « raidCabane » : la case de la page /kit (décision du 25/10). Ne compte
  // que dans un kit, et seul un false explicite retire la carte : un kit.json
  // d'avant le 25/10 (sans la clé) la garde, comme la régie d'Olivier.
  return { present: true, dansUnKit: recu, raidCabane: !(recu && brut.raidCabane === false), ...nettoyerKit(brut), erreur: '' };
}

// Cette régie a-t-elle été reçue dans un kit ? Alors Instagram n'y sert qu'à
// fabriquer l'image : la personne la publie elle-même (décision du 24/10).
// Relu à chaque appel : kit.json est petit, et la page /kit peut le réécrire.
// Une commodité d'interface, PAS une barrière (décision du 24/10) : retirer
// la ligne, ou un kit.json abîmé, rend Instagram. Volontaire : dans le doute,
// la régie marche comme celle d'Olivier plutôt que de se bloquer.
function dansUnKit() {
  return lireKit(parametres.RACINE).dansUnKit;
}

// La carte « Raid · La Cabane » et sa route sont-elles proposées ? Même
// principe que dansUnKit : relu à chaque appel, fail-open.
function raidCabaneActif() {
  return lireKit(parametres.RACINE).raidCabane;
}

function ecrireKit(dossier, valeurs) {
  const actuel = lireKit(dossier);
  // kit.json illisible : on n'écrit rien par-dessus. Le réécrire « propre »
  // effacerait la marque du kit sans que personne ne le voie.
  if (actuel.erreur) throw new Error(actuel.erreur + ' — répare-le (ou retire-le) avant de changer le Client ID.');
  // La marque du kit (et le raid La Cabane retiré) survit à une modification
  // faite sur la page /kit.
  ecrireJson(path.join(dossier, 'kit.json'), { ...fusionnerKit(actuel, valeurs),
    ...(actuel.dansUnKit ? { recuDansUnKit: true, ...(actuel.raidCabane ? {} : { raidCabane: false }) } : {}) });
  return lireKit(dossier);
}

function cheminPreparationKit(dossier) {
  return path.join(dossier, 'data', 'kit-a-preparer.json');
}

function lirePreparationKit(dossier) {
  try {
    const brut = JSON.parse(fs.readFileSync(cheminPreparationKit(dossier), 'utf8').replace(/^﻿/, ''));
    // Raid · La Cabane : décoché tant qu'on ne l'a pas coché (La Cabane est
    // la communauté d'Olivier ; la personne n'en fait souvent pas partie).
    if (brut && typeof brut === 'object') return { present: true, ...nettoyerKit(brut), raidCabane: brut.raidCabane === true };
  } catch (e) { /* jamais préparé (ou illisible) : on repart de zéro */ }
  // Jamais préparé : le Client ID de cette régie vaut pour tous les kits.
  // Le pseudo et le contact, eux, sont à saisir.
  return { present: false, twitchClientId: lireKit(dossier).twitchClientId, twitchClientIdInvalide: false, contact: '', pseudo: '', raidCabane: false };
}

function ecrirePreparationKit(dossier, valeurs) {
  const actuelle = lirePreparationKit(dossier);
  const preparation = { ...fusionnerKit(actuelle, valeurs), raidCabane: typeof valeurs.raidCabane === 'boolean' ? valeurs.raidCabane : actuelle.raidCabane };
  fs.mkdirSync(path.join(dossier, 'data'), { recursive: true });
  ecrireJson(cheminPreparationKit(dossier), preparation);
  // Le Client ID sert aussi à CETTE régie si elle n'en a pas encore de
  // valable : la connexion Twitch par code y devient possible. Seul le
  // Client ID est repris, jamais le pseudo ni le contact.
  const fourni = typeof valeurs.twitchClientId === 'string' && valeurs.twitchClientId.trim() !== '';
  const kitActuel = lireKit(dossier);
  if (fourni && preparation.twitchClientId && !kitActuel.twitchClientId && !kitActuel.erreur) {
    ecrireKit(dossier, { twitchClientId: preparation.twitchClientId });
  }
  return lirePreparationKit(dossier);
}

// D'où viendra le node.exe du kit. Dans l'ordre : la variable REGIE_KIT_NODE
// (contrôles), le Node qui fait tourner ce pont s'il est sous Windows, puis
// un node/node.exe posé dans le dossier de la régie.
function sourceNodeDuKit() {
  const candidats = [];
  if (process.env.REGIE_KIT_NODE) candidats.push({ chemin: process.env.REGIE_KIT_NODE, origine: 'REGIE_KIT_NODE', version: '' });
  if (process.platform === 'win32') candidats.push({ chemin: process.execPath, origine: 'le Node de ce PC', version: process.version });
  candidats.push({ chemin: path.join(parametres.RACINE, 'node', 'node.exe'), origine: 'le dossier node/ de la régie', version: '' });
  for (const c of candidats) {
    try {
      const st = fs.statSync(c.chemin);
      if (st.isFile() && st.size > 1024 * 1024 && /\.exe$/i.test(c.chemin)) return c;
    } catch (e) { /* candidat suivant */ }
  }
  return null;
}

// D'où viendra le wkhtmltoimage.exe du kit (l'outil des images d'annonce).
// Dans l'ordre : la variable REGIE_KIT_WKHTML (contrôles), la copie d'un
// kit si cette régie en vient, puis celui installé sur ce PC — sous
// Windows seulement, puisque c'est un .exe qui part dans le kit.
// Seul wkhtmltoimage.exe voyage : il ne dépend d'aucun autre fichier de
// son dossier, seulement de « Visual C++ » de Microsoft (voir
// expliquerEchecWkhtml), qu'un PC de stream a déjà avec OBS.
function versionWkhtml(chemin) {
  return new Promise((resolve) => {
    wkhtml.lancerSansFenetre(chemin, ['--version'], { timeout: 8000 }, (err, sortie) => {
      const m = /wkhtmltoimage\s+(\d+(?:\.\d+)+)/i.exec(String(sortie || ''));
      resolve(!err && m ? m[1] : '');
    });
  });
}

async function sourceWkhtmlDuKit() {
  const candidats = [];
  if (process.env.REGIE_KIT_WKHTML) candidats.push({ chemin: process.env.REGIE_KIT_WKHTML, origine: 'REGIE_KIT_WKHTML' });
  candidats.push({ chemin: wkhtml.WKHTML_DU_KIT, origine: 'le dossier wkhtmltopdf/ de la régie' });
  if (process.platform === 'win32') {
    const installe = 'l’installation de ce PC';
    if (process.env.WKHTMLTOIMAGE_PATH) candidats.push({ chemin: process.env.WKHTMLTOIMAGE_PATH, origine: installe });
    // La version 64 bits d'abord : c'est celle dont OBS installe déjà le
    // « Visual C++ ».
    for (const racine of [process.env.ProgramW6432, process.env.ProgramFiles, 'C:\\Program Files',
      process.env['ProgramFiles(x86)'], 'C:\\Program Files (x86)']) {
      if (racine) candidats.push({ chemin: path.join(racine, 'wkhtmltopdf', 'bin', 'wkhtmltoimage.exe'), origine: installe });
    }
    for (const dossier of String(process.env.PATH || '').split(';')) {
      const d = dossier.trim().replace(/^"|"$/g, '');
      if (d) candidats.push({ chemin: path.join(d, 'wkhtmltoimage.exe'), origine: installe });
    }
  }
  // Seulement un vrai wkhtmltoimage.exe, en 64 bits. Un autre nom (une
  // variable qui pointerait vers wkhtmltopdf.exe) partirait renommé ; un
  // 32 bits réclamerait chez la personne un « Visual C++ » 32 bits qu'OBS,
  // lui en 64 bits, n'installe pas.
  let trenteDeuxBits = null;
  for (const c of candidats) {
    try {
      if (path.basename(c.chemin).toLowerCase() !== 'wkhtmltoimage.exe') continue;
      const st = fs.statSync(c.chemin);
      if (!st.isFile() || st.size < 1024 * 1024) continue;
      const archi = wkhtml.architecturePe(c.chemin);
      if (archi === 'x86') { trenteDeuxBits = trenteDeuxBits || c; continue; }
      if (archi !== 'x64') continue;
      return { ...c, version: await versionWkhtml(c.chemin) };
    } catch (e) { /* candidat suivant */ }
  }
  return trenteDeuxBits ? { refus: 'x86', chemin: trenteDeuxBits.chemin } : null;
}

function texteAProposWkhtml(version) {
  return [
    'wkhtmltoimage : l’outil qui dessine les images d’annonce de la régie',
    '=====================================================================',
    'Version : ' + (version || 'inconnue') + ', copiée telle quelle depuis le PC qui a préparé ce kit.',
    'Projet : wkhtmltopdf, https://wkhtmltopdf.org',
    'Licence : GNU LGPL version 3 (texte complet dans LICENSE.txt).',
    'Code source : https://github.com/wkhtmltopdf/wkhtmltopdf',
    '',
    'Rien à faire avec ce dossier : la régie s’en sert toute seule.',
    'Si les images d’annonce ne se fabriquent pas, la page « Mon installation »',
    'de la régie dit pourquoi et quoi faire.',
    '',
  ].join('\r\n');
}

// Le LISEZ-MOI du kit : sans les passages qui configurent la publication
// Instagram (connexion Meta, relais imgbb, erreurs de connexion), encadrés
// dans LISEZ-MOI.txt par deux lignes repères, écrites pour rester lisibles
// par qui lit la notice complète (chez Olivier). Une mise à jour ne contient
// jamais LISEZ-MOI.txt (HORS_MISE_A_JOUR) : la notice d'un kit reste la sienne.
// Un repère sans sa fin coupe jusqu'au bout : mieux vaut une notice trop
// courte qu'un kit qui explique une connexion qu'il refuse.
const REPERE_INSTAGRAM_DEBUT = "— Publication Instagram automatique (absente d'une régie reçue en kit) —";
const REPERE_INSTAGRAM_FIN = '— Fin de la partie Publication Instagram automatique —';
function sansInstagramAuto(texte) {
  const lignes = texte.split(/\r?\n/);
  const garde = [];
  let dedans = false;
  for (const l of lignes) {
    if (l.trim() === REPERE_INSTAGRAM_DEBUT) { dedans = true; continue; }
    if (l.trim() === REPERE_INSTAGRAM_FIN) { dedans = false; continue; }
    if (!dedans) garde.push(l);
  }
  return garde.join(/\r\n/.test(texte) ? '\r\n' : '\n');
}

// Le kit : un dossier prêt à envoyer à quelqu'un qui n'y connaît rien.
// Fabriqué à partir d'une LISTE BLANCHE — c'est la garantie qu'aucun accès
// ne part avec : tokens.json, data/ et certs/ ne sont même pas lus. La
// personne qui le reçoit aura SES propres accès, SON autorité locale, SES
// données, créés au premier lancement.
async function fabriquerKit() {
  const { creerZip } = require('./zip.js');
  // Ce qui a été saisi sur la page /kit pour la personne, pas le kit.json
  // de cette régie-ci.
  const kit = lirePreparationKit(parametres.RACINE);
  const entrees = [];
  const lire = (relatif) => fs.readFileSync(path.join(parametres.RACINE, relatif));
  const ajouter = (nomDansZip, donnees, date) => entrees.push({ nom: nomDansZip, donnees, date: date || new Date() });
  const ajouterFichier = (relatif, obligatoire) => {
    const complet = path.join(parametres.RACINE, relatif);
    if (!fs.existsSync(complet)) {
      if (obligatoire) throw new Error(relatif + ' manque dans le dossier de la régie.');
      return;
    }
    ajouter(relatif.split(path.sep).join('/'), fs.readFileSync(complet), fs.statSync(complet).mtime);
  };
  const parcourir = (relatif, garder) => {
    const complet = path.join(parametres.RACINE, relatif);
    if (!fs.existsSync(complet)) return;
    for (const nom of fs.readdirSync(complet)) {
      if (nom.startsWith('.')) continue;
      const r = path.join(relatif, nom);
      const st = fs.statSync(path.join(parametres.RACINE, r));
      const rSlash = r.split(path.sep).join('/');
      if (st.isDirectory()) parcourir(r, garder);
      else if (garder(rSlash)) ajouterFichier(r, true);
    }
  };

  // Le pseudo de la personne remplace le tien s'il est écrit en dur dans
  // la page de l'appli (son titre, par exemple).
  const pseudoActuel = (/pseudo\s*:\s*(['"])(.*?)\1/.exec(lire('public/config.js').toString('utf8')) || [])[2] || '';
  const pseudoKit = kit.pseudo || 'Ma chaîne';
  // Remplacé SEULEMENT dans le texte visible (titre, textes de la page) et
  // seulement en MOT ENTIER. Une première version remplaçait partout : avec
  // un pseudo court comme « Tom », le CSS « bottom » devenait « botLea » et
  // la page se cassait. Le CSS, le JavaScript et les attributs ne sont
  // donc jamais touchés, et le nouveau pseudo est échappé.
  const personnaliser = (html) => {
    if (!pseudoActuel) return html;
    const motif = new RegExp('(^|[^\\p{L}\\p{N}_])(' + pseudoActuel.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')(?=$|[^\\p{L}\\p{N}_])', 'giu');
    let dansCode = false;
    return html.replace(/(<[^>]*>)|([^<]+)/g, (morceau, balise, texte) => {
      if (balise) {
        if (/^<\s*(script|style)\b/i.test(balise)) dansCode = true;
        else if (/^<\s*\/\s*(script|style)\b/i.test(balise)) dansCode = false;
        return balise;
      }
      if (dansCode) return texte;
      return texte.replace(motif, (m, avant, mot) => avant
        + outilsHttp.echapperHtml(mot === mot.toUpperCase() && mot !== mot.toLowerCase() ? pseudoKit.toUpperCase() : pseudoKit));
    });
  };

  // 1. Le lanceur et Node : ce qui fait « rien à installer ».
  ajouterFichier('Regie mobile.exe', false);
  // Les licences : celles de lanceur/, ou, sur une régie qui vient
  // elle-même d'un kit (sans lanceur/), celles qu'elle a reçues.
  const premierExistant = (...relatifs) => relatifs.find((r) => fs.existsSync(path.join(parametres.RACINE, r))) || '';
  const node = sourceNodeDuKit();
  if (node) {
    ajouter('node/node.exe', fs.readFileSync(node.chemin));
    const licence = premierExistant('lanceur/LICENCE-node.txt', 'node/LICENSE.txt');
    if (licence) ajouter('node/LICENSE.txt', lire(licence));
  }
  // 1 bis. L'outil des images d'annonce : sans lui, l'onglet Annonce ne
  //        fabrique aucune image (ni pour Bluesky, ni pour Instagram).
  const wk = await sourceWkhtmlDuKit();
  if (wk && !wk.refus) {
    ajouter('wkhtmltopdf/wkhtmltoimage.exe', fs.readFileSync(wk.chemin));
    const licence = premierExistant('lanceur/LICENCE-wkhtmltopdf.txt', 'wkhtmltopdf/LICENSE.txt');
    if (licence) ajouter('wkhtmltopdf/LICENSE.txt', lire(licence));
    ajouter('wkhtmltopdf/A-PROPOS.txt', Buffer.from(texteAProposWkhtml(wk.version), 'utf8'));
  }
  // 2. Le pont : server.js et TOUT le dossier src/. Un dossier plutôt qu'une
  //    liste de fichiers : un morceau ajouté au pont part dans le kit sans
  //    qu'il faille y penser (une liste oubliée donnait un kit qui ne
  //    démarrait pas : « Cannot find module »).
  ajouterFichier('server.js', true);
  parcourir('src', () => true);
  // .env.example : le modèle commenté des réglages avancés, que le LISEZ-MOI
  // cite (aucune valeur, aucun secret). Le .env de CE PC, lui, ne part jamais.
  // package.json : porte la version de la régie (mises à jour, voir maj.js).
  for (const f of ['start.bat', 'COMMENCER-ICI.txt', '.env.example', 'package.json']) ajouterFichier(f, false);
  // Le LISEZ-MOI sans ce qui configure la publication Instagram : elle
  // n'existe pas dans une régie reçue en kit (voir sansInstagramAuto).
  if (fs.existsSync(path.join(parametres.RACINE, 'LISEZ-MOI.txt'))) {
    ajouter('LISEZ-MOI.txt', Buffer.from(sansInstagramAuto(lire('LISEZ-MOI.txt').toString('utf8')), 'utf8'), fs.statSync(path.join(parametres.RACINE, 'LISEZ-MOI.txt')).mtime);
  }
  // 3. L'appli compilée — sans ses sources (inutiles pour s'en servir), et
  //    avec un config.js et un titre neutres.
  parcourir('public', (r) => !r.startsWith('public/src/') && r !== 'public/config.js' && r !== 'public/index.html');
  ajouter('public/index.html', Buffer.from(personnaliser(lire('public/index.html').toString('utf8')), 'utf8'));
  ajouter('public/config.js', Buffer.from(
    '// ============================================================\n'
    + '//  RÉGIE MOBILE — PERSONNALISATION\n'
    + '// ------------------------------------------------------------\n'
    + '//  Pseudo par défaut, choisi à la préparation du kit. Pour le\n'
    + '//  changer : dans la régie, Réglages → Ton pseudo (rien à faire ici).\n'
    + '// ============================================================\n'
    + 'window.REGIE_CONFIG = {\n'
    + '  pseudo: ' + JSON.stringify(kit.pseudo || '') + ',\n'
    + '};\n', 'utf8'));
  // 4. Le modèle de l'image d'annonce et son fond.
  //    (Plus aucun overlay : un ancien dossier overlay/ resté sur ton PC
  //    ne part pas dans le kit.)
  ajouterFichier(path.join('reel', 'template.html'), false);
  ajouterFichier(path.join('reel', 'backgrounds', 'default.jpg'), false);
  // 5. Le kit lui-même.
  //    « recuDansUnKit » : la régie de la personne sait qu'elle vient d'un
  //    kit (Instagram : image seulement, voir dansUnKit). « raidCabane » :
  //    la case de la page /kit (voir raidCabaneActif).
  ajouter('kit.json', Buffer.from(JSON.stringify({ twitchClientId: kit.twitchClientId, contact: kit.contact, pseudo: kit.pseudo, recuDansUnKit: true, raidCabane: kit.raidCabane }, null, 2) + '\n', 'utf8'));

  // Ceinture et bretelles : rien de sensible, quoi qu'il arrive au code
  // ci-dessus un jour (voir JAMAIS_DANS_UN_ZIP).
  const interdit = entrees.find((e) => JAMAIS_DANS_UN_ZIP.test(e.nom));
  if (interdit) throw new Error('Refusé : ' + interdit.nom + ' ne doit jamais partir dans un kit.');

  const zip = await creerZip(entrees);
  const suffixe = (kit.pseudo || '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^A-Za-z0-9_-]+/g, '').slice(0, 30);
  return { ...zip, nom: 'Regie mobile' + (suffixe ? ' - ' + suffixe : '') + '.zip', avecNode: !!node, avecWkhtml: !!(wk && !wk.refus) };
}
