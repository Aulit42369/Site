// ============================================================
//  Page /kit : préparer la régie pour quelqu'un d'autre
// ============================================================
'use strict';
(function () {
  const { $, json, envoyer, lampe } = window.Guide;

  function afficherComposants(d) {
    if (d.node) {
      lampe($('#l-node'), 'ok');
      $('#t-node').textContent = 'Node sera inclus' + (d.node.version ? ' (' + d.node.version + ')' : '') + ', pris dans ' + d.node.origine + '.';
    } else {
      lampe($('#l-node'), 'attention');
      $('#t-node').textContent = 'Node ne sera pas inclus : la personne devra l’installer elle-même (nodejs.org). Prépare le kit depuis un PC Windows où la régie tourne.';
    }
    if (d.wkhtml) {
      lampe($('#l-wk'), 'ok');
      $('#t-wk').textContent = 'L’outil des images d’annonce sera inclus' + (d.wkhtml.version ? ' (wkhtmltoimage ' + d.wkhtml.version + ')' : '') + ', pris dans ' + d.wkhtml.origine + '.';
    } else {
      lampe($('#l-wk'), 'attention');
      $('#t-wk').textContent = d.wkhtmlRefus
        || 'wkhtmltoimage n’est pas installé sur ce PC : sans lui, la personne devra l’installer pour les images d’annonce (wkhtmltopdf.org).';
    }
    if (d.lanceur) {
      lampe($('#l-exe'), 'ok');
      $('#t-exe').textContent = 'Le lanceur Regie mobile.exe sera inclus.';
    } else {
      lampe($('#l-exe'), 'attention');
      $('#t-exe').textContent = 'Regie mobile.exe est absent de ton dossier : la personne devra lancer start.bat.';
    }
  }

  async function charger() {
    const d = await json('/api/kit').catch(() => null);
    if (!d || !d.ok) {
      $('#retour').textContent = (d && d.error) || 'La régie ne répond pas.';
      return;
    }
    $('#pseudo').value = d.kit.pseudo || '';
    $('#clientId').value = d.kit.twitchClientId || '';
    $('#contact').value = d.kit.contact || '';
    $('#raidCabane').checked = d.kit.raidCabane === true;
    afficherComposants(d);
  }

  $('#formulaire').addEventListener('submit', async (e) => {
    e.preventDefault();
    const retour = $('#retour');
    retour.style.color = '';
    const pseudo = $('#pseudo').value.trim();
    const clientId = $('#clientId').value.trim();
    // Le pseudo est facultatif : la personne le choisit elle-même, à la fin
    // de l'assistant ou dans Réglages → Ton pseudo.
    if (clientId && !/^[a-z0-9]{10,64}$/i.test(clientId)) {
      retour.style.color = 'var(--ambre)';
      retour.textContent = 'Ce Client ID ne ressemble pas à un Client ID Twitch : lettres et chiffres uniquement, une trentaine.';
      $('#clientId').focus();
      return;
    }
    const bouton = $('#fabriquer');
    bouton.disabled = true;
    retour.textContent = 'Enregistrement…';
    const r = await envoyer('/api/kit', { pseudo, twitchClientId: clientId, contact: $('#contact').value.trim(), raidCabane: $('#raidCabane').checked }).catch(() => null);
    if (!r || !r.ok) {
      bouton.disabled = false;
      retour.style.color = 'var(--rouge)';
      retour.textContent = (r && r.error) || 'La régie ne répond pas.';
      return;
    }
    afficherComposants(r);
    retour.style.color = 'var(--vert)';
    // Avec Node et l'outil d'images, le zip dépasse ce que Discord et la
    // plupart des mails acceptent.
    const envoi = (r.node || r.wkhtml)
      ? ' Il pèse plusieurs dizaines de Mo (les outils sont dedans) : pour le lui envoyer, passe par Google Drive, WeTransfer ou une clé USB, pas par Discord ni par mail.'
      : '';
    retour.textContent = (clientId
      ? 'Kit en préparation, le téléchargement démarre dans quelques secondes.'
      : 'Kit en préparation. Sans Client ID, la personne reliera Twitch avec l’ancienne méthode (plus compliquée).') + envoi;
    // Le navigateur télécharge le zip sans quitter la page.
    const lien = document.createElement('a');
    lien.href = '/kit.zip';
    lien.download = '';
    document.body.appendChild(lien);
    lien.click();
    lien.remove();
    setTimeout(() => { bouton.disabled = false; }, 4000);
  });

  // ---------- Publier une mise à jour (régie d'Olivier seulement) ----------
  async function chargerPublication() {
    const d = await json('/api/maj/publier').catch(() => null);
    if (!d || !d.ok || !d.peutPublier) return;
    $('#publication').hidden = false;
    $('#maj-actuelle').textContent = 'Version actuelle : ' + d.actuelle + '.';
    $('#maj-version').value = d.suivante;
    $('#maj-apk-champ').hidden = !d.apkPresente;
    if (!d.cle) {
      $('#retour-maj').style.color = 'var(--ambre)';
      $('#retour-maj').textContent = 'Pas encore de clé de signature : voir README, « Publier une mise à jour », étape 1.';
    }
  }

  $('#publication').addEventListener('submit', async (e) => {
    e.preventDefault();
    const retour = $('#retour-maj');
    const bouton = $('#publier');
    bouton.disabled = true;
    retour.style.color = '';
    retour.textContent = 'Fabrication et signature…';
    const r = await envoyer('/api/maj/publier', { version: $('#maj-version').value.trim(), notes: $('#maj-notes').value, apkVersionCode: $('#maj-apk').value.trim() }).catch(() => null);
    bouton.disabled = false;
    if (!r || !r.ok) {
      retour.style.color = 'var(--rouge)';
      retour.textContent = (r && r.error) || 'La régie ne répond pas.';
      return;
    }
    retour.style.color = 'var(--vert)';
    retour.textContent = 'Version ' + r.version + ' prête dans ' + r.dossier + ' (' + r.fichiers.join(' et ') + ').'
      + ' Dernière étape : GitHub Desktop → dépôt Site → Commit → Push origin. Les régies la verront dans les 24 h (ou avec « Rechercher une mise à jour »).';
    $('#maj-actuelle').textContent = 'Version actuelle : ' + r.version + '.';
  });

  charger();
  chargerPublication();
})();
