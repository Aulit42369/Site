// ============================================================
//  La page /setup (sur le PC)
// ------------------------------------------------------------
//  YouTube, Instagram et TikTok se relient depuis cette page.
//  Dans une régie reçue en kit, sans Instagram (voir sansInstagram).
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  sansInstagram,
  get SETUP_HTML() { return SETUP_HTML; },
};

const parametres = require('./parametres.js');

const SETUP_HTML = `<!DOCTYPE html>
<html lang="fr"><head><meta charset="UTF-8"><title>RÉGIE MOBILE — Publication</title>
<style>
  body{font-family:system-ui,sans-serif;background:#0a0e14;color:#e8ecf1;max-width:560px;margin:40px auto;padding:0 20px;}
  h1{font-size:20px;} h2{font-size:15px;color:#8b95a7;margin-top:36px;}
  p.hint{color:#8b95a7;font-size:13px;line-height:1.6;}
  .aide{background:#10141d;border:1px solid #2a3140;border-radius:10px;padding:13px 15px;margin:10px 0 4px;}
  .aide .etapes{font-size:13px;line-height:1.7;color:#c3cad6;}
  .aide .etapes em{color:#8b95a7;font-size:12px;font-style:normal;display:block;margin-top:6px;}
  .aide .etapes .en{color:#8b95a7;font-style:italic;}
  .aide a{color:#22d3ee;}
  .uri{margin-top:11px;padding-top:11px;border-top:1px solid #2a3140;display:flex;align-items:center;gap:9px;flex-wrap:wrap;}
  .uri-lib{font-size:12px;color:#8b95a7;width:100%;}
  .uri code{flex:1;min-width:0;background:#060910;border:1px solid #2a3140;border-radius:7px;padding:9px 11px;font-size:13px;color:#22d3ee;word-break:break-all;}
  .uri .copier{margin:0;padding:9px 14px;background:#161c27;color:#e8ecf1;border:1px solid #2a3140;font-size:13px;flex-shrink:0;}
  .uri .uri-ligne{display:flex;align-items:center;gap:9px;width:100%;}
  label{font-size:12px;color:#8b95a7;display:block;margin-top:10px;}
  input{width:100%;padding:10px;margin:4px 0 4px;background:#161c27;border:1px solid #2a3140;border-radius:8px;color:#fff;box-sizing:border-box;font-size:14px;}
  button,a.btn{display:inline-block;padding:10px 18px;margin-top:14px;background:#34d399;color:#04120c;border:none;border-radius:8px;font-weight:600;text-decoration:none;cursor:pointer;font-size:14px;}
  .status{padding:10px 14px;border-radius:8px;margin:10px 0;font-size:14px;}
  .ok{background:#0f2a1d;color:#34d399;} .off{background:#241010;color:#f87171;}
  .etiquette{font-size:11px;font-weight:600;color:#0a0e14;background:#8b95a7;border-radius:99px;padding:3px 9px;vertical-align:middle;margin-left:7px;text-transform:uppercase;letter-spacing:.04em;}
  .avertissement{background:#1c1507;border:1px solid #4a3a12;border-radius:10px;padding:14px 16px;margin:10px 0 4px;}
  .avertissement strong{color:#fbbf24;}
  .avertissement p{font-size:13px;line-height:1.65;color:#c3cad6;margin:9px 0 0;}
  .avertissement .devoiler{margin-top:13px;padding:8px 14px;background:#161c27;color:#8b95a7;border:1px solid #2a3140;font-size:12.5px;font-weight:500;}
</style></head><body>
<h1>RÉGIE MOBILE — Publication des clips</h1>
<p class="hint">Cette page se configure une seule fois, ici sur ce PC — pas sur le téléphone. Elle sert à connecter tes comptes de publication (YouTube, etc.).</p>

<h2>YouTube</h2>
<div id="yt-status" class="status off">Chargement…</div>
<div id="yt-form">
<div class="aide">
  <div class="etapes">1. Va sur <a href="https://console.cloud.google.com/apis/credentials" target="_blank">console.cloud.google.com</a> → Créer des identifiants → ID client OAuth → Application Web.<br>2. Colle l'adresse ci-dessous dans « URI de redirection autorisés ». Sans elle, Google refusera la connexion.<br>3. Recopie ici l'ID client et le code secret obtenus.</div>
  <div class="uri">
    <span class="uri-lib">Adresse de redirection à déclarer :</span>
    <code id="uri-yt">http://127.0.0.1:${parametres.PORT}/oauth/youtube/callback</code>
    <button type="button" class="copier" onclick="copier('uri-yt', this)">Copier</button>
  </div>
</div>
  <label>Client ID (Google Cloud Console)</label>
  <input id="yt-client-id" placeholder="xxxx.apps.googleusercontent.com">
  <label>Client Secret</label>
  <input id="yt-client-secret" placeholder="GOCSPX-...">
  <button onclick="saveYt()">Enregistrer puis connecter YouTube</button>
</div>

<!--instagram-->
<h2>Instagram</h2>
<div id="ig-status" class="status off">Chargement…</div>
<p class="hint">Nécessite un compte Instagram Créateur ou Business (pas un compte personnel classique).</p>
<div id="ig-form">
<div class="aide">
  <div class="etapes">1. Va sur <a href="https://developers.facebook.com/apps" target="_blank">developers.facebook.com</a> → Créer une application → produit « Instagram », configuration « API avec connexion Instagram » (en anglais : <span class="en">API setup with Instagram login</span>).<br>2. Dans « Autorisations et fonctionnalités », vérifie que <strong>instagram_business_content_publish</strong> est ajoutée (c'est elle qui permet de publier).<br>3. Dans le bloc « Configurez la connexion professionnelle Instagram », bouton « Paramètres de connexion professionnelle » (<span class="en">Business login settings</span>) : colle <strong>les deux adresses</strong> ci-dessous (avec et sans « / » final) dans les URI de redirection OAuth, puis enregistre. Attends ensuite quelques minutes avant de te connecter : Meta met un moment à prendre un changement en compte. Si la page d'Instagram affiche une erreur d'adresse de redirection, une des deux n'est pas déclarée exactement ainsi.<br>4. Dans « Générer des tokens d'accès », ajoute ton compte Instagram, puis accepte l'invitation dans Instagram (Paramètres → Applications et sites web → Invitations de testeur). Sans ça : « Insufficient developer role ».<br>5. Recopie ici l'<strong>ID de l'app Instagram</strong> et la <strong>clé secrète de l'app Instagram</strong>, affichés en haut de cette même page — <strong>pas</strong> l'ID de l'app Meta du tableau de bord (sinon : « Invalid platform app »).<br><em>Au retour, le navigateur affichera un avertissement de sécurité sur cette adresse : c'est normal, le certificat est fabriqué par le pont et ne sort pas de ce PC. Clique « Paramètres avancés » puis « Continuer ».</em></div>
  <div class="uri">
    <span class="uri-lib">Adresses de redirection à déclarer (les deux) :</span>
    <div class="uri-ligne">
      <code id="uri-ig">https://localhost:${parametres.HTTPS_PORT}/oauth/instagram/callback/</code>
      <button type="button" class="copier" onclick="copier('uri-ig', this)">Copier</button>
    </div>
    <div class="uri-ligne">
      <code id="uri-ig-sans">https://localhost:${parametres.HTTPS_PORT}/oauth/instagram/callback</code>
      <button type="button" class="copier" onclick="copier('uri-ig-sans', this)">Copier</button>
    </div>
  </div>
</div>
  <label>ID de l'app Instagram (Instagram app ID — pas l'ID de l'app Meta)</label>
  <input id="ig-app-id" placeholder="1234567890123456">
  <label>Clé secrète de l'app Instagram (Instagram app secret)</label>
  <input id="ig-app-secret" placeholder="a1b2c3d4e5f6...">
  <button onclick="saveIg()">Enregistrer puis connecter Instagram</button>
</div>
<!--/instagram-->

<h2>Texte des clips publiés</h2>
<p class="hint">Chaque clip publié (description YouTube, légende Instagram) porte son titre, ta chaîne Twitch, ces liens s'ils sont remplis, et les hashtags #Twitch #Clip + le jeu. Un lien laissé vide = sa ligne n'apparaît pas.</p>
<label for="lien-planning">Lien du planning (facultatif)</label>
<input id="lien-planning" placeholder="monsite.github.io/planning.html">
<label for="lien-discord">Lien Discord (facultatif)</label>
<input id="lien-discord" placeholder="discord.gg/tonserveur">
<button onclick="saveLiens()">Enregistrer les liens</button>
<div id="liens-status" role="status"></div>

<h2>TikTok <span class="etiquette">rien à faire ici</span></h2>
<div class="avertissement">
  <strong>Ne perds pas de temps avec cette section.</strong>
  <p>Publier sur TikTok automatiquement demande une autorisation que TikTok
  réserve aux entreprises auditées : un outil personnel comme celui-ci en est
  explicitement exclu par leurs propres règles. Essayé, vérifié — même avec une
  Client Key et un Client Secret parfaitement valides, TikTok refuse l'envoi.</p>
  <p><strong>Pour publier un clip sur TikTok</strong>, l'appli a un bouton
  « TikTok » sur chaque clip (onglet Chaîne) qui fait le trajet en quelques
  taps, sans rien à configurer. C'est la bonne méthode, et la seule qui marche
  aujourd'hui.</p>
  <p>Le formulaire ci-dessous ne sert qu'au jour où TikTok assouplirait cette
  règle. Le remplir maintenant ne débloquera rien.</p>
  <button type="button" class="devoiler" onclick="montrerTt()">Afficher quand même le formulaire</button>
</div>
<div id="tt-bloc" style="display:none">
<div id="tt-status" class="status off">Chargement…</div>
<div id="tt-form">
<div class="aide">
  <div class="etapes">1. Va sur <a href="https://developers.tiktok.com/apps" target="_blank">developers.tiktok.com</a> → Manage apps → crée une application de type <strong>Desktop</strong>.<br>2. Ajoute le produit « Content Posting API » et colle l'adresse ci-dessous dans les URI de redirection.<br>3. Recopie ici la Client Key et le Client Secret.<br><em>Rappel : même correctement rempli, l'envoi sera refusé par TikTok tant que la restriction ci-dessus est en place.</em></div>
  <div class="uri">
    <span class="uri-lib">Adresse de redirection à déclarer :</span>
    <code id="uri-tt">http://127.0.0.1:${parametres.PORT}/oauth/tiktok/callback</code>
    <button type="button" class="copier" onclick="copier('uri-tt', this)">Copier</button>
  </div>
</div>
  <label>Client Key (TikTok for Developers)</label>
  <input id="tt-client-key" placeholder="sbaw0y8...">
  <label>Client Secret</label>
  <input id="tt-client-secret" placeholder="a1b2c3d4e5f6...">
  <button onclick="saveTt()">Enregistrer puis connecter TikTok</button>
</div>
</div>

<script>
function copier(id, bouton) {
  var t = document.getElementById(id).textContent;
  navigator.clipboard.writeText(t).then(function () {
    var avant = bouton.textContent;
    bouton.textContent = 'Copié';
    setTimeout(function () { bouton.textContent = avant; }, 1500);
  });
}
function montrerTt() {
  document.getElementById('tt-bloc').style.display = 'block';
  document.querySelector('.avertissement .devoiler').style.display = 'none';
}
function loadStatus() {
  fetch('/api/setup/status').then(function(r){return r.json();}).then(function(d){
    var el = document.getElementById('yt-status');
    if (d.youtube) { el.className = 'status ok'; el.textContent = '✓ YouTube connecté'; }
    else { el.className = 'status off'; el.textContent = 'YouTube non connecté'; }
    if (d.youtubeClientId) document.getElementById('yt-client-id').value = d.youtubeClientId;
    if (d.youtubeClientSecret) document.getElementById('yt-client-secret').value = d.youtubeClientSecret;

    // Absente dans une régie reçue en kit (voir sansInstagram).
    var elIg = document.getElementById('ig-status');
    if (elIg) {
      if (d.instagram) { elIg.className = 'status ok'; elIg.textContent = '✓ Instagram connecté'; }
      else { elIg.className = 'status off'; elIg.textContent = 'Instagram non connecté'; }
      if (d.instagramAppId) document.getElementById('ig-app-id').value = d.instagramAppId;
      if (d.instagramAppSecret) document.getElementById('ig-app-secret').value = d.instagramAppSecret;
    }

    var elTt = document.getElementById('tt-status');
    if (d.tiktok) { elTt.className = 'status ok'; elTt.textContent = '✓ TikTok connecté'; }
    else { elTt.className = 'status off'; elTt.textContent = 'TikTok non connecté'; }
    if (d.tiktokClientKey) document.getElementById('tt-client-key').value = d.tiktokClientKey;
    if (d.liensClips) {
      document.getElementById('lien-planning').value = d.liensClips.planning || '';
      document.getElementById('lien-discord').value = d.liensClips.discord || '';
    }
    if (d.tiktokClientSecret) document.getElementById('tt-client-secret').value = d.tiktokClientSecret;
  });
}
function saveYt() {
  var clientId = document.getElementById('yt-client-id').value.trim();
  var clientSecret = document.getElementById('yt-client-secret').value.trim();
  if (!clientId || !clientSecret) { alert('Renseigne le Client ID et le Client Secret.'); return; }
  fetch('/api/setup/youtube/credentials', {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ clientId: clientId, clientSecret: clientSecret })
  }).then(function(){ window.location.href = '/oauth/youtube/start'; });
}
function saveIg() {
  var appId = document.getElementById('ig-app-id').value.trim();
  var appSecret = document.getElementById('ig-app-secret').value.trim();
  if (!appId || !appSecret) { alert("Renseigne l'App ID et l'App Secret."); return; }
  fetch('/api/setup/instagram/credentials', {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ appId: appId, appSecret: appSecret })
  }).then(function(){ window.location.href = 'https://localhost:${parametres.HTTPS_PORT}/oauth/instagram/start'; });
}
function saveLiens() {
  var el = document.getElementById('liens-status');
  fetch('/api/setup/liens-clips', {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ planning: document.getElementById('lien-planning').value, discord: document.getElementById('lien-discord').value })
  }).then(function(r){ return r.json(); }).then(function(d){
    el.className = 'status ' + (d.ok ? 'ok' : 'off');
    el.textContent = d.ok ? '✓ Liens enregistrés' : (d.error || 'Enregistrement impossible.');
    if (d.ok) { document.getElementById('lien-planning').value = d.liensClips.planning; document.getElementById('lien-discord').value = d.liensClips.discord; }
  }).catch(function(){ el.className = 'status off'; el.textContent = 'Le pont ne répond pas.'; });
}
function saveTt() {
  var clientKey = document.getElementById('tt-client-key').value.trim();
  var clientSecret = document.getElementById('tt-client-secret').value.trim();
  if (!clientKey || !clientSecret) { alert('Renseigne le Client Key et le Client Secret.'); return; }
  fetch('/api/setup/tiktok/credentials', {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ clientKey: clientKey, clientSecret: clientSecret })
  }).then(function(){ window.location.href = '/oauth/tiktok/start'; });
}
loadStatus();
</script>
</body></html>`;

// La page d'une régie reçue en kit : Instagram n'y sert qu'à fabriquer
// l'image, elle ne propose donc pas de le relier. Un paragraphe le dit à la
// place de la section.
function sansInstagram(html) {
  return html.replace(/<!--instagram-->[\s\S]*?<!--\/instagram-->/,
    '<h2>Instagram</h2>\n<p class="hint">Dans cette régie, Instagram ne se relie pas : l’onglet Annonce fabrique l’image, tu l’enregistres (ou tu la partages) puis tu la publies toi-même sur Instagram.</p>\n');
}
