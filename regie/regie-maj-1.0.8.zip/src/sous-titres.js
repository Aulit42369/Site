// ============================================================
//  Sous-titres incrustés des clips (YouTube, Instagram)
// ------------------------------------------------------------
//  Le travail est fait par outils/sous-titrer.py (transcription
//  locale FR/EN + ffmpeg) ; ici : savoir s'il est installé, le
//  lancer, et dire clairement pourquoi il a échoué. Un échec
//  bloque la publication : jamais de clip publié sans prévenir,
//  jamais de sous-titres inventés.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  demarrer,
  idYoutube,
  sousTitrer,
  verifier,
};

const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFile } = require('child_process');
const parametres = require('./parametres.js');
const etatRegie = require('./etat-regie.js');

// L'interpréteur et l'outil, réglables (.env, contrôles de verifier.sh).
const PYTHON = () => process.env.REGIE_PYTHON || 'python';
const OUTIL = () => process.env.REGIE_SOUS_TITRER || path.join(parametres.RACINE, 'outils', 'sous-titrer.py');
// Un clip de 60 s : ~1 min de transcription + l'encodage. 15 min = l'outil est bloqué.
const DELAI_MS = 15 * 60 * 1000;

function lancer(args, delai) {
  return new Promise((ok) => {
    execFile(PYTHON(), [OUTIL(), ...args], { timeout: delai, windowsHide: true, maxBuffer: 4 * 1024 * 1024 }, (err, stdout, stderr) => {
      ok({ err, stdout: String(stdout || ''), stderr: String(stderr || '') });
    });
  });
}

// État affiché par l'appli : { disponible, raison }. Pas installé (Python,
// l'outil ou un module absent, chez un autre streamer) → option grisée.
async function verifier() {
  let etat;
  if (!fs.existsSync(OUTIL())) etat = { disponible: false, raison: 'L’outil de sous-titres n’est pas installé sur ce PC.' };
  else {
    const r = await lancer(['--verifier'], 60000);
    let rep = null;
    try { rep = JSON.parse(r.stdout.trim().split('\n').pop()); } catch (e) { /* réponse illisible : voir plus bas */ }
    if (rep && rep.ok) etat = { disponible: true, raison: '' };
    else if (rep) etat = { disponible: false, raison: 'Sous-titres indisponibles : ' + rep.raison + '.' };
    else etat = { disponible: false, raison: 'Sous-titres indisponibles : Python ne répond pas (' + (r.err ? r.err.code || r.err.message : 'réponse vide') + ').' };
  }
  etatRegie.setState({ sousTitres: etat });
  return etat;
}

function demarrer() {
  verifier().catch((e) => console.warn('[sous-titres] Vérification impossible :', e.message));
}

// La vidéo → { video: la même, sous-titres incrustés (Buffer), srt: le texte
// des sous-titres ('' si l'outil ne l'a pas laissé), pour le titre du clip
// (src/legende-clip.js) }. Lève une erreur au message lisible.
async function sousTitrer(video) {
  const dossier = fs.mkdtempSync(path.join(os.tmpdir(), 'regie-sous-titres-'));
  try {
    const entree = path.join(dossier, 'clip.mp4');
    const sortie = path.join(dossier, 'clip-sous-titre.mp4');
    fs.writeFileSync(entree, video);
    const r = await lancer([entree, sortie], DELAI_MS);
    if (r.err) {
      const raison = r.err.killed ? 'l’outil n’a pas fini en 15 minutes' : (r.stderr.trim().split('\n').pop() || r.err.message);
      // Peut-être désinstallé depuis le démarrage : l'appli grise l'option.
      verifier().catch(() => {});
      throw new Error('Sous-titres impossibles (' + raison + '). Rien n’a été publié.');
    }
    let srt = '';
    try { srt = fs.readFileSync(sortie + '.srt', 'utf8'); } catch (e) { /* ancien outil : titre sans les sous-titres */ }
    return { video: fs.readFileSync(sortie), srt };
  } finally {
    fs.rmSync(dossier, { recursive: true, force: true });
  }
}

// L'identifiant d'une vidéo YouTube d'après son lien (watch?v=, youtu.be/,
// shorts/) ; '' si ce n'est pas un lien YouTube.
function idYoutube(lien) {
  let u;
  try { u = new URL(String(lien || '')); } catch (e) { return ''; }
  if (!/^(www\.|m\.)?(youtube\.com|youtu\.be)$/.test(u.hostname)) return '';
  const id = u.hostname.endsWith('youtu.be') ? u.pathname.slice(1) : (u.searchParams.get('v') || (u.pathname.match(/^\/shorts\/([^/]+)/) || [])[1] || '');
  return /^[\w-]{6,20}$/.test(id) ? id : '';
}
