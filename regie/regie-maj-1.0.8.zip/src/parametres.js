// ============================================================
//  Paramètres techniques du pont
// ------------------------------------------------------------
//  Le port, les dossiers, et les adresses des services en ligne.
//  Tout ce qui se règle de l’extérieur (variables d’environnement,
//  fichier .env) est lu ici : voir .env.example.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  demarrer,
  get BILAN_DELAI_MS() { return BILAN_DELAI_MS; },
  get BILAN_DUREE_MIN_MS() { return BILAN_DUREE_MIN_MS; },
  get BILAN_RETARD_MAX_MS() { return BILAN_RETARD_MAX_MS; },
  get BLUESKY_SERVICE() { return BLUESKY_SERVICE; },
  get CABANE_CACHE_MS() { return CABANE_CACHE_MS; },
  get CABANE_MEMBRES() { return CABANE_MEMBRES; },
  get DATA_DIR() { return DATA_DIR; },
  get DISCORD_BASE() { return DISCORD_BASE; },
  get GUIDE_DIR() { return GUIDE_DIR; },
  get HTTPS_PORT() { return HTTPS_PORT; },
  get IG_API() { return IG_API; },
  get IG_GRAPH() { return IG_GRAPH; },
  get LANCE_PAR_EXE() { return LANCE_PAR_EXE; },
  get MAJ_DOSSIER_PUBLICATION() { return MAJ_DOSSIER_PUBLICATION; },
  get MAJ_ENVOI() { return MAJ_ENVOI; },
  get MAJ_PREMIER_DELAI_MS() { return MAJ_PREMIER_DELAI_MS; },
  get MAJ_URL() { return MAJ_URL; },
  get MAJ_URL_SECOURS() { return MAJ_URL_SECOURS; },
  get MAJ_VERIFIER() { return MAJ_VERIFIER; },
  get PONT_ALERTES() { return PONT_ALERTES; },
  get PORT() { return PORT; },
  get PUBLIC_DIR() { return PUBLIC_DIR; },
  get RACINE() { return RACINE; },
  get SANTE_INTERVALLE() { return SANTE_INTERVALLE; },
  get SANTE_RELEVES_AVANT_ALERTE() { return SANTE_RELEVES_AVANT_ALERTE; },
  get TWITCH_API() { return TWITCH_API; },
  get TWITCH_ID() { return TWITCH_ID; },
  get TWITCH_WS_URL() { return TWITCH_WS_URL; },
};

const path = require('path');

// ---------- Le dossier, le port ----------

// Le dossier de la régie (celui de server.js), et non src/.
const RACINE = path.join(__dirname, '..');

// Réglages avancés, facultatifs : le fichier .env (modèle : .env.example).
// Lu avant tout le reste : le port, les noms et les pages autorisés en
// dépendent. Une variable déjà définie (lanceur, contrôles) garde sa valeur.
const reglagesEnv = require('./env.js').chargerEnv(path.join(RACINE, '.env'));

// Le port : la variable PORT (lanceur, contrôles, .env), sinon 4560. Une
// valeur qui n'est pas un numéro de port est ignorée, avec la même règle que
// le lanceur (env.portDe) : sinon Node écouterait sur un « canal nommé » et
// rien ne marcherait. Lancé par Regie mobile.exe, le pont reçoit de toute
// façon le port que le lanceur a choisi.
const PORT_INVALIDE = process.env.PORT !== undefined && process.env.PORT !== '' && !require('./env.js').portDe(process.env.PORT);
const PORT = require('./env.js').portDe(process.env.PORT) || 4560;
const HTTPS_PORT = PORT + 1;

const PUBLIC_DIR = path.join(RACINE, 'public');
// Les pages d'installation (QR code, téléphone, Mon installation, kit) :
// du HTML simple, sans React. Volontairement indépendantes de l'appli
// compilée : si l'appli ne s'affiche plus, la page « Mon installation »
// doit, elle, continuer de marcher — c'est elle qui sert à dépanner.
const GUIDE_DIR = path.join(PUBLIC_DIR, 'guide');

// data/ : tout ce qui s'accumule au fil des streams. Volontairement séparé
// de tokens.json : ce dernier contient les accès (petit, critique, jamais
// partagé), tandis que data/ grossit et peut être copié ou archivé sans
// risque. Créé à la volée : une installation neuve n'a rien à préparer.
const DATA_DIR = path.join(RACINE, 'data');

// Lancé par « Regie mobile.exe » ? Le lanceur ouvre alors lui-même la
// fenêtre de la régie ; le pont ne doit pas ouvrir un navigateur en plus.
const LANCE_PAR_EXE = process.env.REGIE_LANCEUR === '1';

// ---------- Les services en ligne ----------
// Chaque adresse est remplaçable par une variable d'environnement : le
// script de vérification (verifier.sh) branche ainsi le pont sur de faux
// services locaux, et contrôle toute la chaîne (connexion, réception,
// journal, bilan, notifications, refus) sans toucher à un vrai compte ni
// dépendre d'internet. En usage normal, ne rien définir : les valeurs
// ci-dessous sont celles des vrais services.

// Twitch : identification (codes, jetons), API, événements en direct.
const TWITCH_ID = process.env.REGIE_TWITCH_ID || 'https://id.twitch.tv';
const TWITCH_API = process.env.REGIE_TWITCH_API || 'https://api.twitch.tv';
const TWITCH_WS_URL = process.env.REGIE_TWITCH_WS || 'wss://eventsub.wss.twitch.tv/ws';
const DISCORD_BASE = process.env.REGIE_DISCORD_BASE || 'https://discord.com';
const BLUESKY_SERVICE = process.env.REGIE_BLUESKY_API || 'https://bsky.social';
const IG_API = process.env.REGIE_INSTAGRAM_API || 'https://api.instagram.com';
const IG_GRAPH = process.env.REGIE_INSTAGRAM_GRAPH || 'https://graph.instagram.com';
// Le pont d'alertes (Script OBS, twitch-alerts-bridge), sur ce PC : « Tester
// une alerte » l'appelle d'ici, jamais depuis le navigateur.
const PONT_ALERTES = (process.env.REGIE_PONT_ALERTES || 'http://127.0.0.1:3940').replace(/\/+$/, '');
// La Cabane (communauté d'Olivier) : la liste publique de ses membres, pour
// les suggestions de raid de fin de live (src/raid-cabane.js).
const CABANE_MEMBRES = process.env.REGIE_CABANE_MEMBRES || 'https://lacabanestreamers.github.io/vitrine/membres.json';

// Mise à jour signée (src/maj.js) : où la régie regarde s'il y a une
// nouvelle version, si elle regarde, et où la régie d'Olivier publie.
// Le Site est servi par le serveur d'Olivier depuis le 05/11/2026 (version 1.0.7).
const MAJ_URL = process.env.REGIE_MAJ_URL || 'https://aulit42369.fr/Site/regie/version.json';
// Repli si MAJ_URL ne répond pas : l'ancienne adresse github.io, le temps que
// la copie GitHub du Site existe. Seulement avec l'adresse par défaut (une
// adresse réglée à la main, comme celle des contrôles, n'a pas de repli).
// La signature est vérifiée pareil, quelle que soit l'adresse lue.
const MAJ_URL_SECOURS = process.env.REGIE_MAJ_URL_SECOURS !== undefined ? process.env.REGIE_MAJ_URL_SECOURS
  : (process.env.REGIE_MAJ_URL ? '' : 'https://aulit42369.github.io/Site/regie/version.json');
const MAJ_VERIFIER = process.env.REGIE_MAJ_VERIFIER !== '0';
const MAJ_DOSSIER_PUBLICATION = process.env.REGIE_MAJ_DOSSIER_PUBLICATION || 'F:/GITHUB/Site/regie';
// Après « Publier », pousser ce dossier (git push : serveur + copie GitHub). 0 : non.
const MAJ_ENVOI = process.env.REGIE_MAJ_ENVOI !== '0';

// ---------- Les délais ----------
// Réglables seulement pour que le script de vérification n'ait pas à
// patienter : ne rien définir en usage normal.

// Bilan de fin de stream : publié trois minutes après la fin (une reprise
// dans ce délai continue le même stream), seulement après un stream d'au
// moins un quart d'heure.
const BILAN_DELAI_MS = Number(process.env.REGIE_BILAN_DELAI_MS) || 3 * 60 * 1000;
const BILAN_DUREE_MIN_MS = Number(process.env.REGIE_BILAN_DUREE_MIN_MS) || 15 * 60 * 1000;
// Une fin de stream que personne n'a vue, constatée plus d'une heure après :
// pas de bilan sur Discord (il arriverait bien après le stream), seulement
// l'historique de comparaison.
const BILAN_RETARD_MAX_MS = Number(process.env.REGIE_BILAN_RETARD_MAX_MS) || 60 * 60 * 1000;
// Santé du direct : un relevé toutes les 10 s, alerte après ~30 s de
// dégradation continue.
const SANTE_INTERVALLE = Number(process.env.REGIE_SANTE_INTERVALLE) || 10000;
const SANTE_RELEVES_AVANT_ALERTE = Number(process.env.REGIE_SANTE_RELEVES) || 3;
// Liste des membres de La Cabane : relue au plus une fois par minute.
const CABANE_CACHE_MS = Number(process.env.REGIE_CABANE_CACHE_MS) || 60 * 1000;
// Première vérification de mise à jour : 30 s après le démarrage.
const MAJ_PREMIER_DELAI_MS = Number(process.env.REGIE_MAJ_PREMIER_DELAI_MS) || 30 * 1000;


// Lancé une fois, au démarrage du pont, dans l’ordre fixé par server.js.
function demarrer() {
  // Les noms seulement : une valeur n'a rien à faire dans le journal.
  if (reglagesEnv.appliques.length) console.log('[pont] Réglages lus dans .env : ' + reglagesEnv.appliques.join(', ') + '.');
  if (PORT_INVALIDE) console.warn('[pont] PORT n’est pas un numéro de port (des chiffres, entre 1 et 65534) : la régie prend ' + PORT + '.');
}
