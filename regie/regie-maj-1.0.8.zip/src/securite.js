// ============================================================
//  Qui a le droit de lire et de commander
// ------------------------------------------------------------
//  Les trois barrières : le nom appelé, la page qui appelle, l’appareil
//  (relié ou non). Le PC a tous les droits.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  accesRequete,
  adresseNormalisee,
  appelantDuReseauLocal,
  get appareils() { return appareils; },
  demarrer,
  get ECRITURES_OUVERTES() { return ECRITURES_OUVERTES; },
  estAutreOrigine,
  etatPourRequete,
  hoteAttendu,
  lectureOuverte,
  oublierCeQuiVientDe,
  originAutorisee,
  ouvertATous,
  refuserAppareilInconnu,
  refuserHorsDuPc,
  requeteIntersiteMuette,
  reserveAuPc,
  surCeMemePc,
  vientDuPc,
};

const { isIP, BlockList } = require('net');
const os = require('os');
const { creerAppareils } = require('./appareils.js');

const parametres = require('./parametres.js');
const etatRegie = require('./etat-regie.js');
const outilsHttp = require('./http-outils.js');
const stockage = require('./stockage.js');
const pseudos = require('./pseudos.js');
const notifications = require('./notifications.js');
const annonces = require('./annonces.js');

// ------------------------------------------------------------
// Qui a le droit de lire quoi
// ------------------------------------------------------------
// Trois barrières, passées dans cet ordre par gererRequete :
//
// 1. Le NOM appelé (en-tête Host). La régie ne répond qu'à ses propres
//    noms : localhost, les adresses du PC, son nom sur le réseau. Un site
//    piégé qui ferait pointer son propre domaine vers ce PC (« rebinding
//    DNS ») se présente sous SON nom : refusé avant d'avoir rien lu. Sans
//    cette barrière, une simple lecture « de même origine » de ce site
//    recevait l'état complet, jeton Twitch compris.
//
// 2. L'ORIGINE de la page qui appelle (en-tête Origin). Une page d'une
//    autre origine n'est acceptée que si c'est un overlay : fichier local
//    (origine « null », ou « http://absolute » : c'est sous cette adresse
//    qu'OBS ouvre un overlay chargé en « Fichier local »), page servie par ce
//    PC lui-même (localhost, ses adresses ou son nom, sur n'importe quel
//    port), ou adresse ajoutée dans .env (REGIE_ORIGINES_AUTORISEES). Elle peut alors LIRE l'état et les
//    événements Twitch (LECTURES_OUVERTES) et piloter le minuteur
//    (ECRITURES_OUVERTES) ; rien d'autre.
//    Limite connue : une page piégée peut se faire passer pour un fichier
//    local (iframe « sandbox »). Elle n'obtient alors que ce qu'obtient un
//    overlay : jamais un accès, jamais une commande hors minuteur, et un
//    minuteur qu'elle lance ne joue les actions de fin de pause que si la
//    régie le permet (interrupteur de la carte Minuteur).
//    Une page d'un autre SITE qui charge une adresse de la régie sans se
//    nommer (image, script, cadre : pas d'en-tête Origin) est repérée par
//    l'en-tête Sec-Fetch-Site (voir requeteIntersiteMuette).
//
// 3. L'APPAREIL. Le PC a tous les droits, à condition d'appeler la régie
//    par localhost ou par une adresse IP (voir vientDuPc) : c'est ce que font
//    le lanceur et les liens de la régie. Un autre appareil du Wi-Fi — ou le
//    PC qui passe par un NOM — doit être relié une fois, avec un code affiché
//    sur le PC (src/appareils.js) ; avant ça, il n'atteint que les pages
//    d'installation.

const listeEnv = (nom) => String(process.env[nom] || '').split(',').map((x) => x.trim()).filter(Boolean);
// Le nom tel qu'écrit dans une adresse, ramené à sa forme simple : en
// minuscules, sans point final, sans crochets autour d'une adresse IPv6.
function nomSimple(nom) {
  return String(nom || '').trim().toLowerCase().replace(/\.$/, '').replace(/^\[(.*)\]$/, '$1');
}
// Noms en plus sous lesquels la régie accepte d'être appelée (nom donné par
// un VPN, par exemple). Un nom ajouté ainsi ne donne jamais les droits du
// PC : ce qui passe par lui doit être relié comme un téléphone.
const HOTES_AJOUTES = new Set(listeEnv('REGIE_HOTES_AUTORISES').map(nomSimple));
// Pages d'une autre origine acceptées en plus des overlays locaux : un
// overlay hébergé sur ton site, par exemple (« https://mon-site.fr »).
const ORIGINES_AJOUTEES = new Set(listeEnv('REGIE_ORIGINES_AUTORISEES')
  .map((o) => { try { return new URL(o).origin; } catch (e) { return ''; } })
  .filter((o) => o && o !== 'null'));
// Adresses traitées comme un appareil relié sans l'être : un second PC qui
// affiche un overlay de la régie, typiquement (il ne peut pas taper de code).
const ADRESSES_DE_CONFIANCE = new Set(listeEnv('REGIE_ADRESSES_DE_CONFIANCE').map((a) => adresseNormalisee(a)));

// Les suffixes que les box ajoutent au nom du PC sur le réseau local. Aucun
// n'est un domaine public qu'un inconnu pourrait acheter (« .box », qui
// figurait ici, en est un depuis 2024 : retiré).
const SUFFIXES_LOCAUX = ['', '.local', '.lan', '.home', '.home.arpa', '.localdomain'];
let nomsDuPcEnCache = null;
function nomsDuPc() {
  if (!nomsDuPcEnCache) {
    nomsDuPcEnCache = new Set(['localhost']);
    try {
      const h = nomSimple(os.hostname());
      if (h) for (const s of SUFFIXES_LOCAUX) nomsDuPcEnCache.add(h + s);
    } catch (e) { /* localhost suffit */ }
  }
  return nomsDuPcEnCache;
}

// Vrai si « nom » désigne ce PC : un de ses noms, une de ses adresses.
function nomDuPc(nom) {
  const n = nomSimple(nom);
  if (!n) return false;
  if (nomsDuPc().has(n) || adressesDuPc().has(adresseNormalisee(n))) return true;
  // Une adresse toute neuve (la box vient d'en donner une autre) : on relit
  // les cartes réseau avant de refuser, au plus une fois toutes les 2 s.
  if (/^[0-9a-f:.]+$/.test(n) && Date.now() - cacheAdressesPc.quand > 2000) {
    cacheAdressesPc.quand = 0;
    return adressesDuPc().has(adresseNormalisee(n));
  }
  return false;
}

// Le nom appelé, sans le port : « 192.168.1.20:4560 » → « 192.168.1.20 »,
// « [::1]:4560 » → « ::1 ».
function hoteDeLaRequete(req) {
  const m = /^(\[[^\]]*\]|[^:[\]]*)(?::\d{1,5})?$/.exec(String(req.headers.host || ''));
  return m ? nomSimple(m[1]) : '';
}

function hoteAttendu(req) {
  const n = hoteDeLaRequete(req);
  return !!n && (nomDuPc(n) || HOTES_AJOUTES.has(n));
}

// L'origine qu'annonce un overlay chargé en « Fichier local » dans une source
// navigateur d'OBS : OBS sert le fichier à l'adresse http://absolute/<chemin>.
// (Les contrôles l'avaient d'abord imité par « null », l'origine d'un fichier
// ouvert tel quel : l'overlay d'Olivier s'est retrouvé refusé.)
const ORIGINE_FICHIER_LOCAL_OBS = 'http://absolute';

// Une page d'une autre origine a-t-elle le droit de lire les réponses ?
function origineAcceptee(o) {
  if (o === 'null' || /^file:/i.test(o)) return true; // fichier local ouvert tel quel
  if (o === ORIGINE_FICHIER_LOCAL_OBS) return true; // « Fichier local » d'une source navigateur d'OBS
  let u;
  try { u = new URL(o); } catch (e) { return false; }
  if (u.protocol !== 'http:' && u.protocol !== 'https:') return false;
  return nomDuPc(u.hostname) || HOTES_AJOUTES.has(nomSimple(u.hostname)) || ORIGINES_AJOUTEES.has(u.origin);
}

// L'origine à renvoyer dans Access-Control-Allow-Origin, ou null : sans
// cet en-tête, le navigateur ne montre pas la réponse à la page.
function originAutorisee(req) {
  const o = req.headers.origin;
  if (!o) return null; // même origine ou appel hors navigateur : rien à ajouter
  return origineAcceptee(o) ? o : null;
}

// Vrai si la requête vient d'une page servie par quelqu'un d'autre que le pont.
// Un POST de l'appli elle-même envoie aussi un en-tête Origin : on compare donc
// à l'hôte réellement appelé, au lieu de se contenter de sa présence.
function estAutreOrigine(req) {
  const o = req.headers.origin;
  if (!o) return false;
  if (o === 'null') return true; // page ouverte depuis un fichier
  if (!hoteAttendu(req)) return true; // on n'est pas appelé par un de nos noms
  try { return new URL(o).host !== req.headers.host; } catch (e) { return true; }
}

// Les en-têtes qu'ajoute un relais (tunnel, proxy) : la requête vient alors
// d'ailleurs, même si elle arrive par l'adresse du PC lui-même.
function viaUnRelais(req) {
  const h = req.headers;
  return !!(h['x-forwarded-for'] || h.forwarded || h['x-real-ip'] || h['cf-connecting-ip'] || h['true-client-ip']);
}

// Les appareils reliés (voir appareils.js). La liste est rangée dans
// tokens.json, avec les autres accès : jamais exportée, jamais dans un kit.
const appareils = creerAppareils({
  lire: () => stockage.platformTokens.appareils,
  ecrire: (liste) => {
    stockage.platformTokens.appareils = liste;
    stockage.saveTokens();
    // Les écrans ouverts sur « Appareils reliés » relisent la liste.
    etatRegie.setStatePartiel({ appareilsMaj: Date.now() });
  },
  journal: (message) => console.log('[appareils] ' + message),
  oublies: (ids) => oublierCeQuiVientDe(ids),
});

// Un appareil retiré (à la main, ou oublié après 90 jours sans ouvrir la
// régie) n'a plus rien : ses flux sont coupés, ses notifications et ses
// annonces programmées partent avec lui (ids : les appareils partis ; null :
// tous les appareils reliés).
function oublierCeQuiVientDe(ids) {
  etatRegie.fermerFluxAppareils(ids);
  notifications.oublierAbonnementsDe(ids);
  const annulees = annonces.annulerProgrammationsDe(ids);
  if (annulees) console.log('[pont] ' + annulees + ' annonce(s) programmée(s) depuis l’appareil retiré annulée(s).');
}

// Un appareil qui ne revient plus jamais doit être oublié quand même (sinon
// ses notifications continueraient de partir) : au démarrage, puis toutes
// les heures. Après stockage, notifications et annonces (leurs listes lues).
function demarrer() {
  appareils.oublierInactifs();
  setInterval(() => appareils.oublierInactifs(), 3600 * 1000).unref();
}

// Qui appelle : { pc: true } pour le PC lui-même, { appareil } pour un
// appareil relié, { confiance: true } pour une adresse déclarée de confiance,
// null pour un appareil du réseau inconnu de la régie.
function accesRequete(req) {
  if (vientDuPc(req)) return { pc: true, appareil: null };
  const appareil = appareils.reconnaitre(req.headers.cookie);
  if (appareil) {
    appareils.noterVu(appareil);
    return { pc: false, appareil };
  }
  if (ADRESSES_DE_CONFIANCE.has(adresseNormalisee(req.socket && req.socket.remoteAddress))) return { pc: false, appareil: null, confiance: true };
  return null;
}

// Ce qu'un appareil du réseau atteint SANS être relié : de quoi installer le
// certificat et se relier. L'appli elle-même (sa page, son code compilé, ses
// icônes) ne contient aucun accès : elle s'affiche, voit qu'elle n'est pas
// reliée, et envoie sur /relier.
const OUVERT_A_TOUS = new Set([
  '/', '/app.js', '/config.js', '/manifest.json', '/sw.js',
  '/telephone', '/installer', '/certificat-regie.crt', '/api/certificat/empreinte', '/ping.gif',
  '/relier', '/api/appareils/moi',
]);
function ouvertATous(methode, chemin) {
  if (methode === 'POST') return chemin === '/api/appareils/relier';
  if (methode !== 'GET' && methode !== 'HEAD') return false;
  return OUVERT_A_TOUS.has(chemin)
    || /^\/icons\/[a-zA-Z0-9._-]+\.png$/.test(chemin)
    || /^\/guide\/[a-zA-Z0-9._-]+\.(css|js|svg|png)$/.test(chemin);
}

// Ce qui ne s'ouvre que sur le PC, même pour un appareil relié : le QR code
// (il porte un code de liaison), la configuration des comptes (identifiants,
// retours d'autorisation) et le kit à donner.
function reserveAuPc(chemin) {
  return chemin === '/qr' || chemin.startsWith('/qr/')
    || chemin === '/setup' || chemin.startsWith('/api/setup/') || chemin.startsWith('/oauth/')
    || chemin === '/kit' || chemin === '/kit.zip' || chemin === '/api/kit' || chemin === '/api/maj/publier'
    || chemin === '/api/oublier-tout';
}

function refuserAppareilInconnu(req, res, url) {
  if (req.method === 'GET' && !url.pathname.startsWith('/api/')) {
    // Une page : direction la page de liaison, qui ramènera ici ensuite.
    res.writeHead(302, { Location: '/relier?retour=' + encodeURIComponent(url.pathname + url.search), 'Cache-Control': 'no-store' });
    res.end();
    return;
  }
  outilsHttp.sendJson(res, 401, {
    ok: false,
    appairage: true,
    error: 'Cet appareil n’est pas relié à la régie. Ouvre la régie dessus : elle te demandera le code affiché sur le PC.',
  });
}

function refuserHorsDuPc(req, res, url) {
  if (url.pathname.startsWith('/api/')) {
    outilsHttp.sendJson(res, 403, { ok: false, error: 'Réservé au PC où tourne la régie.' });
    return;
  }
  outilsHttp.pageSimple(res, 403, 'Cette page s’ouvre sur le PC',
    'Elle sert à configurer la régie (QR code, comptes, kit) : ouvre-la sur le PC où tourne la régie, à l’adresse http://localhost:' + parametres.PORT + url.pathname + '.',
    { href: '/', texte: 'Ouvrir la régie' });
}

// Ce qu'une page d'une AUTRE origine a le droit de LIRE : l'état de la régie
// (minuteur, scènes, statut du stream — sans aucun accès, voir
// etatPourRequete) et son flux, les événements Twitch et leur flux (pour une
// page d'alertes), plus ce qui est ouvert à tous (l'appli, les pages
// d'installation, les icônes). Tout le reste — journal, diagnostic, réglages,
// sauvegardes, appareils reliés, fenêtres ouvertes, kit — est réservé à
// l'appli servie par le pont, même pour une page qui se fait passer pour un
// overlay.
const LECTURES_OUVERTES = new Set([
  '/api/obs/status',
  '/api/obs/events',
  '/api/twitch/events',
  '/api/twitch/stream',
  '/api/generique',       // générique de la scène de fin (faits du stream et récit)
]);
function lectureOuverte(chemin) {
  return LECTURES_OUVERTES.has(chemin) || ouvertATous('GET', chemin);
}

// Une requête qu'une page d'un AUTRE SITE déclenche sans dire qui elle est :
// une image, un script, une feuille de style, un cadre n'envoient pas
// d'en-tête Origin. Le navigateur la signale quand même, par Sec-Fetch-Site.
// Passent : ce qui est ouvert à tous (l'appli, les pages d'installation,
// /ping.gif que la page /telephone charge depuis l'adresse https), et un lien
// suivi en pleine page vers une PAGE de la régie (un retour d'autorisation
// de YouTube, par exemple). Un lien suivi a pour destination « document », ou
// « empty » quand le service worker de l'appli relaie la navigation ; un
// cadre (« iframe ») n'est pas un lien suivi.
// Jamais par un lien venu d'ailleurs : une route /api/, ni le kit — un
// téléchargement laisse la page piégée ouverte, qui recommencerait en
// boucle. Sans cette barrière, une page piégée ouverte sur le PC pouvait
// faire fabriquer le kit sans fin ou lancer des appels à YouTube — sans rien
// lire, mais avec les droits du PC.
function requeteIntersiteMuette(req, chemin) {
  if (req.headers.origin) return false; // la barrière 2 s'en est chargée
  const site = req.headers['sec-fetch-site'];
  if (!site) return pcParSonAdresseSansProvenance(req, chemin);
  if (site !== 'cross-site' && site !== 'same-site') return false;
  if (ouvertATous(req.method, chemin)) return false;
  const lienSuivi = req.headers['sec-fetch-mode'] === 'navigate'
    && (req.headers['sec-fetch-dest'] === 'document' || req.headers['sec-fetch-dest'] === 'empty');
  return !(lienSuivi && !chemin.startsWith('/api/') && chemin !== '/kit.zip');
}

// Le trou de la barrière ci-dessus : les navigateurs n'envoient Sec-Fetch-*
// qu'aux adresses « sûres » (https, localhost, 127.0.0.1). Le PC qui ouvre
// la régie par son adresse réseau en http (http://192.168.1.20:4560) n'en
// reçoit aucun : une image d'un autre site arrivait muette, avec les droits du
// PC (kit fabriqué sans fin, appels YouTube sur le quota). L'appli et les
// pages de la régie, elles, envoient toujours leur propre adresse en Referer
// — ce qu'un autre site ne peut pas imiter. Seulement /api/ et le kit, pour un
// navigateur (un outil hors navigateur n'est pas une page piégée).
function pcParSonAdresseSansProvenance(req, chemin) {
  if (!/^Mozilla\//.test(String(req.headers['user-agent'] || ''))) return false;
  if (!chemin.startsWith('/api/') && chemin !== '/kit.zip') return false;
  if (ouvertATous(req.method, chemin)) return false;
  const hote = hoteDeLaRequete(req);
  if (hote === 'localhost' || hote === '::1' || /^127\./.test(hote)) return false; // Sec-Fetch-* y est toujours envoyé
  if (!vientDuPc(req)) return false;
  try { return new URL(String(req.headers.referer || '')).host !== req.headers.host; } catch (e) { return true; }
}

// Ce qu'une page d'une AUTRE origine a le droit de déclencher. Un overlay a
// légitimement besoin de piloter le minuteur (les boutons Lancer /
// Réinitialiser d'un écran de démarrage) : ces trois routes restent ouvertes.
// Tout le reste — couper le direct, changer de scène, rallumer un micro,
// publier, enregistrer des identifiants — est réservé à l'appli servie par le
// pont. Sans cette barrière, n'importe quel site ouvert dans le navigateur du
// PC pendant un direct pouvait arrêter le stream.
const ECRITURES_OUVERTES = new Set([
  '/api/timer/start',
  '/api/timer/pause',
  '/api/timer/reset',
]);

// L'état tel que cette requête peut le recevoir : jamais le jeton Twitch
// (voir etatRegie.etatPublic), et pour une page d'une autre origine, pas même
// le Client ID. Tout le reste (minuteur, scènes, statut du stream) passe :
// c'est ce dont un overlay a besoin, et ça n'ouvre aucun accès.
function etatPourRequete(req) {
  pseudos.rafraichirPseudo(true);
  return etatRegie.etatPublic(etatRegie.obsState, estAutreOrigine(req));
}

// Les adresses de CE PC — IPv4 ET IPv6 —, gardées 30 s : sert à ne pas
// prendre le PC pour un téléphone quand on l'ouvre par son adresse réseau
// (ou par son nom, qui peut se résoudre en IPv6).
let cacheAdressesPc = { quand: 0, liste: new Set(), local: null };
function adresseNormalisee(a) {
  return String(a || '').replace(/^::ffff:/i, '').replace(/%.*$/, '').toLowerCase();
}
function adressesDuPc() {
  if (Date.now() - cacheAdressesPc.quand > 30000) {
    const liste = new Set(['127.0.0.1', '::1']);
    try {
      for (const cartes of Object.values(os.networkInterfaces())) {
        for (const net of cartes || []) if (net && net.address) liste.add(adresseNormalisee(net.address));
      }
    } catch (e) { /* on garde au moins le bouclage */ }
    cacheAdressesPc = { quand: Date.now(), liste, local: reseauxLocaux() };
  }
  return cacheAdressesPc.liste;
}

// Les réseaux d'où un appareil peut appeler la régie : le bouclage, les plages
// privées (box, VPN type Tailscale en 100.64/10, IPv6 de lien local et ULA), et
// le réseau de chaque carte du PC (c'est ce qui couvre l'IPv6 « publique »
// d'un téléphone du même Wi-Fi : même préfixe /64 que le PC).
function reseauxLocaux() {
  const b = new BlockList();
  for (const [r, l] of [['127.0.0.0', 8], ['10.0.0.0', 8], ['172.16.0.0', 12], ['192.168.0.0', 16], ['169.254.0.0', 16], ['100.64.0.0', 10]]) b.addSubnet(r, l, 'ipv4');
  for (const [r, l] of [['::1', 128], ['fe80::', 10], ['fc00::', 7]]) b.addSubnet(r, l, 'ipv6');
  try {
    for (const cartes of Object.values(os.networkInterfaces())) {
      for (const net of cartes || []) {
        const m = /\/(\d+)$/.exec((net && net.cidr) || '');
        const type = isIP(adresseNormalisee(net && net.address)) === 6 ? 'ipv6' : 'ipv4';
        // Une carte sans masque (ou /0) ne dit rien de son réseau : ignorée.
        if (m && Number(m[1]) > 0) b.addSubnet(adresseNormalisee(net.address), Number(m[1]), type);
      }
    }
  } catch (e) { /* les plages privées suffisent */ }
  return b;
}

// Barrière 0 : la requête vient-elle du réseau local ? Le pont écoute sur
// toutes les cartes, IPv6 comprise, et une IPv6 publique du PC peut être
// joignable depuis Internet si la box laisse passer : un inconnu lisait alors
// les pages d'installation et bloquait la liaison des appareils en tapant des
// codes faux. Les adresses de REGIE_ADRESSES_DE_CONFIANCE passent toujours.
function appelantDuReseauLocal(req) {
  const a = adresseNormalisee(req.socket && req.socket.remoteAddress);
  const type = isIP(a);
  if (!type) return false;
  if (ADRESSES_DE_CONFIANCE.has(a)) return true;
  adressesDuPc(); // relit les cartes au besoin (30 s)
  return cacheAdressesPc.local.check(a, type === 6 ? 'ipv6' : 'ipv4');
}
// La requête part-elle de ce PC lui-même ? Son adresse, et aucun relais :
// un tunnel installé sur le PC fait arriver toutes ses requêtes par
// 127.0.0.1. Sert à ne pas prendre le PC pour le téléphone (preuves.js) ;
// les DROITS du PC, eux, demandent plus (vientDuPc).
function surCeMemePc(req) {
  const distante = adresseNormalisee(req.socket && req.socket.remoteAddress);
  return !!distante && adressesDuPc().has(distante) && !viaUnRelais(req);
}

// Les droits du PC : la requête part du PC ET appelle la régie par localhost
// ou par une adresse IP. Un site piégé qui fait pointer son propre nom vers
// ce PC (« rebinding DNS ») passe forcément par un NOM : même si ce nom
// ressemblait un jour à celui du PC, il n'aurait que les droits d'un appareil
// inconnu. Un nom ajouté à la main (REGIE_HOTES_AUTORISES) ne les donne pas
// non plus.
function vientDuPc(req) {
  if (!surCeMemePc(req)) return false;
  const hote = hoteDeLaRequete(req);
  return (hote === 'localhost' || isIP(hote) !== 0) && !HOTES_AJOUTES.has(hote);
}
