// ============================================================
//  Routes : Twitch (relais Helix, connexion, événements)
// ------------------------------------------------------------
//  Appelé par src/routes/index.js, une fois les barrières passées
//  (voir src/securite.js). « acces » dit qui appelle.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  appelerHelix, // aussi pour le texte des clips publiés (src/legende-clip.js)
  traiter,
};

const parametres = require('../parametres.js');
const etatRegie = require('../etat-regie.js');
const twitchEcoute = require('../twitch-ecoute.js');
const twitchJeton = require('../twitch-jeton.js');
const outilsHttp = require('../http-outils.js');
const stockage = require('../stockage.js');
const reglagesRegie = require('../reglages-regie.js');
const raidCabane = require('../raid-cabane.js');
const fabriqueKit = require('../kit.js');
const journalEvenements = require('../journal-evenements.js');
const generique = require('../generique.js');

// Ce que l'appli a le droit de demander à Twitch, par chemin exact (jamais
// par préfixe : « /helix/channels » et « /helix/channels/vips » sont deux
// autorisations différentes). Le jeton a déjà ses propres limites côté
// Twitch ; cette liste est la seconde barrière, et l'inventaire lisible de
// tout ce que l'appli utilise réellement.
const HELIX_AUTORISE = {
  '/helix/channels': ['GET', 'PATCH'],                        // infos du stream
  '/helix/channels/commercial': ['POST'],                     // coupure pub
  '/helix/channels/vips': ['POST', 'DELETE'],                 // rôle VIP
  '/helix/channel_points/custom_rewards': ['GET', 'POST', 'PATCH'],
  '/helix/chat/announcements': ['POST'],
  '/helix/chat/messages': ['POST'],                           // message dans le tchat
  '/helix/chat/shoutouts': ['POST'],
  '/helix/clips': ['GET', 'POST'],
  '/helix/clips/downloads': ['GET'],
  '/helix/moderation/bans': ['POST', 'DELETE'],               // timeout / unban
  '/helix/moderation/moderators': ['POST', 'DELETE'],
  '/helix/polls': ['GET', 'POST', 'PATCH'],
  '/helix/predictions': ['GET', 'POST', 'PATCH'],
  '/helix/raids': ['POST', 'DELETE'],
  // Planning de la chaîne, tenu par l'Agence Aulit (outil local du PC) : lire
  // le planning, ajouter / modifier / retirer un créneau (channel:manage:schedule).
  '/helix/schedule': ['GET'],
  '/helix/schedule/segment': ['POST', 'PATCH', 'DELETE'],
  '/helix/search/categories': ['GET'],
  '/helix/streams': ['GET'],
  '/helix/users': ['GET'],
};
// Le marqueur de stream n'est plus relayé : il a sa route, qui vérifie le
// direct et le droit avant (POST /api/twitch/marqueur).

// Un appel à Twitch avec le jeton de la régie, renouvelé d'avance s'il
// arrive à échéance (connexion par code). Rend { ok, statut, donnees }.
async function appelerHelix(demande, methode, corps) {
  const creds = etatRegie.obsState.twitchCreds || {};
  let token = await twitchJeton.jetonTwitchValide();
  const entetes = { Authorization: `Bearer ${token}`, 'Client-Id': (creds.clientId || '').trim() };
  const options = { method: methode, headers: entetes };
  if (corps !== undefined && corps !== null) {
    entetes['Content-Type'] = 'application/json';
    options.body = JSON.stringify(corps);
  }
  let r = await fetch(parametres.TWITCH_API + demande, options);
  // Jeton refusé en connexion par code : on le renouvelle et on rejoue la
  // requête UNE fois. La personne ne voit rien ; sans ça, la première
  // action après quatre heures de stream échouait.
  if (r.status === 401 && twitchJeton.connexionParCode()) {
    try {
      token = await twitchJeton.renouvelerJetonTwitch('refusé par Twitch');
      entetes.Authorization = `Bearer ${token}`;
      r = await fetch(parametres.TWITCH_API + demande, options);
    } catch (e) { /* on renvoie le refus d'origine */ }
  }
  // 204 (succès sans contenu) est fréquent sur les routes de modération :
  // appeler .json() dessus lèverait une erreur là où tout va bien.
  const texte = await r.text();
  let donnees = {};
  if (texte) { try { donnees = JSON.parse(texte); } catch (e) { donnees = { message: texte.slice(0, 200) }; } }
  return { ok: r.ok, statut: r.status, donnees };
}

// Un jeton périmé se diagnostique une seule fois, ici, au lieu de
// vingt-sept messages d'erreur différents dans l'appli.
function messageJetonExpire() {
  const mode = (etatRegie.obsState.twitchCreds || {}).mode;
  return (mode === 'code' || mode === 'expire')
    ? 'Connexion Twitch expirée — reconnecte-toi avec un code (Réglages → Twitch).'
    : 'Token Twitch expiré ou révoqué — refais « Obtenir un token » dans Réglages.';
}

const DROIT_PLANNING = 'Le jeton Twitch de la régie n’a pas le droit de modifier le planning (channel:manage:schedule). Reconnecte Twitch dans Réglages → Connexion Twitch : la nouvelle connexion demande ce droit.';

const DROIT_MARQUEUR = 'Le jeton Twitch de la régie n’a pas le droit de poser un marqueur (channel:manage:broadcast). Reconnecte Twitch dans Réglages → Connexion Twitch : la nouvelle connexion demande ce droit.';

// Un marqueur de stream (Helix POST /streams/markers), seulement en direct.
// Rend ce que l'appli affiche : { ok, error, horsLive, droitManquant }.
async function poserMarqueur(description) {
  const moi = await appelerHelix('/helix/users', 'GET');
  const id = moi.ok && moi.donnees.data && moi.donnees.data[0] && moi.donnees.data[0].id;
  if (!id) return { ok: false, error: moi.statut === 401 ? messageJetonExpire() : 'Twitch n’a pas dit qui est connecté (' + (moi.donnees.message || 'code ' + moi.statut) + ').' };
  // Twitch refuse un marqueur hors direct : on le dit avant, clairement.
  const direct = await appelerHelix('/helix/streams?user_id=' + encodeURIComponent(id), 'GET');
  if (direct.ok && Array.isArray(direct.donnees.data) && !direct.donnees.data.some((s) => s.type === 'live')) {
    return { ok: false, horsLive: true, error: 'Tu n’es pas en direct sur Twitch : un marqueur ne se pose que pendant un live.' };
  }
  const r = await appelerHelix('/helix/streams/markers', 'POST', { user_id: id, ...(description ? { description } : {}) });
  if (r.ok) {
    const m = (r.donnees.data && r.donnees.data[0]) || {};
    journalEvenements.noterMoment(m.description || description, Date.now()); // un « moment » du générique de fin
    return { ok: true, positionSecondes: Number(m.position_seconds) || 0, description: m.description || description };
  }
  const message = String(r.donnees.message || '');
  if (r.statut === 403 || (r.statut === 401 && /scope/i.test(message))) return { ok: false, droitManquant: true, error: DROIT_MARQUEUR };
  if (r.statut === 401) return { ok: false, error: messageJetonExpire() };
  if (r.statut === 404) return { ok: false, horsLive: true, error: 'Twitch refuse le marqueur : pas de direct en cours, ou les rediffusions (VOD) sont désactivées sur la chaîne.' };
  return { ok: false, error: 'Marqueur refusé par Twitch : ' + (message || 'code ' + r.statut) };
}

// Rend vrai si la demande a été traitée ici.
async function traiter(req, res, url, acces) {
  if (req.method === 'GET' && url.pathname === '/api/streamers') {
    outilsHttp.sendJson(res, 200, { ok: true, streamers: stockage.platformTokens.streamers || [] });
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/streamers') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      stockage.platformTokens.streamers = Array.isArray(body.streamers) ? body.streamers : [];
      stockage.saveTokens();
      outilsHttp.sendJson(res, 200, { ok: true, streamers: stockage.platformTokens.streamers });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false, error: 'Requête invalide.' });
    }
    return true;
  }

  // ---------- Shoutout sur un raid : la commande envoyée dans le tchat ----------
  if (req.method === 'POST' && url.pathname === '/api/shoutout/commande') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      etatRegie.obsState.shoutoutCommande = reglagesRegie.nettoyerCommandeShoutout(body.commande);
      reglagesRegie.persistExtras();
      etatRegie.broadcastPatch({ shoutoutCommande: etatRegie.obsState.shoutoutCommande });
      outilsHttp.sendJson(res, 200, { ok: true, commande: etatRegie.obsState.shoutoutCommande });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false, error: 'Requête invalide.' });
    }
    return true;
  }

  // ---------- Marqueur de stream ----------
  if (req.method === 'POST' && url.pathname === '/api/twitch/marqueur') {
    let description = '';
    try { description = String((await outilsHttp.readJsonBody(req)).description || '').replace(/\s+/g, ' ').trim().slice(0, 140); } catch (e) { /* sans description */ }
    const creds = etatRegie.obsState.twitchCreds || {};
    if (!String(creds.clientId || '').trim() || !String(creds.token || '').trim()) {
      outilsHttp.sendJson(res, 200, { ok: false, error: 'Twitch non connecté — Réglages → Connexion Twitch.' });
      return true;
    }
    try {
      outilsHttp.sendJson(res, 200, await poserMarqueur(description));
    } catch (e) {
      outilsHttp.sendJson(res, 200, { ok: false, error: 'Twitch ne répond pas : ' + (e.message || String(e)) });
    }
    return true;
  }

  // ---------- Générique de fin (scène de fin d'OBS, Agence Aulit) ----------
  // Lu par la scène de fin (overlay : lecture ouverte, voir securite.js) ;
  // le récit est écrit par l'agence, outil local du PC (jamais par un overlay).
  if (req.method === 'GET' && url.pathname === '/api/generique') {
    const f = await generique.faits({ helix: appelerHelix });
    outilsHttp.sendJson(res, 200, { ok: true, ...generique.pourOverlay(f) });
    return true;
  }
  if (req.method === 'POST' && url.pathname === '/api/generique/recit') {
    let corps = {};
    try { corps = await outilsHttp.readJsonBody(req); } catch (e) { /* refusé ci-dessous */ }
    const r = generique.noterRecit(corps);
    outilsHttp.sendJson(res, r.ok ? 200 : r.statut, r.ok ? { ok: true } : { ok: false, error: r.error });
    return true;
  }

  // ---------- Afficher ou masquer la carte « Raid · La Cabane » ----------
  if (req.method === 'POST' && url.pathname === '/api/raid-cabane/affiche') {
    let affiche;
    try { affiche = (await outilsHttp.readJsonBody(req)).affiche; } catch (e) { /* refusé ci-dessous */ }
    if (typeof affiche !== 'boolean') { outilsHttp.sendJson(res, 400, { ok: false, error: 'Requête invalide.' }); return true; }
    stockage.platformTokens.raidCabaneAffiche = affiche;
    stockage.saveTokens();
    etatRegie.obsState.raidCabaneActif = twitchJeton.raidCabaneVisible();
    etatRegie.broadcastPatch({ raidCabaneActif: etatRegie.obsState.raidCabaneActif });
    outilsHttp.sendJson(res, 200, { ok: true, raidCabaneActif: etatRegie.obsState.raidCabaneActif });
    return true;
  }

  // ---------- Raid de fin de live : La Cabane ----------
  // GET : les membres en direct, triés (voir src/raid-cabane.js) ;
  // POST { versId } : lance le raid ; DELETE : l'annule pendant le compte à rebours.
  if (url.pathname === '/api/twitch/raid-cabane' && ['GET', 'POST', 'DELETE'].includes(req.method)) {
    // Retiré (case du kit ou Réglages → Twitch, voir twitchJeton.raidCabaneVisible).
    if (!twitchJeton.raidCabaneVisible()) {
      outilsHttp.sendJson(res, 403, { ok: false, raidCabaneDesactive: true, error: 'Raid · La Cabane est masqué dans cette régie (Réglages → Connexion Twitch → « Afficher Raid · La Cabane »).' });
      return true;
    }
    const creds = etatRegie.obsState.twitchCreds || {};
    if (!String(creds.clientId || '').trim() || !String(creds.token || '').trim()) {
      outilsHttp.sendJson(res, 200, { ok: false, error: 'Twitch non connecté — Réglages → Connexion Twitch.' });
      return true;
    }
    try {
      let rep;
      if (req.method === 'GET') rep = await raidCabane.suggestions(appelerHelix);
      else if (req.method === 'POST') rep = await raidCabane.lancerRaid(appelerHelix, (await outilsHttp.readJsonBody(req).catch(() => ({}))).versId);
      else rep = await raidCabane.annulerRaid(appelerHelix);
      if (rep.statut === 401) rep = { ...rep, error: messageJetonExpire() };
      outilsHttp.sendJson(res, 200, rep);
    } catch (e) {
      outilsHttp.sendJson(res, 200, { ok: false, error: 'Twitch ne répond pas : ' + (e.message || String(e)) });
    }
    return true;
  }

  // ---------- Relais vers l'API Twitch ----------
  // L'appli appelait Twitch directement depuis le téléphone, avec le jeton
  // dans ses en-têtes. Deux ennuis : le jeton se promenait dans le navigateur
  // de chaque appareil où l'appli avait été ouverte, et chaque commande
  // (sondage, raid, coupure pub, modération) dépendait de la connexion
  // internet DU TÉLÉPHONE — qu'Android coupe volontiers en arrière-plan.
  // C'est le même problème que pour l'écoute des événements, déjà déplacée
  // ici. Le téléphone ne parle plus qu'au pont, sur le réseau local ; c'est
  // le pont, sur le PC resté allumé, qui parle à Twitch.
  //
  // Un seul relais plutôt que vingt-sept routes : l'appli dit quel chemin
  // Helix elle veut, le pont y ajoute l'authentification. La liste blanche
  // ci-dessus borne ce qui est atteignable, et sert aussi d'inventaire de ce
  // que l'appli utilise vraiment.
  if (req.method === 'POST' && url.pathname === '/api/twitch/helix') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      const creds = etatRegie.obsState.twitchCreds || {};
      if (!(creds.clientId || '').trim() || !String(creds.token || '').trim()) {
        outilsHttp.sendJson(res, 200, { ok: false, statut: 0, error: 'Twitch non connecté — Réglages → Twitch.' });
        return true;
      }
      const demande = String(body.chemin || '');
      const sansRequete = demande.split('?')[0];
      const methode = String(body.methode || 'GET').toUpperCase();
      const permises = HELIX_AUTORISE[sansRequete];
      // Le planning ne sert qu'à l'Agence Aulit d'Olivier : absent d'une régie reçue en kit.
      if (sansRequete.startsWith('/helix/schedule') && fabriqueKit.dansUnKit()) {
        outilsHttp.sendJson(res, 403, { ok: false, statut: 0, dansUnKit: true, error: 'Planning Twitch indisponible dans une régie reçue en kit.' });
        return true;
      }
      if (!permises) {
        outilsHttp.sendJson(res, 200, { ok: false, statut: 0, error: 'Chemin Twitch non autorisé : ' + sansRequete });
        return true;
      }
      if (!permises.includes(methode)) {
        outilsHttp.sendJson(res, 200, { ok: false, statut: 0, error: methode + ' non autorisé sur ' + sansRequete });
        return true;
      }
      const r = await appelerHelix(demande, methode, body.corps);
      // Recherche de jeu : « Cinderia » (niche) arrive 11e chez Twitch, derrière les « Cinderella » ; l'interface ne montre que
      // 8 résultats, il n'apparaissait donc jamais. On remonte en tête le jeu au NOM EXACT (helix/games?name=), s'il manque.
      if (sansRequete === '/helix/search/categories' && r.ok && r.donnees && Array.isArray(r.donnees.data)) {
        const q = new URLSearchParams(demande.split('?')[1] || '').get('query') || '';
        const norm = (s) => String(s || '').trim().toLowerCase();
        if (q && !r.donnees.data.slice(0, 8).some((c) => norm(c.name) === norm(q))) {
          try {
            const g = await appelerHelix('/helix/games?name=' + encodeURIComponent(q), 'GET');
            const exact = g.ok && g.donnees && Array.isArray(g.donnees.data) && g.donnees.data.find((x) => norm(x.name) === norm(q));
            if (exact) r.donnees.data = [exact, ...r.donnees.data.filter((c) => norm(c.name) !== norm(exact.name))];
          } catch { /* la recherche marche sans l'ajout du nom exact */ }
        }
      }
      // Planning : un droit manquant (jeton d'avant channel:manage:schedule)
      // se dit comme pour le raid et le marqueur — reconnecter Twitch.
      const droitPlanning = sansRequete.startsWith('/helix/schedule')
        && (r.statut === 403 || (r.statut === 401 && /scope/i.test(String((r.donnees && r.donnees.message) || ''))));
      if (droitPlanning) {
        outilsHttp.sendJson(res, 200, { ok: false, statut: r.statut, droitManquant: true, error: DROIT_PLANNING, donnees: { ...r.donnees, message: DROIT_PLANNING } });
        return true;
      }
      const donnees = r.statut === 401 ? { ...r.donnees, message: messageJetonExpire() } : r.donnees;
      outilsHttp.sendJson(res, 200, { ok: r.ok, statut: r.statut, donnees });
    } catch (e) {
      outilsHttp.sendJson(res, 200, { ok: false, statut: 0, error: e.message || String(e) });
    }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/twitch/credentials') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      etatRegie.obsState.twitchCreds = { clientId: body.clientId || '', token: body.token || '' };
      // Méthode manuelle : un éventuel jeton de renouvellement de la
      // connexion par code ne correspond plus à rien. Le garder ferait
      // renouveler un jeton qui n'est plus celui utilisé.
      twitchJeton.twitchRafraichissement = null;
      delete stockage.platformTokens.twitchAppareil;
      twitchJeton.arreterInterrogationCode();
      twitchJeton.derniereValidationTwitch = 0;
      stockage.persistSharedState();
      etatRegie.broadcastState();
      // C'est le pont qui écoute Twitch désormais : de nouveaux identifiants
      // veulent dire nouvelle connexion.
      twitchEcoute.connectTwitchListen();
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false, error: e.message });
    }
    return true;
  }

  // Historique complet des événements, envoyé au chargement de l'appli pour
  // rattraper tout ce qui est arrivé pendant qu'elle n'était pas là.
  if (req.method === 'GET' && url.pathname === '/api/twitch/events') {
    outilsHttp.sendJson(res, 200, { ok: true, events: twitchEcoute.twitchEvents });
    return true;
  }

  // Flux temps réel des nouveaux événements.
  if (req.method === 'GET' && url.pathname === '/api/twitch/stream') {
    etatRegie.brancherFluxSse(req, res, twitchEcoute.twitchStreamClients);
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/twitch/events/clear') {
    twitchEcoute.twitchEvents = [];
    outilsHttp.sendJson(res, 200, { ok: true });
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/twitch/reconnect') {
    const c = etatRegie.obsState.twitchCreds || {};
    if (!c.clientId || !c.token) {
      // Sans identifiants, relancer ne mènerait à rien : autant le dire.
      outilsHttp.sendJson(res, 200, { ok: false, error: 'Aucun identifiant Twitch enregistré — renseigne le Client ID et le token, puis Connecter.' });
      return true;
    }
    twitchEcoute.connectTwitchListen();
    outilsHttp.sendJson(res, 200, { ok: true });
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/twitch/disconnect') {
    twitchEcoute.disconnectTwitchListen();
    outilsHttp.sendJson(res, 200, { ok: true });
    return true;
  }

  // Avant de remplacer le titre ou la catégorie sur Twitch, l'appli confie
  // au pont ce qu'il y avait : « Rétablir » les remet d'un appui, même après
  // un redémarrage. Un titre remplacé par erreur était perdu pour de bon
  // (Olivier, 19/10) : Twitch n'en garde aucun historique.
  if (req.method === 'POST' && url.pathname === '/api/infos-stream/precedentes') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      etatRegie.obsState.infosStreamPrecedentes = body && (body.title || body.categoryId)
        ? { title: String(body.title || '').slice(0, 140), categoryId: String(body.categoryId || ''), categoryName: String(body.categoryName || '').slice(0, 140), quand: Date.now() }
        : null;
      stockage.persistSharedState();
      etatRegie.broadcastState();
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false, error: e.message });
    }
    return true;
  }
  if (req.method === 'POST' && url.pathname === '/api/prepared-stream-info') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      etatRegie.obsState.preparedStreamInfo = { title: body.title || '', categoryId: body.categoryId || '', categoryName: body.categoryName || '', tags: body.tags || [] };
      stockage.persistSharedState();
      etatRegie.broadcastState();
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false, error: e.message });
    }
    return true;
  }
  return false;
}
