// ============================================================
//  Routes : /setup, autorisations YouTube, Instagram, TikTok, publication
// ------------------------------------------------------------
//  Appelé par src/routes/index.js, une fois les barrières passées
//  (voir src/securite.js). « acces » dit qui appelle.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  traiter,
};

const parametres = require('../parametres.js');
const etatRegie = require('../etat-regie.js');
const outilsHttp = require('../http-outils.js');
const securite = require('../securite.js');
const stockage = require('../stockage.js');
const oauth = require('../oauth.js');
const youtube = require('../youtube.js');
const instagram = require('../instagram.js');
const tiktok = require('../tiktok.js');
const sousTitres = require('../sous-titres.js');
const legendeClip = require('../legende-clip.js');
const pseudos = require('../pseudos.js');
const routesTwitch = require('./twitch.js');
const pageSetup = require('../page-setup.js');
const fabriqueKit = require('../kit.js');

// Ce qui relie ou publie sur Instagram : refusé dans une régie reçue en kit
// (voir instagram.refuserDansUnKit). Ici pour une réponse claire, avant
// même de lire la demande. Toute nouvelle route Instagram va dans cette
// liste (README.md, « Instagram dans un kit »).
const CHEMINS_INSTAGRAM = /^\/(api\/setup\/instagram\/|oauth\/instagram\/|api\/publish\/instagram$)/;

// Un clip publié, noté pour l'appli. Version sous-titrée d'un clip déjà
// publié sans : l'ancienne est retenue (« ancienne »), en attente de l'accord
// du streamer pour être supprimée — jamais avant que la nouvelle soit en ligne.
function enregistrerPublication(clipId, plateforme, lien, avecSousTitres) {
  const clips = etatRegie.obsState.publishedClips;
  const avant = (Object.hasOwn(clips, clipId) && clips[clipId][plateforme]) || {};
  const info = { url: lien };
  if (avecSousTitres) info.sousTitres = true;
  const ancienne = avant.ancienne || (avecSousTitres && avant.url && !avant.sousTitres ? { url: avant.url } : null);
  if (ancienne) info.ancienne = ancienne;
  etatRegie.obsState.publishedClips = { ...clips, [clipId]: { ...(clips[clipId] || {}), [plateforme]: info } };
  stockage.persistSharedState();
  etatRegie.broadcastState();
}

// Rend vrai si la demande a été traitée ici.
async function traiter(req, res, url, acces) {
  if (CHEMINS_INSTAGRAM.test(url.pathname) && fabriqueKit.dansUnKit()) {
    if (req.method === 'GET') outilsHttp.pageSimple(res, 403, 'Instagram', instagram.REFUS_KIT);
    else outilsHttp.sendJson(res, 403, { ok: false, dansUnKit: true, error: instagram.REFUS_KIT });
    return true;
  }

  if (req.method === 'GET' && url.pathname === '/setup') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    // Dans un kit, la page ne propose pas Instagram (image seulement).
    res.end(fabriqueKit.dansUnKit() ? pageSetup.sansInstagram(pageSetup.SETUP_HTML) : pageSetup.SETUP_HTML);
    return true;
  }

  if (req.method === 'GET' && url.pathname === '/api/setup/status') {
    // Cette route sert la page /setup, ouverte sur le PC. Les secrets des
    // applications (Google, Meta, TikTok) n'ont rien à faire dans une réponse
    // lisible par une page d'une autre origine : on ne renvoie alors que l'état
    // des connexions, sans aucun identifiant.
    if (securite.estAutreOrigine(req)) {
      outilsHttp.sendJson(res, 200, {
        youtube: !!(stockage.platformTokens.youtube && stockage.platformTokens.youtube.refreshToken),
        instagram: !!(stockage.platformTokens.instagram && stockage.platformTokens.instagram.accessToken),
        tiktok: !!(stockage.platformTokens.tiktok && stockage.platformTokens.tiktok.refreshToken),
      });
      return true;
    }
    outilsHttp.sendJson(res, 200, {
      youtube: !!(stockage.platformTokens.youtube && stockage.platformTokens.youtube.refreshToken),
      youtubeClientId: (stockage.platformTokens.youtube && stockage.platformTokens.youtube.clientId) || '',
      youtubeClientSecret: (stockage.platformTokens.youtube && stockage.platformTokens.youtube.clientSecret) || '',
      instagram: !!(stockage.platformTokens.instagram && stockage.platformTokens.instagram.accessToken),
      instagramAppId: (stockage.platformTokens.instagram && stockage.platformTokens.instagram.appId) || '',
      instagramAppSecret: (stockage.platformTokens.instagram && stockage.platformTokens.instagram.appSecret) || '',
      tiktok: !!(stockage.platformTokens.tiktok && stockage.platformTokens.tiktok.refreshToken),
      tiktokClientKey: (stockage.platformTokens.tiktok && stockage.platformTokens.tiktok.clientKey) || '',
      tiktokClientSecret: (stockage.platformTokens.tiktok && stockage.platformTokens.tiktok.clientSecret) || '',
      liensClips: { planning: '', discord: '', ...stockage.platformTokens.liensClips },
    });
    return true;
  }

  // Les liens du texte des clips publiés (src/legende-clip.js) : planning et
  // Discord, facultatifs. Vide = ligne retirée du texte. PC seulement (/api/setup/).
  if (req.method === 'POST' && url.pathname === '/api/setup/liens-clips') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      const planning = legendeClip.nettoyerLien(body.planning);
      const discord = legendeClip.nettoyerLien(body.discord);
      if (planning === null || discord === null) throw new Error('Lien invalide : colle une adresse comme « monsite.fr/planning » ou « discord.gg/abc ».');
      stockage.platformTokens.liensClips = { planning, discord };
      stockage.saveTokens();
      outilsHttp.sendJson(res, 200, { ok: true, liensClips: { planning, discord } });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false, error: e.message.startsWith('Lien') ? e.message : 'Requête invalide.' });
    }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/setup/youtube/credentials') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      stockage.platformTokens.youtube = { ...(stockage.platformTokens.youtube || {}), clientId: body.clientId, clientSecret: body.clientSecret };
      stockage.saveTokens();
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false });
    }
    return true;
  }

  if (req.method === 'GET' && url.pathname === '/oauth/youtube/start') {
    if (!stockage.platformTokens.youtube || !stockage.platformTokens.youtube.clientId) {
      res.writeHead(302, { Location: '/setup' }); res.end(); return true;
    }
    res.writeHead(302, { Location: youtube.youtubeAuthUrl() });
    res.end();
    return true;
  }

  if (req.method === 'GET' && url.pathname === '/oauth/youtube/callback') {
    const code = url.searchParams.get('code');
    const errorParam = url.searchParams.get('error');
    const demande = oauth.consommerEtatOauth('youtube', url.searchParams.get('state'));
    if (!demande) { oauth.retourNonDemande(res, 'youtube'); return true; }
    if (errorParam || !code) { oauth.refusOauth(res, 'youtube', { url }); return true; }
    try {
      const yt = stockage.platformTokens.youtube;
      const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ code, client_id: yt.clientId, client_secret: yt.clientSecret, redirect_uri: youtube.YT_REDIRECT_URI, grant_type: 'authorization_code' }),
      });
      const data = await tokenRes.json();
      if (!tokenRes.ok || !data.refresh_token) {
        throw new Error(data.error_description || "Pas de jeton de rafraîchissement reçu — retire l'accès à l'appli dans myaccount.google.com/permissions puis réessaie.");
      }
      yt.refreshToken = data.refresh_token;
      yt.accessToken = data.access_token;
      yt.expiresAt = Date.now() + (data.expires_in || 3600) * 1000;
      stockage.saveTokens();
      // L'onglet YouTube de l'appli n'apparaît qu'une fois YouTube relié.
      etatRegie.setState({ youtubeConfigure: true });
      oauth.pageRetourOauth(res, '✓ YouTube connecté. Tu peux fermer cette page.');
    } catch (e) {
      oauth.refusOauth(res, 'youtube', { erreur: e });
    }
    return true;
  }

  if (req.method === 'GET' && url.pathname === '/oauth/tiktok/start') {
    if (!stockage.platformTokens.tiktok || !stockage.platformTokens.tiktok.clientKey) {
      res.writeHead(302, { Location: '/setup' }); res.end(); return true;
    }
    res.writeHead(302, { Location: tiktok.tiktokAuthUrl() });
    res.end();
    return true;
  }

  if (req.method === 'GET' && url.pathname === '/oauth/tiktok/callback') {
    const code = url.searchParams.get('code');
    const errorParam = url.searchParams.get('error');
    const demande = oauth.consommerEtatOauth('tiktok', url.searchParams.get('state'));
    if (!demande || !demande.verifier) { oauth.retourNonDemande(res, 'tiktok'); return true; }
    if (errorParam || !code) { oauth.refusOauth(res, 'tiktok', { url }); return true; }
    try {
      const tt = stockage.platformTokens.tiktok;
      const verifier = demande.verifier;

      const tokenRes = await fetch('https://open.tiktokapis.com/v2/oauth/token/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          client_key: tt.clientKey, client_secret: tt.clientSecret, grant_type: 'authorization_code',
          code, redirect_uri: tiktok.TT_REDIRECT_URI, code_verifier: verifier,
        }),
      });
      const data = await tokenRes.json();

      if (!tokenRes.ok || !data.access_token) {
        throw new Error(data.error_description || "Échec de l'échange du code.");
      }
      tt.accessToken = data.access_token;
      tt.refreshToken = data.refresh_token;
      tt.expiresAt = Date.now() + (data.expires_in || 86400) * 1000;
      stockage.saveTokens();
      oauth.pageRetourOauth(res, '✓ TikTok connecté. Tu peux fermer cette page.');
    } catch (e) {
      oauth.refusOauth(res, 'tiktok', { erreur: e });
    }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/setup/instagram/credentials') {
    try {
      // Ceinture sous CHEMINS_INSTAGRAM : jamais d'identifiants Instagram
      // écrits dans une régie reçue en kit.
      instagram.refuserDansUnKit();
      const body = await outilsHttp.readJsonBody(req);
      const avant = stockage.platformTokens.instagram || {};
      const ig = { ...avant, appId: body.appId, appSecret: body.appSecret };
      // Une autre app Meta a pu enregistrer l'autre forme d'adresse de
      // retour : la prochaine connexion repart de « avec » (voir
      // instagram.adresseRetourInstagram).
      if (avant.appId !== body.appId) delete ig.retour;
      stockage.platformTokens.instagram = ig;
      stockage.saveTokens();
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      if (e.dansUnKit) outilsHttp.sendJson(res, 403, { ok: false, dansUnKit: true, error: e.message });
      else outilsHttp.sendJson(res, 400, { ok: false });
    }
    return true;
  }

  // Le dépôt vidéo temporaire (vidéos sous-titrées vers Instagram, voir
  // instagram.envoyerFichierInstagram) : adresse du dépôt + sa clé. Réglé
  // à la main (depot-video/README.md) ; PC seulement (/api/setup/), jamais dans un
  // kit (CHEMINS_INSTAGRAM). La clé n'est jamais renvoyée.
  if (req.method === 'POST' && url.pathname === '/api/setup/instagram/depot-video') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      const adresse = String(body.adresse || '').trim().replace(/\/+$/, '');
      const cle = String(body.cle || '').trim();
      if (!/^https?:\/\/[^?#@\s]+$/.test(adresse) || cle.length < 32) throw new Error('Adresse (https://…) ou clé (32 caractères au moins) invalide.');
      stockage.platformTokens.depotVideo = { adresse, cle };
      stockage.saveTokens();
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false, error: e.message.startsWith('Adresse') ? e.message : 'Requête invalide.' });
    }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/setup/tiktok/credentials') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      stockage.platformTokens.tiktok = { ...(stockage.platformTokens.tiktok || {}), clientKey: body.clientKey, clientSecret: body.clientSecret };
      stockage.saveTokens();
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false });
    }
    return true;
  }

  // Un clip sur YouTube ou Instagram. « sousTitres » : la vidéo est
  // sous-titrée sur ce PC (src/sous-titres.js) puis envoyée en fichier
  // (Instagram : par le dépôt vidéo temporaire) ; si
  // les sous-titres échouent, rien n'est publié et l'erreur le dit.
  const publier = /^\/api\/publish\/(youtube|instagram)$/.exec(url.pathname);
  if (req.method === 'POST' && publier) {
    const plateforme = publier[1];
    try {
      const body = await outilsHttp.readJsonBody(req);
      if (!body.downloadUrl) throw new Error('Lien du clip manquant.');
      // Jeu, date et titre du stream, demandés à Twitch (src/legende-clip.js).
      const infos = await legendeClip.infosClip(routesTwitch.appelerHelix, body.clipId);
      const texte = (srt) => {
        const titre = legendeClip.titreClip({ titre: String(body.title || '') || infos.titre, titresStream: infos.titresStream, jeu: infos.jeu, date: infos.date, srt });
        const profil = etatRegie.obsState.twitchListen && etatRegie.obsState.twitchListen.profile;
        const liens = stockage.platformTokens.liensClips || {};
        const legende = legendeClip.texteClip({ titre, pseudo: pseudos.pseudoParDefautServeur(), login: (profil && profil.login) || '', planning: liens.planning, discord: liens.discord, jeu: infos.jeu });
        return { titre, legende: legendeClip.limiter(legende, plateforme) };
      };
      let lien, publie;
      if (plateforme === 'instagram' && !body.sousTitres) {
        publie = texte('');
        lien = await instagram.uploadToInstagram(body.downloadUrl, publie.legende);
      } else {
        if (plateforme === 'instagram') instagram.verifierDepotVideo();
        const clipRes = await fetch(body.downloadUrl);
        if (!clipRes.ok) throw new Error("Impossible de récupérer la vidéo du clip depuis Twitch.");
        let video = Buffer.from(await clipRes.arrayBuffer());
        let srt = '';
        if (body.sousTitres) ({ video, srt } = await sousTitres.sousTitrer(video));
        publie = texte(srt);
        lien = plateforme === 'youtube'
          ? await youtube.uploadToYoutube(video, legendeClip.titreYoutube(publie.titre), publie.legende)
          : await instagram.envoyerFichierInstagram(video, publie.legende);
      }
      if (body.clipId) enregistrerPublication(String(body.clipId), plateforme, lien, !!body.sousTitres);
      outilsHttp.sendJson(res, 200, { ok: true, url: lien, titre: publie.titre, texte: publie.legende });
    } catch (e) {
      outilsHttp.sendJson(res, 200, { ok: false, error: e.message || String(e) });
    }
    return true;
  }

  // L'ancienne version (sans sous-titres) d'un clip republié sous-titré :
  // supprimée seulement sur accord du streamer (« À valider » de l'agence),
  // depuis le PC, et seulement si la nouvelle est en ligne. Instagram
  // (Instagram Login) ne permet pas la suppression : le streamer la fait à la
  // main puis confirme (faitALaMain).
  if (req.method === 'POST' && url.pathname === '/api/clips/supprimer-ancienne') {
    if (!(acces && acces.pc)) { outilsHttp.sendJson(res, 403, { ok: false, error: 'Suppression réservée au PC.' }); return true; }
    try {
      const body = await outilsHttp.readJsonBody(req);
      const clipId = String(body.clipId || '');
      const plateforme = String(body.platform || '');
      const info = Object.hasOwn(etatRegie.obsState.publishedClips, clipId) ? etatRegie.obsState.publishedClips[clipId][plateforme] : null;
      if (!info || !info.ancienne) throw new Error('Aucune ancienne version à supprimer pour ce clip.');
      if (!info.sousTitres || !info.url) throw new Error('La version sous-titrée n’est pas en ligne : l’ancienne est gardée.');
      if (plateforme === 'youtube') {
        const id = sousTitres.idYoutube(info.ancienne.url);
        if (!id || id === sousTitres.idYoutube(info.url)) throw new Error('Lien de l’ancienne vidéo YouTube illisible : supprime-la à la main (' + info.ancienne.url + ').');
        await youtube.supprimerVideoYoutube(id);
      } else if (!body.faitALaMain) {
        throw new Error('Instagram ne laisse pas la Régie supprimer une publication : supprime l’ancienne à la main (' + info.ancienne.url + '), puis confirme.');
      }
      const { ancienne, ...reste } = info;
      etatRegie.obsState.publishedClips = { ...etatRegie.obsState.publishedClips, [clipId]: { ...etatRegie.obsState.publishedClips[clipId], [plateforme]: reste } };
      stockage.persistSharedState();
      etatRegie.broadcastState();
      outilsHttp.sendJson(res, 200, { ok: true, supprimee: ancienne.url });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false, error: e.message || String(e) });
    }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/publish/tiktok') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      if (!body.downloadUrl) throw new Error('Lien du clip manquant.');
      const clipRes = await fetch(body.downloadUrl);
      if (!clipRes.ok) throw new Error("Impossible de récupérer la vidéo du clip depuis Twitch.");
      const buf = Buffer.from(await clipRes.arrayBuffer());
      await tiktok.uploadToTiktok(buf, body.title);
      outilsHttp.sendJson(res, 200, { ok: true, url: '' });
    } catch (e) {
      outilsHttp.sendJson(res, 200, { ok: false, error: e.message || String(e) });
    }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/clips/published') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      if (!body.clipId || !body.platform) throw new Error('Paramètres manquants.');
      if (!['youtube', 'instagram', 'tiktok'].includes(body.platform)) throw new Error('Plateforme inconnue.');
      // L'adresse devient un lien cliquable dans l'appli (sur le PC aussi) :
      // seulement une adresse web, jamais « javascript: » (voir stockage.lienWebOuVide).
      etatRegie.obsState.publishedClips = { ...etatRegie.obsState.publishedClips, [String(body.clipId)]: { ...(etatRegie.obsState.publishedClips[body.clipId] || {}), [body.platform]: { url: stockage.lienWebOuVide(body.url) } } };
      stockage.persistSharedState();
      etatRegie.broadcastState();
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false, error: e.message });
    }
    return true;
  }

  // ---------- Retour d'autorisation Instagram ----------
  // Meta exige du https pour cette redirection, même en local : ces deux
  // adresses sont à déclarer en https chez Meta, et le port https du pont
  // est celui du pont + 1. Elles vivent ici, dans le gestionnaire partagé,
  // pour qu'il n'y ait qu'un seul endroit où chercher une route.
  // Retour de l'autorisation Instagram, sur https://localhost:4561 : l'adresse
  // déclarée chez Meta (voir /setup), avec ou sans « / » final (voir
  // instagram.adresseRetourInstagram).
  if (req.method === 'GET' && (url.pathname === '/oauth/instagram/callback' || url.pathname === '/oauth/instagram/callback/')) {
    const demande = oauth.consommerEtatOauth('instagram', url.searchParams.get('state'));
    if (!demande) { oauth.retourNonDemande(res, 'instagram'); return true; }
    // Instagram ajoute « #_ » après le code : le navigateur ne l'envoie pas,
    // mais on le retire au cas où.
    const code = String(url.searchParams.get('code') || '').replace(/#_$/, '');
    if (url.searchParams.get('error') || !code) { oauth.refusOauth(res, 'instagram', { url }); return true; }
    // La forme de l'adresse envoyée au départ de CETTE autorisation.
    const forme = demande.forme === 'sans' ? 'sans' : 'avec';
    try {
      const { compte, avertissement } = await instagram.connecterInstagram(code, forme);
      oauth.pageRetourOauth(res, '✓ Instagram connecté (' + compte + ').' + (avertissement ? ' ' + avertissement : ' Tu peux fermer cette page.'));
    } catch (e) {
      // Adresse de retour refusée : ce code est grillé, mais une nouvelle
      // autorisation avec l'autre forme peut aboutir. Une seule relance :
      // au second refus, on s'arrête et on dit quoi vérifier.
      if (e.adresseDeRetour && demande.essai !== 2) {
        const autre = instagram.autreFormeRetour(forme);
        console.warn('[instagram] Adresse de retour ' + forme + ' « / » final refusée à l’échange du code : nouvelle autorisation avec l’adresse ' + autre + ' « / » final.');
        oauth.pageRelanceOauth(res, 'Instagram n’a pas accepté l’adresse de retour (' + forme + ' « / » final). La régie recommence avec l’autre forme : Instagram va te redemander d’autoriser, accepte une seconde fois.',
          instagram.instagramAuthUrl({ forme: autre, essai: 2 }));
        return true;
      }
      if (e.adresseDeRetour) e.message += ' ' + instagram.conseilAdresseRetour();
      oauth.refusOauth(res, 'instagram', { erreur: e });
    }
    return true;
  }

  if (req.method === 'GET' && url.pathname === '/oauth/instagram/start') {
    if (!stockage.platformTokens.instagram || !stockage.platformTokens.instagram.appId) {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end('<p style="font-family:system-ui">Configure d\'abord l\'App ID / App Secret sur <a href="http://127.0.0.1:' + parametres.PORT + '/setup">/setup</a>.</p>');
      return true;
    }
    res.writeHead(302, { Location: instagram.instagramAuthUrl() });
    res.end();
    return true;
  }
  return false;
}
