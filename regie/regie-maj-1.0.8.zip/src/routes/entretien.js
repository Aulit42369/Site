// ============================================================
//  Routes : export et import des réglages, diagnostic, sauvegardes, tout oublier
// ------------------------------------------------------------
//  Appelé par src/routes/index.js, une fois les barrières passées
//  (voir src/securite.js). « acces » dit qui appelle.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  traiter,
};

const fs = require('fs');
const path = require('path');
const { enteteCookieEfface } = require('../appareils.js');

const parametres = require('../parametres.js');
const journalTechnique = require('../journal-technique.js');
const etatRegie = require('../etat-regie.js');
const obs = require('../obs.js');
const minuterie = require('../minuterie.js');
const twitchEcoute = require('../twitch-ecoute.js');
const twitchJeton = require('../twitch-jeton.js');
const outilsHttp = require('../http-outils.js');
const securite = require('../securite.js');
const stockage = require('../stockage.js');
const bilanStream = require('../bilan-stream.js');
const reglagesRegie = require('../reglages-regie.js');
const annonces = require('../annonces.js');
const notifications = require('../notifications.js');
const reseauLocal = require('../reseau-local.js');
const fabriqueKit = require('../kit.js');

// ---------- Configuration : export et import ----------
// Ce qu'on a mis du temps à régler et qu'on n'a aucune envie de refaire :
// les raccourcis de scène, la check-list, les modèles d'annonce, le bouton
// panique, la source texte du compte à rebours et la suite de fin de pause.
//
// Les ACCÈS n'y sont volontairement PAS. C'est ce qui rend le fichier
// partageable et transportable sans risque : on peut le mettre sur une clé,
// l'envoyer, le garder dans un dossier de sauvegarde. Les accès, eux, ont
// leurs propres sauvegardes (data/sauvegardes/) et ne sortent pas du PC.
const CONFIG_VERSION = 1;

// Rend vrai si la demande a été traitée ici.
async function traiter(req, res, url, acces) {
  if (req.method === 'GET' && url.pathname === '/api/config/export') {
    const config = {
      format: 'regie-mobile-config',
      version: CONFIG_VERSION,
      exporteLe: new Date().toISOString(),
      raccourcisScene: etatRegie.obsState.sceneShortcuts,
      checklist: (etatRegie.obsState.checklist || []).map((i) => ({ id: i.id, label: i.label })), // sans les cases cochées
      modelesAnnonce: etatRegie.obsState.reelTemplates,
      couleursAnnonce: etatRegie.obsState.couleursAnnonce,
      panique: etatRegie.obsState.panique,
      minuteur: {
        sourceTexte: minuterie.timerState.textSource,
        texteFin: minuterie.timerState.textFinished,
        retourDans: !!minuterie.timerState.retourDans,
        finParOverlay: !!minuterie.timerState.finParOverlay,
        actionsFin: minuterie.timerState.actionsFin,
      },
      reglesNotifications: notifications.reglesPush,
      shoutout: { commande: etatRegie.obsState.shoutoutCommande },
      // Allumé ou non, sans l'adresse du salon : c'est un accès.
      bilanDiscord: { actif: bilanStream.reglagesBilan().actif },
    };
    const corps = JSON.stringify(config, null, 2);
    res.writeHead(200, {
      'Content-Type': 'application/json; charset=utf-8',
      // Le navigateur propose un enregistrement au lieu d'afficher le JSON.
      'Content-Disposition': 'attachment; filename="config-regie.json"',
      'Content-Length': Buffer.byteLength(corps),
    });
    res.end(corps);
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/config/import') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      const c = body && body.config;
      if (!c || c.format !== 'regie-mobile-config') {
        outilsHttp.sendJson(res, 400, { ok: false, error: 'Ce fichier n’est pas une configuration de régie mobile.' });
        return true;
      }
      if (Number(c.version) > CONFIG_VERSION) {
        outilsHttp.sendJson(res, 400, { ok: false, error: 'Ce fichier vient d’une version plus récente de la régie — mets le pont à jour d’abord.' });
        return true;
      }

      // Chaque partie est reprise seulement si elle est présente ET du bon
      // type. Un fichier incomplet ou abîmé ne doit jamais remplacer un
      // réglage valide par du vide : c'est le genre de perte qu'on ne
      // remarque qu'en pleine pause, au moment où la reprise ne part pas.
      const reprises = [];
      if (Array.isArray(c.raccourcisScene) && c.raccourcisScene.length) {
        etatRegie.obsState.sceneShortcuts = c.raccourcisScene.slice(0, 4).map((r) => ({
          label: String(r.label || '').slice(0, 14),
          scene: String(r.scene || ''),
          couleur: ['cyan', 'amber', 'violet', 'green', 'red'].includes(r.couleur) ? r.couleur : 'cyan',
        }));
        reprises.push('raccourcis de scène');
      }
      if (Array.isArray(c.checklist) && c.checklist.length) {
        etatRegie.obsState.checklist = c.checklist.slice(0, 20).map((i, n) => ({
          id: String(i.id || 'i' + n),
          label: String(i.label || '').slice(0, 80),
          done: false, // on importe la liste, pas l'état d'un autre soir
        }));
        reprises.push('check-list');
      }
      if (Array.isArray(c.modelesAnnonce)) {
        etatRegie.obsState.reelTemplates = c.modelesAnnonce.slice(0, 30);
        reprises.push('modèles d’annonce');
      }
      if (c.couleursAnnonce && typeof c.couleursAnnonce === 'object') {
        etatRegie.obsState.couleursAnnonce = reglagesRegie.nettoyerCouleursAnnonce(c.couleursAnnonce, etatRegie.obsState.couleursAnnonce);
        reprises.push('couleurs de l’annonce');
      }
      if (c.panique && typeof c.panique === 'object') {
        etatRegie.obsState.panique = { scene: String(c.panique.scene || ''), micro: String(c.panique.micro || '') };
        reprises.push('bouton panique');
      }
      if (c.minuteur && typeof c.minuteur === 'object') {
        if (typeof c.minuteur.sourceTexte === 'string') minuterie.timerState.textSource = c.minuteur.sourceTexte;
        if (typeof c.minuteur.texteFin === 'string') minuterie.timerState.textFinished = c.minuteur.texteFin.slice(0, 60);
        if (typeof c.minuteur.retourDans === 'boolean') minuterie.timerState.retourDans = c.minuteur.retourDans;
        if (typeof c.minuteur.finParOverlay === 'boolean') minuterie.timerState.finParOverlay = c.minuteur.finParOverlay;
        if (Array.isArray(c.minuteur.actionsFin)) minuterie.timerState.actionsFin = minuterie.nettoyerActionsFin(c.minuteur.actionsFin);
        reprises.push('minuteur et fin de pause');
      }
      if (c.reglesNotifications && typeof c.reglesNotifications === 'object') {
        notifications.reglesPush = { ...notifications.REGLES_PUSH_DEFAUT, ...c.reglesNotifications };
        notifications.persistPush();
        reprises.push('règles de notification');
      }
      if (c.shoutout && typeof c.shoutout.commande === 'string') {
        etatRegie.obsState.shoutoutCommande = reglagesRegie.nettoyerCommandeShoutout(c.shoutout.commande);
        reprises.push('commande de shoutout');
      }
      if (c.bilanDiscord && typeof c.bilanDiscord.actif === 'boolean') {
        stockage.platformTokens.bilanDiscord = { ...(stockage.platformTokens.bilanDiscord || {}), actif: c.bilanDiscord.actif };
        etatRegie.obsState.bilanDiscord = bilanStream.etatBilanPourAppli();
        reprises.push('bilan sur Discord');
      }

      if (!reprises.length) {
        outilsHttp.sendJson(res, 200, { ok: false, error: 'Ce fichier ne contenait aucun réglage exploitable — rien n’a été changé.' });
        return true;
      }

      reglagesRegie.persistExtras();
      etatRegie.broadcastState();
      minuterie.broadcastTimer();
      annonces.diffuserProgrammations();
      console.log('[pont] Configuration importée : ' + reprises.join(', ') + '.');
      outilsHttp.sendJson(res, 200, { ok: true, reprises });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false, error: 'Fichier illisible : ' + (e.message || e) });
    }
    return true;
  }

  // ---------- Diagnostic ----------
  // Ce que le pont sait de lui-même, lisible depuis le téléphone. Quand
  // quelque chose cloche en direct, c'est ça ou traverser la pièce.
  //
  // Refusé aux pages d'une autre origine : le journal peut contenir des noms
  // de scènes, des pseudos, des messages d'erreur de plateformes. Un overlay
  // n'a aucune raison de lire ça.
  if (req.method === 'GET' && url.pathname === '/api/diagnostic') {
    if (securite.estAutreOrigine(req)) {
      outilsHttp.sendJson(res, 403, { ok: false, error: 'Diagnostic réservé à l’appli servie par le pont.' });
      return true;
    }
    const lignes = Math.min(500, Math.max(20, Number(url.searchParams.get('lignes')) || 120));
    outilsHttp.sendJson(res, 200, {
      ok: true,
      pont: {
        versionNode: process.version,
        depuis: Math.round(process.uptime()),
        port: Number(parametres.PORT),
        adresses: reseauLocal.getLocalIps(),
      },
      obs: { statut: etatRegie.obsState.status, erreur: etatRegie.obsState.error, scenes: (etatRegie.obsState.scenes || []).length },
      twitch: {
        statut: etatRegie.obsState.twitchListen.status,
        erreur: etatRegie.obsState.twitchListen.error,
        avertissement: etatRegie.obsState.twitchListen.warning,
        compte: (etatRegie.obsState.twitchListen.profile && etatRegie.obsState.twitchListen.profile.login) || '',
      },
      compteurs: {
        evenementsEnMemoire: twitchEcoute.twitchEvents.length,
        clientsConnectes: etatRegie.sseClients.size,
        annoncesEnAttente: annonces.publicationsProgrammees.filter((p) => p.statut === 'attente').length,
        appareilsNotifies: notifications.abonnementsPush.length,
      },
      journal: journalTechnique.lireJournalTechnique(lignes),
    });
    return true;
  }

  // ---------- Sauvegardes des accès ----------
  if (req.method === 'GET' && url.pathname === '/api/sauvegardes') {
    outilsHttp.sendJson(res, 200, { ok: true, sauvegardes: stockage.listerSauvegardes() });
    return true;
  }

  // Restaurer remplace tous les accès enregistrés. Volontairement, ça ne
  // tente PAS de tout recharger à chaud : le pont dérive une quinzaine de
  // choses de ce fichier à son démarrage (clips publiés, identifiants
  // Twitch, minuteur, annonces programmées, abonnements aux notifications,
  // reconnexion OBS). Les reconstruire en vol, c'est risquer un état
  // à moitié appliqué — le genre de panne qu'on ne comprend qu'en direct.
  // Le fichier est donc remis en place, et le pont demande un redémarrage :
  // un double-clic sur start.bat, et tout repart d'un état propre.
  if (req.method === 'POST' && url.pathname === '/api/sauvegardes/restaurer') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      const nom = String(body.fichier || '');
      // Motif strict : aucun « / » ni « .. » ne peut passer, donc aucun
      // fichier hors du dossier des sauvegardes.
      if (!/^tokens-[\w-]+\.json$/.test(nom)) {
        outilsHttp.sendJson(res, 400, { ok: false, error: 'Nom de sauvegarde invalide.' });
        return true;
      }
      const source = path.join(stockage.SAUVEGARDES_DIR, nom);
      if (!fs.existsSync(source)) {
        outilsHttp.sendJson(res, 404, { ok: false, error: 'Cette sauvegarde n’existe plus.' });
        return true;
      }
      // On vérifie que la sauvegarde est lisible AVANT de toucher à
      // l'original : restaurer un fichier corrompu par-dessus un fichier
      // sain serait le pire résultat possible.
      let contenu;
      try {
        contenu = JSON.parse(fs.readFileSync(source, 'utf8'));
        if (!contenu || typeof contenu !== 'object' || Array.isArray(contenu)) throw new Error('contenu inattendu');
      } catch (e) {
        outilsHttp.sendJson(res, 200, { ok: false, error: 'Cette sauvegarde est illisible (' + e.message + ') — rien n’a été touché.' });
        return true;
      }
      // L'état actuel devient lui-même une sauvegarde : on peut annuler.
      stockage.tournerSauvegardes();
      // La connexion Twitch par code repose sur un jeton à usage UNIQUE qui
      // change toutes les quatre heures : celui d'une sauvegarde a presque
      // toujours déjà servi. Restaurer la sauvegarde telle quelle cassait
      // donc la connexion au redémarrage. On garde la connexion ACTUELLE.
      if (twitchJeton.twitchRafraichissement && twitchJeton.twitchRafraichissement.refreshToken) {
        contenu.twitch = etatRegie.obsState.twitchCreds;
        contenu.twitchAppareil = twitchJeton.twitchRafraichissement;
      }
      // Les appareils reliés restent ceux d'AUJOURD'HUI : une vieille
      // sauvegarde ferait revenir un téléphone retiré depuis (perdu, prêté),
      // et délierait ceux reliés après elle.
      if (Array.isArray(stockage.platformTokens.appareils)) contenu.appareils = stockage.platformTokens.appareils;
      else delete contenu.appareils;
      // … et ce qu'un appareil retiré depuis la sauvegarde avait laissé
      // (abonnement aux notifications, annonce programmée) ne revient pas
      // avec elle : seuls restent ceux du PC (par vide) et des appareils reliés.
      const relies = new Set((stockage.platformTokens.appareils || []).map((a) => a.id));
      const encoreRelie = (x) => !x || !x.par || relies.has(x.par);
      if (Array.isArray(contenu.abonnementsPush)) contenu.abonnementsPush = contenu.abonnementsPush.filter(encoreRelie);
      if (Array.isArray(contenu.publicationsProgrammees)) contenu.publicationsProgrammees = contenu.publicationsProgrammees.filter(encoreRelie);
      // Les comptes YouTube, Instagram et TikTok ne se configurent que sur le PC
      // (/setup) : restaurée depuis un autre appareil, une sauvegarde garde ceux
      // d'AUJOURD'HUI — sinon un téléphone prêté ou retiré trop tard pouvait
      // remettre un ancien compte ou un ancien secret. Depuis le PC, tout revient.
      const comptesGardes = (acces && acces.pc) ? [] : ['youtube', 'instagram', 'tiktok', 'depotVideo'];
      // Dans une régie reçue en kit, Instagram et ses relais (imgbb, dépôt
      // vidéo) ne reviennent jamais d'une sauvegarde, même depuis le PC :
      // ceux d'aujourd'hui restent (en pratique, aucun).
      const ignores = fabriqueKit.dansUnKit() ? ['instagram', 'imgbb', 'depotVideo'] : [];
      for (const cle of [...new Set([...comptesGardes, ...ignores])]) {
        if (stockage.platformTokens[cle]) contenu[cle] = stockage.platformTokens[cle];
        else delete contenu[cle];
      }
      const tmp = stockage.TOKENS_FILE + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(contenu, null, 2));
      stockage.renommerAvecPatience(tmp, stockage.TOKENS_FILE);
      // Ce qui sera écrit d'ici au redémarrage (un jeton Twitch renouvelé,
      // par exemple) part désormais dans le fichier restauré, au lieu de le
      // recouvrir avec les anciens accès.
      stockage.platformTokens = contenu;
      outilsHttp.sendJson(res, 200, {
        ok: true,
        redemarrage: true,
        message: 'Accès restaurés. Ferme la fenêtre noire du pont et relance start.bat pour qu’ils prennent effet.'
          + (comptesGardes.length ? ' Les comptes YouTube, Instagram et TikTok restent ceux d’aujourd’hui : pour les restaurer aussi, fais-le depuis le PC.' : ''),
      });
    } catch (e) {
      outilsHttp.sendJson(res, 500, { ok: false, error: e.message });
    }
    return true;
  }

  // ---------- Tout oublier ----------
  // Le bouton « Effacer toutes les données » ne vidait que le navigateur :
  // le pont gardait les identifiants OBS, Twitch, Bluesky, imgbb, YouTube,
  // Instagram et TikTok, et se reconnectait au démarrage suivant. Celui qui
  // donnait son dossier à quelqu'un d'autre partageait donc ses accès.
  if (req.method === 'POST' && url.pathname === '/api/oublier-tout') {
    // Action irréversible : un corps explicite évite l'appel par mégarde (lien, script).
    const demande = await outilsHttp.readJsonBody(req).catch(() => null);
    if (!demande || demande.confirmer !== 'OUBLIER') {
      outilsHttp.sendJson(res, 400, { ok: false, error: 'Confirmation manquante.' });
      return true;
    }
    try {
      // Une sauvegarde FORCÉE ici, et pas seulement celle du démarrage :
      // c'est l'instant précis où l'on voudra pouvoir revenir en arrière,
      // et un accès ajouté depuis le lancement du pont ne figurerait dans
      // aucune copie sans cette ligne.
      stockage.tournerSauvegardes();

      twitchEcoute.disconnectTwitchListen();
      obs.obsManualDisconnect = true;
      if (obs.obsWs) { try { obs.obsWs.close(); } catch (e) {} }

      stockage.platformTokens = {};
      // … et les codes de liaison encore en attente (la liste vient d'être
      // vidée : retirerTous n'écrit rien, il oublie les codes).
      securite.appareils.retirerTous();
      // Les appareils reliés partent avec le reste : leurs flux sont coupés,
      // et chacun devra être relié de nouveau avec un code du PC.
      etatRegie.fermerFluxAppareils(null);
      if (acces && acces.appareil) res.setHeader('Set-Cookie', enteteCookieEfface());
      etatRegie.obsState.appareilsMaj = Date.now();
      etatRegie.obsState.twitchCreds = { clientId: '', token: '' };
      twitchJeton.twitchRafraichissement = null;
      twitchJeton.arreterInterrogationCode();
      etatRegie.obsState.twitchCode = { ...etatRegie.obsState.twitchCode, etape: 'inactif', code: '', lien: '', expireA: 0, erreur: '' };
      etatRegie.obsState.youtubeConfigure = false;
      etatRegie.obsState.obsDetection = { etat: 'inconnu', source: '', port: 0 };
      etatRegie.obsState.blueskyConnected = false;
      etatRegie.obsState.blueskyHandle = '';
      etatRegie.obsState.imgbbConfigured = false;
      etatRegie.obsState.discordConfigured = false;
      // L'autre salon du bilan est un accès comme les autres : parti avec.
      etatRegie.obsState.bilanDiscord = bilanStream.etatBilanPourAppli();
      etatRegie.obsState.annoncesDiscord = { configure: false };
      etatRegie.obsState.publishedClips = {};
      etatRegie.obsState.sessionHistory = [];
      etatRegie.obsState.preparedStreamInfo = { title: '', categoryId: '', categoryName: '', tags: [] };
      etatRegie.obsState.infosStreamPrecedentes = null;
      etatRegie.obsState.panique = { scene: '', micro: '' };
      etatRegie.obsState.hypeTrain = { active: false, level: 0, progress: 0, goal: 1, total: 0 };
      twitchEcoute.twitchEvents.length = 0;

      // Les abonnements aux notifications sont liés à une clé VAPID qui vient
      // de disparaître avec le reste : les garder ne servirait à rien, et une
      // écriture ultérieure les aurait remis dans le fichier tout neuf —
      // ressuscitant des accès qu'on venait d'effacer.
      notifications.abonnementsPush = [];
      notifications.reglesPush = { ...notifications.REGLES_PUSH_DEFAUT };

      // Les annonces encore en attente visaient des comptes qui n'existent
      // plus ici : les laisser programmées, c'était garantir une volée
      // d'échecs à l'heure dite. On les retire, images comprises.
      for (const p of annonces.publicationsProgrammees) annonces.supprimerImageAnnonce(p.contenu && p.contenu.image);
      annonces.publicationsProgrammees = [];

      // Enregistré APRÈS les remises à zéro, pour que le fichier reflète
      // exactement ce qui reste en mémoire. Sans ça, le premier réglage
      // touché ensuite (une case de la check-list, un raccourci) réécrivait
      // tout un lot de champs par effet de bord.
      stockage.saveTokens();
      reglagesRegie.persistExtras();
      etatRegie.broadcastState();
      annonces.diffuserProgrammations();
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 500, { ok: false, error: e.message });
    }
    return true;
  }
  return false;
}
