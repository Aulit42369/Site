// ============================================================
//  Le texte d'un clip publié (YouTube : description, Instagram : légende)
// ------------------------------------------------------------
//  Titre du clip, chaîne Twitch reliée, liens du planning et du
//  Discord (réglés sur /setup), hashtags #Twitch #Clip + le jeu.
//  Titre vide ou simple titre du stream : la Régie en fabrique un,
//  sans IA externe (phrase forte des sous-titres, sinon « <Jeu> :
//  moment du live du <date> »). Rien d'Aulit en dur : la Régie
//  part en kit.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  hashtagJeu,
  infosClip,
  limiter,
  nettoyerLien,
  phraseForte,
  texteClip,
  titreClip,
  titreYoutube,
};

// Règles des plateformes : Instagram 2 200 caractères et 30 hashtags (Meta),
// YouTube 5 000 caractères de description, 100 de titre, sans « < » ni « > ».
const LIMITES = { instagram: { car: 2200, hashtags: 30 }, youtube: { car: 5000, hashtags: Infinity } };
const TITRE_GENERE_MAX = 60;

// « 7 Days to Die » → « #7DaysToDie », « VALORANT » → « #Valorant ». '' si rien d'utilisable.
function hashtagJeu(nom) {
  const mots = String(nom || '').replace(/['’]/g, '').split(/[^\p{L}\p{N}]+/u).filter(Boolean);
  const tag = mots.map((m) => {
    // Un mot tout en capitales (> 4 lettres) est un nom stylisé : « VALORANT ». Les sigles courts restent (GTA, FC).
    const mot = m.length > 4 && m === m.toUpperCase() ? m.toLowerCase() : m;
    return mot[0].toUpperCase() + mot.slice(1);
  }).join('');
  return tag ? '#' + tag : '';
}

// Un lien saisi sur /setup, affiché sans « https:// » : « » si vide, null si ce n'est pas un lien.
function nettoyerLien(texte) {
  const l = String(texte || '').trim().replace(/^https?:\/\//i, '').replace(/\/+$/, '');
  if (!l) return '';
  return l.length <= 200 && /^[\p{L}\p{N}-]+(\.[\p{L}\p{N}-]+)+(\/[^\s<>"]*)?$/u.test(l) ? l : null;
}

// La phrase la plus « forte » d'un .srt : complète (majuscule au début,
// ponctuation à la fin), 2 mots au moins, 60 caractères au plus.
// ! = 3 points, ? = 2, cri (MOT EN CAPITALES, « noooon ») = 2 ; à égalité, la première. '' si aucune.
function phraseForte(srt) {
  const repliques = String(srt || '').replace(/\r/g, '').split(/\n\s*\n/)
    .map((bloc) => bloc.split('\n').filter((l) => l.trim() && !/^\d+$/.test(l.trim()) && !/-->/.test(l)).join(' ')
      .replace(/<[^>]*>/g, '').replace(/\s+/g, ' ').trim())
    .filter(Boolean);
  // Une réplique suivie d'une minuscule continue la même phrase ; sinon, une
  // coupure. Une bribe sans ponctuation finale est une phrase coupée : jamais prise.
  const texte = repliques.reduce((acc, r) => (acc ? acc + (/^\p{Ll}/u.test(r) ? ' ' : '\n') + r : r), '');
  const phrases = texte.match(/[^.!?…\n]+[.!?…]+/g) || [];
  let meilleure = '', score = -1;
  for (const brute of phrases) {
    const p = brute.trim();
    if (p.length > TITRE_GENERE_MAX || p.split(' ').length < 2 || !/^[\p{Lu}\p{N}«"]/u.test(p)) continue;
    const s = (p.includes('!') ? 3 : 0) + (p.includes('?') ? 2 : 0)
      + (/\b\p{Lu}{3,}\b/u.test(p) || /(\p{L})\1\1/u.test(p) ? 2 : 0);
    if (s > score) { meilleure = p; score = s; }
  }
  return meilleure.replace(/(?<![.!?…])\.$/, '');
}

function dateFr(iso) {
  const d = iso ? new Date(iso) : new Date();
  return (isNaN(d) ? new Date() : d).toLocaleDateString('fr-FR', { timeZone: 'Europe/Paris', day: 'numeric', month: 'long' });
}

// Le titre publié. Celui du clip, sauf s'il est vide ou n'est que le titre
// du stream (titre par défaut d'un clip Twitch) : phrase forte des
// sous-titres, sinon « <Jeu> : moment du live du <date> ».
function titreClip({ titre, titresStream = [], jeu, date, srt } = {}) {
  const t = String(titre || '').replace(/\s+/g, ' ').trim();
  const pareil = (a) => String(a || '').replace(/\s+/g, ' ').trim().toLowerCase() === t.toLowerCase();
  if (t && !titresStream.some(pareil)) return t;
  const phrase = phraseForte(srt);
  if (phrase) return phrase;
  return (jeu ? jeu + ' : m' : 'M') + 'oment du live du ' + dateFr(date);
}

// YouTube refuse « < » et « > » et coupe à 100 caractères.
function titreYoutube(titre) {
  return Array.from(String(titre || 'Clip').replace(/[<>]/g, '').trim() || 'Clip').slice(0, 100).join('').trim();
}

// Le texte complet. Une ligne dont la donnée manque est retirée.
function texteClip({ titre, pseudo, login, planning, discord, jeu } = {}) {
  const nom = pseudo || login || '';
  const de = !nom ? '' : (/^[aeiouyhàâäéèêëîïôöûü]/i.test(nom) ? " d'" : ' de ') + nom;
  const pied = [
    '🎮 Clip du live Twitch' + de,
    login ? 'Viens rigoler en direct : twitch.tv/' + login : '',
    planning ? '📅 Planning : ' + planning : '',
    discord ? '💬 Discord : ' + discord : '',
  ].filter(Boolean).join('\n');
  const tags = ['#Twitch', '#Clip', hashtagJeu(jeu)].filter(Boolean).join(' ');
  return [String(titre || '').trim(), pied, tags].filter(Boolean).join('\n\n');
}

// Le texte aux règles d'une plateforme : hashtags en trop (les premiers, ceux
// du titre) gardés en simple mot, puis la première ligne (le titre) raccourcie.
function limiter(texte, plateforme) {
  const lim = LIMITES[plateforme];
  let t = String(texte || '');
  if (plateforme === 'youtube') t = t.replace(/[<>]/g, '');
  const tags = t.match(/#[\p{L}\p{N}_]+/gu) || [];
  let enTrop = tags.length - lim.hashtags;
  if (enTrop > 0) t = t.replace(/#(?=[\p{L}\p{N}_])/gu, (m) => (enTrop-- > 0 ? '' : m));
  const car = Array.from(t);
  if (car.length <= lim.car) return t;
  const coupure = t.indexOf('\n');
  const reste = coupure < 0 ? '' : t.slice(coupure);
  const place = lim.car - Array.from(reste).length - 1;
  if (place < 1) return car.slice(0, lim.car).join('');
  return Array.from(coupure < 0 ? t : t.slice(0, coupure)).slice(0, place).join('').trimEnd() + '…' + reste;
}

// Ce que Twitch sait du clip : { titre, jeu, date, titresStream }. Ne lève
// jamais : sans Twitch, la publication part avec ce qu'on a.
// « helix » = appelerHelix de src/routes/twitch.js.
async function infosClip(helix, clipId) {
  const infos = { titre: '', jeu: '', date: '', titresStream: [] };
  if (!clipId) return infos;
  const premier = async (chemin) => {
    try { const r = await helix(chemin, 'GET'); return (r.ok && Array.isArray(r.donnees.data) && r.donnees.data[0]) || null; } catch (e) { return null; }
  };
  const clip = await premier('/helix/clips?id=' + encodeURIComponent(clipId));
  if (!clip) return infos;
  infos.titre = clip.title || '';
  infos.date = clip.created_at || '';
  const [jeu, video, chaine] = await Promise.all([
    clip.game_id ? premier('/helix/games?id=' + encodeURIComponent(clip.game_id)) : null,
    clip.video_id ? premier('/helix/videos?id=' + encodeURIComponent(clip.video_id)) : null,
    clip.broadcaster_id ? premier('/helix/channels?broadcaster_id=' + encodeURIComponent(clip.broadcaster_id)) : null,
  ]);
  infos.jeu = (jeu && jeu.name) || '';
  // Le titre du stream du clip (sa VOD) et celui de la chaîne en ce moment.
  infos.titresStream = [video && video.title, chaine && chaine.title].filter(Boolean);
  return infos;
}
