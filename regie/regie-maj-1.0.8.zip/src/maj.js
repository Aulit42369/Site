// ============================================================
//  Mise à jour signée de la régie
// ------------------------------------------------------------
//  Toutes les régies regardent, au démarrage puis toutes les 24 h,
//  version.json sur le site d'Olivier (parametres.MAJ_URL). Une
//  version plus récente, signée par la clé d'Olivier (Ed25519, clé
//  publique dans maj-cle-publique.js), est proposée dans l'appli ;
//  rien ne s'installe sans un clic. La régie d'Olivier (régie
//  « source », celle qui a public/src/) la voit en lecture seule et
//  publie les mises à jour depuis la page /kit.
//
//  Installer : téléchargement https, taille + sha256 + signature,
//  zip lu et vérifié EN ENTIER en mémoire avant la première
//  écriture, sauvegarde des fichiers remplacés dans maj-precedente/,
//  puis redémarrage (par le lanceur s'il est là). Voir
//  ARCHITECTURE.md, « Mise à jour automatique signée ».
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  apkLocale,
  cheminApkVerifiee,
  comparerVersions,
  demarrer,
  envoyer,
  estRegieSource,
  etat,
  fabriquerMiseAJour,
  infosPublication,
  installer,
  messageSigne,
  publier,
  revenir,
  verifier,
  versionActuelle,
};

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');

const parametres = require('./parametres.js');
const etatRegie = require('./etat-regie.js');
const arret = require('./arret.js');
const fabriqueKit = require('./kit.js');
const { creerZip, lireZip } = require('./zip.js');

const PRECEDENTE = 'maj-precedente';
const TAILLE_MAX = 100 * 1024 * 1024;
const JOUR_MS = 24 * 60 * 60 * 1000;

let derniere = null;      // le dernier version.json vérifié, plus récent que la version installée
let enCours = false;      // une installation (ou un retour) à la fois
let redemarrage = '';     // '', 'auto' (le lanceur relance), 'manuel' (« Redémarre la régie »)

const racine = () => parametres.RACINE;
const sha256 = (tampon) => crypto.createHash('sha256').update(tampon).digest('hex');

// ---------- Versions ----------
function analyser(v) {
  const m = /^(\d{1,6})\.(\d{1,6})\.(\d{1,6})$/.exec(String(v || '').trim());
  return m ? [Number(m[1]), Number(m[2]), Number(m[3])] : null;
}

function comparerVersions(a, b) {
  const x = analyser(a) || [0, 0, 0];
  const y = analyser(b) || [0, 0, 0];
  for (let i = 0; i < 3; i += 1) if (x[i] !== y[i]) return x[i] < y[i] ? -1 : 1;
  return 0;
}

// La version installée : celle de package.json. Absente (régie d'un kit
// d'avant le 25/10) : 0.0.0, donc toute version publiée est plus récente.
function versionActuelle() {
  try {
    const v = JSON.parse(fs.readFileSync(path.join(racine(), 'package.json'), 'utf8')).version;
    return analyser(v) ? String(v).trim() : '0.0.0';
  } catch (e) { return '0.0.0'; }
}

// La régie d'Olivier : la seule qui a les sources de l'appli (public/src/,
// jamais dans un kit ni une mise à jour). Elle publie, n'installe jamais :
// une installation écraserait ses sources de travail.
function estRegieSource() {
  return fs.existsSync(path.join(racine(), 'public', 'src'));
}

// ---------- Signature ----------
function messageSigne(info) {
  return info.version + '|' + info.sha256 + '|' + info.taille
    + (info.apk ? '|apk:' + info.apk.versionCode + ':' + info.apk.sha256 : '');
}

function signatureValide(info) {
  const cle = require('./maj-cle-publique.js').CLE_PUBLIQUE_MAJ;
  if (!cle || typeof info.signature !== 'string' || !info.signature) return false;
  try {
    const publique = crypto.createPublicKey({ key: Buffer.from(cle, 'base64'), format: 'der', type: 'spki' });
    return crypto.verify(null, Buffer.from(messageSigne(info), 'utf8'), publique, Buffer.from(info.signature, 'base64'));
  } catch (e) { return false; }
}

// https seulement. Exception : 127.0.0.1 en http, pour le faux serveur des
// contrôles (la signature protège de toute façon le contenu).
function adresseAutorisee(adresse) {
  try {
    const u = new URL(adresse);
    return u.protocol === 'https:' || (u.protocol === 'http:' && u.hostname === '127.0.0.1');
  } catch (e) { return false; }
}

const HEX64 = /^[0-9a-f]{64}$/;
function nettoyerInfo(j) {
  if (!j || typeof j !== 'object') return null;
  const taille = Number(j.taille);
  const info = {
    version: String(j.version || '').trim(),
    date: String(j.date || '').slice(0, 40),
    notes: String(j.notes || '').slice(0, 4000),
    sha256: String(j.sha256 || '').toLowerCase(),
    taille,
    url: String(j.url || ''),
    signature: typeof j.signature === 'string' ? j.signature : '',
  };
  if (!analyser(info.version) || !HEX64.test(info.sha256) || !Number.isInteger(taille) || taille < 1 || taille > TAILLE_MAX || !adresseAutorisee(info.url)) return null;
  if (j.apk) {
    const code = Number(j.apk.versionCode);
    const empreinte = String(j.apk.sha256 || '').toLowerCase();
    if (!Number.isInteger(code) || code < 1 || !HEX64.test(empreinte)) return null;
    info.apk = { versionCode: code, sha256: empreinte };
  }
  return info;
}

// ---------- Vérifier ----------
// null : rien d'utilisable (pas de réseau, rien de publié, mal signé). Pas de
// réseau = silence ; mal signé = une ligne dans le journal.
// L'adresse principale, puis le repli (MAJ_URL_SECOURS) si elle ne donne rien
// d'utilisable : chacune passe par la même vérification de signature.
async function lireVersionDistante() {
  for (const adresse of [parametres.MAJ_URL, parametres.MAJ_URL_SECOURS].filter(Boolean)) {
    const info = await lireVersionA(adresse);
    if (info) return info;
  }
  return null;
}

async function lireVersionA(adresse) {
  if (!adresseAutorisee(adresse)) {
    console.warn('[maj] Adresse de vérification refusée (https seulement) : ' + adresse.slice(0, 120) + '.');
    return null;
  }
  let r;
  try {
    r = await fetch(adresse, { signal: AbortSignal.timeout(10000), headers: { Accept: 'application/json' }, cache: 'no-store' });
  } catch (e) { return null; }
  if (!r.ok) return null;
  let j;
  try { j = await r.json(); } catch (e) { console.warn('[maj] version.json ignoré : illisible.'); return null; }
  const info = nettoyerInfo(j);
  if (!info) { console.warn('[maj] version.json ignoré : champs manquants ou invalides.'); return null; }
  if (!signatureValide(info)) { console.warn('[maj] version.json ignoré : signature absente ou invalide (version ' + info.version + ').'); return null; }
  info.lu = adresse;
  return info;
}

async function verifier() {
  const info = await lireVersionDistante();
  if (info) derniere = comparerVersions(info.version, versionActuelle()) > 0 ? info : null;
  publierEtat();
  return etat();
}

// ---------- L'état diffusé à l'appli ----------
function lireManifeste() {
  try { return JSON.parse(fs.readFileSync(path.join(racine(), PRECEDENTE, 'manifeste.json'), 'utf8')); } catch (e) { return null; }
}

function etat() {
  const m = lireManifeste();
  const actuelle = versionActuelle();
  const apk = apkLocale();
  return {
    actuelle,
    disponible: derniere && comparerVersions(derniere.version, actuelle) > 0
      ? { version: derniere.version, notes: derniere.notes, date: derniere.date } : null,
    lectureSeule: estRegieSource(),
    precedente: m && m.etat === 'fait' ? String(m.depuis || '') : null,
    enCours,
    redemarrage,
    apk: apk ? { versionCode: apk.versionCode } : null,
  };
}

function publierEtat() {
  etatRegie.obsState.miseAJour = etat();
  etatRegie.broadcastPatch({ miseAJour: etatRegie.obsState.miseAJour });
}

// ---------- Installer ----------
// Le zip annoncé, sinon le même nom à côté du version.json lu (repli) : sa
// taille et son sha256 signés sont vérifiés pareil.
async function telecharger(info) {
  const nom = path.posix.basename(new URL(info.url).pathname);
  const adresses = [...new Set([info.url, info.lu ? new URL(nom, info.lu).href : info.url])];
  let erreur;
  for (const adresse of adresses) {
    try { return await telechargerDe(adresse, info); } catch (e) { erreur = e; }
  }
  throw erreur;
}

async function telechargerDe(adresse, info) {
  const r = await fetch(adresse, { signal: AbortSignal.timeout(5 * 60 * 1000) });
  if (!r.ok) throw new Error('Téléchargement refusé par le site (code ' + r.status + ').');
  if (!adresseAutorisee(r.url)) throw new Error('Téléchargement refusé : adresse non sécurisée.');
  const annonce = Number(r.headers.get('content-length'));
  if (annonce && annonce !== info.taille) throw new Error('Téléchargement refusé : taille inattendue.');
  const morceaux = [];
  let lu = 0;
  for await (const morceau of r.body) {
    lu += morceau.length;
    if (lu > info.taille) throw new Error('Téléchargement refusé : plus gros qu’annoncé.');
    morceaux.push(Buffer.from(morceau));
  }
  const tampon = Buffer.concat(morceaux);
  if (tampon.length !== info.taille) throw new Error('Téléchargement incomplet.');
  if (sha256(tampon) !== info.sha256) throw new Error('Fichier refusé : son empreinte (sha256) ne correspond pas à la version signée.');
  return tampon;
}

// Tout ce qui pourrait écrire ailleurs que dans le dossier de la régie, ou
// sur un fichier personnel, fait refuser TOUTE la mise à jour.
function verifierEntrees(entrees, info) {
  const base = path.resolve(racine());
  const vus = new Set();
  for (const { nom } of entrees) {
    const segments = nom.split('/');
    if (!nom || nom.length > 300 || /[\\:\0~]/.test(nom) || nom.startsWith('/')
      || segments.some((s) => s === '' || s === '.' || s === '..' || /[. ]$/.test(s))) {
      throw new Error('Mise à jour refusée : chemin interdit (' + nom.slice(0, 80) + ').');
    }
    const cible = path.resolve(base, nom);
    if (!cible.startsWith(base + path.sep)) throw new Error('Mise à jour refusée : chemin hors du dossier (' + nom.slice(0, 80) + ').');
    if (fabriqueKit.JAMAIS_DANS_UN_ZIP.test(nom) || fabriqueKit.HORS_MISE_A_JOUR.test(nom)) {
      throw new Error('Mise à jour refusée : elle contient ' + nom.slice(0, 80) + ', qui ne doit jamais en faire partie.');
    }
    if (vus.has(nom.toLowerCase())) throw new Error('Mise à jour refusée : fichier en double (' + nom.slice(0, 80) + ').');
    vus.add(nom.toLowerCase());
  }
  const paquet = entrees.find((e) => e.nom === 'package.json');
  let versionZip = '';
  try { versionZip = JSON.parse(paquet.donnees.toString('utf8')).version; } catch (e) { /* vérifié juste après */ }
  if (!entrees.some((e) => e.nom === 'server.js') || versionZip !== info.version) {
    throw new Error('Mise à jour refusée : ce zip n’est pas la version ' + info.version + ' de la régie.');
  }
}

function ecrireFichier(cible, donnees) {
  fs.mkdirSync(path.dirname(cible), { recursive: true });
  const tmp = cible + '.maj-tmp';
  fs.writeFileSync(tmp, donnees);
  try {
    fs.renameSync(tmp, cible);
  } catch (e) {
    // Windows : un antivirus qui lit le fichier fait échouer le renommage.
    fs.copyFileSync(tmp, cible);
    try { fs.unlinkSync(tmp); } catch (e2) { /* sans importance */ }
  }
}

function ecrireManifeste(m) {
  ecrireFichier(path.join(racine(), PRECEDENTE, 'manifeste.json'), JSON.stringify(m, null, 2) + '\n');
}

// Remet les fichiers d'avant la mise à jour et retire ceux qu'elle avait
// ajoutés. Sert au retour en arrière ET à une installation interrompue.
function restaurer(m) {
  const dossier = path.join(racine(), PRECEDENTE, 'fichiers');
  for (const nom of m.remplaces || []) {
    const sauve = path.join(dossier, nom);
    if (fs.existsSync(sauve)) ecrireFichier(path.join(racine(), nom), fs.readFileSync(sauve));
  }
  for (const nom of m.nouveaux || []) fs.rmSync(path.join(racine(), nom), { force: true });
  fs.rmSync(path.join(racine(), PRECEDENTE), { recursive: true, force: true });
}

function appliquer(entrees, version) {
  const dossier = path.join(racine(), PRECEDENTE);
  fs.rmSync(dossier, { recursive: true, force: true });
  const existe = (nom) => fs.existsSync(path.join(racine(), nom));
  const m = {
    etat: 'en cours',
    depuis: versionActuelle(),
    vers: version,
    date: new Date().toISOString(),
    remplaces: entrees.filter((e) => existe(e.nom)).map((e) => e.nom),
    nouveaux: entrees.filter((e) => !existe(e.nom)).map((e) => e.nom),
  };
  // Le manifeste d'abord : un pont arrêté en pleine copie sait, au démarrage
  // suivant, quoi remettre.
  ecrireManifeste(m);
  for (const nom of m.remplaces) {
    const sauve = path.join(dossier, 'fichiers', nom);
    fs.mkdirSync(path.dirname(sauve), { recursive: true });
    fs.copyFileSync(path.join(racine(), nom), sauve);
  }
  try {
    for (const e of entrees) ecrireFichier(path.join(racine(), e.nom), e.donnees);
  } catch (err) {
    restaurer(m);
    throw new Error('Mise à jour interrompue (' + err.message + ') : l’ancienne version est remise.');
  }
  ecrireManifeste({ ...m, etat: 'fait' });
}

// Lancé par Regie mobile.exe : le pont s'arrête proprement et le lanceur le
// relance tout seul (lanceur/pont.c, surArretDuPont). Avec start.bat : à la
// personne de relancer.
function planifierRedemarrage() {
  if (parametres.LANCE_PAR_EXE) {
    redemarrage = 'auto';
    setTimeout(() => arret.arreter('mise à jour'), 1500);
  } else {
    redemarrage = 'manuel';
  }
}

async function installer() {
  if (estRegieSource()) throw new Error('Régie d’Olivier (sources présentes) : la mise à jour ne s’y installe pas, elle s’y publie.');
  if (enCours) throw new Error('Une installation est déjà en cours.');
  enCours = true;
  publierEtat();
  try {
    const info = await lireVersionDistante();
    if (!info) throw new Error('La version publiée est injoignable ou mal signée : rien n’est installé.');
    if (comparerVersions(info.version, versionActuelle()) <= 0) throw new Error('Aucune version plus récente à installer.');
    const zip = await telecharger(info);
    const entrees = lireZip(zip).filter((e) => !e.nom.endsWith('/'));
    verifierEntrees(entrees, info);
    appliquer(entrees, info.version);
    derniere = null;
    console.log('[maj] Version ' + info.version + ' installée (' + entrees.length + ' fichiers).');
    planifierRedemarrage();
    return { ok: true, version: info.version, redemarrage };
  } finally {
    enCours = false;
    publierEtat();
  }
}

function revenir() {
  if (estRegieSource()) throw new Error('Régie d’Olivier : pas de retour en arrière par ici.');
  if (enCours) throw new Error('Une installation est en cours.');
  const m = lireManifeste();
  if (!m || m.etat !== 'fait') throw new Error('Aucune version précédente gardée.');
  restaurer(m);
  console.log('[maj] Retour à la version ' + versionActuelle() + '.');
  planifierRedemarrage();
  publierEtat();
  return { ok: true, version: versionActuelle(), redemarrage };
}

// ---------- L'appli téléphone (APK) ----------
// regie-mobile.apk.json arrive dans la mise à jour signée, avec l'APK : il
// dit quel versionCode la régie peut servir et quelle empreinte vérifier.
function apkLocale() {
  try {
    const m = JSON.parse(fs.readFileSync(path.join(racine(), 'regie-mobile.apk.json'), 'utf8'));
    const code = Number(m.versionCode);
    const empreinte = String(m.sha256 || '').toLowerCase();
    return Number.isInteger(code) && code > 0 && HEX64.test(empreinte) ? { versionCode: code, sha256: empreinte } : null;
  } catch (e) { return null; }
}

// Le chemin de l'APK, seulement si elle a l'empreinte annoncée.
function cheminApkVerifiee() {
  const a = apkLocale();
  if (!a) return null;
  const chemin = path.join(racine(), 'regie-mobile.apk');
  try { return sha256(fs.readFileSync(chemin)) === a.sha256 ? chemin : null; } catch (e) { return null; }
}

// ---------- Publier (régie d'Olivier) ----------
const CLE_PRIVEE = () => path.join(racine(), 'cle-mise-a-jour', 'cle-privee.pem');

function infosPublication() {
  const v = analyser(versionActuelle()) || [0, 0, 0];
  return {
    peutPublier: estRegieSource() && !fabriqueKit.dansUnKit(),
    cle: fs.existsSync(CLE_PRIVEE()),
    actuelle: versionActuelle(),
    suivante: v[0] + '.' + v[1] + '.' + (v[2] + 1),
    dossier: parametres.MAJ_DOSSIER_PUBLICATION,
    apkPresente: fs.existsSync(path.join(racine(), 'regie-mobile.apk')),
    envoi,
  };
}

// Le zip : une liste autorisée (comme le kit), puis le refus final par les
// deux listes uniques de kit.js.
async function fabriquerMiseAJour(options) {
  const avecApk = !!(options && options.avecApk);
  const entrees = [];
  const ajouter = (relatif) => {
    const complet = path.join(racine(), relatif);
    if (!fs.existsSync(complet)) return;
    entrees.push({ nom: relatif.split(path.sep).join('/'), donnees: fs.readFileSync(complet), date: fs.statSync(complet).mtime });
  };
  const parcourir = (relatif, garder) => {
    const complet = path.join(racine(), relatif);
    if (!fs.existsSync(complet)) return;
    for (const nom of fs.readdirSync(complet)) {
      if (nom.startsWith('.')) continue;
      const r = path.join(relatif, nom);
      const rSlash = r.split(path.sep).join('/');
      if (fs.statSync(path.join(racine(), r)).isDirectory()) { if (garder(rSlash + '/')) parcourir(r, garder); } else if (garder(rSlash)) ajouter(r);
    }
  };
  for (const f of ['server.js', 'package.json', 'start.bat', '.env.example']) ajouter(f);
  parcourir('src', () => true);
  parcourir('public', (r) => !r.startsWith('public/src/') && r !== 'public/config.js');
  ajouter(path.join('reel', 'template.html'));
  ajouter(path.join('reel', 'backgrounds', 'default.jpg'));
  if (avecApk) { ajouter('regie-mobile.apk'); ajouter('regie-mobile.apk.json'); }
  const interdit = entrees.find((e) => fabriqueKit.JAMAIS_DANS_UN_ZIP.test(e.nom) || fabriqueKit.HORS_MISE_A_JOUR.test(e.nom));
  if (interdit) throw new Error('Refusé : ' + interdit.nom + ' ne doit jamais partir dans une mise à jour.');
  return creerZip(entrees);
}

async function publier(valeurs) {
  if (!estRegieSource() || fabriqueKit.dansUnKit()) throw new Error('Réservé à la régie d’Olivier.');
  let privee;
  try { privee = crypto.createPrivateKey(fs.readFileSync(CLE_PRIVEE(), 'utf8')); } catch (e) {
    throw new Error('Clé de signature introuvable : lance une fois « node outils/generer-cle-mise-a-jour.js » (voir README, « Publier une mise à jour »).');
  }
  const publique = crypto.createPublicKey(privee).export({ type: 'spki', format: 'der' }).toString('base64');
  if (publique !== require('./maj-cle-publique.js').CLE_PUBLIQUE_MAJ) throw new Error('La clé privée ne correspond pas à src/maj-cle-publique.js : rien n’est publié.');
  const version = String(valeurs.version || '').trim();
  if (!analyser(version)) throw new Error('Version attendue sous la forme 1.2.3.');
  if (comparerVersions(version, versionActuelle()) <= 0) throw new Error('La version doit être plus grande que ' + versionActuelle() + '.');
  const notes = String(valeurs.notes || '').trim().slice(0, 4000);

  let apk = null;
  if (valeurs.apkVersionCode !== undefined && valeurs.apkVersionCode !== null && String(valeurs.apkVersionCode).trim() !== '') {
    const code = Number(valeurs.apkVersionCode);
    if (!Number.isInteger(code) || code < 1 || code > 2100000000) throw new Error('versionCode de l’APK : un nombre entier (celui de build.gradle).');
    const fichier = path.join(racine(), 'regie-mobile.apk');
    if (!fs.existsSync(fichier)) throw new Error('regie-mobile.apk absent de la racine de la régie.');
    apk = { versionCode: code, sha256: sha256(fs.readFileSync(fichier)) };
    ecrireFichier(path.join(racine(), 'regie-mobile.apk.json'), JSON.stringify(apk, null, 2) + '\n');
  }

  const cheminPaquet = path.join(racine(), 'package.json');
  const paquet = JSON.parse(fs.readFileSync(cheminPaquet, 'utf8'));
  paquet.version = version;
  ecrireFichier(cheminPaquet, JSON.stringify(paquet, null, 2) + '\n');

  const { morceaux, taille } = await fabriquerMiseAJour({ avecApk: !!apk });
  const zip = Buffer.concat(morceaux);
  const nomZip = 'regie-maj-' + version + '.zip';
  const info = {
    version,
    date: new Date().toISOString(),
    notes,
    sha256: sha256(zip),
    taille,
    url: new URL(nomZip, parametres.MAJ_URL).href,
    ...(apk ? { apk } : {}),
  };
  info.signature = crypto.sign(null, Buffer.from(messageSigne(info), 'utf8'), privee).toString('base64');
  const dossier = parametres.MAJ_DOSSIER_PUBLICATION;
  fs.mkdirSync(dossier, { recursive: true });
  // Le zip d'abord : version.json ne désigne jamais un zip absent.
  ecrireFichier(path.join(dossier, nomZip), zip);
  ecrireFichier(path.join(dossier, 'version.json'), JSON.stringify(info, null, 2) + '\n');
  console.log('[maj] Version ' + version + ' publiée dans ' + dossier + '.');
  publierEtat();
  return { ok: true, version, dossier, fichiers: [nomZip, 'version.json'], taille, envoi: envoyer(version) };
}

// ---------- Envoyer en ligne (git, régie d'Olivier) ----------
// Après « Publier », la régie pousse elle-même le dossier de publication
// en ligne (serveur d'Olivier, qui publie aussitôt, et copie GitHub : les deux
// pushurl du dépôt Site) : git add du seul dossier, commit, pull --rebase, push (jamais
// --force), puis sonde l'adresse publique jusqu'à y lire la nouvelle
// version. Avancement dans « envoi », lu par la page /kit.
// REGIE_MAJ_ENVOI=0 : rien n'est envoyé (Olivier pousse lui-même).
let envoi = { etape: 'inactif', version: '', message: '', enLigne: false, quand: 0 };
let envoiEnCours = null;

function majEnvoi(champs) { envoi = { ...envoi, ...champs, quand: Date.now() }; }

function git(args, dossier) {
  return new Promise((resolve) => {
    execFile('git', args, {
      cwd: dossier,
      windowsHide: true,
      timeout: 2 * 60 * 1000,
      maxBuffer: 4 * 1024 * 1024,
      // Jamais de question dans un terminal invisible : un échec plutôt.
      env: { ...process.env, GIT_TERMINAL_PROMPT: '0' },
    }, (err, sortie, erreurs) => {
      resolve({ ok: !err, absent: !!(err && err.code === 'ENOENT'), sortie: String(sortie || '').trim(), erreurs: String(erreurs || '').trim() || (err ? err.message : '') });
    });
  });
}

async function gitOuErreur(args, dossier, quoi) {
  const r = await git(args, dossier);
  if (r.absent) throw new Error('Git est introuvable sur ce PC : installe « Git for Windows » (git-scm.com, options par défaut), puis « Réessayer l’envoi ». GitHub Desktop seul ne suffit pas.');
  if (!r.ok) throw new Error(quoi + ' : ' + (r.erreurs || r.sortie).split(/\r?\n/).slice(-6).join(' ').slice(0, 600));
  return r.sortie;
}

// Les zips au-delà des 2 dernières versions quittent le dépôt (git rm) :
// les régies n'en ont plus besoin, et le dépôt ne grossit pas sans fin.
async function nettoyerAnciensZips(depot, dossier) {
  const zips = fs.readdirSync(dossier)
    .map((n) => ({ n, v: (/^regie-maj-(\d+\.\d+\.\d+)\.zip$/.exec(n) || [])[1] }))
    .filter((z) => z.v)
    .sort((a, b) => comparerVersions(b.v, a.v));
  const retires = [];
  for (const { n } of zips.slice(2)) {
    const chemin = path.join(dossier, n);
    const suivi = await git(['ls-files', '--error-unmatch', '--', chemin], depot);
    if (suivi.ok) await gitOuErreur(['rm', '-q', '--', chemin], depot, 'Retrait de ' + n);
    else fs.rmSync(chemin, { force: true });
    retires.push(n);
  }
  return retires;
}

async function sonderEnLigne(version) {
  const essais = Number(process.env.REGIE_MAJ_SONDE_ESSAIS) || 12;
  const pause = Number(process.env.REGIE_MAJ_SONDE_PAUSE_MS) || 15000;
  for (let i = 0; i < essais; i += 1) {
    try {
      const r = await fetch(parametres.MAJ_URL + (parametres.MAJ_URL.includes('?') ? '&' : '?') + 't=' + Date.now(), { signal: AbortSignal.timeout(10000), cache: 'no-store' });
      if (r.ok && String((await r.json()).version) === version) return true;
    } catch (e) { /* pas encore : on réessaie */ }
    if (i < essais - 1) await new Promise((ok) => setTimeout(ok, pause));
  }
  return false;
}

async function envoyerMaintenant(version) {
  const dossier = path.resolve(parametres.MAJ_DOSSIER_PUBLICATION);
  try {
    majEnvoi({ etape: 'git', version, message: 'Envoi en ligne…', enLigne: false });
    const depot = path.resolve(await gitOuErreur(['rev-parse', '--show-toplevel'], dossier, 'Le dossier de publication n’est pas dans un dépôt Git (' + dossier + ')'));
    const relatif = path.relative(depot, dossier).split(path.sep).join('/');
    if (!relatif || relatif.startsWith('..')) throw new Error('Le dossier de publication doit être un sous-dossier du dépôt (par exemple regie/).');
    // Rien d'autre ne doit partir avec : on refuse plutôt que d'embarquer
    // le travail en cours d'Olivier sur le site.
    const indexes = (await gitOuErreur(['diff', '--cached', '--name-only'], depot, 'Lecture de l’index')).split(/\r?\n/).filter(Boolean);
    const autres = indexes.filter((n) => !(n + '/').startsWith(relatif + '/'));
    if (autres.length) {
      throw new Error('D’autres fichiers sont déjà prêts à être commités dans ' + depot + ' (' + autres.slice(0, 5).join(', ') + (autres.length > 5 ? '…' : '')
        + ') : rien n’est envoyé. Commite-les ou retire-les de l’index (GitHub Desktop : décoche-les), puis « Réessayer l’envoi ».');
    }
    const nom = (await git(['config', 'user.name'], depot)).sortie;
    const courriel = (await git(['config', 'user.email'], depot)).sortie;
    if (!nom || !courriel) {
      throw new Error('Identité Git manquante (nom ou adresse mail) : dans un terminal, git config --global user.name "Aulit42369" puis git config --global user.email "ton-adresse", puis « Réessayer l’envoi ».');
    }
    const retires = await nettoyerAnciensZips(depot, dossier);
    await gitOuErreur(['add', '-A', '--', relatif], depot, 'git add');
    const rien = await git(['diff', '--cached', '--quiet'], depot);
    if (!rien.ok) await gitOuErreur(['commit', '-q', '-m', 'Régie : mise à jour ' + version], depot, 'git commit');
    await gitOuErreur(['pull', '--rebase', '--autostash', '-q'], depot, 'git pull --rebase');
    await gitOuErreur(['push', '-q'], depot, 'git push');
    console.log('[maj] Version ' + version + ' envoyée en ligne' + (retires.length ? ' (anciens zips retirés : ' + retires.join(', ') + ')' : '') + '.');
    majEnvoi({ etape: 'sonde', message: 'Envoyée. Vérification de l’adresse publique…' });
    const enLigne = await sonderEnLigne(version);
    majEnvoi({
      etape: 'fait',
      enLigne,
      message: enLigne ? 'Publié en ligne ✓ — ' + parametres.MAJ_URL + ' annonce la version ' + version + '.'
        : 'Envoyée, mais ' + parametres.MAJ_URL + ' n’annonce pas encore la version ' + version + ' (réessaie dans quelques minutes).',
    });
  } catch (e) {
    console.warn('[maj] Envoi de la version ' + version + ' : ' + e.message);
    majEnvoi({ etape: 'erreur', message: e.message, enLigne: false });
  }
}

// Lance l'envoi en arrière-plan (la page /kit suit « envoi »).
function envoyer(version) {
  const v = version || envoi.version || versionActuelle();
  if (!parametres.MAJ_ENVOI) { majEnvoi({ etape: 'desactive', version: v, message: 'Envoi automatique désactivé (REGIE_MAJ_ENVOI=0) : pousse le dossier ' + parametres.MAJ_DOSSIER_PUBLICATION + ' toi-même.' }); return envoi; }
  if (envoiEnCours) return envoi;
  majEnvoi({ etape: 'git', version: v, message: 'Envoi en ligne…', enLigne: false });
  envoiEnCours = envoyerMaintenant(v).finally(() => { envoiEnCours = null; });
  return envoi;
}

// Lancé une fois, au démarrage du pont, dans l’ordre fixé par server.js.
function demarrer() {
  // Un pont arrêté en pleine installation : l'ancienne version revient.
  const m = lireManifeste();
  if (m && m.etat === 'en cours') {
    try {
      restaurer(m);
      console.warn('[maj] Mise à jour interrompue au dernier lancement : ancienne version remise.');
      planifierRedemarrage();
    } catch (e) { console.error('[maj] Mise à jour interrompue, remise impossible : ' + e.message); }
  }
  etatRegie.obsState.miseAJour = etat();
  if (!parametres.MAJ_VERIFIER) return;
  const verifierEnSilence = () => verifier().catch((e) => console.warn('[maj] Vérification impossible : ' + e.message));
  setTimeout(verifierEnSilence, parametres.MAJ_PREMIER_DELAI_MS).unref();
  setInterval(verifierEnSilence, JOUR_MS).unref();
}
