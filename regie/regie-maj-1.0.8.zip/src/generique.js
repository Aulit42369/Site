// ============================================================
//  Le générique de fin du stream
// ------------------------------------------------------------
//  Les faits du stream (durée, catégorie, raids, abos, bits,
//  follows, les plus actifs du tchat, le pic du tchat, les
//  marqueurs) et le récit qui ouvre le générique : celui écrit par
//  l'Agence Aulit (outil local du PC) pour CE stream, sinon un récit
//  par gabarit fait ici, sans IA. Lu par la scène de fin d'OBS
//  (GET /api/generique, ouvert aux overlays comme /api/obs/status).
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  faits,
  noterRecit,
  pourOverlay,
  recitGabarit,
  sessionVisee,
};

const etatRegie = require('./etat-regie.js');
const journalEvenements = require('./journal-evenements.js');

const APRES_FIN_MS = 6 * 60 * 60 * 1000; // le générique du dernier stream reste servi 6 h après sa fin
const GARDE_MAX = 8;
// Les bots du tchat ne sont pas la garde du canal.
const BOTS = new Set(['wizebot', 'streamelements', 'nightbot', 'moobot', 'streamlabs', 'fossabot', 'sery_bot', 'soundalerts', 'kofistreambot', 'commanderroot', 'botrixoficial']);

let recit = null; // { texte, debut, quand } : le dernier récit de l'agence (perdu au redémarrage : le gabarit prend le relais)
let chaine = { quand: 0, categorie: '', titre: '' };

// Le stream dont on fait le générique : celui en cours (ou dans son délai de
// grâce), sinon le dernier de l'historique s'il a fini il y a moins de 6 h.
function sessionVisee(maintenant = Date.now()) {
  const s = require('./bilan-stream.js').suiviStream.etat(); // lu à l'appel : bilan-stream charge twitch-ecoute, qui charge ce journal
  if (s) return { debut: s.debut, fin: s.enCours ? maintenant : s.fin, enCours: s.enCours };
  const h = etatRegie.obsState.sessionHistory || [];
  const d = h[h.length - 1];
  if (d && maintenant - Number(d.endedAt) < APRES_FIN_MS) return { debut: Number(d.startedAt), fin: Number(d.endedAt), enCours: false };
  return null;
}

// Catégorie et titre actuels de la chaîne (Helix), gardés 5 min ; 3 s au plus.
// Repli quand aucun jeu n'a été noté au journal (Régie lancée après le début du stream, par exemple).
async function infosChaine(helix) {
  if (!helix || Date.now() - chaine.quand < 5 * 60 * 1000) return chaine;
  const lire = async () => {
    const moi = await helix('/helix/users', 'GET');
    const id = moi && moi.ok && moi.donnees.data && moi.donnees.data[0] && moi.donnees.data[0].id;
    if (!id) return;
    const c = await helix('/helix/channels?broadcaster_id=' + encodeURIComponent(id), 'GET');
    const d = c && c.ok && c.donnees.data && c.donnees.data[0];
    if (d) chaine = { quand: Date.now(), categorie: String(d.game_name || ''), titre: String(d.title || '') };
  };
  try { await Promise.race([lire(), new Promise((r) => setTimeout(r, 3000).unref())]); } catch (e) { /* Twitch non relié : sans catégorie */ }
  return chaine;
}

// Tout ce qui s'est passé pendant le stream visé, en données (jamais de texte de message).
async function faits({ helix, maintenant = Date.now() } = {}) {
  const s = sessionVisee(maintenant);
  if (!s) return null;
  const evs = journalEvenements.evenementsEntre(s.debut, s.fin);
  const nom = (e) => String(e.user || 'Anonyme').slice(0, 40);

  // Mécènes : abos, résubs, abos offerts, bits — une ligne par personne.
  const mecenes = new Map();
  for (const e of evs) {
    if (!['sub', 'resub', 'gift', 'cheer'].includes(e.type)) continue;
    const m = mecenes.get(nom(e).toLowerCase()) || { nom: nom(e), abos: 0, offerts: 0, bits: 0 };
    if (e.type === 'sub' || e.type === 'resub') m.abos += 1;
    if (e.type === 'gift') m.offerts += Number(e.amount) || 1;
    if (e.type === 'cheer') m.bits += Number(e.amount) || 0;
    mecenes.set(nom(e).toLowerCase(), m);
  }
  const allies = new Map();
  for (const e of evs.filter((x) => x.type === 'raid')) {
    const a = allies.get(nom(e).toLowerCase()) || { nom: nom(e), viewers: 0 };
    a.viewers += Number(e.amount) || 0;
    allies.set(nom(e).toLowerCase(), a);
  }
  const recrues = [...new Map(evs.filter((e) => e.type === 'follow').map((e) => [nom(e).toLowerCase(), nom(e)])).values()];

  // Tchat : compteurs des journées touchées. Les pseudos sont comptés par
  // jour (deux streams le même jour se mélangent) ; les tranches de 5 min
  // et les marqueurs sont datés, donc pris dans le stream seulement.
  const soi = String(etatRegie.obsState.pseudo || '').toLowerCase();
  const parPseudo = new Map();
  const tranches = [];
  const moments = [];
  for (const j of journalEvenements.joursEntre(s.debut, s.fin)) {
    const c = journalEvenements.lireCompteurs(j);
    for (const [p, n] of Object.entries(c.pseudos)) parPseudo.set(p, (parPseudo.get(p) || 0) + n);
    for (const [t, n] of Object.entries(c.tranches)) if (+t + journalEvenements.TRANCHE_MS > s.debut && +t <= s.fin) tranches.push({ t: +t, n });
    for (const m of c.moments) if (m.t >= s.debut && m.t <= s.fin) moments.push({ quand: m.t, detail: m.detail });
  }
  const garde = [...parPseudo].filter(([p]) => p.toLowerCase() !== soi && !BOTS.has(p.toLowerCase()))
    .sort((a, b) => b[1] - a[1]).slice(0, GARDE_MAX).map(([p, n]) => ({ nom: p, messages: n }));
  const pic = tranches.reduce((m, x) => (x.n > (m ? m.messages : 0) ? { quand: x.t, messages: x.n } : m), null);

  const infos = await infosChaine(helix);
  // Les jeux du stream, dans l'ordre (notés par twitch-direct.js) ; à défaut, celui du moment.
  const jeux = [];
  for (const e of evs) if (e.type === 'jeu' && e.detail && !jeux.includes(e.detail)) jeux.push(e.detail);
  if (!jeux.length && infos.categorie) jeux.push(infos.categorie);
  return {
    debut: s.debut,
    fin: s.fin,
    enCours: s.enCours,
    dureeMin: Math.round((s.fin - s.debut) / 60000),
    chaine: etatRegie.obsState.pseudo || '',
    categorie: jeux.join(' · '),
    jeux,
    titre: infos.titre,
    mecenes: [...mecenes.values()],
    allies: [...allies.values()],
    recrues,
    garde,
    messages: tranches.reduce((t, x) => t + x.n, 0),
    pic: pic && pic.messages >= 5 ? pic : null, // 5 messages en 5 min ne sont pas un « pic »
    moments: moments.sort((a, b) => a.quand - b.quand).slice(0, 5),
  };
}

// « A », « A et B », « A, B et C ».
function liste(noms) {
  return noms.length <= 1 ? noms.join('') : noms.slice(0, -1).join(', ') + ' et ' + noms[noms.length - 1];
}
// « , cap sur le secteur A » ou « , cap sur les secteurs A puis B ».
function secteurs(f) {
  const j = f.jeux && f.jeux.length ? f.jeux : (f.categorie ? [f.categorie] : []);
  if (!j.length) return '';
  return j.length === 1 ? `, cap sur le secteur ${j[0]}` : `, cap sur les secteurs ${j.slice(0, -1).join(', ')} puis ${j[j.length - 1]}`;
}
const pluriel = (n, un, plusieurs) => `${n} ${n > 1 ? plusieurs : un}`;
function dureeLisible(min) {
  const h = Math.floor(min / 60), m = min % 60;
  return h ? (m ? `${h} h ${String(m).padStart(2, '0')}` : pluriel(h, 'heure', 'heures')) : pluriel(m, 'minute', 'minutes');
}
const heure = (t) => new Date(t).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', timeZone: 'Europe/Paris' }).replace(':', ' h ');

// Le récit sans IA : uniquement ce que disent les faits, ton space-opera.
function recitGabarit(f) {
  const jour = new Date(f.debut).toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', timeZone: 'Europe/Paris' });
  const capitaine = f.chaine || 'le capitaine';
  const p = [`Journal de bord, ${jour} : ${capitaine} et son équipage ont tenu le canal ${dureeLisible(f.dureeMin)}${secteurs(f)}.`];
  if (f.allies.length) {
    const v = f.allies.reduce((t, a) => t + a.viewers, 0);
    p.push(`${liste(f.allies.map((a) => a.nom))} ${f.allies.length > 1 ? 'ont surgi d’autres secteurs' : 'a surgi d’un autre secteur'}${v ? ` avec ${pluriel(v, 'voyageur', 'voyageurs')} à bord` : ''}.`);
  }
  if (f.mecenes.length) {
    const abos = f.mecenes.reduce((t, m) => t + m.abos + m.offerts, 0), bits = f.mecenes.reduce((t, m) => t + m.bits, 0);
    const quoi = [abos && pluriel(abos, 'abonnement', 'abonnements'), bits && `${bits} bits`].filter(Boolean).join(' et ');
    p.push(`${liste(f.mecenes.map((m) => m.nom))} ${f.mecenes.length > 1 ? 'ont alimenté' : 'a alimenté'} les réacteurs de la flotte${quoi ? ` : ${quoi}` : ''}.`);
  }
  if (f.recrues.length) p.push(`${pluriel(f.recrues.length, 'nouvelle recrue a', 'nouvelles recrues ont')} rejoint l’équipage.`);
  if (f.messages) p.push(`Le canal a relayé ${pluriel(f.messages, 'transmission', 'transmissions')}${f.pic ? `, avec un pic de ${f.pic.messages} en cinq minutes vers ${heure(f.pic.quand)}` : ''}.`);
  const notes = f.moments.map((m) => m.detail).filter(Boolean).slice(0, 3);
  if (notes.length) p.push(`Consigné au journal : ${liste(notes.map((d) => `« ${d} »`))}.`);
  p.push('Fin de transmission. Les moteurs refroidissent, jusqu’au prochain saut.');
  return p.join(' ');
}

// Le récit écrit par l'agence pour le stream en cours. Rend { ok, error }.
function noterRecit(corps, maintenant = Date.now()) {
  const texte = String((corps && corps.texte) || '').replace(/[\u0000-\u0009\u000b-\u001f\u007f<>]/g, '').replace(/\n{3,}/g, '\n\n').trim();
  if (texte.length < 40 || texte.length > 1500) return { ok: false, statut: 400, error: 'Récit de 40 à 1500 caractères attendu.' };
  const s = sessionVisee(maintenant);
  if (!s || Number(corps.debut) !== s.debut) return { ok: false, statut: 409, error: 'Ce récit n’est pas celui du stream en cours (ou du dernier).' };
  recit = { texte, debut: s.debut, quand: maintenant };
  return { ok: true };
}

// Ce que lit la scène de fin : les faits, et le récit de CE stream.
function pourOverlay(f) {
  if (!f) return { faits: null, recit: null };
  const r = recit && recit.debut === f.debut ? { texte: recit.texte, source: 'agence', quand: recit.quand } : { texte: recitGabarit(f), source: 'gabarit', quand: Date.now() };
  return { faits: f, recit: r };
}
