// ============================================================
//  Le direct, vu par l’écoute Twitch
// ------------------------------------------------------------
//  Ce que l’écoute Twitch (twitch-ecoute.js) apprend du direct,
//  transmis au suivi des streams (suivi-stream.js) : en ligne,
//  hors ligne, et la dernière nouvelle reçue pendant le direct,
//  qui date sa fin si elle passe pendant une coupure de l’écoute.
//  Et la question posée à Twitch quand l’écoute (re)démarre : la
//  chaîne est-elle en direct ?
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  bascule,
  coupure,
  enLigne,
  horsLigne,
  noterJeu,
  trameRecue,
  verifierDirect,
};

const parametres = require('./parametres.js');
const etatRegie = require('./etat-regie.js');
const twitchJeton = require('./twitch-jeton.js');
const bilanStream = require('./bilan-stream.js');
const journalEvenements = require('./journal-evenements.js');

// Le dernier instant où une connexion qui avait vu la chaîne en direct (et
// pas encore « hors ligne ») recevait quelque chose de Twitch : le stream
// vivait au moins jusque-là. Retenu à chaque trame, mais donné au suivi
// seulement quand l’écoute se coupe ou revient : un « hors ligne » jamais
// reçu ferait sinon vivre le stream sans fin, et le suivant s’y collerait.
let derniereTrameEnDirect = 0;
// Le dernier « hors ligne » reçu de Twitch. Juste après, Twitch répond
// parfois encore « en direct » pour le stream qui vient de finir : sans ça,
// cette réponse en retard le faisait repartir (voir verifierDirect).
let dernierHorsLigne = 0;

// Chaque trame reçue par la connexion en cours (signe de vie, événement).
function trameRecue(ws) {
  if (ws.directVu) derniereTrameEnDirect = Date.now();
}

// « stream.online ». Seul un vrai direct compte (pas une rediffusion ni une
// première).
function enLigne(ws, e) {
  if (e.type && e.type !== 'live') return;
  ws.directVu = true;
  bilanStream.suiviStream.debut(Date.parse(e.started_at) || Date.now(), 'Twitch');
  // « stream.online » ne dit pas le jeu : on le demande à Twitch.
  if (ws.chaineTwitch) lireJeu(ws.chaineTwitch).then(noterJeu, () => {});
}

// Le jeu (catégorie) du direct, noté au journal du stream en cours : au
// début et à chaque changement (« channel.update »). Le générique de fin
// les lit tous (generique.js).
function noterJeu(nom) {
  const s = bilanStream.suiviStream.etat();
  if (!nom || !s || !s.enCours) return;
  journalEvenements.ecrireJournal({ id: Date.now() + '-jeu', timestamp: Date.now(), source: 'live', type: 'jeu', user: 'Jeu', detail: String(nom).slice(0, 80), amount: null });
}

async function lireJeu(chaine) {
  const jeton = await twitchJeton.jetonTwitchValide();
  const clientId = String((etatRegie.obsState.twitchCreds || {}).clientId || '').trim();
  const r = await fetch(parametres.TWITCH_API + '/helix/channels?broadcaster_id=' + encodeURIComponent(chaine), {
    headers: { Authorization: `Bearer ${jeton}`, 'Client-Id': clientId },
  });
  const d = r.ok ? await r.json() : null;
  return d && d.data && d.data[0] ? d.data[0].game_name : '';
}

// « stream.offline ».
function horsLigne(ws) {
  ws.directVu = false;
  derniereTrameEnDirect = 0;
  dernierHorsLigne = Date.now();
  bilanStream.suiviStream.fin(Date.now(), 'Twitch');
}

// La connexion en cours vient de se couper. En plein direct, le stream
// vivait au moins jusqu’à la dernière trame reçue : si sa fin passe pendant
// la coupure, c’est de là qu’elle part.
function coupure(ws) {
  if (ws.directVu && derniereTrameEnDirect) bilanStream.suiviStream.vivant(derniereTrameEnDirect);
}

// Bascule demandée par Twitch : la nouvelle connexion sait ce que savait
// l’ancienne de la chaîne. La bascule ne change rien au direct.
function bascule(ancienne, nouvelle) {
  nouvelle.chaineTwitch = ancienne.chaineTwitch;
  nouvelle.directVu = ancienne.directVu;
}

// Où en est le direct, d’après Twitch, quand l’écoute (re)démarre :
//  • en direct (pont redémarré pendant le stream) : Twitch ne renverra pas
//    « en ligne », on lui demande donc l’heure de début. Et on lui redemande
//    une fois le délai de grâce passé : juste après une fin de stream, il
//    répond parfois encore « en direct », alors que son « hors ligne » est
//    déjà parti (pendant la coupure) et ne viendra plus ;
//  • plus en direct, et OBS ne diffuse pas : le « hors ligne » a pu passer
//    pendant une coupure. La session que Twitch avait vue finit alors à son
//    dernier signe de vie (suivi-stream.js, finSansSigneDeVie). Signe de vie
//    trop récent, le stream pouvant encore reprendre : on redemande à Twitch
//    une fois le délai de grâce passé. Pas de conclusion sans lui redemander :
//    juste après la mise en ligne, il répond parfois encore « hors ligne ».
// « relances » : combien de fois on peut encore lui redemander.
// « connexion » : rend la connexion en cours (elle a pu changer entre-temps).
async function verifierDirect(chaine, relances, connexion) {
  try {
    const jeton = await twitchJeton.jetonTwitchValide();
    const clientId = String((etatRegie.obsState.twitchCreds || {}).clientId || '').trim();
    const r = await fetch(parametres.TWITCH_API + '/helix/streams?user_id=' + encodeURIComponent(chaine), {
      headers: { Authorization: `Bearer ${jeton}`, 'Client-Id': clientId },
    });
    const d = r.ok ? await r.json() : null;
    // La connexion du moment, pour la même chaîne (une bascule demandée par
    // Twitch la remplace sans rien changer d’autre).
    const ws = connexion();
    if (!ws || ws.muet || ws.chaineTwitch !== chaine || !d || !Array.isArray(d.data)) return;
    const direct = d.data[0];
    const debutDirect = direct && direct.type === 'live' ? (Date.parse(direct.started_at) || Date.now()) : 0;
    // Un direct commencé bien avant la dernière fin connue (dernier « hors
    // ligne » reçu, dernière session close — même par le pont d’avant, via
    // l’historique) est fini : Twitch ne l’a pas encore retiré de sa liste.
    // (La marge : l’horloge de ce PC et celle de Twitch ne sont jamais tout à
    // fait d’accord.)
    const derniereFin = Math.max(dernierHorsLigne, bilanStream.derniereFinConnue());
    const dejaFini = debutDirect > 0 && debutDirect < derniereFin - parametres.BILAN_DELAI_MS;
    const plusTard = () => setTimeout(() => verifierDirect(chaine, relances - 1, connexion), parametres.BILAN_DELAI_MS + 1000);
    if (debutDirect && !dejaFini) {
      ws.directVu = true;
      bilanStream.suiviStream.debut(debutDirect, 'Twitch');
      noterJeu(direct.game_name);
      if (relances > 0) plusTard();
      return;
    }
    ws.directVu = false;
    if (etatRegie.obsState.streaming) return;
    if (derniereTrameEnDirect) bilanStream.suiviStream.vivant(derniereTrameEnDirect);
    derniereTrameEnDirect = 0;
    const issue = bilanStream.suiviStream.finSansSigneDeVie('Twitch : plus en direct', 'Twitch');
    if (issue === 'trop-tot' && relances > 0) plusTard();
  } catch (e) { /* Twitch injoignable : rien n’est conclu */ }
}
