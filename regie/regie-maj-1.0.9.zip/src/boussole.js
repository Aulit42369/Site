// ============================================================
//  La Boussole — relevés Twitch et réponse à l’appli
// ------------------------------------------------------------
//  Toutes les 15 minutes, tant que la régie tourne et que Twitch
//  est relié : les ~40 jeux les plus regardés (GET /helix/games/top),
//  puis pour chacun ses streams en français (GET /helix/streams
//  ?game_id=…&language=fr, 5 pages de 100 au plus) et sa première
//  page mondiale (≈ spectateurs du monde, les 100 plus grosses
//  chaînes portent presque tout). 160 appels au plus par relevé,
//  un toutes les 150 ms, arrêt net sur un 429 : loin des 800 points
//  par minute de Twitch, et rien ne part pendant qu’un relevé tourne.
//
//  Seulement des chiffres publics (nombres de streams et de
//  spectateurs) : aucun pseudo, aucun titre n’est gardé.
//  Historique dans data/boussole.json (calcul : boussole-calcul.js).
//  « appeler » = appelerHelix de routes/twitch.js, donné au démarrage.
// ============================================================

module.exports = {
  demarrer,
  etatPourAppli,
  relever,
};

const fs = require('fs');
const path = require('path');

const parametres = require('./parametres.js');
const etatRegie = require('./etat-regie.js');
const stockage = require('./stockage.js');
const journalEvenements = require('./journal-evenements.js');
const calcul = require('./boussole-calcul.js');

const INTERVALLE_MS = 15 * 60 * 1000;
const PREMIER_RELEVE_MS = 2 * 60 * 1000; // laisse la connexion Twitch s’établir au démarrage
const JEUX_MAX = 40;
const PAGES_FR_MAX = 5;
const APPELS_MAX = 160;
const PAUSE_MS = 150;

const FICHIER = () => path.join(parametres.DATA_DIR, 'boussole.json');
let historique = { releves: 0, dernier: 0, jeux: {} };
let erreur = '';
let enCours = false;
let appelerHelix = null;

const twitchRelie = () => {
  const c = etatRegie.obsState.twitchCreds || {};
  return !!(String(c.clientId || '').trim() && String(c.token || '').trim());
};

// Un relevé complet. Rend { quand, jeux } ou lève une erreur lisible.
// « pause » est remplaçable pour les contrôles.
async function relever(appeler, pause) {
  const attendre = pause || ((ms) => new Promise((r) => setTimeout(r, ms)));
  let appels = 0;
  async function lire(chemin) {
    if (appels >= APPELS_MAX) return null; // budget atteint : le jeu est sauté
    if (appels) await attendre(PAUSE_MS);
    appels += 1;
    const r = await appeler(chemin, 'GET');
    if (r.statut === 429) throw new Error('Twitch demande de ralentir (429) : relevé arrêté, nouvel essai dans 15 min.');
    if (r.statut === 401) throw new Error('Connexion Twitch expirée : reconnecte Twitch dans Réglages.');
    if (!r.ok || !r.donnees || !Array.isArray(r.donnees.data)) throw new Error('Twitch n’a pas répondu comme prévu (' + ((r.donnees && r.donnees.message) || 'code ' + r.statut) + ').');
    return r.donnees;
  }
  const top = await lire('/helix/games/top?first=' + JEUX_MAX);
  const jeux = [];
  for (const g of top.data.slice(0, JEUX_MAX)) {
    if (!/^\d{1,20}$/.test(String(g.id || ''))) continue;
    const base = '/helix/streams?type=live&first=100&game_id=' + g.id;
    const monde = await lire(base);
    if (!monde) break;
    const vus = new Map(); // user_id → spectateurs (Twitch peut répéter un stream d’une page à l’autre)
    let curseur = '';
    let pages = 0;
    let plafonne = false;
    do {
      const p = await lire(base + '&language=fr' + (curseur ? '&after=' + encodeURIComponent(curseur) : ''));
      if (!p) { plafonne = true; break; }
      for (const s of p.data) vus.set(String(s.user_id), Number(s.viewer_count) || 0);
      curseur = (p.pagination && p.pagination.cursor) || '';
      pages += 1;
    } while (curseur && pages < PAGES_FR_MAX);
    if (curseur) plafonne = true;
    const m = calcul.mesurerJeu([...vus.values()], monde.data.reduce((s, x) => s + (Number(x.viewer_count) || 0), 0));
    jeux.push({ id: String(g.id), nom: String(g.name || '').slice(0, 100), ...m, plafonne });
  }
  if (!jeux.length) throw new Error('Twitch n’a donné aucun jeu.');
  return { quand: Date.now(), jeux };
}

function enregistrer() {
  if (!stockage.ensureDataDir()) return;
  try {
    const tmp = FICHIER() + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(historique));
    fs.renameSync(tmp, FICHIER());
  } catch (e) { console.warn('[boussole] Historique non enregistré : ' + e.message); }
}

async function tour() {
  if (enCours || !appelerHelix || !twitchRelie()) return;
  enCours = true;
  try {
    calcul.ajouterReleve(historique, await relever(appelerHelix));
    erreur = '';
    enregistrer();
  } catch (e) {
    const message = e.message || String(e);
    if (message !== erreur) console.warn('[boussole] Relevé non fait : ' + message);
    erreur = message;
  } finally {
    enCours = false;
  }
}

// Les lives passés (historique de comparaison, 62 jours) avec leurs jeux,
// lus dans le journal (événements « jeu » notés pendant le direct).
function mesLives() {
  const sessions = (etatRegie.obsState.sessionHistory || []).map((s) => ({
    ...s,
    jeux: journalEvenements.evenementsEntre(Number(s.startedAt), Number(s.endedAt)).filter((e) => e.type === 'jeu').map((e) => e.detail),
  }));
  return { sessions, parJeu: calcul.livesParJeu(sessions) };
}

// GET /api/boussole.
function etatPourAppli(maintenant) {
  const t = maintenant || Date.now();
  const d = new Date(t);
  const { sessions, parJeu } = mesLives();
  const avecMesLives = (liste) => liste.map((j) => ({ ...j, mesLives: parJeu[j.nom.trim().toLowerCase()] || null }));
  const heureHab = calcul.heureHabituelle(sessions);
  return {
    ok: true,
    twitchRelie: twitchRelie(),
    releves: historique.releves || 0,
    dernier: historique.dernier || 0,
    enCours,
    erreur,
    maintenant: { jour: d.getDay(), heure: d.getHours(), jeux: avecMesLives(calcul.classement(historique, d.getDay(), d.getHours(), t, 10)) },
    habituel: heureHab === null ? null : { heure: heureHab, jeux: avecMesLives(calcul.classement(historique, d.getDay(), heureHab, t, 10)) },
  };
}

// Lancé une fois, au démarrage du pont (server.js), avec appelerHelix.
function demarrer(appeler) {
  appelerHelix = appeler;
  try {
    const lu = JSON.parse(fs.readFileSync(FICHIER(), 'utf8'));
    if (lu && typeof lu === 'object' && lu.jeux && typeof lu.jeux === 'object') historique = lu;
  } catch (e) { /* premier lancement : historique vide */ }
  setTimeout(tour, PREMIER_RELEVE_MS).unref();
  setInterval(tour, INTERVALLE_MS).unref();
}
