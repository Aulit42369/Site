// ============================================================
//  Cam de la scène verticale (Aitum Vertical) liée à la cam normale
// ------------------------------------------------------------
//  Quand la cam est masquée ou affichée dans une scène normale — depuis
//  la régie OU directement dans OBS, la cam seule OU le groupe qui la
//  contient (chez Olivier : groupe « Camera » = « overlay cam » + « Cam ») —,
//  la scène verticale du même nom suit : la caméra et l'effet animé
//  derrière elle (« Vertical effet ») prennent le même état. Sans cam, le
//  vertical garde seulement son fond en dégradé.
//  On RECALCULE la visibilité réelle de la cam dans la scène (cam allumée
//  ET son groupe allumé) au lieu de recopier l'événement : un clic sur
//  le groupe ou sur la cam donne le même résultat.
//  Les scènes verticales sont dans un autre « canvas » d'OBS (32+) :
//  obs-websocket 5.7 les atteint avec canvasUuid. Pas d'Aitum = rien.
// ============================================================

module.exports = {
  suivre,
  nomVertical,
  camDeLaScene,
};

const obs = require('./obs.js');
const etatRegie = require('./etat-regie.js');

const CANVAS_VERTICAL = 'Aitum Vertical';
const EFFET = 'Vertical effet';
const CAMERA = 'dshow_input';

// « Début  du stream » (deux espaces en horizontal) ↔ « Début du stream ».
function nomVertical(nom) {
  return String(nom || '').replace(/\s+/g, ' ').trim();
}

// { noms: caméras de la scène, visible: au moins une caméra réellement à l'écran }
async function camDeLaScene(sceneName) {
  const noms = new Set();
  let visible = false;
  const items = (await obs.obsRequest('GetSceneItemList', { sceneName })).sceneItems || [];
  for (const it of items) {
    if (it.inputKind === CAMERA) {
      noms.add(it.sourceName);
      if (it.sceneItemEnabled) visible = true;
    } else if (it.isGroup) {
      const dedans = (await obs.obsRequest('GetGroupSceneItemList', { sceneName: it.sourceName })).sceneItems || [];
      for (const gi of dedans) {
        if (gi.inputKind !== CAMERA) continue;
        noms.add(gi.sourceName);
        if (it.sceneItemEnabled && gi.sceneItemEnabled) visible = true;
      }
    }
  }
  return { noms, visible };
}

async function suivre(ev) {
  try {
    const principales = (etatRegie.obsState.scenes || []).map((s) => s.sceneName);
    // L'événement vient d'une scène normale, ou d'un groupe : alors les scènes normales qui contiennent ce groupe.
    let scenes = principales.includes(ev.sceneName) ? [ev.sceneName] : [];
    if (!scenes.length) {
      for (const nom of principales) {
        const items = (await obs.obsRequest('GetSceneItemList', { sceneName: nom })).sceneItems || [];
        if (items.some((it) => it.isGroup && it.sourceName === ev.sceneName)) scenes.push(nom);
      }
    }
    if (!scenes.length) return;
    const canvas = ((await obs.obsRequest('GetCanvasList')).canvases || []).find((c) => c.canvasName === CANVAS_VERTICAL);
    if (!canvas) return;
    for (const nom of scenes) {
      const cam = await camDeLaScene(nom);
      if (!cam.noms.size) continue;
      const sceneName = nomVertical(nom);
      let verticaux;
      try { verticaux = (await obs.obsRequest('GetSceneItemList', { sceneName, canvasUuid: canvas.canvasUuid })).sceneItems || []; }
      catch (e) { continue; } // pas de scène verticale de ce nom
      for (const v of verticaux) {
        if ((cam.noms.has(v.sourceName) || v.sourceName === EFFET) && v.sceneItemEnabled !== cam.visible) {
          // Pas de boucle : un changement dans le vertical ne déclenche aucun événement chez nous (vérifié),
          // et s'il en déclenchait un, le recalcul donnerait le même état, donc rien à écrire.
          await obs.obsRequest('SetSceneItemEnabled', { sceneName, canvasUuid: canvas.canvasUuid, sceneItemId: v.sceneItemId, sceneItemEnabled: cam.visible });
        }
      }
    }
  } catch (e) {
    console.error('[cam verticale]', (e && e.message) || e);
  }
}
