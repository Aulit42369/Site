// ============================================================
//  Statistiques des réseaux (lecture seule)
// ------------------------------------------------------------
//  Pour le tableau de bord de l'Agence Aulit : vues des clips
//  publiés par la Régie (YouTube, Instagram), nombre d'abonnés,
//  date de fin du jeton Instagram. Rien n'est publié ni modifié
//  en ligne ; jamais un jeton dans la réponse.
//  Droits : YouTube = ceux déjà demandés (youtube.force-ssl) ;
//  Instagram = abonnés et liste des médias avec
//  instagram_business_basic, mais les vues (insights) demandent
//  instagram_business_manage_insights, demandée depuis le 09/11 :
//  sans lui (connexion plus ancienne), « reconnexion nécessaire ».
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  lire,
};

const parametres = require('./parametres.js');
const etatRegie = require('./etat-regie.js');
const stockage = require('./stockage.js');
const youtube = require('./youtube.js');
const instagram = require('./instagram.js');
const sousTitres = require('./sous-titres.js');

const RECONNEXION = 'reconnexion nécessaire';
const DROIT_VUES_INSTAGRAM = 'instagram_business_manage_insights';

// [clipId, lien] des clips publiés sur une plateforme (publishedClips).
function publies(plateforme) {
  return Object.entries(etatRegie.obsState.publishedClips || {})
    .map(([clipId, p]) => [clipId, (p && p[plateforme] && p[plateforme].url) || ''])
    .filter(([, lien]) => lien);
}

function erreur(message, champs) {
  return Object.assign(new Error(message), champs);
}

async function lireYoutube() {
  const yt = stockage.platformTokens.youtube || {};
  if (!yt.refreshToken) return { relie: false };
  // Google ne donne aucune date de fin au jeton de renouvellement : il tient
  // tant qu'il sert (sauf appli Google « en test » : 7 jours). D'où expireLe null,
  // et un essai de renouvellement qui dit tout de suite s'il faut se reconnecter.
  const r = { relie: true, expireLe: null, abonnes: null, vues: {} };
  let jeton;
  try { jeton = await youtube.ensureYoutubeToken(); } catch (e) { return { ...r, reconnexion: true, erreur: RECONNEXION + ' : ' + e.message }; }
  const appel = async (chemin) => {
    const res = await fetch(parametres.YT_API + '/youtube/v3/' + chemin, { headers: { Authorization: 'Bearer ' + jeton } });
    const d = await res.json().catch(() => ({}));
    if (res.ok) return d;
    const e = d.error || {};
    const raison = String((e.errors && e.errors[0] && e.errors[0].reason) || '');
    // 403 « quotaExceeded » n'est pas un problème de droit : pas de reconnexion.
    const reconnexion = res.status === 401 || /insufficientPermissions|authError|forbidden/i.test(raison);
    throw erreur((reconnexion ? RECONNEXION + ' : ' : 'YouTube : ') + (e.message || 'erreur ' + res.status), { reconnexion });
  };
  try {
    const c = await appel('channels?part=statistics&mine=true');
    const s = c.items && c.items[0] && c.items[0].statistics;
    if (s && !s.hiddenSubscriberCount && s.subscriberCount !== undefined) r.abonnes = Number(s.subscriberCount);
    const parVideo = new Map();
    for (const [clipId, lien] of publies('youtube')) {
      const id = sousTitres.idYoutube(lien);
      if (id) parVideo.set(id, clipId);
    }
    const ids = [...parVideo.keys()];
    for (let i = 0; i < ids.length; i += 50) { // videos.list : 50 identifiants par appel (1 unité de quota)
      const v = await appel('videos?part=statistics&id=' + ids.slice(i, i + 50).map(encodeURIComponent).join(','));
      for (const it of v.items || []) r.vues[parVideo.get(it.id)] = Number((it.statistics || {}).viewCount) || 0;
    }
  } catch (e) {
    r.erreur = e.message;
    if (e.reconnexion) r.reconnexion = true;
  }
  return r;
}

const lienPropre = (l) => String(l || '').split(/[?#]/)[0].replace(/\/+$/, '');

async function lireInstagram() {
  if (!(stockage.platformTokens.instagram || {}).accessToken) return { relie: false };
  let ig;
  // Le lire le renouvelle aussi à moins de 5 jours de sa fin (ensureInstagramToken).
  try { ig = await instagram.ensureInstagramToken(); } catch (e) { return { relie: true, reconnexion: true, erreur: RECONNEXION + ' : ' + e.message }; }
  const r = { relie: true, expireLe: ig.expiresAt || null, abonnes: null, vues: {} };
  if (r.expireLe && r.expireLe <= Date.now()) return { ...r, reconnexion: true, erreur: RECONNEXION + ' : le jeton Instagram a expiré.' };
  const appel = async (chemin, champs) => {
    const res = await fetch(parametres.IG_GRAPH + '/' + instagram.IG_API_VERSION + chemin + '?' + new URLSearchParams({ ...champs, access_token: ig.accessToken }));
    const d = await res.json().catch(() => ({}));
    if (res.ok && !d.error) return d;
    const e = d.error || {};
    const code = Number(e.code) || 0;
    // Meta : 190 = jeton refusé ; 10 et 200-299 = permission manquante.
    const droit = code === 10 || (code >= 200 && code < 300);
    throw erreur((code === 190 || droit ? RECONNEXION + ' : ' : 'Instagram : ') + (e.message || 'erreur ' + res.status), { reconnexion: code === 190 || droit, droit });
  };
  try {
    const moi = await appel('/me', { fields: 'followers_count' });
    if (moi.followers_count !== undefined) r.abonnes = Number(moi.followers_count);
    const clips = publies('instagram');
    if (clips.length) {
      // shortcut: les 100 derniers médias seulement (une page) ; paginer si un clip plus ancien doit compter.
      const medias = await appel('/' + ig.userId + '/media', { fields: 'id,permalink', limit: '100' });
      const parLien = new Map((medias.data || []).map((m) => [lienPropre(m.permalink), m.id]));
      for (const [clipId, lien] of clips) {
        const id = parLien.get(lienPropre(lien));
        if (!id) continue;
        try {
          const ins = await appel('/' + id + '/insights', { metric: 'views' });
          const m = (ins.data || [])[0] || {};
          r.vues[clipId] = Number((m.values && m.values[0] && m.values[0].value) || (m.total_value && m.total_value.value)) || 0;
        } catch (e) {
          if (!e.droit) throw e;
          r.droitManquant = DROIT_VUES_INSTAGRAM;
          r.reconnexion = true;
          r.erreur = RECONNEXION + ' : les vues Instagram demandent la permission ' + DROIT_VUES_INSTAGRAM + ' (à ajouter chez Meta, puis reconnecter Instagram sur /setup).';
          break;
        }
      }
    }
  } catch (e) {
    r.erreur = e.message;
    if (e.reconnexion) r.reconnexion = true;
  }
  return r;
}

// { youtube, instagram } : chacun { relie, expireLe, abonnes, vues: { clipId: n }, reconnexion?, droitManquant?, erreur? }.
async function lire() {
  const [yt, ig] = await Promise.all([lireYoutube(), lireInstagram()]);
  return { youtube: yt, instagram: ig };
}
