// ============================================================
//  La Boussole — le calcul (pur : ni disque, ni réseau, ni horloge)
// ------------------------------------------------------------
//  Quels jeux laissent de la place à un streamer francophone ?
//  « Places libres » = spectateurs FR par streamer FR, calculé SANS
//  le plus gros streamer du jeu (un seul énorme streamer ne fait pas
//  un jeu porteur), et les jeux minuscules sont écartés.
//
//  L’historique est compact et borné : par jeu, une case par jour de
//  semaine × heure (moyenne glissante sur ~8 semaines de relevés),
//  et une somme par jour sur 14 jours (la tendance de la semaine).
//  Contrôlé seul par verif/controles-modules.js (« Boussole »).
// ============================================================
'use strict';

module.exports = {
  ajouterReleve,
  classement,
  heureHabituelle,
  jourCle,
  livesParJeu,
  mesurerJeu,
  placesLibres,
  tendance,
  get CASES_MAX_RELEVES() { return CASES_MAX_RELEVES; },
};

// ~4 relevés par heure et par semaine (toutes les 15 min) × 8 semaines.
const CASES_MAX_RELEVES = 32;
const HUIT_SEMAINES_MS = 8 * 7 * 24 * 3600 * 1000;
const JOURS_GARDES = 14;
// Jeu minuscule : moins de 3 streamers FR ou moins de 20 spectateurs FR.
const STREAMERS_MIN = 3;
const SPECTATEURS_MIN = 20;

function jourCle(t) {
  const x = new Date(t);
  const p = (n) => String(n).padStart(2, '0');
  return `${x.getFullYear()}-${p(x.getMonth() + 1)}-${p(x.getDate())}`;
}

// Un jeu au moment du relevé, d’après ses streams FR (déjà dédoublonnés).
function mesurerJeu(spectateursFr, spectMonde) {
  const v = spectateursFr.map((n) => Math.max(0, Number(n) || 0));
  const total = v.reduce((s, n) => s + n, 0);
  const max = v.length ? Math.max(...v) : 0;
  return { streamers: v.length, spectFr: total, spectSansMax: total - max, spectMonde: Math.max(0, Number(spectMonde) || 0) };
}

// Spectateurs FR par streamer FR, hors le plus gros. null = jeu écarté.
function placesLibres(streamers, spectFr, spectSansMax) {
  if (!(streamers >= STREAMERS_MIN) || !(spectFr >= SPECTATEURS_MIN)) return null;
  return spectSansMax / (streamers - 1);
}

// Ajoute un relevé ({ quand, jeux: [{ id, nom, streamers, spectFr, spectSansMax, spectMonde, plafonne }] })
// à l’historique, et le borne. Rend l’historique (modifié sur place).
function ajouterReleve(h, releve) {
  const quand = releve.quand;
  const d = new Date(quand);
  const caseCle = d.getDay() + '-' + d.getHours();
  const jour = jourCle(quand);
  h.jeux = h.jeux || {};
  for (const j of releve.jeux) {
    const g = h.jeux[j.id] || (h.jeux[j.id] = { nom: j.nom, cases: {}, jours: {} });
    g.nom = j.nom;
    g.vu = quand;
    g.plafonne = !!j.plafonne;
    // [relevés, streamers, spectFr, spectSansMax, spectMonde, vu] : moyenne glissante bornée.
    const c = g.cases[caseCle] || [0, 0, 0, 0, 0, 0];
    const n = Math.min(c[0] + 1, CASES_MAX_RELEVES);
    const moy = (i, x) => Math.round((c[i] + (x - c[i]) / n) * 10) / 10;
    g.cases[caseCle] = [n, moy(1, j.streamers), moy(2, j.spectFr), moy(3, j.spectSansMax), moy(4, j.spectMonde), quand];
    // [relevés, Σ streamers, Σ spectFr, Σ spectSansMax] du jour.
    const s = g.jours[jour] || [0, 0, 0, 0];
    g.jours[jour] = [s[0] + 1, s[1] + j.streamers, s[2] + j.spectFr, s[3] + j.spectSansMax];
  }
  // Bornes : cases de plus de 8 semaines, jours au-delà de 14, jeux plus vus depuis 8 semaines.
  const limiteJour = jourCle(quand - JOURS_GARDES * 24 * 3600 * 1000);
  for (const [id, g] of Object.entries(h.jeux)) {
    for (const [k, c] of Object.entries(g.cases)) if (quand - c[5] > HUIT_SEMAINES_MS) delete g.cases[k];
    for (const k of Object.keys(g.jours)) if (k <= limiteJour) delete g.jours[k];
    if (!Object.keys(g.cases).length || quand - (g.vu || 0) > HUIT_SEMAINES_MS) delete h.jeux[id];
  }
  h.releves = (h.releves || 0) + 1;
  h.dernier = quand;
  return h;
}

// Places libres des 7 derniers jours contre les 7 d’avant, en %. null si l’une manque.
function tendance(g, maintenant) {
  const fin1 = jourCle(maintenant);
  const debut1 = jourCle(maintenant - 6 * 24 * 3600 * 1000);
  const debut2 = jourCle(maintenant - 13 * 24 * 3600 * 1000);
  const somme = (de, a) => Object.entries(g.jours || {}).filter(([k]) => k >= de && k <= a)
    .reduce((t, [, s]) => [t[0] + s[0], t[1] + s[1], t[2] + s[2], t[3] + s[3]], [0, 0, 0, 0]);
  const p = (s) => (s[0] ? placesLibres(s[1] / s[0], s[2] / s[0], s[3] / s[0]) : null);
  const recent = p(somme(debut1, fin1));
  const avant = p(somme(debut2, jourCle(maintenant - 7 * 24 * 3600 * 1000)));
  if (recent === null || avant === null || avant <= 0) return null;
  return Math.round(((recent - avant) / avant) * 100);
}

// Le classement pour un jour de semaine (0 = dimanche) et une heure. Sans relevé
// à ce jour-là, la même heure les autres jours (« approx »). Rend les « max » premiers.
function classement(h, jourSemaine, heure, maintenant, max) {
  const lignes = [];
  for (const [id, g] of Object.entries((h && h.jeux) || {})) {
    let c = g.cases[jourSemaine + '-' + heure];
    let approx = false;
    if (!c) {
      const autres = Object.entries(g.cases).filter(([k]) => k.endsWith('-' + heure)).map(([, x]) => x);
      if (!autres.length) continue;
      const n = autres.reduce((s, x) => s + x[0], 0);
      const moy = (i) => autres.reduce((s, x) => s + x[i] * x[0], 0) / n;
      c = [n, moy(1), moy(2), moy(3), moy(4)];
      approx = true;
    }
    const places = placesLibres(c[1], c[2], c[3]);
    if (places === null) continue;
    lignes.push({
      id, nom: g.nom, places: Math.round(places * 10) / 10,
      streamers: Math.round(c[1]), spectFr: Math.round(c[2]), spectMonde: Math.round(c[4]),
      releves: c[0], approx, plafonne: !!g.plafonne, tendance: tendance(g, maintenant),
    });
  }
  return lignes.sort((a, b) => b.places - a.places).slice(0, max || 10);
}

// L’heure de début la plus fréquente des lives passés (heure locale), ou null.
function heureHabituelle(sessions) {
  const compte = new Map();
  for (const s of sessions || []) {
    if (!Number(s.startedAt)) continue;
    const h = new Date(Number(s.startedAt)).getHours();
    compte.set(h, (compte.get(h) || 0) + 1);
  }
  let meilleure = null;
  for (const [h, n] of compte) if (meilleure === null || n > compte.get(meilleure)) meilleure = h;
  return meilleure;
}

// Les lives passés, par jeu (nom en minuscules) : { lives, follows, minutes }.
// « sessions » : [{ jeux: [noms], counts, startedAt, endedAt }].
function livesParJeu(sessions) {
  const parJeu = {};
  for (const s of sessions || []) {
    for (const nom of new Set((s.jeux || []).map((x) => String(x).trim().toLowerCase()).filter(Boolean))) {
      const a = parJeu[nom] || (parJeu[nom] = { lives: 0, follows: 0, minutes: 0 });
      a.lives += 1;
      a.follows += Number(s.counts && s.counts.follow) || 0;
      a.minutes += Math.max(0, Math.round((Number(s.endedAt) - Number(s.startedAt)) / 60000)) || 0;
    }
  }
  return parJeu;
}
