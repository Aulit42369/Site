// ============================================================
// RÉGIE MOBILE — Serveur pont local
// ------------------------------------------------------------
// Tourne sur le même PC qu'OBS. Fait deux choses :
//   1. Parle à OBS en WebSocket (protocole natif OBS WebSocket v5)
//      — comme un logiciel classique, donc aucune des restrictions
//      de sécurité réseau des navigateurs ne s'applique ici.
//   2. Sert l'appli (page web) et une petite API HTTP à qui la
//      demande sur le réseau local — ton téléphone, ton PC, etc.
//
// Zéro dépendance à installer : uniquement les modules intégrés
// à Node.js (http, crypto, fs, path, os) + le client WebSocket
// natif de Node (stable depuis Node 22.4).
// ============================================================

if (typeof WebSocket === 'undefined') {
  console.error('');
  console.error('❌ Cette version de Node.js ne fournit pas WebSocket nativement.');
  console.error('   Installe Node.js 22 ou plus récent : https://nodejs.org (version LTS)');
  console.error('');
  process.exit(1);
}

const http = require('http');

const parametres = require('./src/parametres.js');
const journalTechnique = require('./src/journal-technique.js');
const arret = require('./src/arret.js');
const etatRegie = require('./src/etat-regie.js');
const obs = require('./src/obs.js');
const minuterie = require('./src/minuterie.js');
const twitchEcoute = require('./src/twitch-ecoute.js');
const twitchJeton = require('./src/twitch-jeton.js');
const outilsHttp = require('./src/http-outils.js');
const stockage = require('./src/stockage.js');
const preuves = require('./src/preuves.js');
const journalEvenements = require('./src/journal-evenements.js');
const bilanStream = require('./src/bilan-stream.js');
const reglagesRegie = require('./src/reglages-regie.js');
const annonces = require('./src/annonces.js');
const notifications = require('./src/notifications.js');
const sante = require('./src/sante.js');
const pseudos = require('./src/pseudos.js');
const securite = require('./src/securite.js');
const serveurHttps = require('./src/serveur-https.js');
const reseauLocal = require('./src/reseau-local.js');
const routes = require('./src/routes/index.js');
const maj = require('./src/maj.js');

// Les morceaux du pont (dossier src/). Tous chargés d’abord : aucun
// ne fait rien à son chargement, chacun démarre plus bas, dans l’ordre.
require('./src/obs-collections.js');
require('./src/image-annonce.js');
require('./src/discord.js');
require('./src/oauth.js');
require('./src/youtube.js');
require('./src/instagram.js');
require('./src/bluesky.js');
require('./src/tiktok.js');
require('./src/page-setup.js');
require('./src/diagnostic.js');
require('./src/kit.js');

// Un pont de streaming doit survivre à une trame inattendue plutôt que de
// disparaître en plein direct : sans ces deux garde-fous, la moindre erreur
// dans un gestionnaire asynchrone (OBS ou Twitch) arrête tout le process.
process.on('unhandledRejection', (e) => {
  console.error('[pont] Erreur asynchrone ignorée :', (e && e.message) || e);
});
process.on('uncaughtException', (e) => {
  console.error('[pont] Erreur inattendue ignorée :', (e && e.message) || e);
});
journalTechnique.demarrer();
arret.demarrer();
parametres.demarrer();
minuterie.demarrer();
obs.demarrer();
twitchJeton.demarrer();
twitchEcoute.demarrer();
outilsHttp.demarrer();
stockage.demarrer();
preuves.demarrer();
journalEvenements.demarrer();
bilanStream.demarrer();
reglagesRegie.demarrer();
annonces.demarrer();
notifications.demarrer();
sante.demarrer();
pseudos.demarrer();
securite.demarrer();
maj.demarrer();

const server = http.createServer(routes.gererRequete);
serveurHttps.demarrer();

server.on('error', (e) => {
  if (e.code === 'EADDRINUSE') {
    console.error('');
    console.error('❌ Le port ' + parametres.PORT + ' est déjà utilisé.');
    console.error('   Le pont tourne probablement déjà dans une autre fenêtre.');
    console.error('');
  } else {
    console.error('❌ Démarrage impossible : ' + e.message);
  }
  process.exit(1);
});

server.listen(parametres.PORT, () => {
  const ips = reseauLocal.getLocalIps();
  console.log('');
  console.log('=========================================');
  console.log('   RÉGIE MOBILE — serveur pont démarré');
  console.log('=========================================');
  console.log('');
  console.log('Ouvre cette adresse depuis ton téléphone (même Wi-Fi que ce PC) :');
  console.log('');
  const detaillees = reseauLocal.getLocalIpsDetaillees();
  if (detaillees.length === 0) {
    console.log('  (Adresse réseau non détectée — ouvre une invite de commandes');
    console.log('   et tape « ipconfig » pour la trouver.)');
  } else {
    detaillees.forEach((x, i) => {
      const adresse = '  → http://' + x.adresse + ':' + parametres.PORT + '/';
      if (i === 0 && detaillees.length > 1) console.log(adresse + '   ← celle-ci en premier');
      else if (x.virtuelle) console.log(adresse + '   (carte virtuelle ' + x.carte + ' — peu probable)');
      else console.log(adresse);
    });
    if (detaillees.length > 1) {
      console.log('');
      console.log('  Plusieurs adresses ? Essaie la première. Si le téléphone');
      console.log('  n\'affiche rien, passe à la suivante.');
    }
  }
  console.log('');
  console.log('Depuis ce PC directement : http://localhost:' + parametres.PORT + '/');
  console.log('');
  console.log('-----------------------------------------');
  console.log('Installer la regie sur le TELEPHONE :');
  console.log('  ouvre  http://localhost:' + parametres.PORT + '/qr  sur ce PC,');
  console.log('  et vise le QR code avec l appareil photo du telephone.');
  console.log('');
  console.log('Quelque chose ne marche pas ?');
  console.log('  http://localhost:' + parametres.PORT + '/mon-installation');
  console.log('-----------------------------------------');
  console.log('');
  console.log('Pour connecter YouTube, Instagram ou TikTok (facultatif) :');
  console.log('  http://localhost:' + parametres.PORT + '/setup');
  console.log('');
  console.log('Laisse cette fenêtre ouverte tant que tu veux garder le contrôle actif.');
  console.log('Pour arrêter : ferme la fenêtre, ou Ctrl+C.');
  console.log('');

  if (stockage.platformTokens.obs && stockage.platformTokens.obs.auto) {
    // Branchement automatique : on relit les réglages d'OBS à chaque
    // démarrage, au cas où ils auraient changé depuis.
    const d = obs.brancherObsAuto('démarrage');
    if (d.etat !== 'trouve') console.log('[OBS] En attente : ' + explicationDetectionObs(d.etat));
  } else if (stockage.platformTokens.obs && stockage.platformTokens.obs.host) {
    console.log('Reconnexion automatique à OBS (' + stockage.platformTokens.obs.host + ')...');
    console.log('');
    obs.connectToObs(stockage.platformTokens.obs.host, stockage.platformTokens.obs.port, stockage.platformTokens.obs.password);
  } else {
    // Rien de réglé : on cherche OBS sur ce PC. C'est ce qui fait qu'une
    // installation neuve se branche à OBS sans qu'on ait rien saisi.
    const d = obs.brancherObsAuto('premier démarrage');
    if (d.etat !== 'trouve') console.log('[OBS] ' + explicationDetectionObs(d.etat));
  }

  // L'écoute Twitch démarre avec le pont, sans attendre qu'un téléphone se
  // connecte : c'est tout l'intérêt de l'avoir déplacée ici.
  if (etatRegie.obsState.twitchCreds && etatRegie.obsState.twitchCreds.clientId && etatRegie.obsState.twitchCreds.token) {
    console.log('Écoute des événements Twitch...');
    console.log('');
    twitchEcoute.connectTwitchListen();
    // Twitch demande de valider le jeton au démarrage (puis toutes les heures).
    twitchJeton.surveillerJetonTwitch().catch(() => {});
  }

  // Premier lancement par start.bat : on ouvre la régie dans le navigateur,
  // l'assistant s'y affiche. Le lanceur (Regie mobile.exe) ouvre lui-même sa
  // fenêtre, et une installation déjà réglée n'a pas besoin qu'on lui
  // ouvre quoi que ce soit.
  if (!parametres.LANCE_PAR_EXE && process.platform === 'win32' && !preuves.configurationDejaFaite() && !process.env.REGIE_SANS_NAVIGATEUR) {
    ouvrirDansLeNavigateur('http://localhost:' + parametres.PORT + '/');
  }
});

function explicationDetectionObs(etat) {
  if (etat === 'desactive') return 'le serveur WebSocket d\u2019OBS est désactivé (OBS : Outils → Paramètres du serveur WebSocket → Activer).';
  if (etat === 'sans-websocket') return 'OBS est installé mais sans serveur WebSocket : il faut OBS 28 ou plus récent.';
  if (etat === 'introuvable') return 'OBS introuvable sur ce PC (s\u2019il est sur un autre PC : Réglages → OBS).';
  return etat;
}

// Ouvre une adresse dans le navigateur par défaut de Windows. « start » est
// une commande de cmd : on passe donc par cmd, avec un premier argument vide
// qui sert de titre (sans lui, start prendrait l'adresse pour un titre).
function ouvrirDansLeNavigateur(adresse) {
  try {
    const { spawn } = require('child_process');
    spawn('cmd.exe', ['/c', 'start', '""', '"' + adresse + '"'], {
      windowsVerbatimArguments: true, detached: true, stdio: 'ignore', windowsHide: true,
    }).unref();
  } catch (e) {
    console.log('Ouvre la régie dans ton navigateur : ' + adresse);
  }
}
