@echo off
setlocal
chcp 65001 >nul 2>nul
title Regie Mobile - pont OBS
cd /d "%~dp0"

rem ============================================================
rem   Demarre le pont dans cette fenetre. Laisse-la ouverte
rem   pendant tout le stream : la fermer coupe le lien avec le
rem   telephone.
rem
rem   Plus simple : double-clique plutot sur "Regie mobile.exe".
rem   Le pont tourne alors en arriere-plan (icone pres de
rem   l'horloge), sans fenetre noire a garder ouverte.
rem ============================================================

rem --- Node.js : celui fourni avec la regie (dossier node), sinon
rem     celui installe sur le PC. ---
set "NODE=%~dp0node\node.exe"
if exist "%NODE%" goto verifier
set "NODE=node"
rem (">nul" et pas ">/dev/null" : la syntaxe Windows est differente,
rem  et une erreur ici empecherait le test de s'executer du tout.)
where node >nul 2>nul
if errorlevel 1 goto pasdenode

:verifier
rem --- Est-il assez recent ? Le pont demande Node 22 ou plus. ---
rem Node repond lui-meme par son code de sortie : pas de "for /f" a
rem guillemets imbriques, qui casse quand le chemin contient un espace.
"%NODE%" -e "process.exit(Number(process.versions.node.split('.')[0]) >= 22 ? 0 : 1)"
if errorlevel 1 goto tropvieux

rem --- Tout est bon : on lance. ---
"%NODE%" server.js
echo.
echo   ------------------------------------------------------------
echo   Le pont s'est arrete. Le message ci-dessus dit pourquoi.
echo   ------------------------------------------------------------
echo.
pause
exit /b 0

:pasdenode
echo.
echo   ============================================================
echo    Node.js n'est pas installe sur ce PC.
echo   ============================================================
echo.
echo    C'est le programme qui fait tourner le pont. Il est gratuit
echo    et s'installe en 2 minutes :
echo.
echo      1. Va sur  https://nodejs.org
echo      2. Clique sur le gros bouton "LTS" (version stable)
echo      3. Installe en laissant toutes les options par defaut
echo      4. FERME cette fenetre, puis relance start.bat
echo.
echo    L'etape 4 est importante : Windows ne voit Node.js qu'apres
echo    avoir ouvert une nouvelle fenetre.
echo.
echo    Ouvrir la page de telechargement maintenant ? (o/n)
choice /c on /n >nul
if errorlevel 2 goto fin
start https://nodejs.org
goto fin

:tropvieux
echo.
echo   ============================================================
echo    Node.js est installe, mais trop ancien.
echo   ============================================================
echo.
"%NODE%" -v
echo.
echo    Le pont a besoin de la version 22 ou plus recente.
echo    Reinstalle-le depuis https://nodejs.org (bouton "LTS"),
echo    puis relance start.bat depuis une NOUVELLE fenetre.
echo.
goto fin

:fin
echo.
pause
exit /b 1
