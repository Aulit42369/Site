// ============================================================
//  Les réglages de la régie
// ------------------------------------------------------------
//  Raccourcis de scène, check-list, modèles d’annonce, panique,
//  shoutout et minuteur : relus de tokens.json au démarrage, et
//  réécrits d’un bloc (persistExtras) à chaque changement.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  demarrer,
  nettoyerCommandeShoutout,
  nettoyerCouleursAnnonce,
  persistExtras,
};

const etatRegie = require('./etat-regie.js');
const obsCollections = require('./obs-collections.js');
const minuterie = require('./minuterie.js');
const stockage = require('./stockage.js');
const bilanStream = require('./bilan-stream.js');
const annonces = require('./annonces.js');
const imageAnnonce = require('./image-annonce.js');

// ------------------------------------------------------------
// Réglages accumulés dans tokens.json
// ------------------------------------------------------------
// Raccourcis de scène, check-list d'avant-live, modèles d'annonce et
// publications programmées : tous stockés côté pont et non dans le
// navigateur, pour qu'un changement de téléphone ou un cache vidé ne
// fasse rien perdre.
const RACCOURCIS_PAR_DEFAUT = [
  { label: 'DIRECT', scene: '', couleur: 'cyan' },
  { label: 'PAUSE', scene: '', couleur: 'amber' },
  { label: 'FIN', scene: '', couleur: 'violet' },
];

const CHECKLIST_PAR_DEFAUT = [
  { id: 'micro', label: 'Micro branché et testé' },
  { id: 'casque', label: 'Retour casque OK' },
  { id: 'overlay', label: 'Overlay chargé et à jour' },
  { id: 'annonce', label: 'Annonce publiée sur les réseaux' },
];

// Le bouton « !so » d'un raid reçu : la commande envoyée dans le tchat, au
// nom de la chaîne, pour que le bot du streamer fasse son shoutout.
// « {pseudo} » devient le pseudo du raideur. Vide : pas de bouton.
const SHOUTOUT_PAR_DEFAUT = '!so @{pseudo}';
function nettoyerCommandeShoutout(texte) {
  return String(texte == null ? '' : texte).replace(/[\r\n]+/g, ' ').trim().slice(0, 200);
}

// Les couleurs de l'image d'annonce : seulement des « #rrggbb », sinon celles
// d'origine. « base » permet de ne changer qu'une des deux.
const COULEURS_ANNONCE_PAR_DEFAUT = { accent: '#00f5ff', accent2: '#9b5cff' };
function nettoyerCouleursAnnonce(c, base = COULEURS_ANNONCE_PAR_DEFAUT) {
  const ok = (v) => typeof v === 'string' && /^#[0-9a-f]{6}$/i.test(v);
  return {
    accent: c && ok(c.accent) ? c.accent.toLowerCase() : base.accent,
    accent2: c && ok(c.accent2) ? c.accent2.toLowerCase() : base.accent2,
  };
}

function persistExtras() {
  stockage.platformTokens.couleursAnnonce = etatRegie.obsState.couleursAnnonce;
  stockage.platformTokens.sceneShortcuts = etatRegie.obsState.sceneShortcuts;
  stockage.platformTokens.checklist = etatRegie.obsState.checklist;
  stockage.platformTokens.reelTemplates = etatRegie.obsState.reelTemplates;
  stockage.platformTokens.panique = etatRegie.obsState.panique;
  stockage.platformTokens.shoutoutCommande = etatRegie.obsState.shoutoutCommande;
  // Le fond de l'image d'annonce (« default » ou « custom ») ; l'image
  // elle-même reste dans reel/backgrounds/, hors de tokens.json.
  stockage.platformTokens.fondChoix = (etatRegie.obsState.fondAnnonce && etatRegie.obsState.fondAnnonce.choix) || 'default';
  stockage.platformTokens.timerTextSource = minuterie.timerState.textSource;
  stockage.platformTokens.timerTextFinished = minuterie.timerState.textFinished;
  stockage.platformTokens.timerRetourDans = !!minuterie.timerState.retourDans;
  stockage.platformTokens.timerActionsFin = minuterie.timerState.actionsFin;
  stockage.platformTokens.timerFinParOverlay = !!minuterie.timerState.finParOverlay;
  stockage.platformTokens.publicationsProgrammees = annonces.publicationsProgrammees;
  // La collection de scènes active garde sa copie à jour de ces réglages
  // (voir basculerReglagesVers).
  if (stockage.platformTokens.reglagesCollection) {
    const parCollection = (stockage.platformTokens.reglagesParCollection && typeof stockage.platformTokens.reglagesParCollection === 'object')
      ? stockage.platformTokens.reglagesParCollection : {};
    parCollection[stockage.platformTokens.reglagesCollection] = obsCollections.reglagesDeCollection();
    stockage.platformTokens.reglagesParCollection = parCollection;
  }
  stockage.saveTokens();
}

// Lancé une fois, au démarrage du pont, dans l’ordre fixé par server.js.
function demarrer() {
  etatRegie.obsState.fondAnnonce = { ...imageAnnonce.etatFond(), choix: stockage.platformTokens.fondChoix === 'custom' ? 'custom' : 'default' };
  etatRegie.obsState.sceneShortcuts = Array.isArray(stockage.platformTokens.sceneShortcuts) && stockage.platformTokens.sceneShortcuts.length
    ? stockage.platformTokens.sceneShortcuts
    : RACCOURCIS_PAR_DEFAUT;
  etatRegie.obsState.checklist = Array.isArray(stockage.platformTokens.checklist) && stockage.platformTokens.checklist.length
    ? stockage.platformTokens.checklist
    : CHECKLIST_PAR_DEFAUT.map((i) => ({ ...i, done: false }));
  etatRegie.obsState.reelTemplates = Array.isArray(stockage.platformTokens.reelTemplates) ? stockage.platformTokens.reelTemplates : [];
  etatRegie.obsState.couleursAnnonce = nettoyerCouleursAnnonce(stockage.platformTokens.couleursAnnonce);
  // Le bouton panique de l'en-tête : quelle scène afficher et quel micro
  // couper. Vide par défaut — inventer un nom de scène ferait un bouton qui
  // ne fait rien chez quiconque n'a pas exactement ce nom-là.
  etatRegie.obsState.panique = {
    scene: (stockage.platformTokens.panique && stockage.platformTokens.panique.scene) || '',
    micro: (stockage.platformTokens.panique && stockage.platformTokens.panique.micro) || '',
  };
  etatRegie.obsState.shoutoutCommande = typeof stockage.platformTokens.shoutoutCommande === 'string'
    ? nettoyerCommandeShoutout(stockage.platformTokens.shoutoutCommande)
    : SHOUTOUT_PAR_DEFAUT;
  // Bilan de fin de stream sur Discord (voir publierBilanFinDeStream).
  etatRegie.obsState.bilanDiscord = bilanStream.etatBilanPourAppli();
  // La suite d'actions jouée à la fin d'une pause. Vide = le minuteur ne fait
  // qu'afficher, ce qui reste le cas tant que rien n'a été réglé.
  //
  // Reprise de l'ancien format : une version précédente ne savait faire
  // qu'une scène et un micro, rangés dans deux champs séparés. On les
  // convertit en liste au premier démarrage, dans le même ordre qu'avant,
  // pour que le réglage de quelqu'un qui met à jour continue de marcher
  // exactement pareil sans qu'il ait à y toucher.
  if (Array.isArray(stockage.platformTokens.timerActionsFin)) {
    minuterie.timerState.actionsFin = minuterie.nettoyerActionsFin(stockage.platformTokens.timerActionsFin);
  } else {
    const reprises = [];
    if (stockage.platformTokens.timerEndScene) reprises.push({ type: 'scene', scene: stockage.platformTokens.timerEndScene });
    if (stockage.platformTokens.timerEndMicInput) reprises.push({ type: 'micro', micro: stockage.platformTokens.timerEndMicInput, couper: false });
    minuterie.timerState.actionsFin = reprises;
    if (reprises.length) {
      stockage.platformTokens.timerActionsFin = reprises;
      delete stockage.platformTokens.timerEndScene;
      delete stockage.platformTokens.timerEndMicInput;
      stockage.saveTokens();
      console.log('[pont] Fin de pause : ancien réglage converti en ' + reprises.length + ' action(s).');
    }
  }
  minuterie.timerState.textSource = stockage.platformTokens.timerTextSource || '';
  minuterie.timerState.textFinished = typeof stockage.platformTokens.timerTextFinished === 'string'
    ? stockage.platformTokens.timerTextFinished
    : "C'est reparti !";
  // La case « Retour dans » : « Retour dans 04:59 » au lieu de « 04:59 »,
  // pour un écran de pause. Décochée par défaut.
  minuterie.timerState.retourDans = stockage.platformTokens.timerRetourDans === true;
  // Un décompte lancé par un overlay joue-t-il aussi la fin de pause ? Éteint
  // par défaut : une page piégée qui se ferait passer pour un overlay
  // pourrait sinon changer la scène ou rallumer le micro.
  minuterie.timerState.finParOverlay = stockage.platformTokens.timerFinParOverlay === true;
  etatRegie.obsState.timer = { ...minuterie.timerState };
}
