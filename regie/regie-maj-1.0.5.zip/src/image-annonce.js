// ============================================================
//  L’image d’annonce de live
// ------------------------------------------------------------
//  Fabriquée par wkhtmltoimage à partir de reel/template.html.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  enregistrerFondPerso,
  etatFond,
  fondPerso,
  generateReelImage,
  revenirAuFondPrecedent,
  get NOMS_FOND_PERSO() { return NOMS_FOND_PERSO; },
  get REEL_BACKGROUNDS_DIR() { return REEL_BACKGROUNDS_DIR; },
  get TAILLE_MAX_FOND() { return TAILLE_MAX_FOND; },
};

const fs = require('fs');
const path = require('path');

const parametres = require('./parametres.js');
const wkhtml = require('./wkhtml.js');
const outilsHttp = require('./http-outils.js');
const pseudos = require('./pseudos.js');

// Le fond (orbes floues) est pré-cuit une fois et embarqué dans le modèle ;
// le reste (texte, anneaux, grille) est dessiné à la volée par
// wkhtmltoimage (voir wkhtml.js).
const REEL_TEMPLATE_PATH = path.join(parametres.RACINE, 'reel', 'template.html');
const REEL_BACKGROUNDS_DIR = path.join(parametres.RACINE, 'reel', 'backgrounds');

function mimeForExt(ext) {
  ext = ext.toLowerCase();
  if (ext === '.png') return 'image/png';
  if (ext === '.webp') return 'image/webp';
  return 'image/jpeg';
}

// Le fond perso : un seul fichier, l'un de ces noms. Déposé à la main dans
// reel/backgrounds/, ou choisi dans l'onglet Annonce (enregistrerFondPerso).
const NOMS_FOND_PERSO = ['custom.jpg', 'custom.jpeg', 'custom.png', 'custom.webp'];
// UNE copie du fond d'avant, gardée à chaque remplacement. Jamais utilisée
// toute seule : seulement par « Revenir à l'image précédente ».
const NOMS_FOND_PRECEDENT = NOMS_FOND_PERSO.map((n) => n.replace('custom.', 'custom-precedent.'));
const TAILLE_MAX_FOND = 8 * 1024 * 1024;
// L'appli envoie toujours 1080×1920 : au-delà de 4096 px de côté, ce n'est
// pas elle (et wkhtmltoimage peinerait à décoder l'image).
const COTE_MAX_FOND = 4096;

// Le type d'une image d'après ses premiers octets, jamais d'après son nom ni
// ce qu'annonce l'appareil : JPEG (FF D8 FF), PNG (89 « PNG » 0D 0A 1A 0A),
// WebP (« RIFF » … « WEBP »). Rend l'extension, ou '' pour tout le reste.
function typeImage(octets) {
  if (octets.length >= 3 && octets[0] === 0xff && octets[1] === 0xd8 && octets[2] === 0xff) return 'jpg';
  if (octets.length >= 8 && octets.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'png';
  if (octets.length >= 12 && octets.toString('latin1', 0, 4) === 'RIFF' && octets.toString('latin1', 8, 12) === 'WEBP') return 'webp';
  return '';
}

// Largeur et hauteur d'un JPEG, lues dans son en-tête SOF (FF C0 à FF CF,
// sauf C4, C8 et CC qui n'en sont pas). null si l'en-tête manque : ce n'est
// pas un JPEG qu'on sait lire.
function dimensionsJpeg(o) {
  if (typeImage(o) !== 'jpg') return null;
  let i = 2;
  while (i + 4 <= o.length) {
    if (o[i] !== 0xff) return null;
    const m = o[i + 1];
    if (m === 0xff) { i += 1; continue; } // octets de remplissage
    if (m === 0x01 || (m >= 0xd0 && m <= 0xd8)) { i += 2; continue; } // marqueurs sans longueur
    if (m === 0xd9 || m === 0xda) return null; // fin ou image, sans SOF avant
    const longueur = o.readUInt16BE(i + 2);
    if (longueur < 2) return null;
    if (m >= 0xc0 && m <= 0xcf && m !== 0xc4 && m !== 0xc8 && m !== 0xcc) {
      if (i + 9 > o.length) return null;
      return { hauteur: o.readUInt16BE(i + 5), largeur: o.readUInt16BE(i + 7) };
    }
    i += 2 + longueur;
  }
  return null;
}

function cheminFond(nom) { return path.join(REEL_BACKGROUNDS_DIR, nom); }
function premierFond(noms) { return noms.find((n) => fs.existsSync(cheminFond(n))) || ''; }

// Un ancien fond qui ne part pas passerait devant le nouveau (custom.jpg
// avant custom.png) : l'échec remonte (réponse 500), jamais un « ok ».
function retirerFond(nom) {
  try { fs.unlinkSync(cheminFond(nom)); } catch (e) {
    if (e.code !== 'ENOENT') throw new Error('Impossible de retirer reel/backgrounds/' + nom + ' : ' + e.message);
  }
}

// Remplace le fond perso par ces octets (type déjà vérifié). Garde d'abord
// UNE copie de l'actuel (custom-precedent.<ext>), puis écrit à côté et
// renomme (jamais un fond à moitié écrit), puis retire les autres custom.*.
// Rend le nom écrit.
function remplacerFond(octets, ext) {
  fs.mkdirSync(REEL_BACKGROUNDS_DIR, { recursive: true });
  const actuel = premierFond(NOMS_FOND_PERSO);
  if (actuel) {
    for (const n of NOMS_FOND_PRECEDENT) retirerFond(n);
    fs.copyFileSync(cheminFond(actuel), cheminFond('custom-precedent' + path.extname(actuel)));
  }
  const nom = 'custom.' + ext;
  const final = cheminFond(nom);
  const tmp = final + '.tmp';
  try {
    fs.writeFileSync(tmp, octets);
    try {
      fs.renameSync(tmp, final);
    } catch (e) {
      // Windows : un antivirus qui lit l'ancien fichier au même instant fait
      // échouer le renommage. On écrit alors directement.
      fs.writeFileSync(final, octets);
    }
  } finally {
    try { fs.unlinkSync(tmp); } catch (e) { /* déjà renommé */ }
  }
  for (const autre of NOMS_FOND_PERSO) if (autre !== nom) retirerFond(autre);
  return nom;
}

// Enregistre le fond envoyé par l'appli (image en « data: » ou en base64)
// sous reel/backgrounds/custom.jpg : nom imposé ici, rien de la demande
// n'entre dans le chemin. JPEG seulement — l'appli envoie toujours la photo
// recadrée en JPEG 1080×1920 —, 4096 px de côté au plus. Un custom.png
// déposé à la main, lui, marche toujours (loadBackgroundDataUri).
// Une erreur porte « statut » : la réponse HTTP à donner.
function enregistrerFondPerso(image) {
  const refus = (statut, message) => Object.assign(new Error(message), { statut });
  const base64 = String(image || '').replace(/^data:[^,]*,/, '');
  if (base64.length > Math.ceil(TAILLE_MAX_FOND * 4 / 3) + 4) throw refus(413, 'Image trop lourde : 8 Mo au plus.');
  const octets = Buffer.from(base64, 'base64');
  if (!octets.length) throw refus(400, 'Aucune image reçue.');
  if (octets.length > TAILLE_MAX_FOND) throw refus(413, 'Image trop lourde : 8 Mo au plus.');
  if (typeImage(octets) !== 'jpg') throw refus(415, 'Seul le JPEG est accepté (l’appli recadre la photo en JPEG avant de l’envoyer).');
  const taille = dimensionsJpeg(octets);
  if (!taille || !taille.largeur || !taille.hauteur) throw refus(415, 'Ce JPEG est illisible (en-tête introuvable).');
  if (taille.largeur > COTE_MAX_FOND || taille.hauteur > COTE_MAX_FOND) throw refus(413, 'Image trop grande : 4096 px de côté au plus.');
  return remplacerFond(octets, 'jpg');
}

// « Revenir à l'image précédente » : la copie gardée redevient le fond, et
// le fond actuel devient à son tour la copie (on peut donc y revenir).
function revenirAuFondPrecedent() {
  const precedent = premierFond(NOMS_FOND_PRECEDENT);
  if (!precedent) throw Object.assign(new Error('Aucune image précédente gardée.'), { statut: 404 });
  const octets = fs.readFileSync(cheminFond(precedent));
  const ext = typeImage(octets);
  if (!ext) throw Object.assign(new Error('L’image précédente est illisible.'), { statut: 415 });
  return remplacerFond(octets, ext);
}

// Le fond perso tel qu'il est sur le disque, pour l'aperçu de l'appli : ses
// octets et son type, lu dans le contenu (jamais d'après le nom). null s'il
// n'y en a pas, ou si ce n'est pas une image reconnue.
const TYPES_MIME = { jpg: 'image/jpeg', png: 'image/png', webp: 'image/webp' };
function fondPerso() {
  const nom = premierFond(NOMS_FOND_PERSO);
  if (!nom) return null;
  const octets = fs.readFileSync(cheminFond(nom));
  const ext = typeImage(octets);
  return ext ? { octets, type: TYPES_MIME[ext] } : null;
}

// Ce que l'appli doit savoir du fond (diffusé dans l'état, voir
// routes/annonce.js) : y a-t-il un fond perso, une copie précédente, et une
// « version » (date du fichier) qui change à chaque nouveau fond.
function etatFond() {
  const nom = premierFond(NOMS_FOND_PERSO);
  let version = 0;
  try { if (nom) version = Math.round(fs.statSync(cheminFond(nom)).mtimeMs); } catch (e) { /* retiré entre-temps */ }
  return { hasCustom: !!nom, precedent: !!premierFond(NOMS_FOND_PRECEDENT), version };
}

// 'default' -> reel/backgrounds/default.jpg (le fond d'origine, orbes cyan/violet).
// 'custom'  -> reel/backgrounds/custom.(jpg|jpeg|png|webp), déposé à la main
//              ou choisi dans l'onglet Annonce.
function loadBackgroundDataUri(choice) {
  const names = choice === 'custom'
    ? NOMS_FOND_PERSO
    : ['default.jpg'];
  for (const name of names) {
    const p = path.join(REEL_BACKGROUNDS_DIR, name);
    if (fs.existsSync(p)) {
      return `data:${mimeForExt(path.extname(name))};base64,${fs.readFileSync(p).toString('base64')}`;
    }
  }
  if (choice === 'custom') {
    throw new Error("Aucune image personnalisée trouvée dans reel/backgrounds/ (custom.jpg, .jpeg, .png ou .webp) — dépose ton fichier là-bas d'abord.");
  }
  throw new Error('Fond par défaut introuvable (reel/backgrounds/default.jpg manquant).');
}
const REEL_TMP_DIR = path.join(parametres.RACINE, 'reel', 'tmp');

// Le titre est le plus gros élément visuel (5.4rem à la base) : sans limite
// de caractères, un texte long doit rétrécir plutôt que déborder ou écraser
// le reste de la composition. Réduction progressive, avec un plancher pour
// que ça reste lisible et ressemble toujours à un titre.
function computeTitleFontSize(line1, line2) {
  const longest = Math.max((line1 || '').length, (line2 || '').length, 1);
  const BASE = 5.4, MIN = 3.4, THRESHOLD = 13, STEP = 0.10;
  if (longest <= THRESHOLD) return BASE;
  const size = BASE - (longest - THRESHOLD) * STEP;
  return Math.max(MIN, Math.round(size * 100) / 100);
}

function sanitizeHexColor(hex, fallback) {
  const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || '').trim());
  return m ? '#' + m[1].toLowerCase() : fallback;
}

function hexToRgbString(hex) {
  const n = parseInt(hex.slice(1), 16);
  return `${(n >> 16) & 255},${(n >> 8) & 255},${n & 255}`;
}

async function generateReelImage({ eyebrow, titleLine1, titleLine2, subtitle, handle, platform, background, accent, accent2 }) {
  let html;
  try {
    html = fs.readFileSync(REEL_TEMPLATE_PATH, 'utf8');
  } catch (e) {
    throw new Error('reel/template.html introuvable.');
  }
  const accentHex = sanitizeHexColor(accent, '#00f5ff');
  const accent2Hex = sanitizeHexColor(accent2, '#9b5cff');
  const bgDataUri = loadBackgroundDataUri(background === 'custom' ? 'custom' : 'default');
  // Les valeurs passent par une fonction : sinon un titre contenant $$ ou
  // $& serait réécrit par le moteur de remplacement (« 100$$ » devenait
  // « 100$ », et « $& » réinjectait le nom du jeton lui-même).
  html = html
    .replace('{{EYEBROW}}', () => outilsHttp.echapperHtml(eyebrow))
    .replace('{{TITLE_LINE1}}', () => outilsHttp.echapperHtml(titleLine1))
    .replace('{{TITLE_LINE2}}', () => outilsHttp.echapperHtml(titleLine2))
    .replace('{{TITLE_SIZE}}', () => String(computeTitleFontSize(titleLine1, titleLine2)))
    .replace('{{SUBTITLE}}', () => outilsHttp.echapperHtml(subtitle))
    // Le pseudo par défaut (kit, puis compte Twitch relié) ne sert que si
    // l'appli n'envoie aucun pseudo
    // (ne devrait jamais arriver normalement) — la vraie personnalisation
    // se fait depuis l'onglet Annonce, champ "Pseudo" (voir PSEUDO_PAR_DEFAUT
    // dans public/index.html pour changer la valeur de départ affichée là-bas).
    .replace('{{HANDLE}}', () => outilsHttp.echapperHtml(handle || pseudos.pseudoParDefautServeur()))
    .replace('{{PLATFORM}}', () => outilsHttp.echapperHtml(platform || 'Twitch.tv'))
    .replace('{{BACKGROUND}}', () => bgDataUri)
    .replaceAll('{{ACCENT_RGB}}', hexToRgbString(accentHex))
    .replaceAll('{{ACCENT2}}', accent2Hex)
    .replaceAll('{{ACCENT}}', accentHex);

  if (!fs.existsSync(REEL_TMP_DIR)) fs.mkdirSync(REEL_TMP_DIR, { recursive: true });
  const id = Date.now() + '_' + Math.random().toString(36).slice(2, 8);
  const htmlPath = path.join(REEL_TMP_DIR, id + '.html');
  // JPEG plutôt que PNG : wkhtmltoimage sort du PNG non compressé (plusieurs Mo
  // pour cette image, largement au-dessus de la limite de taille des requêtes
  // une fois renvoyée au pont pour publication) — le JPEG choisit le format à
  // la volée via l'extension du fichier de sortie, sans dépendance en plus,
  // pour un résultat ~70x plus léger et visuellement identique à cette qualité.
  const imgPath = path.join(REEL_TMP_DIR, id + '.jpg');
  fs.writeFileSync(htmlPath, html, 'utf8');

  let runErr = null;
  try {
    runErr = await wkhtml.runWkhtmlToImage(['--width', '1080', '--height', '1920', '--quality', '92', htmlPath, imgPath]);
  } catch (e) {
    try { fs.unlinkSync(htmlPath); } catch (e2) {}
    throw e;
  }

  let buf = null;
  try { buf = fs.readFileSync(imgPath); } catch (e) {}
  try { fs.unlinkSync(htmlPath); } catch (e) {}
  try { fs.unlinkSync(imgPath); } catch (e) {}
  if (!buf) {
    if (runErr && runErr.explique) throw runErr;
    throw new Error(runErr ? 'wkhtmltoimage : ' + runErr.message : "wkhtmltoimage n'a produit aucune image.");
  }
  return buf;
}
