// ============================================================
//  Routes : l’appli, ses fichiers, les pages d’installation
// ------------------------------------------------------------
//  Appelé par src/routes/index.js, une fois les barrières passées
//  (voir src/securite.js). « acces » dit qui appelle.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  traiter,
};

const fs = require('fs');
const path = require('path');
const { normaliserCode } = require('../appareils.js');

const parametres = require('../parametres.js');
const outilsHttp = require('../http-outils.js');
const serveurHttps = require('../serveur-https.js');
const reseauLocal = require('../reseau-local.js');

const PAGES_GUIDE = {
  '/qr': 'qr.html',
  '/telephone': 'telephone.html',
  '/mon-installation': 'installation.html',
  '/kit': 'kit.html',
  '/relier': 'relier.html',
};
// GIF transparent d'un pixel (voir /ping.gif).
const PIXEL_GIF = Buffer.from('R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7', 'base64');

// Rend vrai si la demande a été traitée ici.
async function traiter(req, res, url, acces) {
  if (req.method === 'GET' && url.pathname === '/') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(outilsHttp.indexHtml);
    return true;
  }

  // L'appli compilée et sa personnalisation. Relus à chaque demande plutôt
  // que gardés en mémoire : modifier config.js ne demande ainsi qu'un
  // rechargement de la page, pas un redémarrage du pont.
  if (req.method === 'GET' && (url.pathname === '/app.js' || url.pathname === '/config.js')) {
    try {
      const nom = path.basename(url.pathname);
      const chemin = path.join(parametres.PUBLIC_DIR, nom);
      const entetes = {
        'Content-Type': 'application/javascript; charset=utf-8',
        // Pas de cache : sinon le téléphone garderait l'ancienne version de
        // l'appli après une mise à jour, ce qui est une source de confusion
        // difficile à diagnostiquer.
        'Cache-Control': 'no-cache, must-revalidate',
      };
      // Compression : app.js pèse ~334 Ko en clair et ~85 Ko compressé.
      // Tous les navigateurs savent la décompresser ; si l'en-tête n'est
      // pas annoncé, on envoie le fichier tel quel.
      if (/\bgzip\b/.test(req.headers['accept-encoding'] || '')) {
        entetes['Content-Encoding'] = 'gzip';
        entetes['Vary'] = 'Accept-Encoding';
        res.writeHead(200, entetes);
        res.end(outilsHttp.litCompresse(chemin, nom));
      } else {
        res.writeHead(200, entetes);
        res.end(fs.readFileSync(chemin));
      }
    } catch (e) {
      res.writeHead(404);
      res.end(path.basename(url.pathname) + ' introuvable dans public/');
    }
    return true;
  }

  // Manifeste + icônes : nécessaires pour installer l'appli sur l'écran
  // d'accueil (et utilisés aussi par l'APK Android pour son icône).
  if (req.method === 'GET' && url.pathname === '/manifest.json') {
    try {
      const body = fs.readFileSync(path.join(parametres.PUBLIC_DIR, 'manifest.json'));
      res.writeHead(200, { 'Content-Type': 'application/manifest+json; charset=utf-8' });
      res.end(body);
    } catch (e) {
      res.writeHead(404); res.end('manifest.json introuvable');
    }
    return true;
  }

  if (req.method === 'GET' && /^\/icons\/[a-zA-Z0-9._-]+\.png$/.test(url.pathname)) {
    // Motif volontairement strict (pas de "/" ni "..") pour qu'aucun chemin
    // ne puisse sortir du dossier des icônes.
    try {
      const body = fs.readFileSync(path.join(parametres.PUBLIC_DIR, 'icons', path.basename(url.pathname)));
      res.writeHead(200, { 'Content-Type': 'image/png', 'Cache-Control': 'public, max-age=86400' });
      res.end(body);
    } catch (e) {
      res.writeHead(404); res.end('Icône introuvable');
    }
    return true;
  }

  // ---------- Installation du certificat sur le téléphone ----------
  // Volontairement servi en HTTP : le téléphone ne peut pas encore faire
  // confiance au HTTPS, c'est justement ce qu'on vient installer. Et
  // volontairement par le réseau plutôt que par câble ou clé USB — ouvrir
  // une adresse dans le navigateur est la seule manipulation qu'on peut
  // demander à quelqu'un sans l'avoir à côté de soi.
  if (req.method === 'GET' && url.pathname === '/certificat-regie.crt') {
    try {
      const corps = fs.readFileSync(serveurHttps.CHEMIN_AUTORITE_CRT);
      res.writeHead(200, {
        // Ce type est celui qui déclenche l'installateur de certificat
        // d'Android. Avec un type générique, le fichier atterrit dans les
        // téléchargements sans que rien ne se passe.
        'Content-Type': 'application/x-x509-ca-cert',
        'Content-Disposition': 'attachment; filename="regie-mobile.crt"',
        'Content-Length': corps.length,
      });
      res.end(corps);
    } catch (e) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end("Certificat introuvable. Relance start.bat : le pont le fabrique au démarrage.");
    }
    return true;
  }

  // Son empreinte, ouverte à tous comme le certificat lui-même : affichée
  // sur /qr (PC) et sur /telephone, pour comparer les deux.
  if (req.method === 'GET' && url.pathname === '/api/certificat/empreinte') {
    const empreinte = serveurHttps.empreinteAutorite();
    outilsHttp.sendJson(res, empreinte ? 200 : 404, empreinte ? { ok: true, empreinte } : { ok: false, error: 'Certificat introuvable. Relance start.bat : le pont le fabrique au démarrage.' });
    return true;
  }

  // L'ancienne page d'installation s'appelait /installer. Elle est citée
  // dans des messages et des documents déjà envoyés : on y répond toujours,
  // en renvoyant vers la page qui l'a remplacée.
  if (req.method === 'GET' && url.pathname === '/installer') {
    res.writeHead(302, { Location: '/telephone' });
    res.end();
    return true;
  }

  // ---------- Pages d'installation (dossier public/guide) ----------
  if (req.method === 'GET' && PAGES_GUIDE[url.pathname]) {
    try {
      const corps = fs.readFileSync(path.join(parametres.GUIDE_DIR, PAGES_GUIDE[url.pathname]));
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache, must-revalidate' });
      res.end(corps);
    } catch (e) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Page introuvable : public/guide/' + PAGES_GUIDE[url.pathname] + ' manque.');
    }
    return true;
  }

  // Leurs feuilles de style, scripts et images. Motif strict : ni « / » ni
  // « .. », aucun chemin ne peut sortir du dossier.
  if (req.method === 'GET' && /^\/guide\/[a-zA-Z0-9._-]+\.(css|js|svg|png)$/.test(url.pathname)) {
    const nom = path.basename(url.pathname);
    const types = { '.css': 'text/css; charset=utf-8', '.js': 'application/javascript; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png' };
    try {
      const corps = fs.readFileSync(path.join(parametres.GUIDE_DIR, nom));
      res.writeHead(200, { 'Content-Type': types[path.extname(nom)], 'Cache-Control': 'no-cache, must-revalidate' });
      res.end(corps);
    } catch (e) {
      res.writeHead(404); res.end('Introuvable');
    }
    return true;
  }

  // Le QR code qui ouvre la page du téléphone. L'adresse est celle du PC sur
  // le réseau ; « ?ip= » permet d'en choisir une autre quand le PC en a
  // plusieurs, mais seulement parmi les siennes. « ?code= » y ajoute un code
  // de liaison (voir /api/appareils/code) : le téléphone qui le vise sera
  // relié à la fin de l'installation, sans rien taper. Le code va après « # » :
  // le navigateur ne l'envoie jamais au pont, donc il ne passe pas en clair
  // sur le Wi-Fi avec la page http (il ne voyage qu'en https, vers /relier).
  if (req.method === 'GET' && url.pathname === '/qr/telephone.svg') {
    const ips = reseauLocal.getLocalIps();
    const demandee = url.searchParams.get('ip');
    const ip = demandee && ips.includes(demandee) ? demandee : ips[0];
    if (!ip) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Ce PC n’a pas d’adresse sur le réseau local.');
      return true;
    }
    const code = normaliserCode(url.searchParams.get('code'));
    try {
      const svg = require('../qr.js').qrSvg('http://' + ip + ':' + parametres.PORT + '/telephone' + (code ? '#code=' + code.slice(0, 4) + '-' + code.slice(4) : ''));
      res.writeHead(200, { 'Content-Type': 'image/svg+xml', 'Cache-Control': 'no-store' });
      res.end(svg);
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('QR code impossible : ' + e.message);
    }
    return true;
  }

  // Une image d'un pixel. Chargée par la page du téléphone (en http) depuis
  // l'adresse https : si elle arrive, le certificat est reconnu. C'est la
  // vérification la plus sûre qui existe — une image sur un certificat non
  // reconnu échoue sans même proposer de « continuer ».
  if (req.method === 'GET' && url.pathname === '/ping.gif') {
    res.writeHead(200, {
      'Content-Type': 'image/gif',
      'Cache-Control': 'no-store',
      'Content-Length': PIXEL_GIF.length,
    });
    res.end(PIXEL_GIF);
    return true;
  }

  // Le service worker : code exécuté par le navigateur même appli fermée.
  // Servi depuis la racine, condition imposée par les navigateurs pour
  // qu'il ait le droit d'agir sur toute l'appli.
  if (req.method === 'GET' && url.pathname === '/sw.js') {
    try {
      const corps = fs.readFileSync(path.join(parametres.PUBLIC_DIR, 'sw.js'));
      res.writeHead(200, {
        'Content-Type': 'application/javascript; charset=utf-8',
        'Cache-Control': 'no-cache, must-revalidate',
        'Service-Worker-Allowed': '/',
      });
      res.end(corps);
    } catch (e) {
      res.writeHead(404);
      res.end('sw.js introuvable dans public/');
    }
    return true;
  }
  return false;
}
