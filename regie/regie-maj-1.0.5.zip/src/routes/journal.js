// ============================================================
//  Routes : journal, bilan, historique
// ------------------------------------------------------------
//  Appelé par src/routes/index.js, une fois les barrières passées
//  (voir src/securite.js). « acces » dit qui appelle.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  traiter,
};

const etatRegie = require('../etat-regie.js');
const obs = require('../obs.js');
const outilsHttp = require('../http-outils.js');
const stockage = require('../stockage.js');
const journalEvenements = require('../journal-evenements.js');

// Rend vrai si la demande a été traitée ici.
async function traiter(req, res, url, acces) {
  // ---------- Journal des événements (jours passés) ----------
  if (req.method === 'GET' && url.pathname === '/api/journal/jours') {
    outilsHttp.sendJson(res, 200, { ok: true, jours: journalEvenements.joursDisponibles() });
    return true;
  }

  if (req.method === 'GET' && url.pathname === '/api/journal') {
    const jour = url.searchParams.get('jour') || journalEvenements.jourLocal();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(jour)) {
      outilsHttp.sendJson(res, 400, { ok: false, error: 'Date invalide.' });
      return true;
    }
    outilsHttp.sendJson(res, 200, { ok: true, jour, evenements: journalEvenements.lireJournal(jour) });
    return true;
  }

  // ---------- Récapitulatif de fin de stream ----------
  if (req.method === 'GET' && url.pathname === '/api/recap') {
    const jour = url.searchParams.get('jour') || journalEvenements.jourLocal();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(jour)) {
      outilsHttp.sendJson(res, 400, { ok: false, error: 'Date invalide.' });
      return true;
    }
    // La durée vient d'OBS quand il diffuse ; sinon on laisse l'appli
    // envoyer celle qu'elle connaît, ou zéro.
    let duree = Number(url.searchParams.get('duree')) || 0;
    if (!duree && etatRegie.obsState.streaming) {
      try {
        const st = await obs.obsRequest('GetStreamStatus');
        duree = Math.round((st.outputDuration || 0) / 1000);
      } catch (e) {}
    }
    outilsHttp.sendJson(res, 200, { ok: true, recap: journalEvenements.construireRecap(jour, duree) });
    return true;
  }

  // (L'historique de comparaison n'est plus envoyé par l'appli : le pont le
  // note lui-même à la fin de chaque stream, voir enregistrerSessionHistorique.)

  if (req.method === 'POST' && url.pathname === '/api/stats/clear-history') {
    etatRegie.obsState.sessionHistory = [];
    stockage.persistSharedState();
    etatRegie.broadcastState();
    outilsHttp.sendJson(res, 200, { ok: true });
    return true;
  }
  return false;
}
