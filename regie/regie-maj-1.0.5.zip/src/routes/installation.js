// ============================================================
//  Routes : installation guidée, diagnostic, kit
// ------------------------------------------------------------
//  Appelé par src/routes/index.js, une fois les barrières passées
//  (voir src/securite.js). « acces » dit qui appelle.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  traiter,
};

const fs = require('fs');
const path = require('path');

const parametres = require('../parametres.js');
const etatRegie = require('../etat-regie.js');
const obs = require('../obs.js');
const twitchJeton = require('../twitch-jeton.js');
const outilsHttp = require('../http-outils.js');
const securite = require('../securite.js');
const stockage = require('../stockage.js');
const preuves = require('../preuves.js');
const pseudos = require('../pseudos.js');
const diagnostics = require('../diagnostic.js');
const fabriqueKit = require('../kit.js');
const reseauLocal = require('../reseau-local.js');
const windows = require('../windows.js');

// Rend vrai si la demande a été traitée ici.
async function traiter(req, res, url, acces) {
  // ---------- Mon installation ----------
  // Réservé aux pages du pont : la réponse contient les adresses du PC, le
  // compte Twitch et les derniers messages du journal.
  if (req.method === 'GET' && (url.pathname === '/api/installation' || url.pathname === '/api/installation/texte')) {
    if (securite.estAutreOrigine(req)) {
      outilsHttp.sendJson(res, 403, { ok: false, error: 'Réservé aux pages servies par le pont.' });
      return true;
    }
    try {
      const faits = await diagnostics.faitsInstallation();
      const verifications = diagnostics.construireVerifications(faits);
      if (url.pathname === '/api/installation/texte') {
        const texte = diagnostics.texteRapport(faits, verifications, diagnostics.secretsConnus());
        res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' });
        res.end(texte);
        return true;
      }
      const ips = reseauLocal.getLocalIpsDetaillees();
      const principale = ips.length ? ips[0].adresse : '';
      const reponse = {
        ok: true,
        verifications,
        adresses: ips.map((x) => ({ adresse: x.adresse, carte: x.carte, virtuelle: x.virtuelle })),
        urlTelephone: principale ? 'http://' + principale + ':' + parametres.PORT + '/telephone' : '',
        urlHttps: principale ? 'https://' + principale + ':' + parametres.HTTPS_PORT + '/' : '',
        telephone: etatRegie.obsState.telephone,
        reseau: faits.reseau,
        demarrageAuto: faits.demarrageAuto,
        lanceur: etatRegie.obsState.lanceur,
        contact: faits.kit.contact,
        configurationTerminee: etatRegie.obsState.configurationTerminee,
      };
      // Même filet que pour le texte : rien de ce qui part ne doit contenir
      // un secret, même par accident.
      const corps = diagnostics.masquerSecrets(JSON.stringify(reponse), diagnostics.secretsConnus());
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      res.end(corps);
    } catch (e) {
      outilsHttp.sendJson(res, 500, { ok: false, error: e.message });
    }
    return true;
  }

  // L'appli, sur le téléphone, signale que son service worker a été accepté
  // (voir noterSiTelephone). Compté seulement en https, et seulement depuis
  // un autre appareil que le PC.
  if (req.method === 'POST' && url.pathname === '/api/telephone/preuve') {
    const valable = !!req.socket.encrypted && !securite.surCeMemePc(req);
    if (valable) preuves.noterPassageTelephone('https');
    outilsHttp.sendJson(res, 200, { ok: true, comptee: valable });
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/installation/terminee') {
    preuves.suiviInstallation.configurationTermineeA = Date.now();
    preuves.enregistrerSuivi();
    etatRegie.setState({ configurationTerminee: true });
    outilsHttp.sendJson(res, 200, { ok: true });
    return true;
  }

  // ---------- Démarrage avec Windows ----------
  if (url.pathname === '/api/demarrage-auto' && (req.method === 'GET' || req.method === 'POST')) {
    if (securite.estAutreOrigine(req)) { outilsHttp.sendJson(res, 403, { ok: false, error: 'Réservé aux pages servies par le pont.' }); return true; }
    try {
      let etat;
      if (req.method === 'POST') {
        const body = await outilsHttp.readJsonBody(req);
        etat = await windows.ecrireDemarrageAuto(parametres.RACINE, !!body.actif);
        console.log('[pont] Lancer avec Windows : ' + (etat.actif ? 'activé' : 'désactivé') + '.');
      } else {
        etat = await windows.lireDemarrageAuto(parametres.RACINE);
      }
      outilsHttp.sendJson(res, 200, { ok: true, ...etat });
    } catch (e) {
      outilsHttp.sendJson(res, 200, { ok: false, error: e.message });
    }
    return true;
  }

  // ---------- OBS : branchement automatique ----------
  if (req.method === 'POST' && url.pathname === '/api/obs/auto') {
    const detection = obs.brancherObsAuto('assistant');
    outilsHttp.sendJson(res, 200, { ok: true, detection, statut: etatRegie.obsState.status });
    return true;
  }

  // ---------- Twitch : connexion par code ----------
  if (req.method === 'POST' && url.pathname === '/api/twitch/code') {
    try {
      await twitchJeton.demarrerConnexionParCode();
      outilsHttp.sendJson(res, 200, { ok: true, twitchCode: etatRegie.obsState.twitchCode });
    } catch (e) {
      twitchJeton.majTwitchCode({ etape: 'erreur', code: '', lien: '', erreur: e.message });
      outilsHttp.sendJson(res, 200, { ok: false, error: e.message });
    }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/twitch/code/annuler') {
    twitchJeton.arreterInterrogationCode();
    twitchJeton.majTwitchCode({ etape: 'inactif', code: '', lien: '', expireA: 0, erreur: '' });
    outilsHttp.sendJson(res, 200, { ok: true });
    return true;
  }

  // ---------- Le pseudo de la chaîne ----------
  // Changé depuis l'appli (Réglages, ou la fin de l'assistant). Vide : on
  // revient au pseudo par défaut (kit, config.js, puis compte Twitch).
  if (req.method === 'POST' && url.pathname === '/api/pseudo') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      if (!body || typeof body.pseudo !== 'string') throw new Error('Indique un pseudo.');
      if (stockage.tokensIllisible) throw new Error('tokens.json est illisible : la régie n’y écrit plus rien tant qu’il n’est pas réparé (voir Mon installation).');
      const pseudo = pseudos.nettoyerPseudo(body.pseudo);
      const avant = stockage.platformTokens.pseudo;
      if (pseudo) stockage.platformTokens.pseudo = pseudo; else delete stockage.platformTokens.pseudo;
      if (!stockage.saveTokens()) {
        // Pas enregistré : on n'annonce pas un changement qui disparaîtrait
        // au prochain redémarrage.
        if (avant === undefined) delete stockage.platformTokens.pseudo; else stockage.platformTokens.pseudo = avant;
        throw new Error('Le pseudo n’a pas pu être enregistré : tokens.json est bloqué (antivirus, OneDrive, disque plein ?). Réessaie dans un instant.');
      }
      etatRegie.broadcastState();
      outilsHttp.sendJson(res, 200, { ok: true, pseudo: etatRegie.obsState.pseudo, source: etatRegie.obsState.pseudoSource });
    } catch (e) {
      outilsHttp.sendJson(res, 200, { ok: false, error: e.message });
    }
    return true;
  }

  // ---------- Kit pour quelqu'un d'autre ----------
  if (url.pathname === '/api/kit' && (req.method === 'GET' || req.method === 'POST')) {
    if (securite.estAutreOrigine(req)) { outilsHttp.sendJson(res, 403, { ok: false, error: 'Réservé aux pages servies par le pont.' }); return true; }
    try {
      // Ce qu'on prépare pour quelqu'un d'autre (data/kit-a-preparer.json),
      // et non le kit.json de CETTE régie : voir installation.js.
      let kit;
      if (req.method === 'POST') {
        const body = await outilsHttp.readJsonBody(req);
        kit = fabriqueKit.ecrirePreparationKit(parametres.RACINE, {
          twitchClientId: body.twitchClientId,
          contact: body.contact,
          pseudo: body.pseudo,
          raidCabane: body.raidCabane,
        });
        // Le Client ID a pu être repris pour cette régie-ci.
        twitchJeton.rafraichirKitDansEtat();
        etatRegie.broadcastState();
      } else {
        kit = fabriqueKit.lirePreparationKit(parametres.RACINE);
      }
      const node = fabriqueKit.sourceNodeDuKit();
      const wk = await fabriqueKit.sourceWkhtmlDuKit();
      outilsHttp.sendJson(res, 200, {
        ok: true,
        kit: { twitchClientId: kit.twitchClientId, contact: kit.contact, pseudo: kit.pseudo, raidCabane: kit.raidCabane },
        node: node ? { version: node.version, origine: node.origine } : null,
        wkhtml: wk && !wk.refus ? { version: wk.version, origine: wk.origine } : null,
        wkhtmlRefus: wk && wk.refus === 'x86'
          ? 'Le wkhtmltoimage de ce PC est la version 32 bits : il ne partira pas dans le kit. Installe la version 64 bits (wkhtmltopdf.org) pour l’inclure.'
          : '',
        lanceur: fs.existsSync(path.join(parametres.RACINE, 'Regie mobile.exe')),
      });
    } catch (e) {
      outilsHttp.sendJson(res, 200, { ok: false, error: e.message });
    }
    return true;
  }

  if (req.method === 'GET' && url.pathname === '/kit.zip') {
    if (securite.estAutreOrigine(req)) { res.writeHead(403); res.end(); return true; }
    try {
      const { morceaux, taille, nom } = await fabriqueKit.fabriquerKit();
      res.writeHead(200, {
        'Content-Type': 'application/zip',
        'Content-Disposition': 'attachment; filename="' + nom + '"',
        'Content-Length': taille,
        'Cache-Control': 'no-store',
      });
      for (const m of morceaux) res.write(m);
      res.end();
      console.log('[pont] Kit fabriqué : ' + nom + ' (' + Math.round(taille / 1024 / 1024) + ' Mo).');
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Kit impossible : ' + e.message);
    }
    return true;
  }
  return false;
}
