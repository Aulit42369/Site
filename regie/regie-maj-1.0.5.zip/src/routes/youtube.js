// ============================================================
//  Routes : YouTube
// ------------------------------------------------------------
//  Appelé par src/routes/index.js, une fois les barrières passées
//  (voir src/securite.js). « acces » dit qui appelle.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  traiter,
};

const outilsHttp = require('../http-outils.js');
const youtube = require('../youtube.js');

// Rend vrai si la demande a été traitée ici.
async function traiter(req, res, url, acces) {
  // Infos de la diffusion YouTube en cours (équivalent de la carte "Infos du
  // stream" de Twitch). Deux différences propres à YouTube : une description,
  // et des catégories de vidéo (Gaming, Musique...) plutôt qu'un jeu.
  if (req.method === 'GET' && url.pathname === '/api/youtube/broadcast') {
    try {
      await youtube.findActiveYoutubeLiveChatId(); // renseigne aussi broadcastId
      const id = youtube.youtubeLiveState.broadcastId;
      if (!id) { outilsHttp.sendJson(res, 200, { ok: true, live: false }); return true; }
      const accessToken = await youtube.ensureYoutubeToken();
      const r = await fetch(`https://www.googleapis.com/youtube/v3/videos?part=snippet&id=${encodeURIComponent(id)}`, {
        headers: { Authorization: `Bearer ${accessToken}` },
      });
      const d = await r.json();
      if (!r.ok) throw new Error((d.error && d.error.message) || ('HTTP ' + r.status));
      const sn = (d.items && d.items[0] && d.items[0].snippet) || {};
      outilsHttp.sendJson(res, 200, {
        ok: true, live: true, id,
        title: sn.title || '', description: sn.description || '',
        tags: sn.tags || [], categoryId: sn.categoryId || '',
      });
    } catch (e) {
      outilsHttp.sendJson(res, 200, { ok: false, error: e.message });
    }
    return true;
  }

  if (req.method === 'GET' && url.pathname === '/api/youtube/categories') {
    try {
      const accessToken = await youtube.ensureYoutubeToken();
      const r = await fetch('https://www.googleapis.com/youtube/v3/videoCategories?part=snippet&regionCode=FR', {
        headers: { Authorization: `Bearer ${accessToken}` },
      });
      const d = await r.json();
      if (!r.ok) throw new Error((d.error && d.error.message) || ('HTTP ' + r.status));
      // Toutes les catégories ne sont pas attribuables à une vidéo.
      const cats = (d.items || [])
        .filter((c) => c.snippet && c.snippet.assignable)
        .map((c) => ({ id: c.id, title: c.snippet.title }));
      outilsHttp.sendJson(res, 200, { ok: true, categories: cats });
    } catch (e) {
      outilsHttp.sendJson(res, 200, { ok: false, error: e.message });
    }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/youtube/broadcast') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      await youtube.findActiveYoutubeLiveChatId();
      const id = youtube.youtubeLiveState.broadcastId;
      if (!id) throw new Error("Aucune diffusion YouTube en cours — rien à modifier.");
      const accessToken = await youtube.ensureYoutubeToken();

      // Google efface toute propriété absente d'une mise à jour : on relit donc
      // la fiche complète et on ne remplace que les champs fournis, sinon la
      // description ou les tags disparaîtraient silencieusement.
      const cur = await fetch(`https://www.googleapis.com/youtube/v3/videos?part=snippet&id=${encodeURIComponent(id)}`, {
        headers: { Authorization: `Bearer ${accessToken}` },
      });
      const curData = await cur.json();
      if (!cur.ok) throw new Error((curData.error && curData.error.message) || ('HTTP ' + cur.status));
      const sn = (curData.items && curData.items[0] && curData.items[0].snippet) || {};

      const snippet = {
        title: body.title !== undefined ? String(body.title) : (sn.title || ''),
        description: body.description !== undefined ? String(body.description) : (sn.description || ''),
        tags: Array.isArray(body.tags) ? body.tags : (sn.tags || []),
        categoryId: body.categoryId || sn.categoryId || '20',
        defaultLanguage: sn.defaultLanguage,
        defaultAudioLanguage: sn.defaultAudioLanguage,
      };
      if (!snippet.title.trim()) throw new Error('YouTube exige un titre non vide.');

      const upd = await fetch('https://www.googleapis.com/youtube/v3/videos?part=snippet', {
        method: 'PUT',
        headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, snippet }),
      });
      const updData = await upd.json();
      if (!upd.ok) throw new Error((updData.error && updData.error.message) || ('HTTP ' + upd.status));
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 200, { ok: false, error: e.message });
    }
    return true;
  }

  if (req.method === 'GET' && url.pathname === '/api/youtube/live-events') {
    try {
      const chatId = await youtube.findActiveYoutubeLiveChatId();
      if (!chatId) { outilsHttp.sendJson(res, 200, { ok: true, live: false, events: [] }); return true; }
      const accessToken = await youtube.ensureYoutubeToken();
      const params = new URLSearchParams({ liveChatId: chatId, part: 'snippet,authorDetails' });
      if (youtube.youtubeLiveState.nextPageToken) params.set('pageToken', youtube.youtubeLiveState.nextPageToken);
      const apiRes = await fetch(`https://www.googleapis.com/youtube/v3/liveChat/messages?${params}`, {
        headers: { Authorization: `Bearer ${accessToken}` },
      });
      const data = await apiRes.json();
      if (!apiRes.ok) throw new Error((data.error && data.error.message) || 'Échec de lecture du tchat YouTube.');
      youtube.youtubeLiveState.nextPageToken = data.nextPageToken || youtube.youtubeLiveState.nextPageToken;
      const events = (data.items || []).map((item) => youtube.mapYoutubeChatItem(item, chatId)).filter(Boolean);
      outilsHttp.sendJson(res, 200, { ok: true, live: true, liveChatId: chatId, events });
    } catch (e) {
      outilsHttp.sendJson(res, 200, { ok: false, error: e.message });
    }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/youtube/moderate') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      const accessToken = await youtube.ensureYoutubeToken();
      const headers = { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' };
      if (body.action === 'delete') {
        const apiRes = await fetch(`https://www.googleapis.com/youtube/v3/liveChat/messages?id=${encodeURIComponent(body.messageId)}`, { method: 'DELETE', headers });
        if (!apiRes.ok && apiRes.status !== 204) {
          const d = await apiRes.json().catch(() => ({}));
          throw new Error((d.error && d.error.message) || 'Échec de la suppression.');
        }
      } else if (body.action === 'ban') {
        const apiRes = await fetch('https://www.googleapis.com/youtube/v3/liveChat/bans?part=snippet', {
          method: 'POST', headers,
          body: JSON.stringify({ snippet: { liveChatId: body.liveChatId, type: 'permanent', bannedUserDetails: { channelId: body.channelId } } }),
        });
        if (!apiRes.ok) {
          const d = await apiRes.json().catch(() => ({}));
          throw new Error((d.error && d.error.message) || 'Échec du bannissement.');
        }
      } else {
        throw new Error('Action inconnue.');
      }
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 200, { ok: false, error: e.message });
    }
    return true;
  }
  return false;
}
