// ============================================================
//  Routes : /setup, autorisations YouTube, Instagram, TikTok, publication
// ------------------------------------------------------------
//  Appelé par src/routes/index.js, une fois les barrières passées
//  (voir src/securite.js). « acces » dit qui appelle.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  traiter,
};

const parametres = require('../parametres.js');
const etatRegie = require('../etat-regie.js');
const outilsHttp = require('../http-outils.js');
const securite = require('../securite.js');
const stockage = require('../stockage.js');
const oauth = require('../oauth.js');
const youtube = require('../youtube.js');
const instagram = require('../instagram.js');
const tiktok = require('../tiktok.js');
const pageSetup = require('../page-setup.js');
const fabriqueKit = require('../kit.js');

// Ce qui relie ou publie sur Instagram : refusé dans une régie reçue en kit
// (voir instagram.refuserDansUnKit). Ici pour une réponse claire, avant
// même de lire la demande. Toute nouvelle route Instagram va dans cette
// liste (README.md, « Instagram dans un kit »).
const CHEMINS_INSTAGRAM = /^\/(api\/setup\/instagram\/|oauth\/instagram\/|api\/publish\/instagram$)/;

// Rend vrai si la demande a été traitée ici.
async function traiter(req, res, url, acces) {
  if (CHEMINS_INSTAGRAM.test(url.pathname) && fabriqueKit.dansUnKit()) {
    if (req.method === 'GET') outilsHttp.pageSimple(res, 403, 'Instagram', instagram.REFUS_KIT);
    else outilsHttp.sendJson(res, 403, { ok: false, dansUnKit: true, error: instagram.REFUS_KIT });
    return true;
  }

  if (req.method === 'GET' && url.pathname === '/setup') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    // Dans un kit, la page ne propose pas Instagram (image seulement).
    res.end(fabriqueKit.dansUnKit() ? pageSetup.sansInstagram(pageSetup.SETUP_HTML) : pageSetup.SETUP_HTML);
    return true;
  }

  if (req.method === 'GET' && url.pathname === '/api/setup/status') {
    // Cette route sert la page /setup, ouverte sur le PC. Les secrets des
    // applications (Google, Meta, TikTok) n'ont rien à faire dans une réponse
    // lisible par une page d'une autre origine : on ne renvoie alors que l'état
    // des connexions, sans aucun identifiant.
    if (securite.estAutreOrigine(req)) {
      outilsHttp.sendJson(res, 200, {
        youtube: !!(stockage.platformTokens.youtube && stockage.platformTokens.youtube.refreshToken),
        instagram: !!(stockage.platformTokens.instagram && stockage.platformTokens.instagram.accessToken),
        tiktok: !!(stockage.platformTokens.tiktok && stockage.platformTokens.tiktok.refreshToken),
      });
      return true;
    }
    outilsHttp.sendJson(res, 200, {
      youtube: !!(stockage.platformTokens.youtube && stockage.platformTokens.youtube.refreshToken),
      youtubeClientId: (stockage.platformTokens.youtube && stockage.platformTokens.youtube.clientId) || '',
      youtubeClientSecret: (stockage.platformTokens.youtube && stockage.platformTokens.youtube.clientSecret) || '',
      instagram: !!(stockage.platformTokens.instagram && stockage.platformTokens.instagram.accessToken),
      instagramAppId: (stockage.platformTokens.instagram && stockage.platformTokens.instagram.appId) || '',
      instagramAppSecret: (stockage.platformTokens.instagram && stockage.platformTokens.instagram.appSecret) || '',
      tiktok: !!(stockage.platformTokens.tiktok && stockage.platformTokens.tiktok.refreshToken),
      tiktokClientKey: (stockage.platformTokens.tiktok && stockage.platformTokens.tiktok.clientKey) || '',
      tiktokClientSecret: (stockage.platformTokens.tiktok && stockage.platformTokens.tiktok.clientSecret) || '',
    });
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/setup/youtube/credentials') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      stockage.platformTokens.youtube = { ...(stockage.platformTokens.youtube || {}), clientId: body.clientId, clientSecret: body.clientSecret };
      stockage.saveTokens();
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false });
    }
    return true;
  }

  if (req.method === 'GET' && url.pathname === '/oauth/youtube/start') {
    if (!stockage.platformTokens.youtube || !stockage.platformTokens.youtube.clientId) {
      res.writeHead(302, { Location: '/setup' }); res.end(); return true;
    }
    res.writeHead(302, { Location: youtube.youtubeAuthUrl() });
    res.end();
    return true;
  }

  if (req.method === 'GET' && url.pathname === '/oauth/youtube/callback') {
    const code = url.searchParams.get('code');
    const errorParam = url.searchParams.get('error');
    const demande = oauth.consommerEtatOauth('youtube', url.searchParams.get('state'));
    if (!demande) { oauth.retourNonDemande(res, 'youtube'); return true; }
    if (errorParam || !code) { oauth.refusOauth(res, 'youtube', { url }); return true; }
    try {
      const yt = stockage.platformTokens.youtube;
      const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ code, client_id: yt.clientId, client_secret: yt.clientSecret, redirect_uri: youtube.YT_REDIRECT_URI, grant_type: 'authorization_code' }),
      });
      const data = await tokenRes.json();
      if (!tokenRes.ok || !data.refresh_token) {
        throw new Error(data.error_description || "Pas de jeton de rafraîchissement reçu — retire l'accès à l'appli dans myaccount.google.com/permissions puis réessaie.");
      }
      yt.refreshToken = data.refresh_token;
      yt.accessToken = data.access_token;
      yt.expiresAt = Date.now() + (data.expires_in || 3600) * 1000;
      stockage.saveTokens();
      // L'onglet YouTube de l'appli n'apparaît qu'une fois YouTube relié.
      etatRegie.setState({ youtubeConfigure: true });
      oauth.pageRetourOauth(res, '✓ YouTube connecté. Tu peux fermer cette page.');
    } catch (e) {
      oauth.refusOauth(res, 'youtube', { erreur: e });
    }
    return true;
  }

  if (req.method === 'GET' && url.pathname === '/oauth/tiktok/start') {
    if (!stockage.platformTokens.tiktok || !stockage.platformTokens.tiktok.clientKey) {
      res.writeHead(302, { Location: '/setup' }); res.end(); return true;
    }
    res.writeHead(302, { Location: tiktok.tiktokAuthUrl() });
    res.end();
    return true;
  }

  if (req.method === 'GET' && url.pathname === '/oauth/tiktok/callback') {
    const code = url.searchParams.get('code');
    const errorParam = url.searchParams.get('error');
    const demande = oauth.consommerEtatOauth('tiktok', url.searchParams.get('state'));
    if (!demande || !demande.verifier) { oauth.retourNonDemande(res, 'tiktok'); return true; }
    if (errorParam || !code) { oauth.refusOauth(res, 'tiktok', { url }); return true; }
    try {
      const tt = stockage.platformTokens.tiktok;
      const verifier = demande.verifier;

      const tokenRes = await fetch('https://open.tiktokapis.com/v2/oauth/token/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          client_key: tt.clientKey, client_secret: tt.clientSecret, grant_type: 'authorization_code',
          code, redirect_uri: tiktok.TT_REDIRECT_URI, code_verifier: verifier,
        }),
      });
      const data = await tokenRes.json();

      if (!tokenRes.ok || !data.access_token) {
        throw new Error(data.error_description || "Échec de l'échange du code.");
      }
      tt.accessToken = data.access_token;
      tt.refreshToken = data.refresh_token;
      tt.expiresAt = Date.now() + (data.expires_in || 86400) * 1000;
      stockage.saveTokens();
      oauth.pageRetourOauth(res, '✓ TikTok connecté. Tu peux fermer cette page.');
    } catch (e) {
      oauth.refusOauth(res, 'tiktok', { erreur: e });
    }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/setup/instagram/credentials') {
    try {
      // Ceinture sous CHEMINS_INSTAGRAM : jamais d'identifiants Instagram
      // écrits dans une régie reçue en kit.
      instagram.refuserDansUnKit();
      const body = await outilsHttp.readJsonBody(req);
      const avant = stockage.platformTokens.instagram || {};
      const ig = { ...avant, appId: body.appId, appSecret: body.appSecret };
      // Une autre app Meta a pu enregistrer l'autre forme d'adresse de
      // retour : la prochaine connexion repart de « avec » (voir
      // instagram.adresseRetourInstagram).
      if (avant.appId !== body.appId) delete ig.retour;
      stockage.platformTokens.instagram = ig;
      stockage.saveTokens();
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      if (e.dansUnKit) outilsHttp.sendJson(res, 403, { ok: false, dansUnKit: true, error: e.message });
      else outilsHttp.sendJson(res, 400, { ok: false });
    }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/setup/tiktok/credentials') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      stockage.platformTokens.tiktok = { ...(stockage.platformTokens.tiktok || {}), clientKey: body.clientKey, clientSecret: body.clientSecret };
      stockage.saveTokens();
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false });
    }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/publish/youtube') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      if (!body.downloadUrl) throw new Error('Lien du clip manquant.');
      const clipRes = await fetch(body.downloadUrl);
      if (!clipRes.ok) throw new Error("Impossible de récupérer la vidéo du clip depuis Twitch.");
      const buf = Buffer.from(await clipRes.arrayBuffer());
      const videoUrl = await youtube.uploadToYoutube(buf, body.title);
      if (body.clipId) {
        etatRegie.obsState.publishedClips = { ...etatRegie.obsState.publishedClips, [body.clipId]: { ...(etatRegie.obsState.publishedClips[body.clipId] || {}), youtube: { url: videoUrl } } };
        stockage.persistSharedState();
        etatRegie.broadcastState();
      }
      outilsHttp.sendJson(res, 200, { ok: true, url: videoUrl });
    } catch (e) {
      outilsHttp.sendJson(res, 200, { ok: false, error: e.message || String(e) });
    }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/publish/instagram') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      if (!body.downloadUrl) throw new Error('Lien du clip manquant.');
      const permalink = await instagram.uploadToInstagram(body.downloadUrl, body.title);
      if (body.clipId) {
        etatRegie.obsState.publishedClips = { ...etatRegie.obsState.publishedClips, [body.clipId]: { ...(etatRegie.obsState.publishedClips[body.clipId] || {}), instagram: { url: permalink } } };
        stockage.persistSharedState();
        etatRegie.broadcastState();
      }
      outilsHttp.sendJson(res, 200, { ok: true, url: permalink });
    } catch (e) {
      outilsHttp.sendJson(res, 200, { ok: false, error: e.message || String(e) });
    }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/publish/tiktok') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      if (!body.downloadUrl) throw new Error('Lien du clip manquant.');
      const clipRes = await fetch(body.downloadUrl);
      if (!clipRes.ok) throw new Error("Impossible de récupérer la vidéo du clip depuis Twitch.");
      const buf = Buffer.from(await clipRes.arrayBuffer());
      await tiktok.uploadToTiktok(buf, body.title);
      outilsHttp.sendJson(res, 200, { ok: true, url: '' });
    } catch (e) {
      outilsHttp.sendJson(res, 200, { ok: false, error: e.message || String(e) });
    }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/clips/published') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      if (!body.clipId || !body.platform) throw new Error('Paramètres manquants.');
      if (!['youtube', 'instagram', 'tiktok'].includes(body.platform)) throw new Error('Plateforme inconnue.');
      // L'adresse devient un lien cliquable dans l'appli (sur le PC aussi) :
      // seulement une adresse web, jamais « javascript: » (voir stockage.lienWebOuVide).
      etatRegie.obsState.publishedClips = { ...etatRegie.obsState.publishedClips, [String(body.clipId)]: { ...(etatRegie.obsState.publishedClips[body.clipId] || {}), [body.platform]: { url: stockage.lienWebOuVide(body.url) } } };
      stockage.persistSharedState();
      etatRegie.broadcastState();
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false, error: e.message });
    }
    return true;
  }

  // ---------- Retour d'autorisation Instagram ----------
  // Meta exige du https pour cette redirection, même en local : ces deux
  // adresses sont à déclarer en https chez Meta, et le port https du pont
  // est celui du pont + 1. Elles vivent ici, dans le gestionnaire partagé,
  // pour qu'il n'y ait qu'un seul endroit où chercher une route.
  // Retour de l'autorisation Instagram, sur https://localhost:4561 : l'adresse
  // déclarée chez Meta (voir /setup), avec ou sans « / » final (voir
  // instagram.adresseRetourInstagram).
  if (req.method === 'GET' && (url.pathname === '/oauth/instagram/callback' || url.pathname === '/oauth/instagram/callback/')) {
    const demande = oauth.consommerEtatOauth('instagram', url.searchParams.get('state'));
    if (!demande) { oauth.retourNonDemande(res, 'instagram'); return true; }
    // Instagram ajoute « #_ » après le code : le navigateur ne l'envoie pas,
    // mais on le retire au cas où.
    const code = String(url.searchParams.get('code') || '').replace(/#_$/, '');
    if (url.searchParams.get('error') || !code) { oauth.refusOauth(res, 'instagram', { url }); return true; }
    // La forme de l'adresse envoyée au départ de CETTE autorisation.
    const forme = demande.forme === 'sans' ? 'sans' : 'avec';
    try {
      const { compte, avertissement } = await instagram.connecterInstagram(code, forme);
      oauth.pageRetourOauth(res, '✓ Instagram connecté (' + compte + ').' + (avertissement ? ' ' + avertissement : ' Tu peux fermer cette page.'));
    } catch (e) {
      // Adresse de retour refusée : ce code est grillé, mais une nouvelle
      // autorisation avec l'autre forme peut aboutir. Une seule relance :
      // au second refus, on s'arrête et on dit quoi vérifier.
      if (e.adresseDeRetour && demande.essai !== 2) {
        const autre = instagram.autreFormeRetour(forme);
        console.warn('[instagram] Adresse de retour ' + forme + ' « / » final refusée à l’échange du code : nouvelle autorisation avec l’adresse ' + autre + ' « / » final.');
        oauth.pageRelanceOauth(res, 'Instagram n’a pas accepté l’adresse de retour (' + forme + ' « / » final). La régie recommence avec l’autre forme : Instagram va te redemander d’autoriser, accepte une seconde fois.',
          instagram.instagramAuthUrl({ forme: autre, essai: 2 }));
        return true;
      }
      if (e.adresseDeRetour) e.message += ' ' + instagram.conseilAdresseRetour();
      oauth.refusOauth(res, 'instagram', { erreur: e });
    }
    return true;
  }

  if (req.method === 'GET' && url.pathname === '/oauth/instagram/start') {
    if (!stockage.platformTokens.instagram || !stockage.platformTokens.instagram.appId) {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end('<p style="font-family:system-ui">Configure d\'abord l\'App ID / App Secret sur <a href="http://127.0.0.1:' + parametres.PORT + '/setup">/setup</a>.</p>');
      return true;
    }
    res.writeHead(302, { Location: instagram.instagramAuthUrl() });
    res.end();
    return true;
  }
  return false;
}
