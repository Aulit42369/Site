// ============================================================
//  Les requêtes HTTP : barrières, puis routes par domaine
// ------------------------------------------------------------
//  Chaque demande passe les trois barrières (voir src/securite.js),
//  puis chaque fichier de routes, dans l’ordre, jusqu’à celui qui
//  la traite.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  gererRequete,
};

const parametres = require('../parametres.js');
const outilsHttp = require('../http-outils.js');
const securite = require('../securite.js');
const preuves = require('../preuves.js');
const routesStatique = require('./statique.js');
const routesInstallation = require('./installation.js');
const routesAppareils = require('./appareils.js');
const routesObs = require('./obs.js');
const routesMinuteur = require('./minuteur.js');
const routesAnnonce = require('./annonce.js');
const routesYoutube = require('./youtube.js');
const routesJournal = require('./journal.js');
const routesEntretien = require('./entretien.js');
const routesNotifications = require('./notifications.js');
const routesComptes = require('./comptes.js');
const routesTwitch = require('./twitch.js');
const routesAlertes = require('./alertes.js');
const routesMaj = require('./maj.js');

// Une ligne dans data/pont.log par refus, au plus une par quart d'heure pour
// une même cause : assez pour comprendre pourquoi un overlay ne reçoit rien,
// sans noyer le journal si une page insiste toutes les secondes.
const refusSignales = new Map();
function signalerRefus(cle, message) {
  const t = Date.now();
  if (t - (refusSignales.get(cle) || 0) < 15 * 60 * 1000) return;
  if (refusSignales.size > 200) refusSignales.clear();
  refusSignales.set(cle, t);
  console.warn('[sécurité] ' + message);
}

// Un seul gestionnaire pour les DEUX serveurs, http et https. Avant,
// seul le serveur https existait, et il ne servait que les deux adresses
// de retour d'Instagram : l'appli, elle, n'était accessible qu'en http.
// Or les navigateurs réservent les notifications et l'installation en
// vraie appli aux adresses sécurisées — d'où l'impossibilité d'avoir des
// notifications sur le téléphone. En partageant ce gestionnaire, la même
// appli répond sur les deux, et aucune route ne peut exister sur l'un
// sans exister sur l'autre.
async function gererRequete(req, res) {
  // Aucune page de la régie ne s'affiche dans le cadre d'une autre page : un
  // site piégé ne peut pas la poser, invisible, sous un faux bouton
  // (« clickjacking »). Sur toutes les réponses : plus sûr qu'au cas par cas.
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Content-Security-Policy', "frame-ancestors 'none'");

  // Barrière 0 : l'appelant est sur le réseau local (voir securite.appelantDuReseauLocal).
  if (!securite.appelantDuReseauLocal(req)) {
    const adresse = securite.adresseNormalisee(req.socket && req.socket.remoteAddress).slice(0, 60);
    signalerRefus('reseau:' + adresse, 'Requête refusée : ' + adresse + ' n’est pas une adresse du réseau local. Si c’est un appareil à toi (autre réseau, VPN), ajoute son adresse à REGIE_ADRESSES_DE_CONFIANCE dans le fichier .env.');
    res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8', 'X-Content-Type-Options': 'nosniff' });
    res.end('La régie ne répond qu’aux appareils du réseau local.');
    return;
  }

  // Barrière 1 : le nom appelé (voir securite.js, « Qui a le droit de lire quoi »).
  if (!securite.hoteAttendu(req)) {
    const hote = String(req.headers.host || '').slice(0, 80);
    signalerRefus('hote:' + hote, 'Requête refusée : la régie a été appelée sous le nom « ' + hote + ' », qui n’est pas le sien. Pour un nom à toi, ajoute-le à REGIE_HOTES_AUTORISES dans le fichier .env.');
    res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8', 'X-Content-Type-Options': 'nosniff' });
    res.end('Adresse non reconnue par la régie. Ouvre-la par l’adresse de ce PC (par exemple http://localhost:' + parametres.PORT + '/ sur le PC), ou ajoute ce nom à REGIE_HOTES_AUTORISES dans le fichier .env.');
    return;
  }

  let url;
  try { url = new URL(req.url, 'http://localhost'); } catch (e) { res.writeHead(400); res.end(); return; }

  // Barrière 2 : la page qui appelle, quand ce n'est pas la régie elle-même.
  if (req.headers.origin && !securite.originAutorisee(req)) {
    const origine = String(req.headers.origin).slice(0, 120);
    signalerRefus('origine:' + origine, 'Page refusée : ' + origine + ' a voulu interroger la régie. Si c’est ton overlay, ajoute cette adresse à REGIE_ORIGINES_AUTORISEES dans le fichier .env.');
    outilsHttp.sendJson(res, 403, { ok: false, error: 'Cette page n’a pas accès à la régie.' });
    return;
  }

  // … et la page d'un autre site qui appelle sans se nommer (image, script,
  // cadre : voir securite.requeteIntersiteMuette).
  if (securite.requeteIntersiteMuette(req, url.pathname)) {
    signalerRefus('intersite:' + url.pathname, 'Requête refusée : une page d’un autre site a voulu charger ' + url.pathname.slice(0, 80) + ' (' + String(req.headers['sec-fetch-dest'] || 'type inconnu').slice(0, 20) + ') sans se présenter.');
    res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8', 'X-Content-Type-Options': 'nosniff' });
    res.end('Réservé aux pages de la régie.');
    return;
  }

  // Le téléphone est-il passé ? (voir preuves.js)
  preuves.noterSiTelephone(req, url);

  // Verrou : une page d'une autre origine ne LIT que ce dont un overlay a
  // besoin (securite.LECTURES_OUVERTES) et ne commande que le minuteur
  // (securite.ECRITURES_OUVERTES). Placé ici, avant tout le reste, pour
  // qu'aucune route ajoutée plus tard ne puisse l'oublier. (Quelques routes
  // gardent leur propre refus, plus ancien : une ceinture de plus.)
  if (req.method !== 'OPTIONS' && securite.estAutreOrigine(req)) {
    const lecture = req.method === 'GET' || req.method === 'HEAD';
    const permise = lecture ? securite.lectureOuverte(url.pathname) : securite.ECRITURES_OUVERTES.has(url.pathname);
    if (!permise) {
      outilsHttp.sendJson(res, 403, {
        ok: false,
        error: lecture
          ? "Une page extérieure ne lit que l'état de la régie et les événements Twitch."
          : "Cette commande n'est acceptée que depuis l'appli servie par le pont.",
      });
      return;
    }
  }

  if (req.method === 'OPTIONS') {
    const origine = securite.originAutorisee(req);
    const entetes = { 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' };
    if (origine) { entetes['Access-Control-Allow-Origin'] = origine; entetes.Vary = 'Origin'; }
    // Les Chromium récents (donc le navigateur interne d'OBS) refusent qu'une
    // page atteigne une adresse du réseau local si le serveur ne l'a pas
    // explicitement permis. Sans cette ligne, un overlay en fichier local se
    // voit refuser l'accès au pont — sans le moindre message visible.
    if (req.headers['access-control-request-private-network'] === 'true') {
      entetes['Access-Control-Allow-Private-Network'] = 'true';
    }
    res.writeHead(204, entetes);
    res.end();
    return;
  }

  // Barrière 3 : l'appareil. Le PC passe toujours ; un appareil du réseau
  // doit être relié, sauf pour les pages d’installation (voir securite.ouvertATous),
  // et rien de ce qui configure les comptes ne s'ouvre ailleurs que sur le PC.
  const acces = securite.accesRequete(req);
  req.acces = acces;
  if (!acces || !acces.pc) {
    if (securite.reserveAuPc(url.pathname)) { securite.refuserHorsDuPc(req, res, url); return; }
    if (!acces && !securite.ouvertATous(req.method, url.pathname)) { securite.refuserAppareilInconnu(req, res, url); return; }
  }

  // Puis chaque fichier de routes, dans l’ordre, jusqu’à celui qui la traite.
  if (await routesStatique.traiter(req, res, url, acces)) return;
  if (await routesInstallation.traiter(req, res, url, acces)) return;
  if (await routesAppareils.traiter(req, res, url, acces)) return;
  if (await routesObs.traiter(req, res, url, acces)) return;
  if (await routesMinuteur.traiter(req, res, url, acces)) return;
  if (await routesAnnonce.traiter(req, res, url, acces)) return;
  if (await routesYoutube.traiter(req, res, url, acces)) return;
  if (await routesJournal.traiter(req, res, url, acces)) return;
  if (await routesEntretien.traiter(req, res, url, acces)) return;
  if (await routesNotifications.traiter(req, res, url, acces)) return;
  if (await routesComptes.traiter(req, res, url, acces)) return;
  if (await routesTwitch.traiter(req, res, url, acces)) return;
  if (await routesAlertes.traiter(req, res, url, acces)) return;
  if (await routesMaj.traiter(req, res, url, acces)) return;

  res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end('Introuvable');
}
