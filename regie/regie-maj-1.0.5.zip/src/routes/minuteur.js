// ============================================================
//  Routes : le minuteur
// ------------------------------------------------------------
//  Appelé par src/routes/index.js, une fois les barrières passées
//  (voir src/securite.js). « acces » dit qui appelle.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  traiter,
};

const minuterie = require('../minuterie.js');
const outilsHttp = require('../http-outils.js');
const reglagesRegie = require('../reglages-regie.js');
const securite = require('../securite.js');

// Rend vrai si la demande a été traitée ici.
async function traiter(req, res, url, acces) {
  if (req.method === 'POST' && url.pathname === '/api/timer/start') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      // Lancé par un overlay (une autre origine) : le décompte s'affiche
      // partout, mais sa fin ne joue pas les actions de fin de pause.
      minuterie.timerStart(body.seconds, { autreOrigine: securite.estAutreOrigine(req) });
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false, error: 'Requête invalide.' });
    }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/timer/pause') {
    minuterie.timerPause();
    outilsHttp.sendJson(res, 200, { ok: true });
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/timer/reset') {
    minuterie.timerReset();
    outilsHttp.sendJson(res, 200, { ok: true });
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/timer/config') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      minuterie.timerConfig({ actions: body.actions, finParOverlay: body.finParOverlay });
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false, error: 'Requête invalide.' });
    }
    return true;
  }

  // ---------- Source texte du compte à rebours ----------
  if (req.method === 'POST' && url.pathname === '/api/timer/overlay') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      minuterie.timerState.textSource = String(body.source || '');
      if (typeof body.texteFin === 'string') minuterie.timerState.textFinished = body.texteFin.slice(0, 60);
      if (typeof body.retourDans === 'boolean') minuterie.timerState.retourDans = body.retourDans;
      minuterie.dernierTexteMinuteur = null; // force la prochaine écriture
      reglagesRegie.persistExtras();
      minuterie.broadcastTimer();
      // Décompte en cours ou en pause : OBS suit tout de suite. Sans ça,
      // cocher « Retour dans » pendant une pause ne changeait rien à
      // l'écran avant la reprise.
      if (minuterie.timerState.remaining > 0) minuterie.ecrireMinuteurDansObs(minuterie.texteDecompte(minuterie.timerState.remaining));
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false, error: 'Requête invalide.' });
    }
    return true;
  }
  return false;
}
