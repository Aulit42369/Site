// ============================================================
//  Routes : appareils reliés
// ------------------------------------------------------------
//  Appelé par src/routes/index.js, une fois les barrières passées
//  (voir src/securite.js). « acces » dit qui appelle.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  traiter,
};

const { lireCookie, enteteCookie, nomParDefaut, enteteCookieEfface } = require('../appareils.js');

const outilsHttp = require('../http-outils.js');
const securite = require('../securite.js');

// Rend vrai si la demande a été traitée ici.
async function traiter(req, res, url, acces) {
  // ---------- Appareils reliés (voir ../appareils.js) ----------
  // Ouverte à tous : l'appli la consulte en démarrant, pour savoir s'il faut
  // d'abord passer par la page de liaison.
  if (req.method === 'GET' && url.pathname === '/api/appareils/moi') {
    if (acces && acces.appareil) {
      // Le cookie revient prolongé de 400 jours à chaque ouverture de
      // l'appli : un appareil dont on se sert ne se retrouve jamais délié.
      // (Le pont, lui, oublie un appareil absent depuis 90 jours : voir
      // ../appareils.js.)
      const secret = lireCookie(req.headers.cookie);
      if (secret) res.setHeader('Set-Cookie', enteteCookie(secret));
    }
    outilsHttp.sendJson(res, 200, {
      ok: true,
      relie: !!acces,
      pc: !!(acces && acces.pc),
      appareil: acces && acces.appareil ? { id: acces.appareil.id, nom: acces.appareil.nom } : null,
      nomPropose: nomParDefaut(req.headers['user-agent']),
    });
    return true;
  }

  // Ouverte à tous aussi : c'est là qu'un appareil tape le code du PC.
  if (req.method === 'POST' && url.pathname === '/api/appareils/relier') {
    if (acces && acces.pc) { outilsHttp.sendJson(res, 200, { ok: true, pc: true }); return true; }
    // 4 Ko suffisent largement (un code et un nom) : cette route est ouverte
    // à n'importe quel appareil du Wi-Fi, elle n'a pas à avaler 15 Mo.
    let corps;
    try {
      corps = await outilsHttp.readJsonBody(req, { max: 4096 });
    } catch (e) {
      outilsHttp.sendJson(res, e.tropGros ? 413 : 400, { ok: false, error: e.tropGros ? 'Demande trop longue.' : 'Demande illisible.' });
      return true;
    }
    const r = securite.appareils.relier({
      code: corps && corps.code,
      nom: corps && corps.nom,
      ua: req.headers['user-agent'],
      adresse: securite.adresseNormalisee(req.socket && req.socket.remoteAddress) || 'adresse inconnue',
      entete: req.headers.cookie,
    });
    if (!r.ok) { outilsHttp.sendJson(res, r.raison === 'essais' ? 429 : 400, { ok: false, raison: r.raison, error: r.error }); return true; }
    if (r.secret) res.setHeader('Set-Cookie', enteteCookie(r.secret));
    outilsHttp.sendJson(res, 200, { ok: true, deja: !!r.deja, appareil: r.appareil });
    return true;
  }

  // Un code de liaison : demandé par le PC (ou un appareil déjà relié), à
  // taper sur le nouvel appareil dans le quart d'heure.
  if (req.method === 'POST' && url.pathname === '/api/appareils/code') {
    const c = securite.appareils.nouveauCode(acces && acces.appareil ? acces.appareil.id : '');
    outilsHttp.sendJson(res, 200, { ok: true, code: c.code, expireA: c.expireA });
    return true;
  }

  if (req.method === 'GET' && url.pathname === '/api/appareils') {
    if (securite.estAutreOrigine(req)) { outilsHttp.sendJson(res, 403, { ok: false, error: 'Réservé à l’appli servie par le pont.' }); return true; }
    const actuel = acces && acces.appareil ? acces.appareil.id : '';
    outilsHttp.sendJson(res, 200, {
      ok: true,
      pc: !!(acces && acces.pc),
      appareils: securite.appareils.liste().map((a) => ({ ...a, actuel: a.id === actuel })),
    });
    return true;
  }

  if (req.method === 'POST' && (url.pathname === '/api/appareils/retirer' || url.pathname === '/api/appareils/retirer-tous')) {
    let ids = null;
    if (url.pathname === '/api/appareils/retirer') {
      const corps = await outilsHttp.readJsonBody(req).catch(() => ({}));
      const parti = securite.appareils.retirer(corps && corps.id);
      if (!parti) { outilsHttp.sendJson(res, 404, { ok: false, error: 'Cet appareil n’est déjà plus relié.' }); return true; }
      ids = new Set([parti.id]);
    } else {
      securite.appareils.retirerTous();
    }
    // Plus rien pour lui ni de lui : flux, notifications, annonces programmées.
    securite.oublierCeQuiVientDe(ids);
    // L'appareil qui se retire lui-même oublie aussi son cookie.
    if (acces && acces.appareil && (!ids || ids.has(acces.appareil.id))) res.setHeader('Set-Cookie', enteteCookieEfface());
    outilsHttp.sendJson(res, 200, { ok: true });
    return true;
  }
  return false;
}
