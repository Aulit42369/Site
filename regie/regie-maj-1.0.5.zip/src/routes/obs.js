// ============================================================
//  Routes : OBS, scènes, sources, panique, check-list
// ------------------------------------------------------------
//  Appelé par src/routes/index.js, une fois les barrières passées
//  (voir src/securite.js). « acces » dit qui appelle.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  traiter,
};

const etatRegie = require('../etat-regie.js');
const obs = require('../obs.js');
const obsCollections = require('../obs-collections.js');
const outilsHttp = require('../http-outils.js');
const securite = require('../securite.js');
const stockage = require('../stockage.js');
const reglagesRegie = require('../reglages-regie.js');

// Rend vrai si la demande a été traitée ici.
async function traiter(req, res, url, acces) {
  // État complet, pour l'appli — et pour un overlay à toi chargé en
  // « Fichier local » dans OBS, qui reçoit tout sauf les accès (voir
  // etatPourRequete et originAutorisee).
  if (req.method === 'GET' && url.pathname === '/api/obs/status') {
    outilsHttp.sendJson(res, 200, securite.etatPourRequete(req));
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/obs/refresh') {
    if (!obs.obsWs) {
      outilsHttp.sendJson(res, 200, { ok: false, error: 'OBS non connecté.' });
      return true;
    }
    // Redemande vraiment à OBS (contrairement à /api/obs/status qui ne fait
    // que relire ce que le pont a déjà en mémoire) — utile si les scènes ou
    // le mélangeur audio sont restés vides après une connexion difficile.
    obs.loadScenes();
    obs.loadAudioInputs();
    outilsHttp.sendJson(res, 200, { ok: true });
    return true;
  }

  if (req.method === 'GET' && url.pathname === '/api/obs/events') {
    etatRegie.brancherFluxSse(req, res, etatRegie.sseClients);
    // État initial, filtré comme les suivants : une page d'une autre origine
    // ne doit pas recevoir les accès, pas même dans ce tout premier message.
    res.write('data: ' + JSON.stringify(securite.etatPourRequete(req)) + '\n\n');
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/obs/connect') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      if (!body.host) { outilsHttp.sendJson(res, 400, { ok: false, error: 'Adresse IP manquante.' }); return true; }
      obs.connectToObs(body.host, body.port || '4455', body.password || '');
      stockage.platformTokens.obs = { host: body.host, port: body.port || '4455', password: body.password || '' };
      stockage.saveTokens();
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false, error: 'Requête invalide.' });
    }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/obs/disconnect') {
    obs.disconnectFromObs();
    outilsHttp.sendJson(res, 200, { ok: true });
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/obs/scene') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      await obs.obsRequest('SetCurrentProgramScene', { sceneName: body.sceneName });
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 200, { ok: false, error: e.message });
    }
    return true;
  }

  // ---------- Collection de scènes ----------
  // En direct ou en enregistrement, tout ce que voient les viewers change
  // pendant le chargement : il faut le confirmer. Vérifié ici et pas
  // seulement dans l'appli, pour qu'aucun autre appareil ne puisse sauter
  // l'étape.
  if (req.method === 'POST' && url.pathname === '/api/obs/collection') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      const nom = String(body.nom || '');
      if ((etatRegie.obsState.streaming || etatRegie.obsState.recording) && body.confirme !== true && nom !== etatRegie.obsState.collection) {
        outilsHttp.sendJson(res, 200, {
          ok: false,
          besoinConfirmation: true,
          error: etatRegie.obsState.streaming
            ? 'Tu es en direct : les viewers verront tout changer pendant le chargement de la collection.'
            : 'Un enregistrement est en cours : il enregistrera le chargement de la collection.',
        });
        return true;
      }
      await obsCollections.changerCollection(nom);
      outilsHttp.sendJson(res, 200, { ok: true, collection: etatRegie.obsState.collection });
    } catch (e) {
      outilsHttp.sendJson(res, 200, { ok: false, error: e.message });
    }
    return true;
  }

  // ---------- Capture de jeu / de fenêtre : quelle fenêtre ----------
  // La liste vient d'OBS : ce sont les fenêtres qu'il propose lui-même dans
  // les propriétés de la source. Les titres de fenêtres ouvertes (un mail,
  // une conversation, un document) n'ont rien à faire hors de la régie :
  // la liste est refusée aux pages d'une autre origine, comme le diagnostic.
  if (req.method === 'GET' && url.pathname === '/api/obs/capture/fenetres') {
    if (securite.estAutreOrigine(req)) {
      outilsHttp.sendJson(res, 403, { ok: false, error: 'Liste des fenêtres réservée à l’appli servie par le pont.' });
      return true;
    }
    const source = String(url.searchParams.get('source') || '');
    try {
      const reglages = await obs.obsRequest('GetInputSettings', { inputName: source });
      const kind = String(reglages.inputKind || '');
      if (!obsCollections.CAPTURES_FENETRE.has(kind)) throw new Error('« ' + source + ' » n’est ni une capture de jeu ni une capture de fenêtre.');
      const liste = await obs.obsRequest('GetInputPropertiesListPropertyItems', { inputName: source, propertyName: 'window' });
      const fenetres = (liste.propertyItems || [])
        .filter((i) => i && i.itemValue && i.itemEnabled !== false)
        .map((i) => ({ nom: String(i.itemName || obsCollections.nomFenetreObs(i.itemValue)), valeur: String(i.itemValue) }));
      const r = reglages.inputSettings || {};
      const valeur = String(r.window || '');
      // Réglage absent = valeur par défaut d'OBS, qui n'est pas renvoyée :
      // pour une capture de jeu, « n'importe quelle application en plein écran ».
      const mode = kind === 'game_capture' ? String(r.capture_mode || 'any_fullscreen') : 'window';
      const ouverte = fenetres.find((f) => f.valeur === valeur);
      outilsHttp.sendJson(res, 200, {
        ok: true, source, kind, mode, fenetres,
        actuelle: valeur ? { valeur, nom: ouverte ? ouverte.nom : obsCollections.nomFenetreObs(valeur), ouverte: !!ouverte } : null,
      });
    } catch (e) {
      outilsHttp.sendJson(res, 200, { ok: false, error: e.message, fenetres: [] });
    }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/obs/capture/fenetre') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      const source = String(body.source || '');
      const valeur = String(body.valeur || '');
      if (!source || !valeur || valeur.length > 1024) throw new Error('Choisis une fenêtre dans la liste.');
      const reglages = await obs.obsRequest('GetInputSettings', { inputName: source });
      const kind = String(reglages.inputKind || '');
      if (!obsCollections.CAPTURES_FENETRE.has(kind)) throw new Error('« ' + source + ' » n’est ni une capture de jeu ni une capture de fenêtre.');
      // Une capture de jeu réglée sur « plein écran » ignorerait la fenêtre
      // choisie : elle passe en « capturer une fenêtre spécifique ».
      const inputSettings = kind === 'game_capture' ? { capture_mode: 'window', window: valeur } : { window: valeur };
      await obs.obsRequest('SetInputSettings', { inputName: source, inputSettings, overlay: true });
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 200, { ok: false, error: e.message });
    }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/obs/source') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      await obs.obsRequest('SetSceneItemEnabled', {
        sceneName: body.sceneName,
        sceneItemId: body.sceneItemId,
        sceneItemEnabled: body.sceneItemEnabled,
      });
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 200, { ok: false, error: e.message });
    }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/obs/audio/volume') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      await obs.obsRequest('SetInputVolume', { inputName: body.inputName, inputVolumeDb: body.inputVolumeDb });
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 200, { ok: false, error: e.message });
    }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/obs/audio/mute') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      await obs.obsRequest('SetInputMute', { inputName: body.inputName, inputMuted: body.inputMuted });
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 200, { ok: false, error: e.message });
    }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/obs/stream/start') {
    try { await obs.obsRequest('StartStream'); outilsHttp.sendJson(res, 200, { ok: true }); }
    catch (e) { outilsHttp.sendJson(res, 200, { ok: false, error: e.message }); }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/obs/stream/stop') {
    try { await obs.obsRequest('StopStream'); outilsHttp.sendJson(res, 200, { ok: true }); }
    catch (e) { outilsHttp.sendJson(res, 200, { ok: false, error: e.message }); }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/obs/record/start') {
    try { await obs.obsRequest('StartRecord'); outilsHttp.sendJson(res, 200, { ok: true }); }
    catch (e) { outilsHttp.sendJson(res, 200, { ok: false, error: e.message }); }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/obs/record/stop') {
    try { await obs.obsRequest('StopRecord'); outilsHttp.sendJson(res, 200, { ok: true }); }
    catch (e) { outilsHttp.sendJson(res, 200, { ok: false, error: e.message }); }
    return true;
  }

  if (req.method === 'GET' && url.pathname === '/api/obs/stats') {
    try {
      const [stats, streamStatus] = await Promise.all([
        obs.obsRequest('GetStats').catch(() => ({})),
        obs.obsRequest('GetStreamStatus').catch(() => ({})),
      ]);
      outilsHttp.sendJson(res, 200, { ok: true, stats, streamStatus });
    } catch (e) {
      outilsHttp.sendJson(res, 200, { ok: false, error: e.message });
    }
    return true;
  }

  if (req.method === 'GET' && url.pathname === '/api/obs/text-sources') {
    try {
      const list = await obs.obsRequest('GetInputList');
      const textInputs = (list.inputs || []).filter((i) => (i.inputKind || '').startsWith('text_'));
      const withText = await Promise.all(textInputs.map(async (inp) => {
        try {
          const settings = await obs.obsRequest('GetInputSettings', { inputName: inp.inputName });
          return { inputName: inp.inputName, text: (settings.inputSettings && settings.inputSettings.text) || '' };
        } catch (e) {
          return { inputName: inp.inputName, text: '' };
        }
      }));
      outilsHttp.sendJson(res, 200, { ok: true, sources: withText });
    } catch (e) {
      outilsHttp.sendJson(res, 200, { ok: false, error: e.message, sources: [] });
    }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/obs/text') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      await obs.obsRequest('SetInputSettings', { inputName: body.inputName, inputSettings: { text: body.text }, overlay: true });
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 200, { ok: false, error: e.message });
    }
    return true;
  }

  // ---------- Raccourcis de scène ----------
  if (req.method === 'POST' && url.pathname === '/api/scene-shortcuts') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      if (!Array.isArray(body.raccourcis)) {
        outilsHttp.sendJson(res, 400, { ok: false, error: 'Format attendu : { raccourcis: [...] }' });
        return true;
      }
      etatRegie.obsState.sceneShortcuts = body.raccourcis.slice(0, 4).map((r) => ({
        label: String(r.label || '').slice(0, 14),
        scene: String(r.scene || ''),
        couleur: ['cyan', 'amber', 'violet', 'green', 'red'].includes(r.couleur) ? r.couleur : 'cyan',
      }));
      reglagesRegie.persistExtras();
      etatRegie.broadcastPatch({ sceneShortcuts: etatRegie.obsState.sceneShortcuts });
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false, error: 'Requête invalide.' });
    }
    return true;
  }

  // ---------- Bouton panique ----------
  if (req.method === 'POST' && url.pathname === '/api/panique') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      etatRegie.obsState.panique = {
        scene: String(body.scene || ''),
        micro: String(body.micro || ''),
      };
      reglagesRegie.persistExtras();
      etatRegie.broadcastPatch({ panique: etatRegie.obsState.panique });
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false, error: 'Requête invalide.' });
    }
    return true;
  }

  // ---------- Check-list d'avant-live ----------
  if (req.method === 'POST' && url.pathname === '/api/checklist') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      if (!Array.isArray(body.items)) {
        outilsHttp.sendJson(res, 400, { ok: false, error: 'Format attendu : { items: [...] }' });
        return true;
      }
      etatRegie.obsState.checklist = body.items.slice(0, 20).map((i, n) => ({
        id: String(i.id || 'i' + n),
        label: String(i.label || '').slice(0, 80),
        done: !!i.done,
      }));
      reglagesRegie.persistExtras();
      etatRegie.broadcastPatch({ checklist: etatRegie.obsState.checklist });
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false, error: 'Requête invalide.' });
    }
    return true;
  }
  return false;
}
