// ============================================================
//  Raid de fin de live : les membres de La Cabane en direct
// ------------------------------------------------------------
//  La Cabane publie la liste de ses membres (vitrine/membres.json,
//  site lacabanestreamers.github.io). Le pont la lit (gardée 60 s,
//  dernière liste connue si le site ne répond pas), demande à
//  Twitch qui est en direct (GET /helix/streams, 100 logins par
//  appel), et trie. Lancer et annuler un raid passent aussi ici.
//
//  Le tri, dans l'ordre :
//    1. même catégorie que la chaîne d'Olivier (game_id) ;
//    2. catégorie proche : le jeu du membre fait partie des jeux
//       habituels d'Olivier, ou le jeu d'Olivier fait partie des
//       jeux habituels du membre (champ « jeux » de La Cabane) ;
//    3. les autres ;
//  et dans chaque groupe, le moins de spectateurs d'abord (un raid
//  compte plus pour une petite chaîne).
//
//  Chaque fonction reçoit « appeler » : l'appel à Twitch avec le
//  jeton de la régie (appelerHelix de routes/twitch.js). Ce fichier
//  ne charge donc aucun autre fichier du pont, sauf les paramètres.
// ============================================================

module.exports = {
  annulerRaid,
  lancerRaid,
  suggestions,
  trier,
};

const parametres = require('./parametres.js');

let cache = null;         // { quand, membres } : dernière liste lue avec succès
let cacheLu = 0;          // quand le site a été interrogé pour la dernière fois

const DROIT_RAID = 'Le jeton Twitch de la régie n’a pas le droit de lancer un raid (channel:manage:raids). Reconnecte Twitch dans Réglages → Connexion Twitch : la nouvelle connexion demande ce droit.';

// Les membres de La Cabane : { membres, injoignable, depuis }.
async function membresCabane() {
  if (cache && Date.now() - cacheLu < parametres.CABANE_CACHE_MS) return { membres: cache.membres, injoignable: false, depuis: cache.quand };
  cacheLu = Date.now();
  try {
    const r = await fetch(parametres.CABANE_MEMBRES, { signal: AbortSignal.timeout(6000), headers: { Accept: 'application/json' } });
    if (!r.ok) throw new Error('code ' + r.status);
    const j = await r.json();
    const membres = (Array.isArray(j.membres) ? j.membres : [])
      .filter((m) => m && /^[a-z0-9_]{2,25}$/i.test(String(m.login || '')))
      .map((m) => ({
        login: String(m.login).toLowerCase(),
        nom: String(m.nom || m.login).slice(0, 60),
        avatar: /^https:\/\//.test(String(m.avatar || '')) ? String(m.avatar) : '',
        jeux: Array.isArray(m.jeux) ? m.jeux.map((x) => String(x).slice(0, 100)) : [],
      }));
    cache = { quand: Date.now(), membres };
    return { membres, injoignable: false, depuis: cache.quand };
  } catch (e) {
    // Le site ne répond pas : la dernière liste connue (au pire, aucune).
    return { membres: cache ? cache.membres : [], injoignable: true, depuis: cache ? cache.quand : 0 };
  }
}

const minuscule = (t) => String(t || '').trim().toLowerCase();

// Le tri décrit en tête de fichier. « moi » : { gameId, gameName, jeux }.
// Pur (sans réseau) : contrôlé seul par verif/controles-modules.js.
function trier(lives, moi) {
  const mesJeux = new Set((moi.jeux || []).map(minuscule));
  const monJeu = minuscule(moi.gameName);
  const avecRang = lives.map((l) => {
    let rang = 2, raison = '';
    if (moi.gameId && l.gameId === moi.gameId) { rang = 0; raison = 'Même jeu que toi'; }
    else if (l.gameName && mesJeux.has(minuscule(l.gameName))) { rang = 1; raison = 'Un jeu que tu streames aussi'; }
    else if (monJeu && (l.jeux || []).map(minuscule).includes(monJeu)) { rang = 1; raison = 'Joue souvent à ' + moi.gameName; }
    return { ...l, rang, raison };
  });
  return avecRang.sort((a, b) => a.rang - b.rang || a.spectateurs - b.spectateurs || a.nom.localeCompare(b.nom, 'fr'));
}

async function quiSuisJe(appeler) {
  const moi = await appeler('/helix/users', 'GET');
  const u = moi.ok && moi.donnees.data && moi.donnees.data[0];
  return u && u.id ? { id: String(u.id), login: minuscule(u.login) } : { erreur: moi };
}

// La liste pour la carte « Raid · La Cabane ».
async function suggestions(appeler) {
  const moi = await quiSuisJe(appeler);
  if (!moi.id) return { ok: false, statut: moi.erreur.statut, error: 'Twitch n’a pas dit qui est connecté (' + (moi.erreur.donnees.message || 'code ' + moi.erreur.statut) + ').' };
  const cabane = await membresCabane();
  const autres = cabane.membres.filter((m) => m.login !== moi.login);
  const chaine = await appeler('/helix/channels?broadcaster_id=' + encodeURIComponent(moi.id), 'GET');
  const c = (chaine.ok && chaine.donnees.data && chaine.donnees.data[0]) || {};
  const fiche = cabane.membres.find((m) => m.login === moi.login);
  const contexte = { gameId: String(c.game_id || ''), gameName: String(c.game_name || ''), jeux: fiche ? fiche.jeux : [] };

  // Twitch accepte 100 logins par appel.
  const lives = [];
  for (let i = 0; i < autres.length; i += 100) {
    const lot = autres.slice(i, i + 100);
    const r = await appeler('/helix/streams?first=100&' + lot.map((m) => 'user_login=' + encodeURIComponent(m.login)).join('&'), 'GET');
    if (!r.ok) return { ok: false, statut: r.statut, error: 'Twitch n’a pas donné les lives (' + (r.donnees.message || 'code ' + r.statut) + ').' };
    for (const s of r.donnees.data || []) {
      if (s.type && s.type !== 'live') continue;
      if (String(s.user_id) === moi.id) continue;
      const m = autres.find((x) => x.login === minuscule(s.user_login));
      if (!m) continue;
      lives.push({
        id: String(s.user_id), login: m.login, nom: String(s.user_name || m.nom), avatar: m.avatar, jeux: m.jeux,
        gameId: String(s.game_id || ''), gameName: String(s.game_name || ''), titre: String(s.title || ''),
        spectateurs: Number(s.viewer_count) || 0, debut: String(s.started_at || ''),
      });
    }
  }
  return {
    ok: true,
    monJeu: contexte.gameName,
    membres: cabane.membres.length,
    cabaneInjoignable: cabane.injoignable,
    cabaneDepuis: cabane.depuis,
    lives: trier(lives, contexte).map(({ jeux, ...l }) => l),
  };
}

// Le refus de Twitch, dit simplement. Commun au lancement et à l'annulation.
function refus(r, quoi) {
  const message = String(r.donnees.message || '');
  if (r.statut === 403 || (r.statut === 401 && /scope/i.test(message))) return { ok: false, droitManquant: true, error: DROIT_RAID };
  if (r.statut === 401) return { ok: false, jetonExpire: true, error: 'Connexion Twitch expirée ou révoquée — reconnecte-la dans Réglages → Connexion Twitch.' };
  if (r.statut === 429) return { ok: false, error: 'Twitch limite les raids : attends quelques secondes et réessaie.' };
  return { ok: false, error: quoi + ' refusé par Twitch : ' + (message || 'code ' + r.statut) };
}

// POST /helix/raids : Twitch lance un compte à rebours (90 s environ), puis le raid.
async function lancerRaid(appeler, versId) {
  if (!/^\d{1,20}$/.test(String(versId || ''))) return { ok: false, error: 'Chaîne à raider inconnue.' };
  const moi = await quiSuisJe(appeler);
  if (!moi.id) return { ok: false, error: 'Twitch n’a pas dit qui est connecté (' + (moi.erreur.donnees.message || 'code ' + moi.erreur.statut) + ').' };
  if (moi.id === String(versId)) return { ok: false, error: 'Impossible de se raider soi-même.' };
  const r = await appeler('/helix/raids?from_broadcaster_id=' + moi.id + '&to_broadcaster_id=' + versId, 'POST');
  if (r.ok) {
    const d = (r.donnees.data && r.donnees.data[0]) || {};
    return { ok: true, creeA: d.created_at || new Date().toISOString(), mature: !!d.is_mature };
  }
  if (r.statut === 409) return { ok: false, error: 'Un raid est déjà en préparation : annule-le d’abord.' };
  return refus(r, 'Raid');
}

// DELETE /helix/raids : seulement pendant le compte à rebours.
async function annulerRaid(appeler) {
  const moi = await quiSuisJe(appeler);
  if (!moi.id) return { ok: false, error: 'Twitch n’a pas dit qui est connecté (' + (moi.erreur.donnees.message || 'code ' + moi.erreur.statut) + ').' };
  const r = await appeler('/helix/raids?broadcaster_id=' + moi.id, 'DELETE');
  if (r.ok) return { ok: true };
  if (r.statut === 404) return { ok: false, dejaParti: true, error: 'Aucun raid en attente : il est déjà parti, ou il a été annulé.' };
  return refus(r, 'Annulation');
}
