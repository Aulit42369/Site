// ============================================================
//  Où OBS range son serveur WebSocket (port, mot de passe)
// ------------------------------------------------------------
//  Lu directement dans les fichiers d'OBS, au lieu de demander à
//  quelqu'un qui n'y connaît rien de recopier un port et un mot de
//  passe. Le mot de passe ne quitte jamais le pont.
// ============================================================
'use strict';

module.exports = {
  detecterObs,
  dossierConfigObs,
  lireIni,
};

const fs = require('fs');
const os = require('os');
const path = require('path');

// Où OBS range sa configuration. REGIE_OBS_CONFIG_DIR sert aux contrôles
// de verif/ ; en usage normal, ne rien définir.
function dossierConfigObs() {
  if (process.env.REGIE_OBS_CONFIG_DIR) return process.env.REGIE_OBS_CONFIG_DIR;
  if (process.platform === 'win32') {
    return path.join(process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming'), 'obs-studio');
  }
  if (process.platform === 'darwin') return path.join(os.homedir(), 'Library', 'Application Support', 'obs-studio');
  return path.join(process.env.XDG_CONFIG_HOME || path.join(os.homedir(), '.config'), 'obs-studio');
}

function lireIni(chemin, section) {
  const texte = fs.readFileSync(chemin, 'utf8').replace(/^﻿/, '');
  const valeurs = {};
  let dedans = false;
  for (const ligneBrute of texte.split(/\r?\n/)) {
    const ligne = ligneBrute.trim();
    if (!ligne || ligne.startsWith(';') || ligne.startsWith('#')) continue;
    const s = /^\[(.+)\]$/.exec(ligne);
    if (s) { dedans = s[1] === section; continue; }
    if (!dedans) continue;
    const i = ligne.indexOf('=');
    if (i > 0) valeurs[ligne.slice(0, i).trim()] = ligne.slice(i + 1); // le mot de passe peut contenir « = »
  }
  return valeurs;
}

const versBooleen = (v, defaut) => {
  if (typeof v === 'boolean') return v;
  if (typeof v === 'string') return /^(true|1)$/i.test(v.trim()) ? true : (/^(false|0)$/i.test(v.trim()) ? false : defaut);
  return defaut;
};

// Lit le serveur WebSocket d'OBS tel qu'OBS l'a enregistré. Deux formats :
//  • obs-websocket récent : plugin_config/obs-websocket/config.json
//  • obs-websocket 5.0 à 5.2 (OBS 28-29) : section [OBSWebSocket] de
//    global.ini (OBS déplace ensuite ces valeurs dans config.json).
// Valeurs par défaut = celles du code d'obs-websocket : désactivé, port
// 4455, authentification requise.
function detecterObs() {
  const dossier = dossierConfigObs();
  const resultat = { trouve: false, dossier, source: '', active: false, port: 4455, authRequise: true, motDePasse: '' };

  const json = path.join(dossier, 'plugin_config', 'obs-websocket', 'config.json');
  try {
    const d = JSON.parse(fs.readFileSync(json, 'utf8').replace(/^﻿/, ''));
    return {
      ...resultat,
      trouve: true,
      source: 'config.json',
      active: versBooleen(d.server_enabled, false),
      port: Number(d.server_port) > 0 && Number(d.server_port) < 65536 ? Number(d.server_port) : 4455,
      authRequise: versBooleen(d.auth_required, true),
      motDePasse: typeof d.server_password === 'string' ? d.server_password : '',
    };
  } catch (e) { /* format ancien ou OBS absent : on continue */ }

  for (const fichier of ['global.ini', 'user.ini']) {
    try {
      const v = lireIni(path.join(dossier, fichier), 'OBSWebSocket');
      if (!Object.keys(v).length) continue;
      return {
        ...resultat,
        trouve: true,
        source: fichier,
        active: versBooleen(v.ServerEnabled, false),
        port: Number(v.ServerPort) > 0 && Number(v.ServerPort) < 65536 ? Number(v.ServerPort) : 4455,
        authRequise: versBooleen(v.AuthRequired, true),
        motDePasse: typeof v.ServerPassword === 'string' ? v.ServerPassword : '',
      };
    } catch (e) { /* fichier absent */ }
  }

  // OBS installé (son dossier existe) mais jamais ouvert avec le module
  // WebSocket : on le distingue d'« OBS absent », le conseil n'est pas
  // le même.
  try { if (fs.statSync(dossier).isDirectory()) return { ...resultat, obsInstalle: true }; } catch (e) {}
  return resultat;
}
