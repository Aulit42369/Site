// ============================================================
//  wkhtmltoimage : le trouver, le lancer, expliquer ses pannes
// ------------------------------------------------------------
//  Le seul programme extérieur de tout le pont, et seulement pour
//  l'image d'annonce : absent, tout le reste marche. Windows :
//  https://wkhtmltopdf.org/downloads.html (installeur ~80 Mo, ajoute
//  wkhtmltoimage au PATH). Chemin personnalisable par la variable
//  WKHTMLTOIMAGE_PATH (voir .env.example).
//
//  Un kit apporte sa propre copie (wkhtmltopdf/wkhtmltoimage.exe, à
//  côté de server.js) : la personne qui le reçoit n'a rien à
//  installer. Elle passe avant celle du PC, mais après
//  WKHTMLTOIMAGE_PATH, réglé exprès.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  architecturePe,
  expliquerBlocageWkhtml,
  expliquerEchecWkhtml,
  expliquerLenteurWkhtml,
  lancerSansFenetre,
  lieuWkhtml,
  runWkhtmlToImage,
  wkhtmlDisponible,
  get WKHTML_ABSENT() { return WKHTML_ABSENT; },
  get WKHTML_BLOQUE() { return WKHTML_BLOQUE; },
  get WKHTML_DU_KIT() { return WKHTML_DU_KIT; },
  get WKHTMLTOIMAGE_CANDIDATES() { return WKHTMLTOIMAGE_CANDIDATES; },
};

const { execFile } = require('child_process');
const fs = require('fs');
const path = require('path');

const parametres = require('./parametres.js');

const WKHTML_DU_KIT = path.join(parametres.RACINE, 'wkhtmltopdf', 'wkhtmltoimage.exe');
const WKHTMLTOIMAGE_CANDIDATES = [
  process.env.WKHTMLTOIMAGE_PATH,
  // Un .exe Windows : ailleurs, il ne servirait qu'à échouer (la variable
  // REGIE_WKHTML_KIT_PARTOUT sert aux contrôles de verif/).
  (process.platform === 'win32' || process.env.REGIE_WKHTML_KIT_PARTOUT === '1') ? WKHTML_DU_KIT : null,
  'wkhtmltoimage',
  'C:\\Program Files\\wkhtmltopdf\\bin\\wkhtmltoimage.exe',
  'C:\\Program Files (x86)\\wkhtmltopdf\\bin\\wkhtmltoimage.exe',
].filter(Boolean);
// Absent : on passe au suivant, sans rien dire.
const WKHTML_ABSENT = new Set(['ENOENT']);
// Présent, mais impossible à lancer ici (droits, antivirus, fichier
// abîmé…) : on passe aussi au suivant, et on s'en souvient pour
// l'expliquer si aucun ne marche.
const WKHTML_BLOQUE = new Set(['EACCES', 'EPERM', 'ENOEXEC', 'EFTYPE', 'ELOOP', 'EBUSY', 'EISDIR', 'ENOTDIR', 'UNKNOWN']);
function lieuWkhtml(chemin) {
  return chemin === WKHTML_DU_KIT ? 'dans le dossier wkhtmltopdf de la régie' : chemin;
}

// execFile peut LEVER une erreur au lieu d'appeler son rappel : Node ne
// passe au rappel que ENOENT, EACCES, EAGAIN, EMFILE et ENFILE, et lève
// tout le reste sur le coup (EPERM quand un antivirus bloque, EBUSY,
// UNKNOWN…). Levée depuis un rappel, l'erreur partait dans le filet global
// et la promesse ne se terminait jamais : « Mon installation » restait
// suspendue. Ici, tout passe par le rappel — et toujours sans fenêtre.
function lancerSansFenetre(fichier, args, options, rappel) {
  try {
    execFile(fichier, args, { ...options, windowsHide: true }, rappel);
  } catch (e) {
    process.nextTick(rappel, e, '', '');
  }
}

// Essaie chaque chemin candidat l'un après l'autre ; ne passe au
// suivant que si celui-ci est introuvable (voir WKHTML_ABSENT) — toute
// autre erreur (mauvais argument, page invalide...) remonte tout de
// suite, pas la peine d'essayer les autres chemins dans ce cas.
//
// windowsHide est indispensable : lancé par Regie mobile.exe, le pont n'a
// pas de fenêtre, et Windows en ouvrirait alors une, noire, à chaque image.
function runWkhtmlToImage(args) {
  return new Promise((resolve, reject) => {
    let bloque = null;
    function tryNext(i) {
      if (i >= WKHTMLTOIMAGE_CANDIDATES.length) {
        reject(new Error(bloque
          ? expliquerBlocageWkhtml(lieuWkhtml(bloque.chemin), bloque.code)
          : "wkhtmltoimage introuvable. Installe-le depuis https://wkhtmltopdf.org/downloads.html, " +
            "PUIS redémarre la régie : clic droit sur son icône près de l'horloge → « Redémarrer la régie » " +
            "(ou ferme la fenêtre noire et relance start.bat). Elle ne voit un logiciel installé qu'à son " +
            "démarrage : une simple actualisation de la page ne suffit pas."
        ));
        return;
      }
      const chemin = WKHTMLTOIMAGE_CANDIDATES[i];
      lancerSansFenetre(chemin, args, { timeout: 20000 }, (err) => {
        if (err && WKHTML_ABSENT.has(err.code)) { tryNext(i + 1); return; }
        if (err && WKHTML_BLOQUE.has(err.code)) { bloque = bloque || { chemin, code: err.code }; tryNext(i + 1); return; }
        const explication = expliquerEchecWkhtml(err, chemin);
        if (explication) { const e = new Error(explication); e.explique = true; resolve(e); return; }
        resolve(err || null);
      });
    }
    tryNext(0);
  });
}

// wkhtmltoimage marche-t-il ? (pour le diagnostic) Un résultat positif est
// gardé 10 min ; un négatif 15 s seulement, pour qu'une réparation (un
// composant de Windows installé) se voie dès l'actualisation de la page.
let cacheWkhtml = { quand: 0, resultat: null };
function wkhtmlDisponible() {
  const c = cacheWkhtml;
  if (c.resultat && Date.now() - c.quand < (c.resultat.present ? 10 * 60 * 1000 : 15 * 1000)) {
    return Promise.resolve(c.resultat);
  }
  return new Promise((resolve) => {
    const finir = (resultat) => { cacheWkhtml = { quand: Date.now(), resultat }; resolve(resultat); };
    let bloque = null;
    const essayer = (i) => {
      if (i >= WKHTMLTOIMAGE_CANDIDATES.length) {
        finir({ present: false, raison: bloque ? expliquerBlocageWkhtml(lieuWkhtml(bloque.chemin), bloque.code) : '' });
        return;
      }
      const chemin = WKHTMLTOIMAGE_CANDIDATES[i];
      lancerSansFenetre(chemin, ['--version'], { timeout: 8000 }, (err) => {
        if (err && WKHTML_ABSENT.has(err.code)) { essayer(i + 1); return; }
        if (err && WKHTML_BLOQUE.has(err.code)) { bloque = bloque || { chemin, code: err.code }; essayer(i + 1); return; }
        if (err && err.killed) { finir({ present: false, raison: expliquerLenteurWkhtml() }); return; }
        finir({ present: !err, raison: err ? expliquerEchecWkhtml(err, chemin) : '' });
      });
    };
    essayer(0);
  });
}

// L'architecture d'un programme Windows, lue dans son en-tête (PE) :
// 'x64', 'x86', 'arm64', ou '' si ce n'est pas un programme Windows.
function architecturePe(chemin) {
  let fd;
  try {
    fd = fs.openSync(chemin, 'r');
    const tete = Buffer.alloc(4096);
    const lus = fs.readSync(fd, tete, 0, tete.length, 0);
    if (lus < 64 || tete.toString('latin1', 0, 2) !== 'MZ') return '';
    const pe = tete.readUInt32LE(0x3c);
    if (pe + 6 > lus || tete.toString('latin1', pe, pe + 4) !== 'PE\0\0') return '';
    const machine = tete.readUInt16LE(pe + 4);
    if (machine === 0x8664) return 'x64';
    if (machine === 0x14c) return 'x86';
    if (machine === 0xaa64) return 'arm64';
    return '';
  } catch (e) {
    return '';
  } finally {
    if (fd !== undefined) { try { fs.closeSync(fd); } catch (e) { /* déjà fermé */ } }
  }
}

// Quand Windows ne peut même pas DÉMARRER un programme, Node ne rapporte
// qu'un code de sortie (« Command failed »), qui ne dit rien à personne.
// Le cas attendu ici : la bibliothèque « Visual C++ » de Microsoft
// (MSVCP140.dll, VCRUNTIME140.dll) que réclame wkhtmltoimage. OBS
// l'installe d'habitude, d'où sa rareté sur un PC de stream — mais le
// jour où elle manque, il faut dire quoi installer, dans la bonne
// version (32 ou 64 bits, celle du programme).
const LIEN_VISUAL_CPP = {
  x64: 'https://aka.ms/vs/17/release/vc_redist.x64.exe',
  x86: 'https://aka.ms/vs/17/release/vc_redist.x86.exe',
};
const CODES_DEMARRAGE_IMPOSSIBLE = new Set([
  0xC0000135, // une DLL est introuvable
  0xC0000139, // une DLL est trop ancienne (point d'entrée absent)
  0xC0000142, // une DLL n'a pas pu s'initialiser
  0xC000007B, // DLL 32 bits pour un programme 64 bits, ou abîmée
]);
function expliquerEchecWkhtml(err, chemin) {
  if (!err || typeof err.code !== 'number') return '';
  if (!CODES_DEMARRAGE_IMPOSSIBLE.has(err.code >>> 0)) return '';
  const archi = chemin && architecturePe(chemin) === 'x86' ? 'x86' : 'x64';
  return 'wkhtmltoimage ne démarre pas : il manque à Windows un composant de Microsoft, '
    + '« Visual C++ Redistributable » (' + archi + '). Installe-le depuis ' + LIEN_VISUAL_CPP[archi]
    + ' puis réessaie : pas besoin de redémarrer la régie.';
}

// Présent, mais l'ordinateur refuse de le lancer : sur un .exe non signé
// arrivé par un zip, c'est presque toujours l'antivirus.
function expliquerBlocageWkhtml(lieu, code) {
  return 'wkhtmltoimage est bien là (' + lieu + '), mais l’ordinateur refuse de le lancer (' + code + ') : '
    + 'un antivirus le bloque sans doute. Autorise-le dans l’antivirus, ou installe wkhtmltoimage depuis '
    + 'https://wkhtmltopdf.org/downloads.html, puis redémarre la régie.';
}

// Il a répondu trop lentement : au premier lancement, l'antivirus examine
// parfois longuement un programme qu'il ne connaît pas.
function expliquerLenteurWkhtml() {
  return 'wkhtmltoimage n’a pas répondu à temps. Au premier lancement, l’antivirus l’examine parfois '
    + 'longuement : actualise la page dans une minute.';
}
