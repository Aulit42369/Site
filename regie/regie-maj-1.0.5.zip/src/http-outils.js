// ============================================================
//  Petits outils HTTP
// ------------------------------------------------------------
//  Lire une demande, répondre en JSON ou par une page simple, servir
//  l’appli compressée.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  demarrer,
  echapperHtml,
  get indexHtml() { return indexHtml; },
  litCompresse,
  pageSimple,
  readJsonBody,
  sendJson,
};

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const parametres = require('./parametres.js');
const securite = require('./securite.js');

// ------------------------------------------------------------
// Petit serveur HTTP (sans dépendance) : sert l'appli + l'API
// ------------------------------------------------------------
let indexHtml;

// Compression mise en cache, indexée sur la date de modification du fichier.
// Elle était refaite à chaque requête : comprimer 334 Ko est un travail
// synchrone, donc pendant ce temps le pont ne répond à personne d'autre —
// ni à l'overlay, ni à une commande de scène. Et l'appli est redemandée à
// chaque ouverture ou rechargement de page, sur chaque appareil.
// La date de modification comme clé préserve l'intérêt de la relecture :
// toucher config.js ou recompiler l'appli invalide le cache tout seul,
// un simple rechargement de la page suffit toujours.
const cacheCompresse = new Map();
function litCompresse(chemin, cle) {
  const mtime = fs.statSync(chemin).mtimeMs;
  const garde = cacheCompresse.get(cle);
  if (garde && garde.mtime === mtime) return garde.gz;
  const gz = zlib.gzipSync(fs.readFileSync(chemin));
  cacheCompresse.set(cle, { mtime, gz });
  return gz;
}

// « max » : la taille permise, en octets (15 Mo par défaut, de quoi passer
// une image d'annonce). Comptée PENDANT la lecture, et non d'après l'en-tête
// Content-Length : une demande envoyée par morceaux n'en a pas. L'erreur
// rendue porte « tropGros » (la route répond alors 413).
function readJsonBody(req, { max = 15e6 } = {}) {
  return new Promise((resolve, reject) => {
    // Les morceaux sont assemblés en binaire avant d'être décodés : convertir
    // chaque morceau séparément casse les caractères accentués qui tombent à
    // cheval sur une frontière, et le JSON reste valide — la légende partait
    // alors en charabia sur Instagram sans que rien ne le signale.
    const morceaux = [];
    let taille = 0;
    req.on('data', (chunk) => {
      taille += chunk.length;
      if (taille > max) {
        // On coupe la LECTURE sans tuer la connexion : détruire le socket
        // empêchait la route d'envoyer sa réponse d'erreur, et l'appli
        // n'affichait qu'un « impossible de contacter le pont » trompeur.
        req.pause();
        req.removeAllListeners('data');
        req.removeAllListeners('end');
        const e = new Error('Corps de requête trop volumineux (' + (max >= 1e6 ? Math.round(max / 1e6) + ' Mo' : Math.round(max / 1024) + ' Ko') + ' maximum).');
        e.tropGros = true;
        reject(e);
        return;
      }
      morceaux.push(chunk);
    });
    req.on('end', () => {
      if (!morceaux.length) { resolve({}); return; }
      try { resolve(JSON.parse(Buffer.concat(morceaux).toString('utf8'))); } catch (e) { reject(e); }
    });
    req.on('error', reject);
  });
}

// Une page de quelques lignes, aux couleurs des pages d'installation. Tout ce
// qui vient de l'extérieur passe par echapperHtml.
function pageSimple(res, statut, titre, message, lien) {
  res.writeHead(statut, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end('<!DOCTYPE html><html lang="fr"><head><meta charset="utf-8">'
    + '<meta name="viewport" content="width=device-width, initial-scale=1">'
    + '<title>' + echapperHtml(titre) + ' · Régie mobile</title>'
    + '<link rel="stylesheet" href="/guide/guide.css"></head><body><div class="page">'
    + '<h1>' + echapperHtml(titre) + '</h1><p class="chapo">' + echapperHtml(message) + '</p>'
    + (lien ? '<p><a class="bouton" href="' + echapperHtml(lien.href) + '">' + echapperHtml(lien.texte) + '</a></p>' : '')
    + '</div></body></html>');
}

function sendJson(res, statusCode, obj) {
  const body = JSON.stringify(obj);
  const entetes = {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
  };
  // res.req évite d'avoir à passer la requête aux centaines d'appels existants.
  const origine = res.req && securite.originAutorisee(res.req);
  if (origine) { entetes['Access-Control-Allow-Origin'] = origine; entetes.Vary = 'Origin'; }
  res.writeHead(statusCode, entetes);
  res.end(body);
}

function echapperHtml(texte) {
  return String(texte).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// Lancé une fois, au démarrage du pont, dans l’ordre fixé par server.js.
function demarrer() {
  try {
    indexHtml = fs.readFileSync(path.join(parametres.PUBLIC_DIR, 'index.html'));
  } catch (e) {
    console.error('❌ Impossible de trouver public/index.html à côté de server.js.');
    process.exit(1);
  }
}
