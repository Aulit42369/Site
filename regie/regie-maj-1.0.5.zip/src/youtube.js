// ============================================================
//  YouTube
// ------------------------------------------------------------
//  Autorisation Google, envoi de clips, tchat du direct.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  ensureYoutubeToken,
  findActiveYoutubeLiveChatId,
  mapYoutubeChatItem,
  uploadToYoutube,
  youtubeAuthUrl,
  get youtubeLiveState() { return youtubeLiveState; },
  get YT_REDIRECT_URI() { return YT_REDIRECT_URI; },
};

const parametres = require('./parametres.js');
const stockage = require('./stockage.js');
const oauth = require('./oauth.js');

// OAuth Google + Data API v3 (envoi reprenable).
// La connexion se fait une seule fois, sur ce PC, via /setup —
// jamais depuis le téléphone (Google exige un vrai serveur pour
// le "retour" de l'autorisation, contrairement à Twitch).
const YT_REDIRECT_URI = `http://127.0.0.1:${parametres.PORT}/oauth/youtube/callback`;

function youtubeAuthUrl() {
  const yt = stockage.platformTokens.youtube || {};
  const params = new URLSearchParams({
    client_id: yt.clientId || '',
    redirect_uri: YT_REDIRECT_URI,
    response_type: 'code',
    access_type: 'offline',
    prompt: 'consent',
    scope: 'https://www.googleapis.com/auth/youtube.upload https://www.googleapis.com/auth/youtube.force-ssl',
    state: oauth.creerEtatOauth('youtube'),
  });
  return `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;
}

async function ensureYoutubeToken() {
  const yt = stockage.platformTokens.youtube;
  if (!yt || !yt.refreshToken) throw new Error(`YouTube non connecté — ouvre http://127.0.0.1:${parametres.PORT}/setup sur ce PC.`);
  if (yt.accessToken && yt.expiresAt && Date.now() < yt.expiresAt - 60000) return yt.accessToken;
  const res = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ client_id: yt.clientId, client_secret: yt.clientSecret, refresh_token: yt.refreshToken, grant_type: 'refresh_token' }),
  });
  if (!res.ok) throw new Error('Impossible de rafraîchir le jeton YouTube — reconnecte-le sur /setup.');
  const data = await res.json();
  yt.accessToken = data.access_token;
  yt.expiresAt = Date.now() + (data.expires_in || 3600) * 1000;
  stockage.saveTokens();
  return yt.accessToken;
}

// ------------------------------------------------------------
// YouTube Live — tchat en direct + modération basique.
// liveChatMessages.list est fait pour être sondé à intervalle
// régulier (pas de push/WebSocket public côté YouTube), donc côté
// pont on retrouve juste le liveChatId actif (mis en cache 30s pour
// ne pas le redemander à chaque appel) et on avance une page à la
// fois via nextPageToken, exactement comme YouTube le prévoit.
// ------------------------------------------------------------
let youtubeLiveState = { chatId: null, broadcastId: null, checkedAt: 0, nextPageToken: null };

async function findActiveYoutubeLiveChatId() {
  const now = Date.now();
  // La garde ne doit pas exiger un direct en cours : sinon, hors direct (le
  // cas le plus fréquent) le cache ne servait jamais et l'appli interrogeait
  // YouTube toutes les 8 secondes, ce qui épuise le quota quotidien en
  // quelques heures d'onglet ouvert.
  if (youtubeLiveState.checkedAt && now - youtubeLiveState.checkedAt < 30000) return youtubeLiveState.chatId;
  const accessToken = await ensureYoutubeToken();
  const res = await fetch('https://www.googleapis.com/youtube/v3/liveBroadcasts?part=snippet&broadcastStatus=active&broadcastType=all', {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  const data = await res.json();
  if (!res.ok) {
    // Sans cette vérification, un refus de Google (permission manquante,
    // jeton périmé) passait pour "aucune diffusion en cours" : l'onglet
    // YouTube restait vide sans la moindre explication.
    const detail = (data.error && data.error.message) || ('HTTP ' + res.status);
    if (res.status === 401 || res.status === 403) {
      throw new Error(
        "YouTube refuse l'accès au direct (" + detail + "). La connexion YouTube a probablement été " +
        "autorisée avant l'ajout du tchat en direct, qui demande des permissions plus larges. " +
        "Refais une fois la connexion sur http://127.0.0.1:" + parametres.PORT + "/setup depuis le PC — " +
        "mêmes Client ID et Secret, il s'agit juste de redonner l'accord à Google."
      );
    }
    throw new Error('YouTube : ' + detail);
  }
  const item = (data.items && data.items[0]) || null;
  const chatId = (item && item.snippet && item.snippet.liveChatId) || null;
  if (chatId !== youtubeLiveState.chatId) youtubeLiveState.nextPageToken = null;
  youtubeLiveState.chatId = chatId;
  // L'identifiant de la diffusion est aussi celui de la vidéo : c'est par lui
  // que passent la lecture et la modification du titre, de la description et
  // des tags.
  youtubeLiveState.broadcastId = (item && item.id) || null;
  youtubeLiveState.checkedAt = now;
  return chatId;
}

function mapYoutubeChatItem(item, liveChatId) {
  const snip = item.snippet || {};
  const author = item.authorDetails || {};
  const base = {
    id: 'yt_' + item.id,
    platform: 'youtube',
    user: author.displayName || 'Inconnu',
    userId: author.channelId || '',
    source: 'live',
    youtubeMessageId: item.id,
    youtubeLiveChatId: liveChatId,
  };
  if (snip.type === 'textMessageEvent') {
    return { ...base, type: 'chat', detail: (snip.textMessageDetails && snip.textMessageDetails.messageDisplay) || '' };
  }
  if (snip.type === 'superChatEvent') {
    const d = snip.superChatDetails || {};
    return { ...base, type: 'superchat', detail: `${d.amountDisplayString || ''}${d.userComment ? ' — ' + d.userComment : ''}`, amount: (Number(d.amountMicros) || 0) / 1e6 };
  }
  if (snip.type === 'superStickerEvent') {
    const d = snip.superStickerDetails || {};
    return { ...base, type: 'superchat', detail: `Super Sticker ${d.amountDisplayString || ''}`, amount: (Number(d.amountMicros) || 0) / 1e6 };
  }
  if (snip.type === 'newSponsorEvent') {
    const d = snip.newSponsorDetails || {};
    return { ...base, type: d.isUpgrade ? 'resub' : 'sub', detail: d.memberLevelName ? `Membre — ${d.memberLevelName}` : 'Nouveau membre' };
  }
  return null;
}

async function uploadToYoutube(videoBuffer, title) {
  const accessToken = await ensureYoutubeToken();
  const initRes = await fetch('https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
      'X-Upload-Content-Type': 'video/mp4',
      'X-Upload-Content-Length': String(videoBuffer.length),
    },
    body: JSON.stringify({ snippet: { title: title || 'Clip', description: 'Publié depuis RÉGIE MOBILE.' }, status: { privacyStatus: 'public' } }),
  });
  if (!initRes.ok) throw new Error(`YouTube a refusé la session d'envoi (${initRes.status}).`);
  const uploadUrl = initRes.headers.get('location');
  if (!uploadUrl) throw new Error("YouTube n'a pas fourni d'adresse d'envoi.");

  const putRes = await fetch(uploadUrl, {
    method: 'PUT',
    headers: { 'Content-Type': 'video/mp4', 'Content-Length': String(videoBuffer.length) },
    body: videoBuffer,
  });
  if (!putRes.ok) throw new Error(`Échec de l'envoi de la vidéo à YouTube (${putRes.status}).`);
  const video = await putRes.json();
  return `https://youtube.com/watch?v=${video.id}`;
}
