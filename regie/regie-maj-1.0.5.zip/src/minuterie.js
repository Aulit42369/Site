// ============================================================
//  Le minuteur des pauses
// ------------------------------------------------------------
//  Décompte partagé, actions de fin de pause, texte écrit dans une
//  source d’OBS.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  demarrer,
  broadcastTimer,
  get dernierTexteMinuteur() { return dernierTexteMinuteur; },
  set dernierTexteMinuteur(valeur) { dernierTexteMinuteur = valeur; },
  ecrireMinuteurDansObs,
  get erreurMinuteurOverlay() { return erreurMinuteurOverlay; },
  set erreurMinuteurOverlay(valeur) { erreurMinuteurOverlay = valeur; },
  nettoyerActionsFin,
  texteDecompte,
  timerConfig,
  timerPause,
  timerReset,
  timerStart,
  get timerState() { return timerState; },
};

const etatRegie = require('./etat-regie.js');
const obs = require('./obs.js');
const reglagesRegie = require('./reglages-regie.js');

// ------------------------------------------------------------
// Minuteur partagé : piloté depuis le téléphone, affiché en direct
// dans l'overlay OBS, déclenche une action de fin automatique.
// ------------------------------------------------------------
let timerState;
// Le dernier lancement (ou la dernière reprise) venait-il d'une page d'une
// autre origine ? Voir onTimerFinished.
let lanceParAutreOrigine = false;

function broadcastTimer() {
  timerState.overlayError = typeof erreurMinuteurOverlay === 'string' ? erreurMinuteurOverlay : '';
  // Le texte tel que l'écrit la source texte d'OBS : « Retour dans 04:59 »
  // (case cochée) ou « 04:59 », puis le texte de fin une fois à zéro, et
  // rien au repos. Pour une page d'overlay à soi, qui l'affiche sans rien
  // recalculer — et suit la case « Retour dans » si elle le veut.
  timerState.affichage = timerState.remaining > 0
    ? texteDecompte(timerState.remaining)
    : (timerState.termine ? String(timerState.textFinished || '') : '');
  // Le minuteur change chaque seconde. Diffuser l'état complet à ce rythme
  // (scènes, sources, clips publiés, historique...) représentait ~97 % de
  // données inutiles et forçait un rendu intégral de l'appli à chaque tic :
  // on n'envoie donc que la partie qui bouge.
  etatRegie.obsState.timer = { ...timerState };
  etatRegie.broadcastPatch({ timer: etatRegie.obsState.timer });
}

// ------------------------------------------------------------
// Ce qui se passe à la fin d'une pause
// ------------------------------------------------------------
// C'était « une scène et un micro », dans cet ordre, point. Or une reprise
// de direct ressemble plutôt à une petite suite : revenir sur la scène,
// attendre que l'habillage s'affiche, rallumer le micro, masquer le panneau
// « pause ». On exécute donc une liste d'actions, dans l'ordre.
//
// Types possibles, chacun avec le strict nécessaire :
//   { type: 'scene',   scene: 'DIRECT' }
//   { type: 'micro',   micro: 'Micro',  couper: false }
//   { type: 'source',  scene: 'DIRECT', source: 'Panneau pause', visible: false }
//   { type: 'attendre', secondes: 2 }
const ACTIONS_FIN_MAX = 10;

function nettoyerActionsFin(liste) {
  if (!Array.isArray(liste)) return [];
  return liste.slice(0, ACTIONS_FIN_MAX).map((a) => {
    const type = String((a && a.type) || '');
    if (type === 'scene') return { type, scene: String(a.scene || '') };
    if (type === 'micro') return { type, micro: String(a.micro || ''), couper: !!a.couper };
    if (type === 'source') return { type, scene: String(a.scene || ''), source: String(a.source || ''), visible: !!a.visible };
    if (type === 'attendre') return { type, secondes: Math.min(60, Math.max(1, Math.round(Number(a.secondes) || 1))) };
    return null;
  }).filter(Boolean);
}

async function onTimerFinished() {
  if (!obs.obsWs || obs.obsWs.readyState !== WebSocket.OPEN) return;
  const actions = Array.isArray(timerState.actionsFin) ? timerState.actionsFin : [];
  // Rien de configuré = rien à faire. Le minuteur sert alors seulement
  // d'affichage, ce qui est le cas tant que l'utilisateur n'a pas choisi.
  if (!actions.length) return;
  // Lancé par une page d'une autre origine : rien n'est joué, sauf si la
  // régie le permet (interrupteur « Aussi quand un overlay lance le
  // minuteur », timerState.finParOverlay, éteint au départ). Sans cette
  // garde, une page piégée qui se fait passer pour un overlay pouvait, en
  // lançant un minuteur d'une seconde, changer la scène ou rallumer le
  // micro — ce que la barrière des origines interdit par ailleurs (voir
  // securite.ECRITURES_OUVERTES).
  if (lanceParAutreOrigine && !timerState.finParOverlay) {
    console.log('[minuteur] Fin du décompte lancé par une page extérieure (un overlay) : les actions de fin de pause ne sont pas jouées. Pour les autoriser : carte Minuteur → À la fin de la pause → « Aussi quand un overlay lance le minuteur ».');
    // L'appli le montre sur la carte du minuteur, jusqu'au prochain lancement.
    timerState.finIgnoree = true;
    broadcastTimer();
    return;
  }

  for (const a of actions) {
    try {
      if (a.type === 'scene' && a.scene) {
        await obs.obsRequest('SetCurrentProgramScene', { sceneName: a.scene });
      } else if (a.type === 'micro' && a.micro) {
        await obs.obsRequest('SetInputMute', { inputName: a.micro, inputMuted: !!a.couper });
      } else if (a.type === 'source' && a.scene && a.source) {
        // OBS travaille par identifiant d'élément, pas par nom : il faut
        // d'abord retrouver l'élément dans la scène.
        const liste = await obs.obsRequest('GetSceneItemList', { sceneName: a.scene });
        const item = (liste.sceneItems || []).find((it) => it.sourceName === a.source);
        if (!item) throw new Error('source « ' + a.source + ' » absente de la scène « ' + a.scene + ' »');
        await obs.obsRequest('SetSceneItemEnabled', {
          sceneName: a.scene, sceneItemId: item.sceneItemId, sceneItemEnabled: !!a.visible,
        });
      } else if (a.type === 'attendre') {
        await new Promise((r) => setTimeout(r, a.secondes * 1000));
      }
    } catch (e) {
      // Une action qui échoue ne doit pas emporter les suivantes : rallumer
      // le micro reste utile même si la scène n'a pas pu changer. L'échec
      // est journalisé, donc relisible dans le Diagnostic.
      console.error('[pont] Fin de pause, action « ' + a.type + ' » ignorée : ' + ((e && e.message) || e));
    }
  }
}

// « autreOrigine » : lancé (ou repris) par une page d'une autre origine, un
// overlay typiquement (voir onTimerFinished).
function timerStart(seconds, { autreOrigine = false } = {}) {
  lanceParAutreOrigine = !!autreOrigine;
  timerState.finIgnoree = false;
  const dur = Number(seconds) > 0 ? Math.round(Number(seconds)) : (timerState.remaining > 0 ? timerState.remaining : 600);
  timerState.remaining = dur;
  timerState.endAt = Date.now() + dur * 1000;
  timerState.running = true;
  timerState.termine = false;
  broadcastTimer();
}
function timerPause() {
  if (timerState.running && timerState.endAt) {
    // Même arrondi que le tic : une pause ne doit pas faire perdre
    // une seconde au passage.
    timerState.remaining = Math.max(0, Math.ceil((timerState.endAt - Date.now()) / 1000));
  }
  timerState.running = false;
  timerState.endAt = null;
  broadcastTimer();
}
function timerReset() {
  timerState.running = false;
  timerState.endAt = null;
  timerState.remaining = 0;
  timerState.termine = false;
  timerState.finIgnoree = false;
  broadcastTimer();
}
// Ce que l'appli règle : la suite d'actions (« actions », une liste) et le
// droit pour un overlay de la déclencher (« finParOverlay », oui ou non).
// Seul ce qui est fourni change.
function timerConfig({ actions, finParOverlay } = {}) {
  if (Array.isArray(actions)) timerState.actionsFin = nettoyerActionsFin(actions);
  if (typeof finParOverlay === 'boolean') timerState.finParOverlay = finParOverlay;
  // Enregistré : sans ça le réglage était à refaire à chaque démarrage du
  // pont, et l'appli le reprenait du pont sans jamais le lui renvoyer.
  // persistExtras vit dans reglages-regie.js, qui écrit tous ces réglages
  // dans tokens.json.
  try { reglagesRegie.persistExtras(); } catch (e) {}
  broadcastTimer();
}

// ------------------------------------------------------------
// Compte à rebours visible par les viewers
// ------------------------------------------------------------
// Écrit le temps restant dans une source texte d'OBS, une fois par
// seconde. On garde en mémoire la dernière valeur envoyée : sans ça,
// on enverrait une requête à OBS même quand l'affichage n'a pas
// changé (minuteur en pause, par exemple).
let dernierTexteMinuteur = null;
let erreurMinuteurOverlay = '';
function formaterMinuteur(secondes) {
  const m = Math.floor(Math.max(0, secondes) / 60);
  const s = Math.max(0, secondes) % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}
// Ce que la source texte affiche pendant le décompte. Le texte de fin,
// lui, s'affiche tel quel, sans « Retour dans » devant.
function texteDecompte(secondes) {
  return (timerState.retourDans ? 'Retour dans ' : '') + formaterMinuteur(secondes);
}

async function ecrireMinuteurDansObs(texte) {
  if (!timerState.textSource) return;
  if (texte === dernierTexteMinuteur) return;
  if (!obs.obsWs || obs.obsWs.readyState !== WebSocket.OPEN) return;
  // Changement de collection en cours : on se tait, sans signaler d'erreur.
  // L'écriture reprend au tic qui suit la fin du chargement.
  if (obs.obsChangementCollection) return;
  dernierTexteMinuteur = texte;
  try {
    // « overlay: true » comme la carte Texte d'overlay, qui fonctionne :
    // les autres réglages de la source (police, couleur, taille) sont
    // conservés au lieu d'être remis à leur valeur par défaut.
    await obs.obsRequest('SetInputSettings', {
      inputName: timerState.textSource,
      inputSettings: { text: texte },
      overlay: true,
    });
    if (erreurMinuteurOverlay) { erreurMinuteurOverlay = ''; broadcastTimer(); }
  } catch (e) {
    // On n'efface SURTOUT pas le réglage : une erreur passagère (OBS qui
    // redémarre, scène en cours de chargement) désactiverait alors la
    // fonction pour de bon, sans que personne comprenne pourquoi.
    // On remonte le message dans l'appli et on retente au tic suivant.
    dernierTexteMinuteur = null;
    const msg = 'Source « ' + timerState.textSource + ' » : ' + e.message;
    if (msg !== erreurMinuteurOverlay) {
      erreurMinuteurOverlay = msg;
      console.error('[pont] Compte à rebours — ' + msg);
      broadcastTimer();
    }
  }
}

// Lancé une fois, au démarrage du pont, dans l’ordre fixé par server.js.
function demarrer() {
  timerState = { ...etatRegie.obsState.timer };
  // Arrondi vers le HAUT, et c'est important : plusieurs afficheurs lisent ce
  // minuteur (le téléphone, la source texte d'OBS, un overlay qui interroge le
  // pont). Avec un arrondi au plus proche ici et vers le haut dans l'appli, le
  // téléphone affichait 10:00 pendant que l'overlay affichait déjà 09:59 — et le compte
  // atteignait 00:00 une demi-seconde avant l'échéance réelle. Même règle
  // partout, donc même chiffre partout.
  setInterval(() => {
    if (!timerState.running || !timerState.endAt) return;
    const remaining = Math.max(0, Math.ceil((timerState.endAt - Date.now()) / 1000));
    timerState.remaining = remaining;
    if (remaining <= 0) {
      timerState.running = false;
      timerState.endAt = null;
      timerState.termine = true;
      broadcastTimer();
      // Le texte de fin remplace 00:00 a l'ecran : les viewers voient
      // "C'est reparti !" plutot qu'un compteur fige a zero.
      ecrireMinuteurDansObs(timerState.textFinished || '');
      onTimerFinished();
    } else {
      broadcastTimer();
      ecrireMinuteurDansObs(texteDecompte(remaining));
    }
  }, 1000);
}
