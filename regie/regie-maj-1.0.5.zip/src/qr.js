// ============================================================
//  QR code — sans aucune dépendance
// ------------------------------------------------------------
//  Sert à une seule chose : afficher sur l'écran du PC un code que
//  le téléphone vise avec son appareil photo, pour ouvrir la régie
//  sans avoir à recopier « http://192.168.1.21:4560/telephone » à
//  la main — la première étape où un débutant se trompe.
//
//  Le pont reste sans dépendance : pas de bibliothèque à installer,
//  donc ce petit encodeur. Il ne gère que le mode « octets » (assez
//  pour n'importe quelle adresse) et les versions 1 à 10 (jusqu'à
//  213 caractères en correction M, très au-delà d'une adresse).
//
//  Il est vérifié en le faisant LIRE par un vrai décodeur dans
//  verif/ (toutes les versions, tous les niveaux, tous les masques)
//  — un QR code qui « a l'air juste » mais que les téléphones ne
//  lisent pas est le pire des cas : on chercherait la panne partout
//  ailleurs.
//
//  L'algorithme suit la norme ISO/IEC 18004 dans l'organisation du
//  générateur de référence de Project Nayuki (licence MIT).
// ============================================================
'use strict';

// Niveaux de correction : bits de format (norme) et indice des tables.
const NIVEAUX = {
  L: { bits: 1, i: 0 },
  M: { bits: 0, i: 1 },
  Q: { bits: 3, i: 2 },
  H: { bits: 2, i: 3 },
};

// Par version (indice 1 à 10) : octets de correction par bloc, et nombre
// de blocs. L'indice 0 est inutilisé. Versions 1 à 10 seulement : c'est
// ce que le décodeur de verif/ contrôle une par une.
const CORRECTION_PAR_BLOC = [
  [-1, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18],  // L
  [-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26], // M
  [-1, 13, 22, 18, 26, 18, 24, 18, 22, 20, 24], // Q
  [-1, 17, 28, 22, 16, 22, 28, 26, 26, 24, 28], // H
];
const NOMBRE_DE_BLOCS = [
  [-1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4],  // L
  [-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5],  // M
  [-1, 1, 1, 2, 2, 4, 4, 6, 6, 8, 8],  // Q
  [-1, 1, 1, 2, 4, 4, 4, 5, 6, 8, 8],  // H
];
const VERSION_MAX = 10;

// ---------- Arithmétique dans GF(256), polynôme 0x11D ----------
function multiplier(x, y) {
  let z = 0;
  for (let i = 7; i >= 0; i -= 1) {
    z = (z << 1) ^ ((z >>> 7) * 0x11d);
    z ^= ((y >>> i) & 1) * x;
  }
  return z & 0xff;
}

function diviseurReedSolomon(degre) {
  const resultat = new Array(degre).fill(0);
  resultat[degre - 1] = 1;
  let racine = 1;
  for (let i = 0; i < degre; i += 1) {
    for (let j = 0; j < degre; j += 1) {
      resultat[j] = multiplier(resultat[j], racine);
      if (j + 1 < degre) resultat[j] ^= resultat[j + 1];
    }
    racine = multiplier(racine, 0x02);
  }
  return resultat;
}

function resteReedSolomon(donnees, diviseur) {
  const resultat = diviseur.map(() => 0);
  for (const b of donnees) {
    const facteur = b ^ resultat.shift();
    resultat.push(0);
    diviseur.forEach((coef, i) => { resultat[i] ^= multiplier(coef, facteur); });
  }
  return resultat;
}

// ---------- Capacités ----------
function modulesDeDonneesBruts(version) {
  let n = (16 * version + 128) * version + 64;
  if (version >= 2) {
    const nbAlign = Math.floor(version / 7) + 2;
    n -= (25 * nbAlign - 10) * nbAlign - 55;
    if (version >= 7) n -= 36;
  }
  return n;
}

function octetsDeDonnees(version, niveau) {
  return Math.floor(modulesDeDonneesBruts(version) / 8)
    - CORRECTION_PAR_BLOC[niveau.i][version] * NOMBRE_DE_BLOCS[niveau.i][version];
}

function positionsAlignement(version, taille) {
  if (version === 1) return [];
  const nbAlign = Math.floor(version / 7) + 2;
  const pas = Math.floor((version * 8 + nbAlign * 3 + 5) / (nbAlign * 4 - 4)) * 2;
  const resultat = [6];
  for (let pos = taille - 7; resultat.length < nbAlign; pos -= pas) resultat.splice(1, 0, pos);
  return resultat;
}

// ---------- Encodage des données ----------
function encoderOctets(octets, version, niveau) {
  const bits = [];
  const ajouter = (valeur, longueur) => {
    for (let i = longueur - 1; i >= 0; i -= 1) bits.push((valeur >>> i) & 1);
  };
  ajouter(0x4, 4);                                // mode « octets »
  ajouter(octets.length, version <= 9 ? 8 : 16);  // nombre de caractères
  for (const o of octets) ajouter(o, 8);

  const capacite = octetsDeDonnees(version, niveau) * 8;
  ajouter(0, Math.min(4, capacite - bits.length)); // terminateur
  ajouter(0, (8 - (bits.length % 8)) % 8);         // jusqu'à l'octet
  const donnees = [];
  for (let i = 0; i < bits.length; i += 8) {
    let o = 0;
    for (let j = 0; j < 8; j += 1) o = (o << 1) | bits[i + j];
    donnees.push(o);
  }
  for (let rembourrage = 0xec; donnees.length < capacite / 8; rembourrage ^= 0xec ^ 0x11) {
    donnees.push(rembourrage);
  }
  return donnees;
}

function ajouterCorrectionEtEntrelacer(donnees, version, niveau) {
  const nbBlocs = NOMBRE_DE_BLOCS[niveau.i][version];
  const longueurCorrection = CORRECTION_PAR_BLOC[niveau.i][version];
  const octetsBruts = Math.floor(modulesDeDonneesBruts(version) / 8);
  const nbBlocsCourts = nbBlocs - (octetsBruts % nbBlocs);
  const longueurBlocCourt = Math.floor(octetsBruts / nbBlocs);

  const blocs = [];
  const diviseur = diviseurReedSolomon(longueurCorrection);
  let k = 0;
  for (let i = 0; i < nbBlocs; i += 1) {
    const dat = donnees.slice(k, k + longueurBlocCourt - longueurCorrection + (i < nbBlocsCourts ? 0 : 1));
    k += dat.length;
    const correction = resteReedSolomon(dat, diviseur);
    if (i < nbBlocsCourts) dat.push(0);
    blocs.push(dat.concat(correction));
  }

  const resultat = [];
  for (let i = 0; i < blocs[0].length; i += 1) {
    blocs.forEach((bloc, j) => {
      if (i !== longueurBlocCourt - longueurCorrection || j >= nbBlocsCourts) resultat.push(bloc[i]);
    });
  }
  return resultat;
}

// ---------- La matrice ----------
function construireMatrice(octetsFinaux, version, niveau, masqueForce) {
  const taille = version * 4 + 17;
  const modules = Array.from({ length: taille }, () => new Array(taille).fill(false));
  const fonction = Array.from({ length: taille }, () => new Array(taille).fill(false));
  const poser = (x, y, sombre) => { modules[y][x] = sombre; fonction[y][x] = true; };

  // Motifs de synchronisation
  for (let i = 0; i < taille; i += 1) {
    poser(6, i, i % 2 === 0);
    poser(i, 6, i % 2 === 0);
  }
  // Repères des trois coins (avec leur marge claire)
  const repere = (cx, cy) => {
    for (let dy = -4; dy <= 4; dy += 1) {
      for (let dx = -4; dx <= 4; dx += 1) {
        const dist = Math.max(Math.abs(dx), Math.abs(dy));
        const x = cx + dx, y = cy + dy;
        if (x >= 0 && x < taille && y >= 0 && y < taille) poser(x, y, dist !== 2 && dist !== 4);
      }
    }
  };
  repere(3, 3);
  repere(taille - 4, 3);
  repere(3, taille - 4);
  // Motifs d'alignement
  const pos = positionsAlignement(version, taille);
  for (let i = 0; i < pos.length; i += 1) {
    for (let j = 0; j < pos.length; j += 1) {
      const coin = (i === 0 && j === 0) || (i === 0 && j === pos.length - 1) || (i === pos.length - 1 && j === 0);
      if (coin) continue;
      for (let dy = -2; dy <= 2; dy += 1) {
        for (let dx = -2; dx <= 2; dx += 1) {
          poser(pos[i] + dx, pos[j] + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
        }
      }
    }
  }
  // Zones réservées au format (remplies plus bas) et à la version
  const ecrireFormat = (masque) => {
    const donnees = (niveau.bits << 3) | masque;
    let reste = donnees;
    for (let i = 0; i < 10; i += 1) reste = (reste << 1) ^ ((reste >>> 9) * 0x537);
    const bits = ((donnees << 10) | reste) ^ 0x5412;
    const bit = (i) => ((bits >>> i) & 1) !== 0;
    for (let i = 0; i <= 5; i += 1) poser(8, i, bit(i));
    poser(8, 7, bit(6));
    poser(8, 8, bit(7));
    poser(7, 8, bit(8));
    for (let i = 9; i < 15; i += 1) poser(14 - i, 8, bit(i));
    for (let i = 0; i < 8; i += 1) poser(taille - 1 - i, 8, bit(i));
    for (let i = 8; i < 15; i += 1) poser(8, taille - 15 + i, bit(i));
    poser(8, taille - 8, true); // le module toujours sombre
  };
  ecrireFormat(0);
  if (version >= 7) {
    let reste = version;
    for (let i = 0; i < 12; i += 1) reste = (reste << 1) ^ ((reste >>> 11) * 0x1f25);
    const bits = (version << 12) | reste;
    for (let i = 0; i < 18; i += 1) {
      const sombre = ((bits >>> i) & 1) !== 0;
      const a = taille - 11 + (i % 3);
      const b = Math.floor(i / 3);
      poser(a, b, sombre);
      poser(b, a, sombre);
    }
  }

  // Les données, en zigzag de droite à gauche, deux colonnes à la fois
  let i = 0;
  for (let droite = taille - 1; droite >= 1; droite -= 2) {
    if (droite === 6) droite = 5;
    for (let vert = 0; vert < taille; vert += 1) {
      for (let j = 0; j < 2; j += 1) {
        const x = droite - j;
        const montant = ((droite + 1) & 2) === 0;
        const y = montant ? taille - 1 - vert : vert;
        if (!fonction[y][x] && i < octetsFinaux.length * 8) {
          modules[y][x] = ((octetsFinaux[i >>> 3] >>> (7 - (i & 7))) & 1) !== 0;
          i += 1;
        }
      }
    }
  }

  const appliquerMasque = (masque) => {
    for (let y = 0; y < taille; y += 1) {
      for (let x = 0; x < taille; x += 1) {
        if (fonction[y][x]) continue;
        let inverse;
        switch (masque) {
          case 0: inverse = (x + y) % 2 === 0; break;
          case 1: inverse = y % 2 === 0; break;
          case 2: inverse = x % 3 === 0; break;
          case 3: inverse = (x + y) % 3 === 0; break;
          case 4: inverse = (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0; break;
          case 5: inverse = ((x * y) % 2) + ((x * y) % 3) === 0; break;
          case 6: inverse = (((x * y) % 2) + ((x * y) % 3)) % 2 === 0; break;
          default: inverse = (((x + y) % 2) + ((x * y) % 3)) % 2 === 0; break;
        }
        if (inverse) modules[y][x] = !modules[y][x];
      }
    }
  };

  let masqueRetenu = masqueForce;
  if (masqueRetenu === undefined || masqueRetenu === null) {
    // On essaie les huit masques et on garde celui qui pénalise le moins :
    // c'est ce qui évite les grandes plages unies et les faux repères qui
    // gênent la lecture par un appareil photo.
    let meilleur = Infinity;
    for (let m = 0; m < 8; m += 1) {
      appliquerMasque(m);
      ecrireFormat(m);
      const p = penalite(modules, taille);
      if (p < meilleur) { meilleur = p; masqueRetenu = m; }
      appliquerMasque(m); // un masque appliqué deux fois s'annule
    }
  }
  appliquerMasque(masqueRetenu);
  ecrireFormat(masqueRetenu);
  return { modules, taille, masque: masqueRetenu };
}

// Pénalité de la norme (règles N1 à N4).
function penalite(modules, taille) {
  let total = 0;
  const lignes = [];
  for (let y = 0; y < taille; y += 1) lignes.push(modules[y]);
  for (let x = 0; x < taille; x += 1) lignes.push(modules.map((rang) => rang[x]));

  for (const ligne of lignes) {
    // N1 : suites de 5 modules identiques ou plus
    let suite = 1;
    for (let i = 1; i <= ligne.length; i += 1) {
      if (i < ligne.length && ligne[i] === ligne[i - 1]) { suite += 1; continue; }
      if (suite >= 5) total += 3 + (suite - 5);
      suite = 1;
    }
    // N3 : motifs qui ressemblent à un repère (1:1:3:1:1 bordé de clair).
    // Les modules hors du symbole comptent comme clairs (marge).
    const motifA = [true, false, true, true, true, false, true, false, false, false, false];
    const motifB = [false, false, false, false, true, false, true, true, true, false, true];
    for (let i = -4; i < ligne.length; i += 1) {
      let a = true, b = true;
      for (let k = 0; k < 11; k += 1) {
        const v = (i + k >= 0 && i + k < ligne.length) ? ligne[i + k] : false;
        if (v !== motifA[k]) a = false;
        if (v !== motifB[k]) b = false;
        if (!a && !b) break;
      }
      if (a) total += 40;
      if (b) total += 40;
    }
  }
  // N2 : blocs 2x2 de même couleur
  for (let y = 0; y < taille - 1; y += 1) {
    for (let x = 0; x < taille - 1; x += 1) {
      const c = modules[y][x];
      if (c === modules[y][x + 1] && c === modules[y + 1][x] && c === modules[y + 1][x + 1]) total += 3;
    }
  }
  // N4 : équilibre clair / sombre
  let sombres = 0;
  for (const rang of modules) for (const m of rang) if (m) sombres += 1;
  const ecart = Math.abs((sombres * 100) / (taille * taille) - 50);
  total += Math.floor(ecart / 5) * 10;
  return total;
}

// ---------- Point d'entrée ----------
// Renvoie la matrice (tableau de lignes de booléens, true = sombre).
function encoderQr(texte, options) {
  const opts = options || {};
  const niveau = NIVEAUX[opts.niveau || 'M'];
  if (!niveau) throw new Error('Niveau de correction inconnu : ' + opts.niveau);
  const octets = Array.from(Buffer.from(String(texte), 'utf8'));

  let version = opts.version || 0;
  if (!version) {
    for (let v = 1; v <= VERSION_MAX; v += 1) {
      const enTete = 4 + (v <= 9 ? 8 : 16);
      if (enTete + octets.length * 8 <= octetsDeDonnees(v, niveau) * 8) { version = v; break; }
    }
    if (!version) throw new Error('Texte trop long pour un QR code (' + octets.length + ' octets).');
  } else {
    const enTete = 4 + (version <= 9 ? 8 : 16);
    if (version > VERSION_MAX || enTete + octets.length * 8 > octetsDeDonnees(version, niveau) * 8) {
      throw new Error('Le texte ne tient pas dans la version ' + version);
    }
  }

  const donnees = encoderOctets(octets, version, niveau);
  const finaux = ajouterCorrectionEtEntrelacer(donnees, version, niveau);
  const { modules, taille, masque } = construireMatrice(finaux, version, niveau, opts.masque);
  return { modules, taille, version, masque, niveau: opts.niveau || 'M' };
}

// En SVG : net à toute taille, et léger (quelques centaines d'octets).
// Toujours sombre sur clair, avec la marge de 4 modules exigée par la
// norme : un QR code inversé ou collé au bord est refusé par une partie
// des appareils photo.
function qrSvg(texte, options) {
  const opts = options || {};
  const { modules, taille } = encoderQr(texte, opts);
  const marge = 4;
  const cote = taille + marge * 2;
  let chemin = '';
  for (let y = 0; y < taille; y += 1) {
    for (let x = 0; x < taille; x += 1) {
      if (modules[y][x]) chemin += 'M' + (x + marge) + ' ' + (y + marge) + 'h1v1h-1z';
    }
  }
  const clair = opts.clair || '#ffffff';
  const sombre = opts.sombre || '#05080d';
  return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + cote + ' ' + cote + '" '
    + 'shape-rendering="crispEdges" role="img" aria-label="QR code">'
    + '<rect width="' + cote + '" height="' + cote + '" fill="' + clair + '"/>'
    + '<path fill="' + sombre + '" d="' + chemin + '"/></svg>';
}

module.exports = { encoderQr, qrSvg, VERSION_MAX };
