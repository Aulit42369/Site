// ============================================================
//  Le serveur https et son certificat
// ------------------------------------------------------------
//  Autorité locale et certificat fabriqués sur ce PC (src/certificat.js).
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  demarrer,
  empreinteAutorite,
  get CHEMIN_AUTORITE_CRT() { return CHEMIN_AUTORITE_CRT; },
  get CHEMIN_SERVEUR_CERT() { return CHEMIN_SERVEUR_CERT; },
  get etatHttps() { return etatHttps; },
};

const fs = require('fs');
const os = require('os');
const path = require('path');

const parametres = require('./parametres.js');
const reseauLocal = require('./reseau-local.js');
const routes = require('./routes/index.js');

// Le serveur https a-t-il démarré ? (rempli par demarrer, au lancement)
let etatHttps = { actif: false, erreur: '' };

// Le serveur https sert la même appli que le http (port suivant) : les
// navigateurs réservent les notifications et l'installation en vraie appli
// aux adresses sécurisées, et Meta exige du https pour le retour
// d'autorisation d'Instagram, même en local.
// Le certificat est fabriqué par le pont lui-même au premier démarrage
// (voir certificat.js) : plus rien à installer ni à taper en ligne de
// commande. Il est ensuite réutilisé tel quel.
const CERTS_DIR = path.join(parametres.RACINE, 'certs');
const CHEMIN_AUTORITE_CERT = path.join(CERTS_DIR, 'ca.pem');
const CHEMIN_AUTORITE_CLE = path.join(CERTS_DIR, 'ca.key.pem');
const CHEMIN_SERVEUR_CERT = path.join(CERTS_DIR, 'cert.pem');
const CHEMIN_SERVEUR_CLE = path.join(CERTS_DIR, 'key.pem');
// Le même contenu que ca.pem, sous l'extension qu'Android reconnaît. Avoir
// les deux évite d'expliquer un renommage de fichier à quelqu'un sur son
// téléphone.
const CHEMIN_AUTORITE_CRT = path.join(CERTS_DIR, 'ca.crt');

// L'empreinte SHA-256 de l'autorité téléchargée par les téléphones, en
// groupes de deux caractères (« 3F A0 … ») : la page /qr du PC l'affiche,
// la page /telephone demande de la comparer avant d'installer. Le
// certificat voyage en http : c'est ce qui prouve qu'il n'a pas été
// remplacé en route. Vide si l'autorité n'existe pas encore.
function empreinteAutorite() {
  try {
    return new (require('crypto').X509Certificate)(fs.readFileSync(CHEMIN_AUTORITE_CRT)).fingerprint256.replace(/:/g, ' ');
  } catch (e) {
    return '';
  }
}

// Les noms et adresses que le certificat doit couvrir. Toutes les adresses
// du PC y passent : on ne sait pas laquelle le téléphone utilisera, et un
// certificat qui ne couvre pas l'adresse employée est refusé net.
function nomsACouvrir() {
  return {
    noms: ['localhost', os.hostname(), os.hostname() + '.local'].filter(Boolean),
    ips: ['127.0.0.1', ...reseauLocal.getLocalIps()],
  };
}

// Faut-il réémettre le certificat du serveur ? Oui s'il manque, s'il
// n'est plus valable très longtemps, ou si l'adresse du PC a changé —
// nouveau réseau, box redémarrée, câble au lieu du wifi. Sans cette
// vérification, déménager le PC cassait l'accès https sans un mot
// d'explication, et le seul symptôme aurait été « connexion refusée ».
function certificatServeurAReemettre(attendus) {
  try {
    const x = new (require('crypto').X509Certificate)(fs.readFileSync(CHEMIN_SERVEUR_CERT));
    const resteJours = (new Date(x.validTo).getTime() - Date.now()) / (24 * 3600 * 1000);
    if (resteJours < 30) return 'il arrive à expiration';
    // Correspondance EXACTE : avec un simple « contient », 192.168.1.2 était
    // vu comme couvert par 192.168.1.23, le certificat n'était pas réémis
    // après un changement d'adresse, et le https cessait de marcher.
    const entrees = new Set(String(x.subjectAltName || '').split(',').map((e) => e.trim()));
    const manquantes = attendus.ips.filter((ip) => !entrees.has('IP Address:' + ip));
    if (manquantes.length) return 'l\u2019adresse du PC a changé (' + manquantes.join(', ') + ')';
    return null;
  } catch (e) {
    return 'il est absent ou illisible';
  }
}

// L'autorité locale et le certificat du serveur. L'autorité ne change
// JAMAIS une fois créée : c'est elle qu'on installe sur le téléphone, et on
// ne veut pas refaire cette manipulation à chaque changement de réseau.
// Seul le certificat du serveur est réémis, et ça ne demande rien au
// téléphone puisque la signature vient de la même autorité.
function certificatLocal() {
  const { fabriquerAutorite, fabriquerCertificatServeur } = require('./certificat.js');
  fs.mkdirSync(CERTS_DIR, { recursive: true });

  let autoriteCert, autoriteCle;
  try {
    autoriteCert = fs.readFileSync(CHEMIN_AUTORITE_CERT, 'utf8');
    autoriteCle = fs.readFileSync(CHEMIN_AUTORITE_CLE, 'utf8');
  } catch (e) {
    const a = fabriquerAutorite();
    autoriteCert = a.certificatPem;
    autoriteCle = a.clePem;
    fs.writeFileSync(CHEMIN_AUTORITE_CERT, autoriteCert);
    fs.writeFileSync(CHEMIN_AUTORITE_CLE, autoriteCle);
    console.log('[pont] Autorite locale creee dans certs/ (a installer une fois sur le telephone).');
  }
  // Toujours réécrit : si le fichier .crt a été supprimé, ou si l'autorité
  // vient d'être créée, il doit exister pour être téléchargeable.
  try { fs.writeFileSync(CHEMIN_AUTORITE_CRT, autoriteCert); } catch (e) {}

  const attendus = nomsACouvrir();
  const raison = certificatServeurAReemettre(attendus);
  if (raison) {
    const srv = fabriquerCertificatServeur({
      autoriteClePem: autoriteCle,
      autoriteCertPem: autoriteCert,
      noms: attendus.noms,
      ips: attendus.ips,
    });
    fs.writeFileSync(CHEMIN_SERVEUR_CLE, srv.clePem);
    fs.writeFileSync(CHEMIN_SERVEUR_CERT, srv.certificatPem);
    console.log('[pont] Certificat du serveur reemis : ' + raison + '.');
    console.log('       Adresses couvertes : ' + attendus.ips.join(', '));
    console.log('       Rien a refaire sur le telephone : la meme autorite le signe.');
  }

  return {
    key: fs.readFileSync(CHEMIN_SERVEUR_CLE),
    cert: fs.readFileSync(CHEMIN_SERVEUR_CERT),
  };
}

// Lancé une fois, au démarrage du pont, dans l’ordre fixé par server.js.
function demarrer() {
  try {
    const https = require('https');
    const { key: httpsKey, cert: httpsCert } = certificatLocal();
    const httpsServer = https.createServer({ key: httpsKey, cert: httpsCert }, routes.gererRequete);
    // Un échec ici ne concerne que la connexion Instagram : le pont doit

    // continuer de tourner normalement pour tout le reste.

    httpsServer.on('error', (e) => {
      etatHttps = { actif: false, erreur: e.code === 'EADDRINUSE' ? 'Le port ' + parametres.HTTPS_PORT + ' est déjà utilisé.' : e.message };
      console.error('[pont] Serveur HTTPS indisponible : ' + e.message);
    });
    httpsServer.listen(parametres.HTTPS_PORT, () => { etatHttps = { actif: true, erreur: '' }; });
    // L'adresse du PC peut changer pendant que le pont tourne — c'est même la
    // règle avec « Lancer avec Windows » : le pont démarre souvent AVANT que le
    // Wi-Fi soit connecté. On revérifie chaque minute, et on remplace le
    // certificat à chaud, sans redémarrage ni rien à refaire sur le téléphone
    // (la même autorité le signe).
    setInterval(() => {
      if (!etatHttps.actif) return;
      const raison = certificatServeurAReemettre(nomsACouvrir());
      if (!raison) return;
      try {
        const { key, cert } = certificatLocal();
        httpsServer.setSecureContext({ key, cert });
        console.log('[pont] Certificat https remplacé à chaud (' + raison + ').');
      } catch (e) {
        console.error('[pont] Certificat https non remplacé : ' + e.message);
      }
    }, 60 * 1000);
  } catch (e) {
    // Cet échec est maintenant VISIBLE, et c'est un changement voulu. Avant,
    // le serveur https ne servait que la redirection Instagram : le signaler
    // à quelqu'un qui ne publie pas sur Instagram n'aurait fait qu'inquiéter
    // pour rien. Depuis qu'il sert l'appli elle-même, un échec ici fait
    // perdre les notifications sur le téléphone et l'installation en vraie
    // appli — se taire laisserait chercher pendant des heures.
    etatHttps = { actif: false, erreur: e.message };
    console.error('');
    console.error('⚠ Le serveur HTTPS n\u2019a pas démarré : ' + e.message);
    console.error('  Conséquences : pas de notifications web sur le téléphone, pas');
    console.error('  d\u2019installation en vraie appli, et pas de connexion Instagram.');
    console.error('  Le reste de la régie fonctionne normalement, et les notifications');
    console.error('  Discord aussi (Réglages → Notifications → Par Discord).');
    console.error('');
  }
}
