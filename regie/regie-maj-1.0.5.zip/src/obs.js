// ============================================================
//  Connexion à OBS (obs-websocket v5)
// ------------------------------------------------------------
//  Requêtes, scènes, sources, audio, branchement automatique et
//  reconnexion.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  demarrer,
  brancherObsAuto,
  connectToObs,
  disconnectFromObs,
  loadAudioInputs,
  loadScenes,
  get minuteurChangementCollection() { return minuteurChangementCollection; },
  set minuteurChangementCollection(valeur) { minuteurChangementCollection = valeur; },
  get obsChangementCollection() { return obsChangementCollection; },
  set obsChangementCollection(valeur) { obsChangementCollection = valeur; },
  get obsManualDisconnect() { return obsManualDisconnect; },
  set obsManualDisconnect(valeur) { obsManualDisconnect = valeur; },
  obsRequest,
  get obsWs() { return obsWs; },
};

const { createHash } = require('crypto');

const etatRegie = require('./etat-regie.js');
const obsDetection = require('./obs-detection.js');
const obsCollections = require('./obs-collections.js');
const stockage = require('./stockage.js');
const bilanStream = require('./bilan-stream.js');
const sante = require('./sante.js');

// ------------------------------------------------------------
// Authentification OBS WebSocket v5
// (base64(SHA256(base64(SHA256(password + salt)) + challenge)))
// ------------------------------------------------------------
function sha256B64(str) {
  return createHash('sha256').update(str, 'utf8').digest('base64');
}
function buildObsAuth(password, salt, challenge) {
  const secret = sha256B64(password + salt);
  return sha256B64(secret + challenge);
}

// General(1) + Config(2) + Scenes(4) + Inputs(8) + Outputs(64) + SceneItems(128) = 207
// Config : sans lui, OBS ne prévient pas d'un changement de collection de
// scènes, et le pont enverrait ses requêtes en plein chargement.
const OBS_EVENT_SUB = 1 | (1 << 1) | (1 << 2) | (1 << 3) | (1 << 6) | (1 << 7);

// ------------------------------------------------------------
// Connexion à OBS
// ------------------------------------------------------------
let obsWs = null;
let obsManualDisconnect = false;
let obsReconnectTimer = null;
let obsPending = {};
let obsReqCounter = 0;
// Vrai pendant qu'OBS charge une autre collection de scènes (voir
// changerCollection) : aucune requête ne part vers OBS pendant ce temps.
let obsChangementCollection = false;
let minuteurChangementCollection = null;

// options.delai : attente maximale de la réponse (8 s par défaut).
// options.pendantChangement : seule la requête qui LANCE un changement de
// collection passe pendant ce changement.
function obsRequest(requestType, requestData, options) {
  const opts = options || {};
  return new Promise((resolve, reject) => {
    if (!obsWs || obsWs.readyState !== WebSocket.OPEN) { reject(new Error('OBS non connecté.')); return; }
    // OBS prévient qu'une requête reçue pendant un changement de collection
    // peut le faire planter. Toutes les requêtes passent par ici : c'est donc
    // ici qu'on les arrête, minuteur, santé et boutons compris.
    if (obsChangementCollection && !opts.pendantChangement) {
      reject(new Error('OBS charge une autre collection de scènes : réessaie dans un instant.'));
      return;
    }
    const requestId = String(++obsReqCounter);
    // Le minuteur est annulé dès la réponse reçue : loadAudioInputs en lance
    // deux par entrée audio, ils s'accumuleraient sinon par dizaines.
    const minuteur = setTimeout(() => {
      if (obsPending[requestId]) { delete obsPending[requestId]; reject(new Error('Délai dépassé.')); }
    }, opts.delai || 8000);
    obsPending[requestId] = {
      resolve: (v) => { clearTimeout(minuteur); resolve(v); },
      reject: (e) => { clearTimeout(minuteur); reject(e); },
    };
    obsWs.send(JSON.stringify({ op: 6, d: { requestType, requestId, requestData: requestData || {} } }));
  });
}

async function loadSceneItems(sceneName) {
  try {
    const res = await obsRequest('GetSceneItemList', { sceneName });
    const items = res.sceneItems || [];
    // Les sources rangées dans un dossier (groupe OBS) ne sont pas incluses
    // par GetSceneItemList : il faut interroger chaque groupe séparément.
    const withGroups = await Promise.all(items.map(async (it) => {
      if (!it.isGroup) return it;
      try {
        const nested = await obsRequest('GetGroupSceneItemList', { sceneName: it.sourceName });
        return { ...it, groupItems: nested.sceneItems || [] };
      } catch (e) {
        return { ...it, groupItems: [] };
      }
    }));
    etatRegie.setState({ sceneItems: withGroups });
  } catch (e) { /* on ignore, un prochain événement remettra tout à jour */ }
}

async function loadScenes(attempt = 1) {
  try {
    const res = await obsRequest('GetSceneList');
    etatRegie.setState({ scenes: res.scenes || [], currentScene: res.currentProgramSceneName || '' });
    if (res.currentProgramSceneName) loadSceneItems(res.currentProgramSceneName);
  } catch (e) {
    if (attempt < 3) setTimeout(() => loadScenes(attempt + 1), 1500);
  }
}

async function loadAudioInputs(attempt = 1) {
  try {
    const res = await obsRequest('GetInputList');
    const inputs = res.inputs || [];
    // OBS ne dit pas directement quelles entrées ont de l'audio : on le déduit
    // en interrogeant leur volume (les entrées sans audio répondent une erreur).
    const results = await Promise.all(inputs.map(async (inp) => {
      try {
        const vol = await obsRequest('GetInputVolume', { inputName: inp.inputName });
        let muted = false;
        try {
          const m = await obsRequest('GetInputMute', { inputName: inp.inputName });
          muted = !!m.inputMuted;
        } catch (e) {}
        return { inputName: inp.inputName, inputKind: inp.inputKind, volumeDb: vol.inputVolumeDb, muted };
      } catch (e) {
        return null;
      }
    }));
    etatRegie.setState({ audioInputs: results.filter(Boolean) });
  } catch (e) {
    // OBS était peut-être occupé pile à ce moment (chargement de collection,
    // etc.) — on retente avant d'abandonner, plutôt que de laisser la liste
    // vide indéfiniment jusqu'à la prochaine reconnexion complète.
    if (attempt < 3) setTimeout(() => loadAudioInputs(attempt + 1), 1500);
  }
}

function connectToObs(host, port, password) {
  if (obsReconnectTimer) { clearTimeout(obsReconnectTimer); obsReconnectTimer = null; }
  obsManualDisconnect = false;
  if (obsWs) { try { obsWs.close(); } catch (e) {} obsWs = null; }
  // Rejeter les requêtes encore en vol : sans ça, leur minuteur de 8 s ne les
  // retrouve plus dans le nouvel objet et la réponse HTTP n'arrive jamais —
  // le bouton reste bloqué sur le téléphone.
  for (const id of Object.keys(obsPending)) {
    try { obsPending[id].reject(new Error('Connexion OBS réinitialisée.')); } catch (e) {}
  }
  obsPending = {};
  obsChangementCollection = false;
  clearTimeout(minuteurChangementCollection);
  // Ceinture du banc de test : verifier.sh interdit 4455 à son pont de test,
  // qui ne doit jamais piloter le vrai OBS (vu le 24/10). Vide en temps normal.
  if (String(process.env.REGIE_OBS_PORTS_INTERDITS || '').split(',').map((p) => p.trim()).includes(String(port).trim())) {
    console.warn('[OBS] Port ' + port + ' interdit à ce pont (REGIE_OBS_PORTS_INTERDITS) : aucune connexion.');
    etatRegie.setState({ status: 'disconnected', error: 'Port ' + port + ' interdit à ce pont de test.' });
    return;
  }
  etatRegie.setState({ status: 'connecting', error: '', collectionChargement: false, collectionCible: '' });

  let ws;
  try {
    ws = new WebSocket(`ws://${host}:${port}`);
  } catch (e) {
    etatRegie.setState({ status: 'error', error: 'Adresse ou port invalide.' });
    return;
  }
  obsWs = ws;

  ws.onmessage = async (evt) => {
    try { await handleObsMessage(ws, evt, password); }
    // Une trame inattendue (port pointant vers un autre service, version d'OBS
    // différente) ne doit jamais faire tomber le pont au milieu d'un direct.
    catch (e) { console.error('[OBS] trame ignorée :', (e && e.message) || e); }
  };

  async function handleObsMessage(ws, evt, password) {
    let msg;
    try { msg = JSON.parse(evt.data); } catch (e) { return; }

    if (msg.op === 0) {
      const d = { rpcVersion: msg.d.rpcVersion, eventSubscriptions: OBS_EVENT_SUB };
      if (msg.d.authentication) {
        d.authentication = buildObsAuth(password, msg.d.authentication.salt, msg.d.authentication.challenge);
      }
      ws.send(JSON.stringify({ op: 1, d }));
    } else if (msg.op === 2) {
      etatRegie.setState({ status: 'connected', error: '' });
      loadScenes();
      loadAudioInputs();
      obsCollections.chargerCollections();
      try {
        const streamRes = await obsRequest('GetStreamStatus');
        etatRegie.setState({ streaming: !!streamRes.outputActive });
        // Pont (re)démarré en plein direct : le stream a commencé il y a
        // « outputDuration », pas maintenant — c'est ce qu'en retient le bilan.
        if (streamRes.outputActive) bilanStream.suiviStream.debut(Date.now() - (Number(streamRes.outputDuration) || 0), 'OBS');
      } catch (e) {}
      try {
        const recordRes = await obsRequest('GetRecordStatus');
        etatRegie.setState({ recording: !!recordRes.outputActive });
      } catch (e) {}
    } else if (msg.op === 7) {
      const { requestId, requestStatus, responseData } = msg.d;
      const p = obsPending[requestId];
      if (p) {
        delete obsPending[requestId];
        if (requestStatus && requestStatus.result) p.resolve(responseData || {});
        else p.reject(new Error((requestStatus && requestStatus.comment) || 'Requête refusée par OBS.'));
      }
    } else if (msg.op === 5) {
      const eventType = msg.d.eventType;
      const eventData = msg.d.eventData || {};
      if (eventType === 'CurrentProgramSceneChanged') {
        etatRegie.setState({ currentScene: eventData.sceneName });
        loadSceneItems(eventData.sceneName);
      } else if (eventType === 'SceneItemEnableStateChanged') {
        const targetGroup = etatRegie.obsState.sceneItems.find((it) => it.isGroup && it.sourceName === eventData.sceneName);
        const newItems = targetGroup
          ? etatRegie.obsState.sceneItems.map((it) => (it !== targetGroup ? it : {
              ...it,
              groupItems: (it.groupItems || []).map((gi) => (gi.sceneItemId === eventData.sceneItemId ? { ...gi, sceneItemEnabled: eventData.sceneItemEnabled } : gi)),
            }))
          : etatRegie.obsState.sceneItems.map((it) => (it.sceneItemId === eventData.sceneItemId ? { ...it, sceneItemEnabled: eventData.sceneItemEnabled } : it));
        etatRegie.setState({ sceneItems: newItems });
      } else if (eventType === 'InputVolumeChanged') {
        // Diffusion partielle : un curseur qu'on fait glisser produit une
        // rafale de ces événements (voir setStatePartiel).
        etatRegie.setStatePartiel({ audioInputs: etatRegie.obsState.audioInputs.map((a) => (a.inputName === eventData.inputName ? { ...a, volumeDb: eventData.inputVolumeDb } : a)) });
      } else if (eventType === 'InputMuteStateChanged') {
        etatRegie.setStatePartiel({ audioInputs: etatRegie.obsState.audioInputs.map((a) => (a.inputName === eventData.inputName ? { ...a, muted: eventData.inputMuted } : a)) });
      } else if (eventType === 'StreamStateChanged') {
        // OBS distingue l'arrêt volontaire de la perte de connexion : c'est
        // la seule façon fiable de les différencier, « outputActive: false »
        // valant pour les deux. Une coupure de box pendant un direct, c'est
        // exactement ce qu'on veut apprendre par le téléphone plutôt qu'en
        // lisant le tchat dix minutes plus tard.
        const etatSortie = eventData.outputState;
        // Pendant une reconnexion, et encore APRÈS une reconnexion réussie,
        // OBS annonce « outputActive: false » : la régie croyait le direct
        // arrêté jusqu'au stream suivant. Le direct, lui, continue.
        const reconnexion = etatSortie === 'OBS_WEBSOCKET_OUTPUT_RECONNECTING' || etatSortie === 'OBS_WEBSOCKET_OUTPUT_RECONNECTED';
        etatRegie.setState({ streaming: !!eventData.outputActive || reconnexion });
        if (etatSortie === 'OBS_WEBSOCKET_OUTPUT_STARTED') bilanStream.suiviStream.debut(Date.now(), 'OBS');
        else if (etatSortie === 'OBS_WEBSOCKET_OUTPUT_STOPPED') bilanStream.suiviStream.fin(Date.now(), 'OBS');
        if (etatSortie === 'OBS_WEBSOCKET_OUTPUT_RECONNECTING') {
          console.error('[pont] Le direct a perdu la connexion — OBS tente de se reconnecter.');
          sante.notifierSante('🔴 Direct interrompu', 'OBS a perdu la connexion au serveur et tente de se reconnecter.');
        } else if (etatSortie === 'OBS_WEBSOCKET_OUTPUT_RECONNECTED') {
          console.log('[pont] Le direct est reconnecté.');
          sante.notifierSante('✅ Direct rétabli', 'OBS a retrouvé le serveur, la diffusion continue.');
        }
      } else if (eventType === 'RecordStateChanged') {
        etatRegie.setState({ recording: !!eventData.outputActive });
      } else if (eventType === 'CurrentSceneCollectionChanging') {
        // Lancé depuis la régie, ou directement dans OBS : dans les deux cas,
        // plus aucune requête jusqu'à « Changed ».
        obsCollections.debutChangementCollection('');
      } else if (eventType === 'CurrentSceneCollectionChanged') {
        obsCollections.finChangementCollection(String(eventData.sceneCollectionName || ''));
      } else if (eventType === 'SceneCollectionListChanged') {
        if (Array.isArray(eventData.sceneCollections)) etatRegie.setState({ collections: eventData.sceneCollections.map(String) });
      }
    }
  }

  ws.onerror = () => {
    // Sans cette garde, l'agonie d'un ancien socket écrase l'état d'une
    // connexion neuve déjà fonctionnelle (scènes et audio masqués à tort).
    if (obsWs !== ws) return;
    // Branchement automatique sur ce PC : OBS est simplement fermé, ou en
    // train de démarrer. Le dire ainsi plutôt que parler d'IP et de port à
    // quelqu'un qui n'a rien saisi.
    if (stockage.platformTokens.obs && stockage.platformTokens.obs.auto) {
      etatRegie.setState({ status: 'error', error: 'OBS ne répond pas. Lance OBS : la régie se branche toute seule dès qu’il est ouvert.' });
      return;
    }
    etatRegie.setState({ status: 'error', error: "Connexion impossible depuis le pont. Vérifie l'IP, le port, et que le serveur WebSocket OBS est activé (Outils → Paramètres du serveur WebSocket)." });
  };
  ws.onclose = (evt) => {
    if (obsWs === ws) {
      obsWs = null;
      // OBS ne renvoie pas d'erreur quand le mot de passe est faux : il FERME
      // la connexion avec le code 4009. Sans traduire ce code, la carte
      // affichait « déconnecté » sans un mot et réessayait toutes les 5 s,
      // indéfiniment. Or OBS active l'authentification par défaut avec un mot
      // de passe généré : c'est l'échec le plus probable au premier essai.
      let message = '';
      const code = evt && evt.code;
      if (code === 4009) {
        message = (stockage.platformTokens.obs && stockage.platformTokens.obs.auto)
          // Le mot de passe vient des fichiers d'OBS : s'il est refusé, OBS a
          // été lancé avec un autre (option --websocket_password), ou ses
          // réglages ont changé sans être enregistrés.
          ? 'OBS refuse le mot de passe lu dans ses propres réglages. Dans OBS : Outils → Paramètres du serveur WebSocket → OK '
            + '(pour les enregistrer), ou saisis le mot de passe à la main dans Réglages → OBS.'
          : 'Mot de passe OBS refusé. Dans OBS : Outils → Paramètres du serveur WebSocket → '
          + '« Afficher les informations de connexion », puis recopie le mot de passe dans Réglages. '
          + 'Si tu as décoché l\u2019authentification dans OBS, laisse le champ vide.';
      } else if (code === 4008) {
        message = 'OBS a refusé la connexion (identification manquante). Renseigne le mot de passe du serveur WebSocket OBS dans Réglages.';
      }
      // Une connexion qui n'a jamais abouti déclenche « error » PUIS « close » :
      // sans cette ligne, la fermeture effaçait aussitôt l'explication donnée
      // par l'erreur, et l'appli n'affichait plus que « déconnecté ».
      const explicationPrecedente = etatRegie.obsState.status === 'error' ? etatRegie.obsState.error : '';
      obsChangementCollection = false;
      clearTimeout(minuteurChangementCollection);
      etatRegie.setState({
        status: 'disconnected', error: message || explicationPrecedente, scenes: [], sceneItems: [], currentScene: '', audioInputs: [], streaming: false, recording: false,
        collection: '', collections: [], collectionChargement: false, collectionCible: '',
      });
      if (!obsManualDisconnect && stockage.platformTokens.obs && stockage.platformTokens.obs.host) {
        if (obsReconnectTimer) clearTimeout(obsReconnectTimer);
        obsReconnectTimer = setTimeout(() => {
          obsReconnectTimer = null;
          // Branchement automatique : on RELIT les fichiers d'OBS avant de
          // retenter. Si la personne a changé le mot de passe ou le port dans
          // OBS, la régie suit d'elle-même, sans rien lui demander.
          if (stockage.platformTokens.obs && stockage.platformTokens.obs.auto) brancherObsAuto('reconnexion');
          else connectToObs(stockage.platformTokens.obs.host, stockage.platformTokens.obs.port, stockage.platformTokens.obs.password);
        }, 5000);
      }
    }
  };
}

// ------------------------------------------------------------
// Branchement automatique d'OBS (OBS sur le même PC que la régie)
// ------------------------------------------------------------
// Le port et le mot de passe du serveur WebSocket sont LUS dans les fichiers
// d'OBS (voir obs-detection.js) au lieu d'être recopiés à la main —
// l'étape où un débutant décroche : trouver le menu, afficher le mot de
// passe, le recopier sans faute.
//
// Renvoie l'état de la détection (sans le mot de passe) :
//  'trouve' | 'desactive' | 'introuvable' | 'sans-websocket'
function brancherObsAuto(raison) {
  // OBS réglé à la main sur un AUTRE ordinateur (installation à deux PC) :
  // on ne remplace jamais ce réglage par celui du PC local.
  const reglageActuel = stockage.platformTokens.obs || {};
  const manuelDistant = !!reglageActuel.host && !reglageActuel.auto
    && !['127.0.0.1', 'localhost', '::1'].includes(String(reglageActuel.host).trim().toLowerCase());
  const d = obsDetection.detecterObs();
  let etat;
  if (!d.trouve) etat = d.obsInstalle ? 'sans-websocket' : 'introuvable';
  else if (!d.active) etat = 'desactive';
  else etat = 'trouve';
  const detection = { etat, source: d.source, port: d.trouve ? d.port : 0 };

  if (etat === 'trouve' && !manuelDistant) {
    const motDePasse = d.authRequise ? d.motDePasse : '';
    const actuel = stockage.platformTokens.obs || {};
    const identique = !!actuel.auto && actuel.host === '127.0.0.1'
      && String(actuel.port) === String(d.port) && actuel.password === motDePasse;
    if (!identique) {
      stockage.platformTokens.obs = { host: '127.0.0.1', port: String(d.port), password: motDePasse, auto: true };
      stockage.saveTokens();
    }
    // Déjà relié (ou en train de l'être) avec exactement ces réglages : on
    // ne coupe pas une connexion qui marche.
    const dejaBon = identique && !obsManualDisconnect && (etatRegie.obsState.status === 'connected' || etatRegie.obsState.status === 'connecting');
    if (!dejaBon) {
      if (raison !== 'reconnexion' && raison !== 'surveillance') {
        console.log('[OBS] Réglages lus dans OBS (' + d.source + ', port ' + d.port + ') — connexion.');
      }
      connectToObs('127.0.0.1', String(d.port), motDePasse);
    }
  }
  if (JSON.stringify(detection) !== JSON.stringify(etatRegie.obsState.obsDetection)) etatRegie.setState({ obsDetection: detection });
  return detection;
}

function disconnectFromObs() {
  obsManualDisconnect = true;
  if (obsReconnectTimer) { clearTimeout(obsReconnectTimer); obsReconnectTimer = null; }
  if (obsWs) { try { obsWs.close(); } catch (e) {} }
  obsWs = null;
  etatRegie.setState({ status: 'disconnected', error: '', scenes: [], sceneItems: [], currentScene: '', audioInputs: [], streaming: false, recording: false });
}

// Lancé une fois, au démarrage du pont, dans l’ordre fixé par server.js.
function demarrer() {
  // Branchement automatique en attente (serveur WebSocket désactivé dans OBS,
  // par exemple) : on relit les fichiers d'OBS régulièrement. Dès que la
  // personne coche la case et valide, la régie se branche, sans rien toucher.
  //
  // Aussi quand RIEN n'est encore réglé : c'est justement le cas de quelqu'un
  // qui a passé l'assistant et coche la case dans OBS plus tard. La première
  // version ne surveillait qu'un branchement automatique déjà enregistré —
  // et celui-ci ne l'est qu'une fois OBS trouvé : la régie ne se branchait
  // donc jamais, faute d'avoir trouvé OBS… au premier essai.
  setInterval(() => {
    if (obsManualDisconnect) return;
    const o = stockage.platformTokens.obs;
    if (o && o.host && !o.auto) return; // réglage manuel : on n'y touche pas
    if (etatRegie.obsState.status === 'connected' || etatRegie.obsState.status === 'connecting' || obsReconnectTimer) return;
    brancherObsAuto('surveillance');
  }, 10000);
}
