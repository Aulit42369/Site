// ============================================================
//  Les retours d’autorisation (OAuth)
// ------------------------------------------------------------
//  Un jeton « state » à usage unique par départ vers une page
//  d’autorisation : un retour que la régie n’a pas demandé est refusé.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  consommerEtatOauth,
  creerEtatOauth,
  get MESSAGE_ETAT_OAUTH() { return MESSAGE_ETAT_OAUTH; },
  pageRelanceOauth,
  pageRetourOauth,
  refusOauth,
  retourNonDemande,
};

const { randomBytes } = require('crypto');

const parametres = require('./parametres.js');
const outilsHttp = require('./http-outils.js');

// ------------------------------------------------------------
// Retours d'autorisation (YouTube, Instagram, TikTok) : « state »
// ------------------------------------------------------------
// Chaque départ vers une page d'autorisation reçoit un jeton à usage unique,
// valable 15 minutes, gardé ici. Un retour qui ne le rapporte pas est refusé :
// sans ça, une page piégée pouvait envoyer le navigateur du PC sur l'adresse
// de retour avec SON code, et faire relier SON compte à la régie (les envois
// partaient alors chez elle). TikTok y range aussi son code_verifier, qui
// voyageait en clair dans l'adresse.
const ETATS_OAUTH = new Map(); // jeton -> { plateforme, cree, donnees }
const ETAT_OAUTH_DUREE_MS = 15 * 60 * 1000;
function creerEtatOauth(plateforme, donnees) {
  const maintenant = Date.now();
  for (const [jeton, e] of ETATS_OAUTH) if (maintenant - e.cree > ETAT_OAUTH_DUREE_MS) ETATS_OAUTH.delete(jeton);
  const jeton = randomBytes(24).toString('base64url');
  ETATS_OAUTH.set(jeton, { plateforme, cree: maintenant, donnees: donnees || {} });
  return jeton;
}
// Les données rangées au départ, ou null si ce retour n'a pas été demandé ici
// (ou a déjà servi, ou a expiré). Le jeton est consommé dans tous les cas.
function consommerEtatOauth(plateforme, jeton) {
  const e = jeton ? ETATS_OAUTH.get(String(jeton)) : null;
  if (!e) return null;
  ETATS_OAUTH.delete(String(jeton));
  if (e.plateforme !== plateforme || Date.now() - e.cree > ETAT_OAUTH_DUREE_MS) return null;
  return e.donnees;
}
const MESSAGE_ETAT_OAUTH = 'Ce retour d’autorisation n’a pas été demandé par la régie, ou il a expiré : relance la connexion depuis la page /setup.';
// La petite page affichée au retour d'une autorisation. Le message peut venir
// du service (description d'erreur) : il est échappé, jamais interprété.
function pageRetourOauth(res, message) {
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end('<!DOCTYPE html><meta charset="utf-8"><p style="font-family:system-ui">' + outilsHttp.echapperHtml(message)
    + ' <a href="http://127.0.0.1:' + parametres.PORT + '/setup">Retour</a></p>');
}

// Une NOUVELLE autorisation que la régie relance d'elle-même (Instagram, quand
// l'adresse de retour n'avait pas la forme enregistrée chez Meta) :
// l'explication, puis le départ tout seul vers le service au bout de quelques
// secondes (sans JavaScript), ou tout de suite par le lien.
function pageRelanceOauth(res, message, adresse) {
  const lien = outilsHttp.echapperHtml(adresse);
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end('<!DOCTYPE html><meta charset="utf-8"><meta http-equiv="refresh" content="7;url=' + lien + '">'
    + '<p style="font-family:system-ui">' + outilsHttp.echapperHtml(message)
    + ' <a href="' + lien + '">Continuer maintenant</a></p>');
}

// Un retour sans « state » valable (pas demandé ici, déjà servi, ou plus de
// 15 minutes passées sur la page du service) : noté au journal aussi.
function retourNonDemande(res, service) {
  console.warn('[' + service + '] Retour d’autorisation refusé : pas demandé par la régie, ou expiré (plus de 15 minutes).');
  pageRetourOauth(res, MESSAGE_ETAT_OAUTH);
}

// Un retour d'autorisation qui échoue : la raison s'affiche ET part dans
// data/pont.log (masqué), pour qu'on puisse la retrouver après coup. « url »
// porte, quand le service a refusé lui-même, sa raison (error_description,
// error_reason, error) ; « erreur », l'échec de l'échange du code.
function refusOauth(res, service, { url, erreur } = {}) {
  let message;
  if (erreur) {
    message = 'Erreur : ' + String(erreur.message || erreur);
  } else {
    const p = url ? url.searchParams : new URLSearchParams();
    const raison = String(p.get('error_description') || p.get('error_reason') || p.get('error') || '').slice(0, 300);
    message = 'Autorisation annulée ou refusée' + (raison ? ' : ' + raison : '') + '.';
  }
  console.error('[' + service + '] Connexion refusée — ' + message);
  pageRetourOauth(res, message);
}
