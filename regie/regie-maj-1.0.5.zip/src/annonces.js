// ============================================================
//  Les annonces programmées
// ------------------------------------------------------------
//  Images en attente dans data/annonces/, publication à l’heure dite.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  annulerProgrammationsDe,
  demarrer,
  diffuserProgrammations,
  ecrireImageAnnonce,
  get publicationsProgrammees() { return publicationsProgrammees; },
  set publicationsProgrammees(valeur) { publicationsProgrammees = valeur; },
  publierPartout,
  supprimerImageAnnonce,
};

const fs = require('fs');
const path = require('path');

const parametres = require('./parametres.js');
const etatRegie = require('./etat-regie.js');
const stockage = require('./stockage.js');
const reglagesRegie = require('./reglages-regie.js');
const instagram = require('./instagram.js');
const bluesky = require('./bluesky.js');

// ------------------------------------------------------------
// Publications programmées
// ------------------------------------------------------------
// Le pont tourne déjà en permanence sur le PC du stream : c'est donc
// lui qui déclenche, pas le téléphone. Une annonce préparée le matin
// part à l'heure dite même téléphone éteint. Vérification à la minute,
// ce qui suffit très largement pour une publication de réseau social.
let publicationsProgrammees;

// ------------------------------------------------------------
// Images des annonces programmées
// ------------------------------------------------------------
// Elles vivent dans data/annonces/, PAS dans tokens.json. Une image
// d'annonce pèse ~100 Ko en base64 : trois annonces en attente
// faisaient passer le fichier des accès de quelques Ko à plus de
// 400 Ko. Or c'est le fichier le plus précieux du dossier (tous tes
// jetons) et le plus fragile : plus il est gros et plus il est
// réécrit souvent, plus il y a d'occasions de le corrompre — et une
// corruption, c'est tous les accès à refaire.
const ANNONCES_DIR = path.join(parametres.DATA_DIR, 'annonces');

function ecrireImageAnnonce(id, dataUri) {
  try {
    fs.mkdirSync(ANNONCES_DIR, { recursive: true });
    const m = /^data:image\/(\w+);base64,/.exec(String(dataUri || ''));
    const ext = m ? (m[1] === 'jpeg' ? 'jpg' : m[1]) : 'jpg';
    const octets = Buffer.from(String(dataUri || '').replace(/^data:image\/\w+;base64,/, ''), 'base64');
    const nom = `${id}.${ext}`;
    fs.writeFileSync(path.join(ANNONCES_DIR, nom), octets);
    return nom;
  } catch (e) {
    console.error('[pont] Image de l\u2019annonce non enregistrée :', e.message);
    return null;
  }
}

function lireImageAnnonce(nom) {
  if (!nom) return '';
  try {
    const octets = fs.readFileSync(path.join(ANNONCES_DIR, path.basename(nom)));
    const ext = path.extname(nom).slice(1).toLowerCase();
    return `data:image/${ext === 'jpg' ? 'jpeg' : ext};base64,` + octets.toString('base64');
  } catch (e) {
    return '';
  }
}

function supprimerImageAnnonce(nom) {
  if (!nom) return;
  try { fs.unlinkSync(path.join(ANNONCES_DIR, path.basename(nom))); } catch (e) {}
}

// Un seul chemin de publication, utilisé aussi bien par le bouton
// « Publier maintenant » que par le déclencheur programmé : ce qui part
// à 21 h est exactement ce qui serait parti en appuyant sur le bouton.
async function publierPartout(contenu) {
  const imageBuffer = Buffer.from(
    String(contenu.image || '').replace(/^data:image\/\w+;base64,/, ''),
    'base64'
  );
  const targets = Array.isArray(contenu.targets) ? contenu.targets : [];
  const results = {};

  if (targets.includes('instagram')) {
    try {
      const r = await instagram.publishStoryToInstagram(imageBuffer);
      results.instagram = { ok: true, id: r.id, url: r.url };
    } catch (e) {
      results.instagram = { ok: false, error: e.message };
    }
  }

  if (targets.includes('bluesky')) {
    try {
      const r = await bluesky.postToBluesky({ text: contenu.caption || '', imageBuffer, imageAlt: contenu.caption || '' });
      results.blueskyPost = { ok: true, url: r.url };
    } catch (e) {
      results.blueskyPost = { ok: false, error: e.message };
    }
    if (contenu.liveDurationMinutes) {
      try {
        await bluesky.setBlueskyLiveStatus({
          durationMinutes: contenu.liveDurationMinutes,
          twitchUrl: contenu.twitchUrl,
          title: contenu.caption,
        });
        results.blueskyLive = { ok: true };
      } catch (e) {
        results.blueskyLive = { ok: false, error: e.message };
      }
    }
  }

  return results;
}

// L'etat partage part a TOUS les clients connectes (l'appli, mais aussi
// un overlay OBS qui ecouterait le pont). Les images des publications
// programmees pesent ~100 Ko chacune en base64 : les y laisser gonflerait
// chaque diffusion et noierait les lecteurs legers. On ne partage donc
// que de quoi afficher la liste.
function programmationsAllegees() {
  return publicationsProgrammees.map(({ contenu, par, ...reste }) => reste);
}

// Un appareil retiré ne laisse rien partir après lui : ses annonces encore
// en attente sont annulées (ids : les appareils retirés ; null : tous les
// appareils reliés). Celles du PC (par vide) restent. Rend leur nombre.
function annulerProgrammationsDe(ids) {
  const visee = (p) => p.statut === 'attente' && !!p.par && (!ids || ids.has(p.par));
  const parties = publicationsProgrammees.filter(visee);
  if (!parties.length) return 0;
  parties.forEach((p) => supprimerImageAnnonce(p.contenu && p.contenu.image));
  publicationsProgrammees = publicationsProgrammees.filter((p) => !visee(p));
  reglagesRegie.persistExtras();
  diffuserProgrammations();
  return parties.length;
}
function diffuserProgrammations() {
  etatRegie.obsState.publicationsProgrammees = programmationsAllegees();
  etatRegie.broadcastPatch({ publicationsProgrammees: etatRegie.obsState.publicationsProgrammees });
}

async function executerPublicationProgrammee(p) {
  p.statut = 'en cours';
  diffuserProgrammations();
  try {
    const image = lireImageAnnonce(p.contenu.image);
    if (!image) throw new Error('Image introuvable dans data/annonces/ — annonce annulée.');
    const resultats = await publierPartout({ ...p.contenu, image });
    // « fait » doit vouloir dire que quelque chose est parti. Chaque
    // destination est tentée séparément et rapporte son propre résultat :
    // si AUCUNE n'a abouti, l'annonce est un échec, pas une réussite —
    // sinon elle s'affiche en vert alors que rien n'a été publié.
    const abouties = Object.values(resultats).filter((r) => r && r.ok).length;
    const echouees = Object.entries(resultats).filter(([, r]) => r && !r.ok);
    p.resultats = resultats;
    p.termineeA = Date.now();
    if (abouties === 0) {
      p.statut = 'echec';
      p.erreur = echouees.map(([nom, r]) => `${nom} : ${r.error}`).join(' · ') || 'Aucune destination n\u2019a abouti.';
    } else {
      p.statut = 'fait';
      // Succès partiel : on garde la trace de ce qui n'est pas passé.
      p.erreur = echouees.length ? echouees.map(([nom, r]) => `${nom} : ${r.error}`).join(' · ') : '';
    }
  } catch (e) {
    p.statut = 'echec';
    p.erreur = e.message;
    p.termineeA = Date.now();
  }
  reglagesRegie.persistExtras();
  diffuserProgrammations();
}

// Lancé une fois, au démarrage du pont, dans l’ordre fixé par server.js.
function demarrer() {
  publicationsProgrammees = Array.isArray(stockage.platformTokens.publicationsProgrammees)
    ? stockage.platformTokens.publicationsProgrammees
    : [];
  // Reprise des annonces enregistrées par une version précédente, qui gardait
  // l'image entière dans tokens.json. On les sort du fichier des accès au
  // premier démarrage ; une annonce dont l'image serait illisible est écartée
  // plutôt que de rester en attente et d'échouer le moment venu.
  // Placé APRÈS la déclaration de ANNONCES_DIR : l'inverse planterait au
  // démarrage, la constante n'existant pas encore à cet instant.
  (function migrerImagesAnnonces() {
    let migrees = 0, perdues = 0;
    publicationsProgrammees = publicationsProgrammees.filter((p) => {
      const img = p.contenu && p.contenu.image;
      if (!img || !String(img).startsWith('data:')) return true; // déjà au nouveau format
      const nom = ecrireImageAnnonce(p.id, img);
      if (!nom) { perdues += 1; return false; }
      p.contenu.image = nom;
      migrees += 1;
      return true;
    });
    if (migrees || perdues) {
      stockage.platformTokens.publicationsProgrammees = publicationsProgrammees;
      stockage.saveTokens();
      console.log(`[pont] Annonces programmées : ${migrees} image(s) déplacée(s) vers data/annonces/` +
        (perdues ? `, ${perdues} illisible(s) et retirée(s).` : '.'));
    }
  })();
  etatRegie.obsState.publicationsProgrammees = programmationsAllegees();
  setInterval(() => {
    const maintenant = Date.now();
    let changement = false;
    for (const p of publicationsProgrammees) {
      if (p.statut !== 'attente' || p.quand > maintenant) continue;
      changement = true;
      // Au-delà de deux heures de retard, l'annonce a perdu son sens : le PC
      // était éteint, ou le pont arrêté. La publier maintenant enverrait
      // « Live à 21h ! » le lendemain matin. On la marque manquée.
      if (maintenant - p.quand > 2 * 3600 * 1000) {
        p.statut = 'echec';
        p.erreur = 'Heure dépassée de plus de 2 h (pont arrêté à ce moment-là) — rien n\u2019a été publié.';
        p.termineeA = maintenant;
        reglagesRegie.persistExtras();
        continue;
      }
      executerPublicationProgrammee(p);
    }
    // Purge des programmations terminées depuis plus de 7 jours : sans ça
    // la liste grossit indéfiniment et l'écran devient illisible.
    const avant = publicationsProgrammees.length;
    const aGarder = (p) => p.statut === 'attente' || !p.termineeA || maintenant - p.termineeA < 7 * 24 * 3600 * 1000;
    // L'image part avec sa programmation : sans ça, data/annonces/ garderait
    // une image de 100 Ko pour chaque annonce publiée, indéfiniment.
    publicationsProgrammees.filter((p) => !aGarder(p)).forEach((p) => supprimerImageAnnonce(p.contenu && p.contenu.image));
    publicationsProgrammees = publicationsProgrammees.filter(aGarder);
    if (publicationsProgrammees.length !== avant) { changement = true; reglagesRegie.persistExtras(); }
    if (changement) diffuserProgrammations();
  }, 30000);
}
