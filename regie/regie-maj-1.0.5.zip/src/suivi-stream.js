// ============================================================
//  SUIVI DES STREAMS — un début, une fin, et le bilan après coup
// ------------------------------------------------------------
//  Le pont apprend qu'un stream commence ou s'arrête par deux
//  voies : OBS (« le direct démarre / s'arrête ») et Twitch
//  (« la chaîne passe en ligne / hors ligne »). Ce module en fait
//  des sessions :
//    • une session commence au premier signal de début ;
//    • un signal de fin ne la termine qu'après un délai de grâce :
//      un redémarrage pendant ce délai (box qui décroche, OBS
//      relancé) continue la MÊME session, au lieu d'en faire deux ;
//    • le second signal de fin (Twitch arrive souvent une minute
//      après OBS) est ignoré ;
//    • une fin que personne n'a vue (OBS fermé d'un coup ET écoute
//      Twitch coupée) : le stream suivant ne prolonge plus l'ancien.
//      Un début qui arrive bien après le dernier signe de vie de la
//      session (vivant(), et chaque signal de début) — selon l'heure
//      annoncée ET selon l'horloge de ce PC — la clôt à ce moment-là,
//      puis en ouvre une nouvelle. finSansSigneDeVie() la clôt dès que
//      l'écoute Twitch revient et trouve la chaîne hors ligne ;
//      cloreEnAttente() clôt sans attendre une session dans son délai
//      de grâce, quand le pont s'arrête.
//
//  Quand une session est finie pour de bon, il appelle
//  aLaFin({ debut, fin, sources, donnees, tardive }). C'est le pont
//  qui décide quoi en faire (publier le bilan sur Discord, ou rien).
//  « tardive » : la fin remonte à plus de retardMaxMs (une heure par
//  défaut) quand on la constate, un bilan publié alors arriverait
//  bien après le stream.
//  auDebut(session) lui permet d'y ranger ce qu'il veut retrouver
//  à la fin (dans session.donnees).
//
//  Aucune dépendance, aucune horloge cachée : l'horloge et les
//  minuteurs peuvent être remplacés, pour les contrôles.
// ============================================================
'use strict';

function creerSuiviStream(options) {
  const o = options || {};
  const delaiMs = Number.isFinite(o.delaiMs) ? o.delaiMs : 3 * 60 * 1000;
  const retardMaxMs = Number.isFinite(o.retardMaxMs) ? o.retardMaxMs : 60 * 60 * 1000;
  const maintenant = o.maintenant || Date.now;
  const programmer = o.programmer || setTimeout;
  const annuler = o.annuler || clearTimeout;
  const auDebut = o.auDebut || (() => {});
  const aLaFin = o.aLaFin || (() => {});
  const journal = o.journal || (() => {});

  let session = null; // { debut, fin, vu, sources, donnees, minuteur }
  let derniereFinClose = 0; // la fin de la dernière session confiée au pont

  // La session est finie pour de bon : on la confie au pont. Rend ce que
  // rend aLaFin (la publication du bilan, quand elle est en cours).
  function clore(s) {
    if (session === s) session = null;
    if (s.minuteur) { annuler(s.minuteur); s.minuteur = null; }
    derniereFinClose = Math.max(derniereFinClose, s.fin);
    try {
      return aLaFin({ debut: s.debut, fin: s.fin, sources: s.sources.slice(), donnees: s.donnees, tardive: maintenant() - s.fin > retardMaxMs });
    } catch (e) {
      journal('aLaFin : ' + (e.message || e));
      return undefined;
    }
  }

  function debut(quand, source) {
    const ici = maintenant();
    const t = Number(quand) || ici;
    if (session && session.fin === null && t > session.vu + delaiMs && ici > session.vu + delaiMs) {
      // Ce début arrive bien après le dernier signe de vie de la session :
      // le stream précédent s'est arrêté sans que personne le voie. Il
      // finit à ce dernier signe de vie, au lieu de se prolonger. Les DEUX
      // horloges doivent le dire : l'heure de début vient de Twitch, et un
      // PC en retard de quelques minutes coupait sinon un stream en deux.
      const ancienne = session;
      ancienne.fin = ancienne.vu;
      journal(`fin du stream précédent jamais vue : clos à son dernier signe de vie`);
      clore(ancienne);
    }
    if (session && session.fin !== null && ici - session.fin > delaiMs) {
      // Le minuteur du délai de grâce n'a pas encore sonné, mais l'horloge
      // dit que le délai est passé (PC mis en veille juste après le stream,
      // minuteurs en retard) : la session est finie, ce début est un autre.
      journal('fin du stream confirmée (le délai de grâce est passé)');
      clore(session);
    }
    if (session && session.fin !== null) {
      // Reprise pendant le délai de grâce : c'est le même stream.
      annuler(session.minuteur);
      session.minuteur = null;
      session.fin = null;
      journal(`reprise du direct (${source}) : le stream continue`);
    } else if (session) {
      // Déjà en cours. Un signal qui situe le début plus tôt (Twitch donne
      // l'heure exacte de mise en ligne) corrige l'heure retenue.
      if (t < session.debut) session.debut = t;
    } else {
      session = { debut: t, fin: null, vu: Math.max(t, ici), sources: [], donnees: {}, minuteur: null };
      try { auDebut(session); } catch (e) { journal('auDebut : ' + (e.message || e)); }
      journal(`début du stream (${source})`);
    }
    if (!session.sources.includes(source)) session.sources.push(source);
    // Un signal de début, c'est aussi un signe que le stream vit.
    session.vu = Math.max(session.vu, ici);
  }

  // Un signe que le stream vit encore (OBS diffuse, relevé de santé) : sert
  // à dater sa fin si personne ne la voit. Rien pendant le délai de grâce.
  function vivant(quand) {
    if (!session || session.fin !== null) return;
    session.vu = Math.max(session.vu, Number(quand) || maintenant());
  }

  // On vient d'apprendre que plus rien ne diffuse : l'écoute Twitch revient
  // et la chaîne n'est plus en direct, OBS ne diffuse pas. Seulement pour une
  // session que « siVuPar » (Twitch) a vue en direct : un stream sur YouTube
  // seul n'est pas concerné. Sans signe de vie depuis plus que le délai de
  // grâce, elle a fini sans qu'on le voie : close tout de suite, à son
  // dernier signe de vie (le délai est déjà passé ; l'attendre encore
  // laissait un début tout proche passer pour une reprise). Rend 'close',
  // 'trop-tot' (signe de vie trop récent : à revoir après le délai) ou 'rien'.
  function finSansSigneDeVie(source, siVuPar) {
    if (!session || session.fin !== null) return 'rien';
    if (siVuPar && !session.sources.includes(siVuPar)) return 'rien';
    if (maintenant() - session.vu <= delaiMs) return 'trop-tot';
    const s = session;
    s.fin = s.vu;
    journal(`fin du stream (${source}) : plus aucun signe de vie, clos au dernier`);
    clore(s);
    return 'close';
  }

  // Le pont s'arrête : une session dans son délai de grâce est close tout de
  // suite (son bilan et son historique partaient sinon avec le pont). Une
  // session encore en cours qu'OBS a vue, alors qu'OBS (relié) ne diffuse
  // plus : sa fin n'a pas été vue (OBS fermé d'un coup, puis rouvert), elle
  // est close à son dernier signe de vie. Rend la publication en cours, que
  // l'arrêt peut attendre un peu.
  function cloreEnAttente(o) {
    if (!session) return undefined;
    if (session.fin === null) {
      const obsArrete = !!(o && o.obsRelie && !o.obsDiffuse);
      if (!obsArrete || !session.sources.includes('OBS')) return undefined;
      session.fin = session.vu;
      journal('arrêt du pont, OBS ne diffuse plus : le stream est clos à son dernier signe de vie');
      return clore(session);
    }
    journal('arrêt du pont pendant le délai de grâce : le stream est clos maintenant');
    return clore(session);
  }

  // La fin la plus récente connue : celle d'une session dans son délai de
  // grâce, ou de la dernière close. Sert à reconnaître un « en direct » en
  // retard de Twitch (twitch-direct.js).
  function derniereFin() {
    return Math.max(derniereFinClose, session && session.fin !== null ? session.fin : 0);
  }

  function fin(quand, source) {
    if (!session) return; // fin d'un stream dont on n'a pas vu le début : rien à conclure
    if (session.fin !== null) return; // déjà en train de finir (second signal)
    const s = session;
    s.fin = Number(quand) || maintenant();
    journal(`fin du stream (${source}), confirmée dans ${Math.round(delaiMs / 1000)} s si rien ne redémarre`);
    s.minuteur = programmer(() => {
      if (session !== s || s.fin === null) return;
      s.minuteur = null;
      clore(s);
    }, delaiMs);
  }

  // Pour le diagnostic et les contrôles : rien de modifiable.
  function etat() {
    if (!session) return null;
    return { debut: session.debut, fin: session.fin, vu: session.vu, enCours: session.fin === null, sources: session.sources.slice() };
  }

  return { debut, fin, vivant, finSansSigneDeVie, cloreEnAttente, derniereFin, etat };
}

module.exports = { creerSuiviStream };
