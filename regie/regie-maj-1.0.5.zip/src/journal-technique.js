// ============================================================
//  Journal technique du pont (data/pont.log)
// ------------------------------------------------------------
//  Tout ce que le pont affiche part aussi dans data/pont.log, jetons
//  masqués : c’est ce qu’on relit après un incident.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  demarrer,
  lireJournalTechnique,
};

const fs = require('fs');
const path = require('path');

const parametres = require('./parametres.js');

// Le pont n'écrivait AUCUNE trace. Quand quelque chose cassait en plein
// direct — OBS qui refuse une scène, Twitch qui révoque une souscription,
// une annonce qui échoue — le seul témoignage était la fenêtre noire, qu'on
// finit par fermer. Le lendemain, il ne restait rien pour comprendre.
//
// Tout ce que le pont affiche est donc aussi écrit ici. On intercepte
// console.log, console.error et console.warn plutôt que d'ajouter des
// appels partout : une seule fois, et les messages à venir sont couverts
// d'office. server.js le branche en tout premier (demarrer), pour que même
// les messages du chargement des accès y figurent — c'est justement celui
// qui dit « tokens.json est illisible » qu'on veut pouvoir relire.
let journalEnCours = false;            // garde-fou : écrire ne doit pas se journaliser
const JOURNAL_TAILLE_MAX = 512 * 1024; // au-delà, on coupe la moitié la plus ancienne

// Chemin recalculé à chaque écriture plutôt que figé : la fonction ne
// dépend de rien qui pourrait ne pas être prêt au tout premier message.
function cheminJournalTechnique() {
  return path.join(parametres.RACINE, 'data', 'pont.log');
}

// Un jeton ne doit jamais atterrir dans un fichier qu'on partage pour
// demander de l'aide. Aucun message n'en affiche aujourd'hui, mais un
// message à venir pourrait : la précaution est ici, une fois pour toutes.
function masquerSecrets(texte) {
  return String(texte)
    .replace(/\b(Bearer|oauth:)\s*[\w-]{10,}/gi, '$1 ***')
    // Une adresse de webhook Discord est un accès complet au salon.
    .replace(/(discord(?:app)?\.com\/api\/webhooks\/)\d+\/[\w-]+/gi, '$1***')
    .replace(/\b[a-z0-9]{26,}\b/gi, (m) => m.slice(0, 4) + '***');
}

function ecrireJournalTechnique(niveau, args) {
  if (journalEnCours) return;
  journalEnCours = true;
  try {
    const chemin = cheminJournalTechnique();
    fs.mkdirSync(path.dirname(chemin), { recursive: true });
    // Heure LOCALE, comme partout ailleurs dans la régie : en UTC, un
    // incident vu à 21 h apparaissait à 19 h dans le journal, et on cherchait
    // au mauvais endroit.
    const d = new Date();
    const p2 = (n) => String(n).padStart(2, '0');
    const quand = d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate())
      + ' ' + p2(d.getHours()) + ':' + p2(d.getMinutes()) + ':' + p2(d.getSeconds());
    const message = args.map((a) => (typeof a === 'string' ? a : (a && a.message) || String(a))).join(' ');
    fs.appendFileSync(chemin, `${quand} [${niveau}] ${masquerSecrets(message)}\n`);

    // Rotation par troncature : on garde la seconde moitié. Pas de fichier
    // « .1 » à gérer, et la taille reste bornée même après des mois.
    if (fs.statSync(chemin).size > JOURNAL_TAILLE_MAX) {
      const contenu = fs.readFileSync(chemin, 'utf8');
      const coupe = contenu.slice(Math.floor(contenu.length / 2));
      // On repart d'une ligne entière, pas du milieu d'une phrase.
      const propre = coupe.slice(coupe.indexOf('\n') + 1);
      fs.writeFileSync(chemin, '--- début tronqué (journal trop long) ---\n' + propre);
    }
  } catch (e) {
    // Un journal qui ne s'écrit pas ne doit jamais faire tomber le pont.
  } finally {
    journalEnCours = false;
  }
}

function lireJournalTechnique(lignes) {
  try {
    const tout = fs.readFileSync(cheminJournalTechnique(), 'utf8').split('\n').filter(Boolean);
    return tout.slice(-(lignes || 200));
  } catch (e) {
    return [];
  }
}

// Lancé en tout premier par server.js : le journal reçoit tout ce qui suit.
function demarrer() {
  for (const [niveau, nom] of [['INFO', 'log'], ['ERREUR', 'error'], ['ALERTE', 'warn']]) {
    const original = console[nom].bind(console);
    console[nom] = (...args) => { original(...args); ecrireJournalTechnique(niveau, args); };
  }
}
