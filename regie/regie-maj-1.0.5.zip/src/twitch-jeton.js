// ============================================================
//  Le jeton Twitch
// ------------------------------------------------------------
//  Connexion par code, renouvellement d’avance, validation.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  demarrer,
  arreterInterrogationCode,
  connexionParCode,
  demarrerConnexionParCode,
  get derniereValidationTwitch() { return derniereValidationTwitch; },
  set derniereValidationTwitch(valeur) { derniereValidationTwitch = valeur; },
  jetonTwitchValide,
  majTwitchCode,
  rafraichirKitDansEtat,
  raidCabaneVisible,
  renouvelerJetonTwitch,
  surveillerJetonTwitch,
  get twitchRafraichissement() { return twitchRafraichissement; },
  set twitchRafraichissement(valeur) { twitchRafraichissement = valeur; },
};

const twitchAppareil = require('./twitch-appareil.js');

const parametres = require('./parametres.js');
const etatRegie = require('./etat-regie.js');
const twitchEcoute = require('./twitch-ecoute.js');
const stockage = require('./stockage.js');
const fabriqueKit = require('./kit.js');

// Ce que le kit (kit.json) apporte à l'état diffusé : la connexion Twitch
// par code est-elle possible, et le pseudo par défaut. Relu au démarrage
// et quand la page /kit l'enregistre.
function rafraichirKitDansEtat() {
  const kit = fabriqueKit.lireKit(parametres.RACINE);
  etatRegie.obsState.twitchCode = { ...etatRegie.obsState.twitchCode, disponible: !!kit.twitchClientId };
  etatRegie.obsState.pseudoKit = kit.pseudo || '';
  // Régie reçue dans un kit : l'appli y cache la publication Instagram.
  etatRegie.obsState.dansUnKit = kit.dansUnKit;
  // Raid · La Cabane : l'appli cache la carte si on l'a retirée.
  etatRegie.obsState.raidCabaneActif = raidCabaneVisible();
  return kit;
}

// La carte « Raid · La Cabane » est-elle proposée ? L'interrupteur de
// Réglages (tokens.json, raidCabaneAffiche) passe devant la case du kit
// (kit.json, raidCabane), qui n'en fixe que la valeur de départ.
function raidCabaneVisible() {
  const choix = stockage.platformTokens.raidCabaneAffiche;
  return typeof choix === 'boolean' ? choix : fabriqueKit.raidCabaneActif();
}

// ------------------------------------------------------------
// Jeton Twitch : connexion par code, renouvellement, validation
// ------------------------------------------------------------
// Deux façons d'être connecté :
//  • « manuelle » (l'ancienne) : un jeton collé à la main. Il ne se
//    renouvelle pas ; quand il expire, il faut en recoller un.
//  • « par code » (twitchCreds.mode === 'code') : le pont garde aussi un
//    jeton de RENOUVELLEMENT, et repart tout seul quand le jeton d'accès
//    (4 h) arrive à échéance.
//
// Le jeton de renouvellement ne quitte JAMAIS le pont : il vit ici et dans
// tokens.json (platformTokens.twitchAppareil), jamais dans obsState — donc
// jamais dans ce qui part vers un navigateur, même l'appli.
let twitchRafraichissement = null;   // { refreshToken, clientId }
let renouvellementEnCours = null;

function connexionParCode() {
  const c = etatRegie.obsState.twitchCreds || {};
  return c.mode === 'code' && !!(twitchRafraichissement && twitchRafraichissement.refreshToken);
}

function enregistrerJetonsTwitch(clientId, jetons) {
  etatRegie.obsState.twitchCreds = { clientId, token: jetons.accessToken, mode: 'code', expireA: jetons.expireA };
  // Usage unique côté Twitch : le NOUVEAU jeton de renouvellement doit être
  // écrit tout de suite, sinon la connexion est perdue au prochain tour.
  if (jetons.refreshToken) twitchRafraichissement = { refreshToken: jetons.refreshToken, clientId };
  stockage.platformTokens.twitchAppareil = twitchRafraichissement;
  stockage.persistSharedState();
  etatRegie.broadcastState();
}

async function renouvelerJetonTwitch(raison) {
  if (!connexionParCode()) throw new Error('Connexion manuelle : le jeton ne se renouvelle pas.');
  // Une seule demande à la fois : deux renouvellements simultanés
  // utiliseraient deux fois le même jeton à usage unique, et le second
  // ferait échouer la connexion pour de bon.
  if (renouvellementEnCours) return renouvellementEnCours;
  // La connexion de départ : si elle change pendant qu'on attend Twitch
  // (méthode manuelle choisie, nouveau code, « Tout oublier »), la réponse
  // ne doit RIEN écraser — elle ressusciterait des accès effacés ou
  // remplacerait ceux qu'on vient de donner.
  const source = twitchRafraichissement;
  const clientId = etatRegie.obsState.twitchCreds.clientId;
  renouvellementEnCours = (async () => {
    try {
      const j = await twitchAppareil.renouveler({ base: parametres.TWITCH_ID, clientId, refreshToken: source.refreshToken });
      if (twitchRafraichissement !== source) {
        console.log('[Twitch] Renouvellement ignoré : la connexion a changé entre-temps.');
        throw new Error('La connexion Twitch a changé pendant le renouvellement.');
      }
      enregistrerJetonsTwitch(clientId, j);
      console.log('[Twitch] Jeton renouvelé (' + raison + ').');
      return j.accessToken;
    } catch (e) {
      if (e.definitif && twitchRafraichissement === source) {
        console.error('[Twitch] Renouvellement refusé : ' + e.message);
        twitchRafraichissement = null;
        delete stockage.platformTokens.twitchAppareil;
        etatRegie.obsState.twitchCreds = { ...etatRegie.obsState.twitchCreds, mode: 'expire' };
        stockage.persistSharedState();
        twitchEcoute.setTwitchListen({ status: 'error', error: e.message });
      }
      throw e;
    } finally {
      renouvellementEnCours = null;
    }
  })();
  return renouvellementEnCours;
}

// Le jeton à utiliser maintenant. En connexion par code, il est renouvelé
// d'avance s'il expire dans moins de 5 minutes.
async function jetonTwitchValide() {
  const c = etatRegie.obsState.twitchCreds || {};
  if (connexionParCode() && c.expireA && c.expireA - Date.now() < 5 * 60 * 1000) {
    try { return await renouvelerJetonTwitch('bientôt expiré'); } catch (e) { /* on tente avec l'actuel */ }
  }
  return String(c.token || '').trim().replace(/^oauth:/i, '');
}

// Renouvellement en avance, et validation horaire. Twitch demande aux
// applications de vérifier leur jeton au démarrage puis toutes les heures :
// c'est ce qui révèle une autorisation retirée depuis le site de Twitch.
let derniereValidationTwitch = 0;
async function surveillerJetonTwitch() {
  const c = etatRegie.obsState.twitchCreds || {};
  if (!c.clientId || !c.token) return;
  if (connexionParCode() && c.expireA && c.expireA - Date.now() < 10 * 60 * 1000) {
    try { await renouvelerJetonTwitch('programmé'); } catch (e) {}
    return;
  }
  if (Date.now() - derniereValidationTwitch < 60 * 60 * 1000) return;
  derniereValidationTwitch = Date.now();
  let v;
  try { v = await twitchAppareil.valider({ base: parametres.TWITCH_ID, token: String(c.token).replace(/^oauth:/i, '') }); }
  catch (e) { derniereValidationTwitch = 0; return; } // réseau : on retentera
  if (v.valide) return;
  if (v.statut !== 401) return;
  if (connexionParCode()) {
    try { await renouvelerJetonTwitch('jeton refusé à la validation'); } catch (e) {}
  } else {
    twitchEcoute.setTwitchListen({ warning: 'Le jeton Twitch n’est plus valide (expiré ou autorisation retirée). Reconnecte Twitch dans Réglages.' });
  }
}

// ---------- La connexion par code ----------
let interrogationCode = null; // { deviceCode, clientId, intervalle, expireA, minuteur }

function majTwitchCode(patch) {
  etatRegie.obsState.twitchCode = { ...etatRegie.obsState.twitchCode, ...patch };
  etatRegie.broadcastState();
}

function arreterInterrogationCode() {
  if (interrogationCode) { clearTimeout(interrogationCode.minuteur); interrogationCode = null; }
}

async function demarrerConnexionParCode() {
  const kit = fabriqueKit.lireKit(parametres.RACINE);
  if (!kit.twitchClientId) {
    throw new Error(kit.twitchClientIdInvalide
      ? 'Le Client ID Twitch de kit.json est invalide. Corrige-le sur la page /kit du PC.'
      : 'La connexion par code n’est pas préparée sur cette régie (pas de Client ID dans kit.json). '
        + 'Utilise la méthode manuelle, ou demande à la personne qui t’a installé la régie.');
  }
  arreterInterrogationCode();
  const d = await twitchAppareil.demanderCode({ base: parametres.TWITCH_ID, clientId: kit.twitchClientId });
  interrogationCode = {
    deviceCode: d.deviceCode,
    clientId: kit.twitchClientId,
    intervalle: d.intervalle,
    expireA: Date.now() + d.expireDans * 1000,
    minuteur: null,
  };
  majTwitchCode({ etape: 'attente', code: d.code, lien: d.lien, expireA: interrogationCode.expireA, erreur: '' });
  planifierInterrogationCode();
}

function planifierInterrogationCode() {
  const it = interrogationCode;
  if (!it) return;
  it.minuteur = setTimeout(async () => {
    if (interrogationCode !== it) return;
    if (Date.now() > it.expireA) {
      interrogationCode = null;
      majTwitchCode({ etape: 'expire', code: '', lien: '', erreur: 'Le code a expiré. Demande un nouveau code.' });
      return;
    }
    let r;
    try {
      r = await twitchAppareil.interrogerUneFois({ base: parametres.TWITCH_ID, clientId: it.clientId, deviceCode: it.deviceCode });
    } catch (e) {
      r = { etat: 'attente' }; // coupure réseau passagère : on continue d'attendre
    }
    if (interrogationCode !== it) return; // annulé pendant l'attente de la réponse
    if (r.etat === 'attente') { planifierInterrogationCode(); return; }
    if (r.etat === 'ralentir') { it.intervalle += 5; planifierInterrogationCode(); return; }
    interrogationCode = null;
    if (r.etat === 'ok') {
      enregistrerJetonsTwitch(it.clientId, r.jetons);
      derniereValidationTwitch = Date.now();
      majTwitchCode({ etape: 'termine', code: '', lien: '', erreur: '' });
      console.log('[Twitch] Connecté par code.');
      twitchEcoute.connectTwitchListen();
    } else {
      majTwitchCode({ etape: r.expire ? 'expire' : 'erreur', code: '', lien: '', erreur: r.erreur || 'Échec.' });
    }
  }, it.intervalle * 1000);
}

// Lancé une fois, au démarrage du pont, dans l’ordre fixé par server.js.
function demarrer() {
  setInterval(() => { surveillerJetonTwitch().catch(() => {}); }, 60 * 1000);
}
