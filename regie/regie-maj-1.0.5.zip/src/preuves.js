// ============================================================
//  Les preuves de l’installation (data/installation.json)
// ------------------------------------------------------------
//  Le téléphone est passé, son certificat est reconnu, l’appli tourne
//  en https : noté par le pont lui-même, jamais sur parole.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  demarrer,
  configurationDejaFaite,
  enregistrerSuivi,
  noterPassageTelephone,
  noterSiTelephone,
  get suiviInstallation() { return suiviInstallation; },
};

const fs = require('fs');
const path = require('path');

const parametres = require('./parametres.js');
const etatRegie = require('./etat-regie.js');
const securite = require('./securite.js');
const stockage = require('./stockage.js');
const arret = require('./arret.js');

// ------------------------------------------------------------
// Suivi de l'installation (data/installation.json)
// ------------------------------------------------------------
// Les PREUVES qu'une étape a marché, notées par le pont lui-même au lieu de
// croire la personne sur parole :
//  • le téléphone a joint la régie (une requête venue du réseau local) ;
//  • son certificat est reconnu (il a chargé /ping.gif en https : une image
//    sur un certificat non reconnu échoue sans même proposer « Continuer ») ;
//  • l'appli a tourné en https sur le téléphone (il a demandé /sw.js en
//    https : Chrome refuse le service worker sur un certificat contesté).
// Rien de secret ici : des dates. Le fichier vit dans data/, avec le reste
// de ce qui s'accumule.
const FICHIER_INSTALLATION = path.join(parametres.DATA_DIR, 'installation.json');
let suiviInstallation = { telephoneVuA: 0, certificatOkA: 0, appliHttpsA: 0, configurationTermineeA: 0, discordDernierEchec: '' };

let ecritureSuiviPrevue = null;
function ecrireSuivi() {
  if (!stockage.ensureDataDir()) return;
  try {
    const tmp = FICHIER_INSTALLATION + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(suiviInstallation, null, 2));
    fs.renameSync(tmp, FICHIER_INSTALLATION);
  } catch (e) { console.error('[pont] Suivi d’installation non enregistré :', e.message); }
}
function enregistrerSuivi() {
  if (ecritureSuiviPrevue) return;
  ecritureSuiviPrevue = setTimeout(() => {
    ecritureSuiviPrevue = null;
    ecrireSuivi();
  }, 1500);
}
// À l'arrêt du pont : une écriture prévue dans la seconde est faite tout de suite.
function ecrireSuiviEnAttente() {
  if (!ecritureSuiviPrevue) return;
  clearTimeout(ecritureSuiviPrevue);
  ecritureSuiviPrevue = null;
  ecrireSuivi();
}

// type : 'vu' | 'certificat' | 'https'
function noterPassageTelephone(type) {
  const maintenant = Date.now();
  const champ = { vu: 'telephoneVuA', certificat: 'certificatOkA', https: 'appliHttpsA' }[type];
  if (!champ) return;
  const avant = Number(suiviInstallation[champ]) || 0;
  // Une écriture par minute au plus : l'appli fait des dizaines de requêtes.
  if (maintenant - avant < 60 * 1000) return;
  suiviInstallation[champ] = maintenant;
  // Une preuve forte implique les plus faibles.
  if (type !== 'vu') suiviInstallation.telephoneVuA = maintenant;
  if (type === 'https') suiviInstallation.certificatOkA = maintenant;
  enregistrerSuivi();
  const t = {
    vuA: suiviInstallation.telephoneVuA,
    certificatOkA: suiviInstallation.certificatOkA,
    appliHttpsA: suiviInstallation.appliHttpsA,
  };
  // Diffusé tout de suite seulement au PREMIER passage (c'est ce que l'écran
  // du PC attend pour passer au vert) ; ensuite l'état suit discrètement.
  if (!avant) etatRegie.setState({ telephone: t });
  else etatRegie.setStatePartiel({ telephone: t });
}

// Une installation qui marchait avant l'arrivée de l'assistant compte comme
// déjà configurée : on ne lui ouvre pas d'assistant ni de navigateur.
function configurationDejaFaite() {
  return !!(suiviInstallation.configurationTermineeA
    || (stockage.platformTokens.obs && stockage.platformTokens.obs.host && !stockage.platformTokens.obs.auto)
    || (etatRegie.obsState.twitchCreds && etatRegie.obsState.twitchCreds.token));
}

// Deux preuves sont notées ici, au passage des requêtes : le téléphone a
// joint la régie (n'importe quelle requête), et son certificat est reconnu
// (l'image /ping.gif chargée en https). La troisième — l'appli tourne en
// mode sécurisé — est ENVOYÉE par l'appli elle-même (POST
// /api/telephone/preuve), une fois son service worker accepté par le
// navigateur : c'est la seule preuve que le certificat est vraiment de
// confiance. Une simple requête https ne prouve rien — on peut passer
// l'avertissement de Chrome d'un clic sur « Continuer ».
function noterSiTelephone(req, url) {
  if (securite.surCeMemePc(req)) return;
  if (req.socket.encrypted && url.pathname === '/ping.gif') noterPassageTelephone('certificat');
  else noterPassageTelephone('vu');
}

// Lancé une fois, au démarrage du pont, dans l’ordre fixé par server.js.
function demarrer() {
  try {
    const lu = JSON.parse(fs.readFileSync(FICHIER_INSTALLATION, 'utf8'));
    if (lu && typeof lu === 'object') suiviInstallation = { ...suiviInstallation, ...lu };
  } catch (e) { /* première installation */ }
  etatRegie.obsState.telephone = {
    vuA: Number(suiviInstallation.telephoneVuA) || 0,
    certificatOkA: Number(suiviInstallation.certificatOkA) || 0,
    appliHttpsA: Number(suiviInstallation.appliHttpsA) || 0,
  };
  etatRegie.obsState.configurationTerminee = configurationDejaFaite();
  arret.avantArret('suivi de l’installation', ecrireSuiviEnAttente);
}
