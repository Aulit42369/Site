// ============================================================
//  La clé PUBLIQUE des mises à jour (Ed25519)
// ------------------------------------------------------------
//  Source unique : la régie n'installe une mise à jour que si
//  version.json est signé par la clé privée qui va avec (gardée
//  par Olivier, dossier cle-mise-a-jour/, jamais dans un zip).
//  Écrite par outils/generer-cle-mise-a-jour.js : ne pas la
//  modifier à la main. Vide : aucune mise à jour acceptée.
// ============================================================

module.exports = {
  CLE_PUBLIQUE_MAJ: 'MCowBQYDK2VwAyEAX0SZcJo+Nub+Gak1pJx9pImYX98Wmh7Q6G3Nrgxrzc4=',
};
