// ============================================================
//  Bluesky
// ------------------------------------------------------------
//  Mot de passe d’application, posts, statut « en direct ».
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  blueskyLogin,
  normaliserIdentifiantBluesky,
  postToBluesky,
  setBlueskyLiveStatus,
};

const parametres = require('./parametres.js');
const stockage = require('./stockage.js');

// Authentification par « mot de passe d'application » (pas d'OAuth), image
// envoyée directement en blob (pas besoin d'adresse publique, contrairement
// à Instagram), post et statut « en direct » avec sa durée.

// Ce qu'on tape n'est pas toujours ce que Bluesky attend : « @lea.bsky.social »
// copié depuis le profil, « lea » tout court, une espace en trop. Un e-mail
// sert aussi d'identifiant : on n'y touche pas.
function normaliserIdentifiantBluesky(saisie) {
  let id = String(saisie || '').replace(/\s+/g, '');
  if (id.startsWith('@')) id = id.slice(1);
  if (!id || id.includes('@') || /^did:/i.test(id)) return id;
  id = id.toLowerCase();
  return id.includes('.') ? id : id + '.bsky.social';
}

async function blueskyLogin() {
  const bs = stockage.platformTokens.bluesky;
  if (!bs || !bs.handle || !bs.appPassword) throw new Error('Bluesky non connecté.');
  let res;
  try {
    res = await fetch(`${parametres.BLUESKY_SERVICE}/xrpc/com.atproto.server.createSession`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ identifier: bs.handle, password: bs.appPassword }),
    });
  } catch (e) {
    throw new Error('Bluesky ne répond pas : vérifie la connexion internet du PC.');
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    // Les messages de Bluesky sont en anglais et parlent à un développeur.
    if (data.error === 'AuthFactorTokenRequired') {
      throw new Error('Ce compte demande un code reçu par e-mail avec le mot de passe principal. '
        + 'Utilise un mot de passe d’application : il n’en a pas besoin.');
    }
    if (res.status === 401) {
      throw new Error('Bluesky refuse ce pseudo ou ce mot de passe d’application. Vérifie le pseudo '
        + '(par exemple lea.bsky.social) et recopie le mot de passe d’application.');
    }
    if (res.status === 429) throw new Error('Trop d’essais d’affilée : Bluesky bloque un moment. Réessaie dans quelques minutes.');
    throw new Error(data.message || 'Identifiants Bluesky refusés.');
  }
  // « handle.invalid » : Bluesky n'a pas pu vérifier le pseudo (domaine
  // personnalisé mal configuré). Il ne fait ni un affichage ni un lien.
  return { accessJwt: data.accessJwt, did: data.did, handle: data.handle && data.handle !== 'handle.invalid' ? data.handle : '' };
}

async function blueskyUploadImageBlob(session, buffer) {
  const res = await fetch(`${parametres.BLUESKY_SERVICE}/xrpc/com.atproto.repo.uploadBlob`, {
    method: 'POST',
    headers: { 'Content-Type': 'image/jpeg', Authorization: `Bearer ${session.accessJwt}` },
    body: buffer,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || "Échec de l'envoi de l'image à Bluesky.");
  return data.blob;
}

async function postToBluesky({ text, imageBuffer, imageAlt }) {
  const session = await blueskyLogin();
  const record = { $type: 'app.bsky.feed.post', text: text || '', createdAt: new Date().toISOString() };
  if (imageBuffer) {
    const blob = await blueskyUploadImageBlob(session, imageBuffer);
    record.embed = { $type: 'app.bsky.embed.images', images: [{ image: blob, alt: imageAlt || '' }] };
  }
  const res = await fetch(`${parametres.BLUESKY_SERVICE}/xrpc/com.atproto.repo.createRecord`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${session.accessJwt}` },
    body: JSON.stringify({ repo: session.did, collection: 'app.bsky.feed.post', record }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || 'Bluesky a refusé la publication.');
  // data.uri est au format at://did:plc:xxx/app.bsky.feed.post/RKEY —
  // le dernier segment (rkey) suffit à reconstruire un lien bsky.app cliquable.
  // Le pseudo renvoyé par Bluesky, pas l'identifiant tapé : ce dernier
  // peut être un e-mail, qui ne fait pas une adresse de profil.
  const rkey = String(data.uri || '').split('/').pop();
  const profil = session.handle || session.did || stockage.platformTokens.bluesky.handle;
  const url = rkey ? `https://bsky.app/profile/${profil}/post/${rkey}` : '';
  return { ...data, url };
}

async function setBlueskyLiveStatus({ durationMinutes, twitchUrl, title }) {
  const session = await blueskyLogin();
  const record = {
    $type: 'app.bsky.actor.status',
    status: 'app.bsky.actor.status#live',
    embed: { $type: 'app.bsky.embed.external', external: { uri: twitchUrl, title: title || 'En direct sur Twitch', description: '' } },
    durationMinutes: Number(durationMinutes) || 120,
    createdAt: new Date().toISOString(),
  };
  // app.bsky.actor.status est un enregistrement "singleton" (un seul statut
  // actif possible par compte) : Bluesky exige la clé fixe "self", et
  // putRecord (plutôt que createRecord) pour remplacer le précédent statut
  // à chaque nouveau live plutôt que d'échouer s'il en existe déjà un.
  const res = await fetch(`${parametres.BLUESKY_SERVICE}/xrpc/com.atproto.repo.putRecord`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${session.accessJwt}` },
    body: JSON.stringify({ repo: session.did, collection: 'app.bsky.actor.status', rkey: 'self', record }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || 'Bluesky a refusé le statut live.');
  return data;
}
