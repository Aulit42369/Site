// ============================================================
//  Réglages avancés : le fichier .env (facultatif)
// ------------------------------------------------------------
//  Une ligne par réglage, « NOM=valeur ». Le modèle commenté est
//  .env.example : le copier en .env, à côté de server.js, et
//  enlever le # devant ce qu'on veut changer.
//
//  Une variable déjà définie (par le lanceur, par un script de
//  contrôle) garde sa valeur : .env ne fait que compléter. Le
//  lanceur (Regie mobile.exe) lit le PORT du même fichier, pour
//  que les deux s'accordent sans rien se dire.
//
//  Jamais bloquant : un .env absent ou illisible est ignoré.
// ============================================================
'use strict';
const fs = require('fs');

// Le texte d'un .env → { NOM: 'valeur' }. Accepte « export NOM=... »,
// des guillemets autour de la valeur (le texte entre eux est pris tel quel,
// même suivi d'un commentaire), un commentaire en fin de ligne (précédé d'un
// espace). Si un nom revient, la dernière ligne l'emporte. Le lanceur lit le
// PORT avec ces mêmes règles (lanceur/outils.c, lirePort).
function lireEnv(texte) {
  const valeurs = {};
  for (const brute of String(texte || '').replace(/^﻿/, '').split(/\r?\n/)) {
    const ligne = brute.trim();
    if (!ligne || ligne.startsWith('#')) continue;
    const m = /^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/.exec(ligne);
    if (!m) continue;
    let valeur = m[2].trim();
    const entreGuillemets = /^(["'])(.*?)\1(?:\s+#.*)?$/.exec(valeur);
    if (entreGuillemets) valeur = entreGuillemets[2];
    else valeur = valeur.replace(/\s+#.*$/, '');
    valeurs[m[1]] = valeur;
  }
  return valeurs;
}

// Le port écrit dans PORT → un numéro, ou 0 s'il n'en est pas un : des
// chiffres seulement (5 au plus, espaces autour permis), entre 1 et 65534
// (le https prend le suivant). Exactement la règle du lanceur
// (lanceur/outils.c, lirePort) : sur une valeur bancale, les deux renoncent
// ensemble et prennent 4560.
function portDe(texte) {
  const brut = String(texte === undefined || texte === null ? '' : texte).trim();
  if (!/^\d{1,5}$/.test(brut)) return 0;
  const p = Number(brut);
  return p > 0 && p < 65535 ? p : 0;
}

// Complète « env » (process.env par défaut) avec le fichier « chemin ».
// Rend les NOMS appliqués (jamais les valeurs : elles n'ont rien à faire
// dans un journal).
function chargerEnv(chemin, env = process.env) {
  let texte;
  try { texte = fs.readFileSync(chemin, 'utf8'); } catch (e) { return { lu: false, appliques: [] }; }
  const appliques = [];
  for (const [nom, valeur] of Object.entries(lireEnv(texte))) {
    if (env[nom] === undefined) {
      env[nom] = valeur;
      appliques.push(nom);
    }
  }
  return { lu: true, appliques };
}

module.exports = { lireEnv, chargerEnv, portDe };
