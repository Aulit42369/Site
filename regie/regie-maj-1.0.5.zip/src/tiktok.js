// ============================================================
//  TikTok
// ------------------------------------------------------------
//  Autorisation (PKCE), envoi vers les brouillons.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  tiktokAuthUrl,
  get TT_REDIRECT_URI() { return TT_REDIRECT_URI; },
  uploadToTiktok,
};

const { randomBytes, createHash } = require('crypto');

const parametres = require('./parametres.js');
const stockage = require('./stockage.js');
const oauth = require('./oauth.js');

// ------------------------------------------------------------
// TikTok — Content Posting API (envoi vers les brouillons)
// Sans audit TikTok (non applicable à un outil perso), le contenu
// envoyé atterrit dans les brouillons du compte, pas publié
// automatiquement — un dernier tap dans l'appli TikTok reste requis.
// Connexion sur ce PC via /setup, comme YouTube/Instagram. Contrairement
// à Instagram, TikTok refuse "localhost" pour une appli "Web" — il faut
// déclarer l'appli en "Desktop" chez eux, qui exige au contraire du
// loopback en clair (http, pas https) et une sécurité PKCE additionnelle.
// ------------------------------------------------------------
const TT_REDIRECT_URI = `http://127.0.0.1:${parametres.PORT}/oauth/tiktok/callback`;

function base64UrlEncode(buf) {
  return buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function tiktokAuthUrl() {
  const tt = stockage.platformTokens.tiktok || {};
  const verifier = base64UrlEncode(randomBytes(32));
  const challenge = base64UrlEncode(createHash('sha256').update(verifier).digest());
  const params = new URLSearchParams({
    client_key: tt.clientKey || '',
    redirect_uri: TT_REDIRECT_URI,
    response_type: 'code',
    scope: 'video.upload',
    // Le code_verifier reste dans le pont ; seul un jeton opaque part.
    state: oauth.creerEtatOauth('tiktok', { verifier }),
    code_challenge: challenge,
    code_challenge_method: 'S256',
  });
  return `https://www.tiktok.com/v2/auth/authorize/?${params.toString()}`;
}

async function ensureTiktokToken() {
  const tt = stockage.platformTokens.tiktok;
  if (!tt || !tt.refreshToken) throw new Error(`TikTok non connecté — ouvre http://127.0.0.1:${parametres.PORT}/setup sur ce PC.`);
  if (tt.accessToken && tt.expiresAt && Date.now() < tt.expiresAt - 60000) return tt.accessToken;
  const res = await fetch('https://open.tiktokapis.com/v2/oauth/token/', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ client_key: tt.clientKey, client_secret: tt.clientSecret, grant_type: 'refresh_token', refresh_token: tt.refreshToken }),
  });
  const data = await res.json();
  if (!res.ok || !data.access_token) throw new Error('Impossible de rafraîchir le jeton TikTok — reconnecte-le sur /setup.');
  tt.accessToken = data.access_token;
  tt.refreshToken = data.refresh_token || tt.refreshToken;
  tt.expiresAt = Date.now() + (data.expires_in || 86400) * 1000;
  stockage.saveTokens();
  return tt.accessToken;
}

async function uploadToTiktok(videoBuffer, title) {
  const accessToken = await ensureTiktokToken();
  const size = videoBuffer.length;

  const initRes = await fetch('https://open.tiktokapis.com/v2/post/publish/inbox/video/init/', {
    method: 'POST',
    headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ source_info: { source: 'FILE_UPLOAD', video_size: size, chunk_size: size, total_chunk_count: 1 } }),
  });
  const initData = await initRes.json();
  if (!initRes.ok || !initData.data || !initData.data.publish_id) {
    throw new Error('TikTok a refusé l’envoi : ' + (initData.error ? initData.error.message : initRes.status));
  }
  const { publish_id, upload_url } = initData.data;

  const putRes = await fetch(upload_url, {
    method: 'PUT',
    headers: { 'Content-Type': 'video/mp4', 'Content-Range': `bytes 0-${size - 1}/${size}` },
    body: videoBuffer,
  });
  if (!putRes.ok) throw new Error(`Échec de l'envoi de la vidéo à TikTok (${putRes.status}).`);

  let status = 'PROCESSING_UPLOAD';
  for (let i = 0; i < 20 && (status === 'PROCESSING_UPLOAD' || status === 'PROCESSING_DOWNLOAD'); i++) {
    await new Promise((r) => setTimeout(r, 2000));
    const statusRes = await fetch('https://open.tiktokapis.com/v2/post/publish/status/fetch/', {
      method: 'POST',
      headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ publish_id }),
    });
    const statusData = await statusRes.json().catch(() => ({}));
    status = (statusData.data && statusData.data.status) || status;
    if (status === 'FAILED') throw new Error('TikTok a signalé un échec de traitement.');
  }
  return '';
}
