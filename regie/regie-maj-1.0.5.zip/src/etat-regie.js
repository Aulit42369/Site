// ============================================================
//  L’état de la régie, partagé par tous les écrans
// ------------------------------------------------------------
//  obsState fait foi : l’appli, les pages et les overlays le reçoivent
//  en direct (flux SSE), complet ou par fragments.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  brancherFluxSse,
  broadcastPatch,
  broadcastState,
  etatPublic,
  fermerFluxAppareils,
  get obsState() { return obsState; },
  setState,
  setStatePartiel,
  get sseClients() { return sseClients; },
};

const parametres = require('./parametres.js');
const twitchEcoute = require('./twitch-ecoute.js');
const securite = require('./securite.js');
const pseudos = require('./pseudos.js');

// Empreinte de l'appli servie (public/app.js), lue au démarrage du pont. Après
// une mise à jour, le pont redémarre seul mais la fenêtre restée ouverte garde
// l'ancien code : en voyant une autre empreinte, l'appli se recharge.
function empreinteAppli() {
  try {
    return require('crypto').createHash('sha256').update(require('fs').readFileSync(require('path').join(parametres.PUBLIC_DIR, 'app.js'))).digest('hex').slice(0, 16);
  } catch (e) {
    return '';
  }
}

let obsState = {
  versionAppli: empreinteAppli(),
  status: 'disconnected', // disconnected | connecting | connected | error
  error: '',
  currentScene: '',
  scenes: [],
  sceneItems: [],
  audioInputs: [],
  // Collections de scènes d'OBS : l'active, la liste, et le chargement en
  // cours (« collectionCible » : celle qu'on attend, si on la connaît).
  collection: '',
  collections: [],
  collectionChargement: false,
  collectionCible: '',
  // Volontairement VIDES : ce sont des actions déclenchées automatiquement à
  // la fin d'une pause (changer de scène, rallumer un micro). Des valeurs
  // par défaut inventées feraient basculer la scène et ouvrir un micro au
  // mauvais moment chez quelqu'un qui n'a jamais touché ce réglage.
  // « finParOverlay » : un décompte lancé par un overlay joue lui aussi la
  // fin de pause (réglage de la carte Minuteur, éteint au départ).
  // « finIgnoree » : le dernier décompte, lancé par un overlay, est arrivé à
  // zéro sans la jouer (voir minuterie.onTimerFinished).
  timer: { running: false, endAt: null, remaining: 0, actionsFin: [], affichage: '', termine: false, finParOverlay: false, finIgnoree: false },
  streaming: false,
  recording: false,
  publishedClips: {},
  twitchCreds: { clientId: '', token: '' },
  // Écoute Twitch (EventSub) tenue par le pont et non plus par le téléphone :
  // le PC reste allumé pendant le stream, donc aucun événement n'est perdu
  // quand le téléphone se met en veille ou que l'appli passe en arrière-plan.
  twitchListen: { status: 'disconnected', error: '', warning: '', profile: null },
  hypeTrain: { active: false, level: 0, progress: 0, goal: 1, total: 0 },
  blueskyConnected: false,
  blueskyHandle: '',
  imgbbConfigured: false,
  discordConfigured: false,
  sessionHistory: [],
  preparedStreamInfo: { title: '', categoryId: '', categoryName: '', tags: [] },
  // Les infos de la chaîne telles qu'elles étaient AVANT le dernier
  // remplacement fait depuis la régie (titre, catégorie) : de quoi les
  // rétablir d'un appui. Twitch ne garde aucun historique des titres.
  infosStreamPrecedentes: null,
  // ---- Installation guidée ----
  // Connexion Twitch par code : le code à taper et où en est l'attente.
  // « disponible » : le kit fournit un Client ID, la méthode est possible.
  twitchCode: { disponible: false, etape: 'inactif', code: '', lien: '', expireA: 0, erreur: '' },
  // Ce que le pont a trouvé dans les fichiers d'OBS (jamais le mot de passe).
  obsDetection: { etat: 'inconnu', source: '', port: 0 },
  // Les preuves que le téléphone est passé : il a joint la régie, son
  // certificat est reconnu, l'appli a tourné en https.
  telephone: { vuA: 0, certificatOkA: 0, appliHttpsA: 0 },
  configurationTerminee: false,
  youtubeConfigure: false,
  lanceur: { exe: parametres.LANCE_PAR_EXE, windows: process.platform === 'win32' },
  pseudoKit: '',
  // Régie reçue dans un kit (kit.json marqué par fabriquerKit) : Instagram
  // n'y sert qu'à fabriquer l'image, la personne la publie elle-même.
  dansUnKit: false,
  // Carte « Raid · La Cabane » proposée (false seulement dans un kit qui l'a
  // retirée, voir kit.raidCabaneActif).
  raidCabaneActif: true,
  // Le fond de l'image d'annonce : le choix retenu (« default » ou
  // « custom »), et ce qu'il y a sur le disque (voir imageAnnonce.etatFond).
  fondAnnonce: { choix: 'default', hasCustom: false, precedent: false, version: 0 },
  // Les deux couleurs de l'image d'annonce choisies par le streamer (gardées
  // dans tokens.json, voir reglages-regie.nettoyerCouleursAnnonce).
  couleursAnnonce: { accent: '#00f5ff', accent2: '#9b5cff' },
  // Le pseudo de la chaîne, affiché partout (voir pseudoChaine), et d'où il
  // vient : 'appli', 'kit', 'config', 'twitch' ou vide.
  pseudo: '',
  pseudoSource: '',
  // Change à chaque liaison ou retrait d'un appareil (voir appareils.js) :
  // les écrans qui affichent la liste ou un code de liaison se mettent à jour.
  appareilsMaj: 0,
};

const sseClients = new Set();

// Un téléphone qui quitte le wifi ou part en veille profonde ne ferme pas
// proprement sa connexion : sans signal de vie régulier, le pont garde la
// référence et continue d'écrire dans le vide, indéfiniment.
function brancherFluxSse(req, res, clients) {
  // Retenu une fois pour toutes à l'ouverture : le flux reste ensuite ouvert
  // des heures, on ne peut plus interroger la requête à chaque message.
  res.autreOrigine = securite.estAutreOrigine(req);
  // L'appareil relié qui a ouvert le flux : s'il est retiré, son flux est
  // coupé aussitôt (voir fermerFluxAppareils) au lieu de rester ouvert des heures.
  res.appareilId = (req.acces && req.acces.appareil && req.acces.appareil.id) || '';
  const entetes = {
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache',
    Connection: 'keep-alive',
  };
  // Sans cet en-tête, un overlay servi depuis un fichier local ne peut pas
  // ouvrir le flux : EventSource échoue silencieusement et la page reste
  // figée sur sa valeur de départ.
  const origine = securite.originAutorisee(req);
  if (origine) { entetes['Access-Control-Allow-Origin'] = origine; entetes.Vary = 'Origin'; }
  res.writeHead(200, entetes);
  res.write(': ok\n\n');
  try { res.socket.setKeepAlive(true, 30000); } catch (e) {}
  clients.add(res);
  const battement = setInterval(() => {
    try { res.write(': ping\n\n'); } catch (e) { clients.delete(res); clearInterval(battement); }
  }, 20000);
  const fermer = () => { clients.delete(res); clearInterval(battement); };
  req.on('close', fermer);
  res.on('error', fermer);
}

// Coupe les flux ouverts par des appareils qui viennent d'être retirés (tous
// les appareils reliés si « ids » est null). Le PC et les overlays gardent les
// leurs. L'appli du téléphone voit son flux tomber, tente de le rouvrir, se
// le voit refuser, et passe d'elle-même sur la page de liaison.
function fermerFluxAppareils(ids) {
  for (const clients of [sseClients, twitchEcoute.twitchStreamClients]) {
    for (const res of [...clients]) {
      if (!res.appareilId || (ids && !ids.has(res.appareilId))) continue;
      clients.delete(res);
      try { res.destroy(); } catch (e) {}
    }
  }
}

// Les accès Twitch tels qu'un écran les voit : JAMAIS le jeton lui-même. Il
// ne quitte pas le PC — le pont s'en sert pour écouter Twitch et pour
// relayer les commandes (/api/twitch/helix). L'appli apprend seulement le
// Client ID (pas un secret), qu'un jeton est enregistré (pour proposer
// « Relancer la connexion ») et la méthode ; une page d'une autre origine —
// un overlay — n'apprend rien du tout. Avant, l'appli recevait le jeton en
// clair : chaque téléphone relié en détenait une copie.
function credsPublics(creds, autreOrigine) {
  if (autreOrigine) return { clientId: '', token: '' };
  const c = creds || {};
  const publics = { clientId: c.clientId || '', token: '', jeton: !!c.token };
  if (c.mode) publics.mode = c.mode;
  return publics;
}

// L'état (ou un fragment d'état) tel qu'on peut l'envoyer à un écran. Tout ce
// qui part du pont vers un écran passe par ici : broadcastState,
// broadcastPatch et securite.etatPourRequete (/api/obs/status, premier
// message du flux).
//
// Une autre origine (overlay, ou page piégée qui se fait passer pour un
// fichier local) ne reçoit pas non plus le code de connexion Twitch en
// attente : elle pourrait le valider la première, avec SON compte, et la
// régie se brancherait sur sa chaîne.
function etatPublic(etat, autreOrigine) {
  if (!etat) return etat;
  let sortie = etat;
  if ('twitchCreds' in etat) sortie = { ...sortie, twitchCreds: credsPublics(etat.twitchCreds, autreOrigine) };
  if (autreOrigine && 'twitchCode' in etat) {
    sortie = { ...sortie };
    delete sortie.twitchCode;
  }
  return sortie;
}

function broadcastState() {
  // Le pseudo dépend de plusieurs sources (réglage, kit, compte Twitch) :
  // recalculé à chaque envoi, il ne peut pas être en retard sur l'une d'elles.
  pseudos.rafraichirPseudo();
  // Deux versions : l'appli (servie par le pont) et une page d'une autre
  // origine — un overlay, typiquement —, chacune sans les accès (etatPublic).
  const complet = 'data: ' + JSON.stringify(etatPublic(obsState, false)) + '\n\n';
  let allege = null;
  for (const res of sseClients) {
    let charge = complet;
    if (res.autreOrigine) {
      if (allege === null) allege = 'data: ' + JSON.stringify(etatPublic(obsState, true)) + '\n\n';
      charge = allege;
    }
    try { res.write(charge); } catch (e) { sseClients.delete(res); }
  }
}
function setState(patch) {
  obsState = { ...obsState, ...patch };
  broadcastState();
}

// Diffusion partielle : seuls les champs fournis sont transmis, l'appli ne
// met à jour qu'eux. Réservé aux changements très fréquents.
//
// Le filtre des accès est le même que dans broadcastState : sans lui, il
// suffirait qu'un jour un champ sensible passe par ici pour que le jeton
// Twitch parte vers un écran. La garde vit donc dans la fonction, pas
// dans la tête de celui qui l'appelle.
function broadcastPatch(patch) {
  const complet = 'data: ' + JSON.stringify({ __patch: etatPublic(patch, false) }) + '\n\n';
  let allege = null;
  for (const res of sseClients) {
    let charge = complet;
    if (res.autreOrigine && ('twitchCreds' in patch || 'twitchCode' in patch)) {
      if (allege === null) allege = 'data: ' + JSON.stringify({ __patch: etatPublic(patch, true) }) + '\n\n';
      charge = allege;
    }
    try { res.write(charge); } catch (e) { sseClients.delete(res); }
  }
}

// Met l'état à jour pour les nouveaux arrivants, mais ne diffuse QUE le
// champ qui bouge. Pour ce qui change plusieurs fois par seconde : un
// curseur de volume qu'on fait glisser produit une rafale d'événements
// OBS, et rediffuser à chaque fois l'état complet (scènes, sources, clips
// publiés, historique des sessions, modèles d'annonce...) envoyait des
// dizaines de kilo-octets par seconde à chaque client — overlay compris —
// et forçait un rendu intégral de l'appli.
function setStatePartiel(patch) {
  obsState = { ...obsState, ...patch };
  broadcastPatch(patch);
}
