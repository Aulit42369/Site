// ============================================================
//  Écoute Twitch (EventSub), tenue par le pont
// ------------------------------------------------------------
//  Réception des événements, doublons écartés, reconnexion.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  demarrer,
  connectTwitchListen,
  disconnectTwitchListen,
  setTwitchListen,
  get twitchEvents() { return twitchEvents; },
  set twitchEvents(valeur) { twitchEvents = valeur; },
  get twitchStreamClients() { return twitchStreamClients; },
};

const parametres = require('./parametres.js');
const etatRegie = require('./etat-regie.js');
const twitchJeton = require('./twitch-jeton.js');
const journalEvenements = require('./journal-evenements.js');
const notifications = require('./notifications.js');
const twitchDirect = require('./twitch-direct.js');

// ------------------------------------------------------------
// Écoute Twitch (EventSub) tenue par le pont.
//
// Auparavant, c'était le téléphone qui maintenait cette connexion : dès
// qu'Android coupait le réseau en arrière-plan, les événements survenus
// pendant la coupure étaient définitivement perdus. Ici le PC écoute en
// continu et conserve tout, le téléphone ne fait plus qu'afficher.
// ------------------------------------------------------------
const TWITCH_EVENTS_MAX = 500;
let twitchEvents = [];          // tampon des événements reçus, du plus récent au plus ancien
let twitchWs = null;
let twitchReconnectTimer = null;
let twitchRetry = 0;
let twitchManualStop = false;
const twitchStreamClients = new Set(); // abonnés SSE aux nouveaux événements

function twitchEventToLocal(type, e) {
  const base = { id: Date.now() + '-' + Math.random().toString(36).slice(2, 8), timestamp: Date.now(), source: 'live' };
  if (type === 'channel.follow') return { ...base, type: 'follow', user: e.user_name, detail: 'Nouveau follower', amount: null };
  if (type === 'channel.subscribe') return { ...base, type: 'sub', user: e.user_name, detail: (e.is_gift ? 'Abo offert reçu · Tier ' : 'Nouvel abo · Tier ') + (Number(e.tier) / 1000), amount: Number(e.tier) / 1000 };
  if (type === 'channel.subscription.gift') return { ...base, type: 'gift', user: e.is_anonymous ? 'Anonyme' : e.user_name, detail: `${e.total} abo(s) offert(s) · Tier ${Number(e.tier) / 1000}`, amount: e.total };
  if (type === 'channel.subscription.message') return { ...base, type: 'resub', user: e.user_name, detail: `${e.cumulative_months} mois${e.message && e.message.text ? ' · ' + e.message.text : ''}`, amount: e.cumulative_months };
  if (type === 'channel.cheer') return { ...base, type: 'cheer', user: e.is_anonymous ? 'Anonyme' : (e.user_name || 'Anonyme'), detail: e.message || 'A envoyé des bits', amount: e.bits };
  // « login » : le nom technique (minuscules, sans accent), celui qu'attend
  // une commande « !so @login » ; « user » est le nom affiché, qui peut
  // contenir des caractères qu'aucun bot ne retrouverait.
  if (type === 'channel.raid') return { ...base, type: 'raid', user: e.from_broadcaster_user_name, login: e.from_broadcaster_user_login || '', userId: e.from_broadcaster_user_id, detail: 'Raid entrant', amount: e.viewers };
  if (type === 'channel.chat.message') return { ...base, type: 'chat', user: e.chatter_user_name, userId: e.chatter_user_id, detail: (e.message && e.message.text) || '', amount: null };
  return null;
}

// En direct : OBS diffuse (« Lancer le streaming »), ou le suivi du stream
// (OBS ou Twitch) a une session ouverte — un pont relancé en plein direct,
// OBS pas encore relié, n'oublie donc rien. Lu à l'appel : bilan-stream.js
// charge ce fichier, le charger ici en tête ferait une boucle.
function enDirect() {
  if (etatRegie.obsState.streaming) return true;
  const session = require('./bilan-stream.js').suiviStream.etat();
  return !!(session && session.enCours);
}

function pushTwitchEvent(ev) {
  twitchEvents.unshift(ev);
  if (twitchEvents.length > TWITCH_EVENTS_MAX) twitchEvents.length = TWITCH_EVENTS_MAX;
  // Copie sur disque : le tampon ci-dessus est plafonné et disparaît au
  // redémarrage, le journal garde tout (un fichier par jour dans data/,
  // voir journal-evenements.js). Seulement pendant un direct (demande
  // d'Olivier, 26/10) : un follow un mardi sans stream remplissait le journal
  // de jours où il n'a pas joué. Le fil en direct et les notifications, eux,
  // continuent de tout montrer.
  if (enDirect()) journalEvenements.ecrireJournal(ev);
  notifications.notifierEvenement(ev);
  const payload = 'data: ' + JSON.stringify(ev) + '\n\n';
  for (const res of twitchStreamClients) {
    try { res.write(payload); } catch (e) { twitchStreamClients.delete(res); }
  }
}

function setTwitchListen(patch) {
  etatRegie.obsState.twitchListen = { ...etatRegie.obsState.twitchListen, ...patch };
  etatRegie.broadcastState();
}

// ------------------------------------------------------------
// Un événement Twitch ne compte qu'une fois
// ------------------------------------------------------------
// Un raid, un don, un follow : une ligne au journal, un message Discord,
// une notification. Jamais deux. Deux façons de recevoir la même chose :
//  • Twitch renvoie une notification déjà livrée (même message_id) ;
//  • deux abonnements actifs reçoivent le même événement — une ancienne
//    connexion restée ouverte, ou deux fois le même abonnement : même
//    contenu, mais abonnement différent.
// Deux événements légitimement identiques (deux dons de 100 bits avec le
// même message, coup sur coup) arrivent, eux, par le MÊME abonnement : ils
// sont gardés tous les deux.
const DOUBLONS_FENETRE_MS = 10000;
const messagesTwitchVus = new Map();   // message_id -> instant de réception
const evenementsTwitchVus = new Map(); // empreinte -> { t, abonnement, session }
let dernierAvisDoublon = 0;

function verdictDoublonTwitch(msg) {
  const maintenant = Date.now();
  for (const [k, t] of messagesTwitchVus) if (maintenant - t > 5 * 60 * 1000) messagesTwitchVus.delete(k);
  for (const [k, v] of evenementsTwitchVus) if (maintenant - v.t > DOUBLONS_FENETRE_MS) evenementsTwitchVus.delete(k);
  const id = msg.metadata && msg.metadata.message_id;
  if (id) {
    if (messagesTwitchVus.has(id)) return { doublon: true, raison: 'renvoi' };
    messagesTwitchVus.set(id, maintenant);
  }
  const sub = (msg.payload && msg.payload.subscription) || {};
  const empreinte = (sub.type || '') + '|' + JSON.stringify((msg.payload && msg.payload.event) || null);
  const abonnement = String(sub.id || '');
  const session = String((sub.transport && sub.transport.session_id) || '');
  const deja = evenementsTwitchVus.get(empreinte);
  if (deja && deja.abonnement !== abonnement) {
    return { doublon: true, raison: 'abonnement', premier: deja, second: { abonnement, session } };
  }
  evenementsTwitchVus.set(empreinte, { t: maintenant, abonnement, session });
  return { doublon: false };
}

// Le doublon est ignoré ; on le dit dans le journal technique (une fois par
// quart d'heure, pas à chaque événement), avec de quoi savoir d'où il venait.
// Et si l'abonnement fautif n'est pas celui de la connexion en cours, on le
// supprime chez Twitch : c'est lui qui envoyait chaque événement une
// seconde fois.
const abonnementsTwitchSupprimes = new Set();
function traiterDoublonTwitch(verdict) {
  const court = (x) => (x ? String(x).slice(0, 8) + '…' : '?');
  if (Date.now() - dernierAvisDoublon > 15 * 60 * 1000) {
    dernierAvisDoublon = Date.now();
    console.log(verdict.raison === 'renvoi'
      ? '[Twitch] Notification renvoyée par Twitch : le doublon est ignoré.'
      : '[Twitch] Événement reçu deux fois (abonnement ' + court(verdict.premier.abonnement) + ' sur la session ' + court(verdict.premier.session)
        + ', puis ' + court(verdict.second.abonnement) + ' sur la session ' + court(verdict.second.session) + ') : le doublon est ignoré.');
  }
  if (verdict.raison !== 'abonnement') return;
  const actuelle = twitchWs && twitchWs.sessionTwitch;
  let fautif = '';
  if (verdict.second.session && verdict.second.session !== actuelle) fautif = verdict.second.abonnement;
  else if (verdict.premier.session && verdict.premier.session !== actuelle) fautif = verdict.premier.abonnement;
  else {
    // Les deux sur la session en cours : on garde celui qu'elle a créé.
    const miens = (twitchWs && twitchWs.abonnementsTwitch && twitchWs.abonnementsTwitch.ids) || [];
    fautif = miens.includes(verdict.second.abonnement) && !miens.includes(verdict.premier.abonnement)
      ? verdict.premier.abonnement : verdict.second.abonnement;
  }
  if (!fautif || abonnementsTwitchSupprimes.has(fautif)) return;
  abonnementsTwitchSupprimes.add(fautif);
  const creds = etatRegie.obsState.twitchCreds || {};
  fetch(parametres.TWITCH_API + '/helix/eventsub/subscriptions?id=' + encodeURIComponent(fautif), {
    method: 'DELETE',
    headers: { Authorization: 'Bearer ' + String(creds.token || '').replace(/^oauth:/i, ''), 'Client-Id': String(creds.clientId || '') },
  }).then((r) => {
    console.log(r.ok
      ? '[Twitch] Abonnement en double supprimé chez Twitch (' + court(fautif) + ').'
      : '[Twitch] Abonnement en double non supprimé (' + court(fautif) + ', Twitch répond ' + r.status + ') : les doublons restent ignorés.');
  }).catch(() => {});
}

// Fin d'une connexion qu'on remplace : plus aucun message traité, plus de
// surveillance, fermeture, et suppression chez Twitch des abonnements
// qu'elle avait créés. Fermer ne suffit pas toujours : si Twitch ne répond
// pas à la fermeture, la connexion reste ouverte de son côté, avec ses
// abonnements, et continue de recevoir chaque événement.
function oublierConnexionTwitch(ws) {
  if (!ws) return;
  ws.muet = true;
  if (ws.arreterGarde) ws.arreterGarde();
  try { ws.close(); } catch (e) {}
  const a = ws.abonnementsTwitch;
  ws.abonnementsTwitch = null;
  if (!a || !a.ids.length) return;
  // Le jeton de création a pu être renouvelé depuis (connexion par code) :
  // même application, on prend celui du moment.
  const creds = etatRegie.obsState.twitchCreds || {};
  const jeton = creds.clientId === a.clientId ? String(creds.token || '').replace(/^oauth:/i, '') : a.jeton;
  for (const id of a.ids) {
    fetch(parametres.TWITCH_API + '/helix/eventsub/subscriptions?id=' + encodeURIComponent(id), {
      method: 'DELETE',
      headers: { Authorization: 'Bearer ' + jeton, 'Client-Id': a.clientId },
    }).catch(() => {});
  }
}

function scheduleTwitchReconnect() {
  if (twitchReconnectTimer || twitchManualStop) return;
  const delay = Math.min(30000, 2000 * Math.pow(2, Math.min(twitchRetry, 4)));
  twitchRetry += 1;
  twitchReconnectTimer = setTimeout(() => {
    twitchReconnectTimer = null;
    openTwitchSocket(parametres.TWITCH_WS_URL);
  }, delay);
}

// isReconnect : bascule demandée par Twitch. Le protocole EventSub transfère
// les souscriptions à la nouvelle session, donc les recréer provoquerait un
// refus et un faux avertissement « Non activés : ... » alors que tout marche.
function openTwitchSocket(url, isReconnect) {
  const creds = etatRegie.obsState.twitchCreds || {};
  const clientId = (creds.clientId || '').trim();
  const token = (creds.token || '').trim().replace(/^oauth:/i, '');
  if (!clientId || !token) {
    setTwitchListen({ status: 'disconnected', error: 'Identifiants Twitch absents.' });
    return null;
  }

  let ws;
  try {
    ws = new WebSocket(url);
  } catch (e) {
    setTwitchListen({ status: 'error', error: e.message });
    scheduleTwitchReconnect();
    return null;
  }
  // Une connexion encore vivante qu'on remplace sans bascule demandée par
  // Twitch : on l'oublie proprement, sinon elle continue de recevoir chaque
  // événement en parallèle de la nouvelle.
  if (!isReconnect && twitchWs && twitchWs !== ws && !twitchWs.muet) oublierConnexionTwitch(twitchWs);
  twitchWs = ws;

  let keepaliveSeconds = 10;
  // Un chien de garde par socket, et non un seul partagé : pendant une
  // bascule demandée par Twitch les deux sockets coexistent quelques
  // secondes, et l'ancien annulait la surveillance du nouveau en partant.
  let gardeDeCeSocket = null;
  function armWatchdog() {
    clearTimeout(gardeDeCeSocket);
    gardeDeCeSocket = setTimeout(() => { try { ws.close(); } catch (e) {} }, (keepaliveSeconds + 8) * 1000);
  }
  ws.arreterGarde = () => clearTimeout(gardeDeCeSocket);

  // Sans ça, un socket qui s'ouvre mais ne dit jamais rien n'est surveillé
  // par personne : l'appli resterait sur « connexion en cours » indéfiniment.
  ws.addEventListener('open', () => armWatchdog());

  ws.addEventListener('message', async (evt) => {
    // « muet » est posé sur l'ancien socket lors d'une bascule. Un simple
    // « onmessage = null » ne suffisait pas : le gestionnaire est attaché
    // par addEventListener, que cette affectation ne retire pas. Résultat,
    // les deux sockets livraient les mêmes événements pendant les trois
    // secondes de chevauchement — chaque raid, chaque don comptait double
    // dans le bilan et déclenchait deux notifications.
    if (ws.muet) return;
    // Filet : seule la connexion en cours compte. Une autre qui recevrait
    // encore quelque chose est une ancienne restée ouverte — on la ferme.
    if (ws !== twitchWs) {
      console.log('[Twitch] Une ancienne connexion recevait encore des événements : elle est fermée.');
      oublierConnexionTwitch(ws);
      return;
    }
    try { await handleTwitchMessage(evt); }
    catch (e) { console.error('[Twitch] trame ignorée :', (e && e.message) || e); }
  });

  async function handleTwitchMessage(evt) {
    armWatchdog();
    let msg;
    try { msg = JSON.parse(evt.data); } catch (e) { return; }
    const mtype = msg.metadata && msg.metadata.message_type;
    twitchDirect.trameRecue(ws);

    if (mtype === 'session_welcome') {
      keepaliveSeconds = (msg.payload.session && msg.payload.session.keepalive_timeout_seconds) || 10;
      ws.sessionTwitch = (msg.payload.session && msg.payload.session.id) || '';
      armWatchdog();
      if (isReconnect) {
        // Bascule : les souscriptions suivent la session, rien à refaire.
        twitchRetry = 0;
        setTwitchListen({ status: 'connected', error: '' });
        return;
      }
      try {
        // Le jeton du MOMENT (renouvelé d'avance en connexion par code), et non
        // celui lu à l'ouverture du socket : une reconnexion peut survenir des
        // heures plus tard, bien après l'expiration du jeton de départ.
        let jeton = await twitchJeton.jetonTwitchValide();
        let userRes = await fetch(parametres.TWITCH_API + '/helix/users', {
          headers: { Authorization: `Bearer ${jeton}`, 'Client-Id': clientId },
        });
        if (userRes.status === 401 && twitchJeton.connexionParCode()) {
          try {
            jeton = await twitchJeton.renouvelerJetonTwitch('refusé à la connexion');
            userRes = await fetch(parametres.TWITCH_API + '/helix/users', {
              headers: { Authorization: `Bearer ${jeton}`, 'Client-Id': clientId },
            });
          } catch (e) { /* le message d'erreur est donné juste en dessous */ }
        }
        if (!userRes.ok) {
          // Seul un refus d'authentification est définitif : réessayer n'y
          // changerait rien. Une panne passagère de Twitch (500, 503) ou une
          // coupure réseau doit au contraire laisser la reconnexion faire son
          // travail, sinon une erreur d'une seconde coupe l'écoute pour tout
          // le reste du stream.
          const definitif = userRes.status === 401 || userRes.status === 403;
          if (definitif) twitchManualStop = true;
          setTwitchListen({
            status: 'error',
            error: definitif
              ? (etatRegie.obsState.twitchCreds && (etatRegie.obsState.twitchCreds.mode === 'code' || etatRegie.obsState.twitchCreds.mode === 'expire')
                ? 'Connexion Twitch expirée — reconnecte-toi avec un code (Réglages → Twitch).'
                : 'Token Twitch expiré ou révoqué — refais "Obtenir un token" dans Réglages.')
              : 'Twitch n\'a pas répondu correctement (' + userRes.status + ') — nouvelle tentative en cours.',
          });
          try { ws.close(); } catch (e) {}
          return;
        }
        const userData = await userRes.json();
        const me = userData.data && userData.data[0];
        if (!me) throw new Error('Profil Twitch introuvable.');

        const sessionId = msg.payload.session.id;
        const subs = [
          { type: 'channel.follow', version: '2', condition: { broadcaster_user_id: me.id, moderator_user_id: me.id }, label: 'Follows' },
          { type: 'channel.subscribe', version: '1', condition: { broadcaster_user_id: me.id }, label: 'Abonnements' },
          { type: 'channel.subscription.gift', version: '1', condition: { broadcaster_user_id: me.id }, label: 'Abos offerts' },
          { type: 'channel.subscription.message', version: '1', condition: { broadcaster_user_id: me.id }, label: 'Résubs' },
          { type: 'channel.cheer', version: '1', condition: { broadcaster_user_id: me.id }, label: 'Bits' },
          { type: 'channel.raid', version: '1', condition: { to_broadcaster_user_id: me.id }, label: 'Raids' },
          { type: 'channel.chat.message', version: '1', condition: { broadcaster_user_id: me.id, user_id: me.id }, label: 'Messages tchat' },
          { type: 'channel.hype_train.begin', version: '2', condition: { broadcaster_user_id: me.id }, label: 'Hype Train (début)' },
          { type: 'channel.hype_train.progress', version: '2', condition: { broadcaster_user_id: me.id }, label: 'Hype Train (progression)' },
          { type: 'channel.hype_train.end', version: '2', condition: { broadcaster_user_id: me.id }, label: 'Hype Train (fin)' },
          // Début et fin du direct, vus par Twitch : un deuxième témoin à
          // côté d'OBS pour le bilan de fin de stream (voir suivi-stream.js),
          // qui reste juste si OBS se ferme d'un coup en plein direct.
          { type: 'stream.online', version: '1', condition: { broadcaster_user_id: me.id }, label: 'Début du direct' },
          { type: 'stream.offline', version: '1', condition: { broadcaster_user_id: me.id }, label: 'Fin du direct' },
        ];

        const failed = [];
        // Les abonnements créés, pour pouvoir les supprimer chez Twitch le
        // jour où cette connexion est remplacée (voir oublierConnexionTwitch).
        ws.abonnementsTwitch = { clientId, jeton, ids: [] };
        for (const s of subs) {
          if (ws.muet) break; // remplacée pendant qu'on s'abonnait : inutile de continuer
          try {
            const r = await fetch(parametres.TWITCH_API + '/helix/eventsub/subscriptions', {
              method: 'POST',
              headers: { Authorization: `Bearer ${jeton}`, 'Client-Id': clientId, 'Content-Type': 'application/json' },
              body: JSON.stringify({ type: s.type, version: s.version, condition: s.condition, transport: { method: 'websocket', session_id: sessionId } }),
            });
            const d = await r.json().catch(() => ({}));
            if (!r.ok) {
              failed.push(`${s.label} (${r.status}${d.message ? ' : ' + d.message : ''})`);
            } else if (d.data && d.data[0] && d.data[0].id) {
              if (ws.abonnementsTwitch) ws.abonnementsTwitch.ids.push(String(d.data[0].id));
              else oublierConnexionTwitch({ abonnementsTwitch: { clientId, jeton, ids: [String(d.data[0].id)] }, close() {} });
            }
          } catch (e) { failed.push(`${s.label} (${e.message || 'erreur réseau'})`); }
        }
        if (ws.muet) return; // remplacée entre-temps : ne pas afficher son état

        twitchRetry = 0;
        setTwitchListen({
          status: 'connected',
          error: '',
          warning: failed.length ? `Non activés : ${failed.join(' · ')}` : '',
          profile: { id: me.id, login: me.login, displayName: me.display_name },
        });
        // Où en est le direct (voir twitch-direct.js).
        ws.chaineTwitch = me.id;
        twitchDirect.verifierDirect(me.id, 2, () => twitchWs);
      } catch (e) {
        setTwitchListen({ status: 'error', error: e.message || String(e) });
      }
    } else if (mtype === 'notification') {
      const verdict = verdictDoublonTwitch(msg);
      if (verdict.doublon) { traiterDoublonTwitch(verdict); return; }
      const subType = msg.payload.subscription.type;
      if (subType === 'channel.hype_train.begin' || subType === 'channel.hype_train.progress') {
        const e = msg.payload.event;
        // Pendant un Hype Train, la progression arrive à chaque contribution :
        // c'est l'autre champ qui mérite une diffusion partielle.
        etatRegie.setStatePartiel({ hypeTrain: { active: true, level: e.level || 1, progress: e.progress || 0, goal: e.goal || 1, total: e.total || 0 } });
      } else if (subType === 'channel.hype_train.end') {
        etatRegie.setStatePartiel({ hypeTrain: { active: false, level: 0, progress: 0, goal: 1, total: 0 } });
      } else if (subType === 'stream.online') {
        twitchDirect.enLigne(ws, msg.payload.event || {});
      } else if (subType === 'stream.offline') {
        twitchDirect.horsLigne(ws);
      } else {
        const local = twitchEventToLocal(subType, msg.payload.event);
        if (local) pushTwitchEvent(local);
      }
    } else if (mtype === 'revocation') {
      // Twitch a annulé une souscription de son côté (autorisation retirée,
      // rôle de modérateur perdu...). Le socket reste ouvert et le statut
      // resterait au vert alors que ce type d'événement ne remonte plus.
      const type = (msg.payload && msg.payload.subscription && msg.payload.subscription.type) || 'inconnue';
      setTwitchListen({ warning: 'Souscription révoquée par Twitch (' + type + ') — reconnecte Twitch dans Réglages.' });
    } else if (mtype === 'session_reconnect') {
      // Twitch demande une bascule : on ouvre le nouveau lien avant de fermer
      // l'ancien pour ne rien manquer entre les deux. L'ancien est rendu muet
      // immédiatement, sinon les deux sockets livrent les mêmes événements
      // pendant le chevauchement et tout apparaît en double.
      const old = ws;
      old.muet = true;                      // plus aucune trame traitée par l'ancien
      if (old.arreterGarde) old.arreterGarde(); // et il n'emporte plus la surveillance du nouveau
      const nouveau = openTwitchSocket(msg.payload.session.reconnect_url, true);
      // Les abonnements passent à la nouvelle connexion : c'est elle qui
      // devra les supprimer le jour où on la remplace.
      // Ce qu'elle sait du direct aussi (voir twitch-direct.js).
      if (nouveau) {
        nouveau.abonnementsTwitch = old.abonnementsTwitch; old.abonnementsTwitch = null;
        twitchDirect.bascule(old, nouveau);
      }
      setTimeout(() => { try { old.close(); } catch (e) {} }, 3000);
    }
  }

  // Fin de cette connexion (coupée, ou jamais ouverte) : on en reprend une.
  let finie = false;
  function finDeConnexion() {
    if (finie || twitchWs !== ws) return; // déjà traité, ou remplacé par une bascule demandée par Twitch
    finie = true;
    clearTimeout(gardeDeCeSocket);
    twitchDirect.coupure(ws); // en plein direct : de quoi dater sa fin
    if (twitchManualStop) { setTwitchListen({ status: 'disconnected' }); return; }
    setTwitchListen({ status: 'connecting' });
    scheduleTwitchReconnect();
  }

  ws.addEventListener('error', () => {
    if (twitchWs !== ws) return; // socket déjà remplacé : ne pas écraser l'état du nouveau
    setTwitchListen({ error: 'Connexion WebSocket Twitch impossible.' });
    // Connexion jamais ouverte (Twitch injoignable, box qui redémarre) : le
    // WebSocket de Node signale l'erreur mais n'annonce JAMAIS « close », et
    // reste « en connexion » pour toujours. Sans ça, l'écoute ne revenait
    // plus après une coupure réseau, jusqu'à une relance à la main.
    if (ws.readyState === 0 /* CONNECTING */) finDeConnexion();
  });

  ws.addEventListener('close', finDeConnexion);

  return ws;
}

function connectTwitchListen() {
  twitchManualStop = false;
  clearTimeout(twitchReconnectTimer);
  twitchReconnectTimer = null;
  twitchRetry = 0;
  if (twitchWs) { oublierConnexionTwitch(twitchWs); twitchWs = null; }
  setTwitchListen({ status: 'connecting', error: '' });
  openTwitchSocket(parametres.TWITCH_WS_URL);
}

function disconnectTwitchListen() {
  twitchManualStop = true;
  clearTimeout(twitchReconnectTimer);
  twitchReconnectTimer = null;
  if (twitchWs) {
    oublierConnexionTwitch(twitchWs);
    twitchWs = null;
  }
  setTwitchListen({ status: 'disconnected', error: '', warning: '', profile: null });
}

// Lancé une fois, au démarrage du pont, dans l’ordre fixé par server.js.
function demarrer() {
  // Filet de sécurité : même sur un PC, un lien peut mourir sans se déclarer
  // fermé (coupure réseau brutale, veille de la machine).
  setInterval(() => {
    if (twitchManualStop || !twitchWs) return;
    if (twitchWs.readyState === 3 /* CLOSED */ && !twitchReconnectTimer) scheduleTwitchReconnect();
  }, 15000);
}
