// ============================================================
//  Fabrication d'un .zip — sans aucune dépendance
// ------------------------------------------------------------
//  Sert au générateur de kit (page /kit) : un dossier prêt à
//  envoyer à quelqu'un, fabriqué PAR LE PONT à partir d'une liste
//  blanche de fichiers. C'est ce qui garantit qu'aucun accès ne
//  part avec : data/, certs/ et tokens.json ne sont jamais lus,
//  donc ils ne peuvent pas se retrouver dans l'archive, quoi qu'on
//  ait dans son dossier.
//
//  Format ZIP classique (pas de ZIP64 : un kit pèse ~100 Mo, loin
//  des 4 Go de la limite). Compression « deflate » de zlib, intégré
//  à Node. Les noms sont marqués UTF-8 (bit 11), que l'extracteur
//  de Windows et tous les autres reconnaissent.
// ============================================================
'use strict';
const zlib = require('zlib');
const { promisify } = require('util');
// Compression ASYNCHRONE : elle tourne sur un fil à part de Node. Avec la
// version synchrone, compresser node.exe (~90 Mo) figeait le pont six
// secondes — plus de réponse à OBS ni au téléphone pendant ce temps.
const deflateRaw = promisify(zlib.deflateRaw);

// zlib.crc32 existe depuis Node 22.2 — le pont exige Node 22 ou plus,
// mais une version 22.0 ou 22.1 l'aurait pas : on garde un repli.
let tableCrc = null;
function crc32(donnees) {
  if (typeof zlib.crc32 === 'function') return zlib.crc32(donnees) >>> 0;
  if (!tableCrc) {
    tableCrc = new Uint32Array(256);
    for (let n = 0; n < 256; n += 1) {
      let c = n;
      for (let k = 0; k < 8; k += 1) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
      tableCrc[n] = c >>> 0;
    }
  }
  let crc = 0xffffffff;
  for (let i = 0; i < donnees.length; i += 1) crc = tableCrc[(crc ^ donnees[i]) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}

function dateDos(d) {
  const date = d instanceof Date && !Number.isNaN(d.getTime()) ? d : new Date();
  const annee = Math.max(1980, date.getFullYear());
  return {
    heure: (date.getHours() << 11) | (date.getMinutes() << 5) | Math.floor(date.getSeconds() / 2),
    jour: ((annee - 1980) << 9) | ((date.getMonth() + 1) << 5) | date.getDate(),
  };
}

// entrees : [{ nom: 'dossier/fichier.txt', donnees: Buffer, date?: Date }]
// Renvoie (promesse) { morceaux: [Buffer...], taille } : à écrire dans
// l'ordre. On ne recolle pas tout en un seul Buffer — inutile de doubler la
// mémoire pour un kit qui contient node.exe (~90 Mo).
async function creerZip(entrees) {
  if (!Array.isArray(entrees) || entrees.length === 0) throw new Error('Rien à mettre dans le zip.');
  if (entrees.length > 65000) throw new Error('Trop de fichiers pour un zip simple.');

  const morceaux = [];
  const central = [];
  let decalage = 0;
  const vus = new Set();

  for (const e of entrees) {
    const nom = String(e.nom || '').replace(/\\/g, '/');
    // Garde-fous : jamais de chemin absolu ni de remontée de dossier dans
    // une archive qu'on donne à quelqu'un — un extracteur naïf écrirait
    // n'importe où sur son disque.
    if (!nom || nom.startsWith('/') || /^[a-zA-Z]:/.test(nom) || nom.split('/').includes('..')) {
      throw new Error('Nom de fichier refusé dans le zip : ' + nom);
    }
    if (vus.has(nom.toLowerCase())) throw new Error('Fichier en double dans le zip : ' + nom);
    vus.add(nom.toLowerCase());

    const brut = Buffer.isBuffer(e.donnees) ? e.donnees : Buffer.from(e.donnees || '');
    const crc = crc32(brut);
    let methode = 8;
    // Niveau 9 pour les petits fichiers, 6 pour les gros : même taille à
    // 1 % près, deux fois plus vite.
    let compresse = await deflateRaw(brut, { level: brut.length > 4 * 1024 * 1024 ? 6 : 9 });
    if (compresse.length >= brut.length) { methode = 0; compresse = brut; }

    const nomOctets = Buffer.from(nom, 'utf8');
    const utf8 = /[^\x20-\x7e]/.test(nom);
    const drapeaux = utf8 ? 0x0800 : 0;
    const { heure, jour } = dateDos(e.date);

    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);           // version nécessaire : 2.0
    local.writeUInt16LE(drapeaux, 6);
    local.writeUInt16LE(methode, 8);
    local.writeUInt16LE(heure, 10);
    local.writeUInt16LE(jour, 12);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(compresse.length, 18);
    local.writeUInt32LE(brut.length, 22);
    local.writeUInt16LE(nomOctets.length, 26);
    local.writeUInt16LE(0, 28);

    const entete = Buffer.alloc(46);
    entete.writeUInt32LE(0x02014b50, 0);
    entete.writeUInt16LE(20, 4);          // fabriqué par : 2.0 (MS-DOS)
    entete.writeUInt16LE(20, 6);
    entete.writeUInt16LE(drapeaux, 8);
    entete.writeUInt16LE(methode, 10);
    entete.writeUInt16LE(heure, 12);
    entete.writeUInt16LE(jour, 14);
    entete.writeUInt32LE(crc, 16);
    entete.writeUInt32LE(compresse.length, 20);
    entete.writeUInt32LE(brut.length, 24);
    entete.writeUInt16LE(nomOctets.length, 28);
    entete.writeUInt16LE(0, 30);          // extra
    entete.writeUInt16LE(0, 32);          // commentaire
    entete.writeUInt16LE(0, 34);          // disque
    entete.writeUInt16LE(0, 36);          // attributs internes
    entete.writeUInt32LE(0x20, 38);       // attribut « archive » de Windows
    entete.writeUInt32LE(decalage, 42);

    morceaux.push(local, nomOctets, compresse);
    central.push(entete, nomOctets);
    decalage += local.length + nomOctets.length + compresse.length;
    if (decalage > 0xfffffff0) throw new Error('Archive trop grosse pour un zip simple.');
  }

  const tailleCentral = central.reduce((s, b) => s + b.length, 0);
  const fin = Buffer.alloc(22);
  fin.writeUInt32LE(0x06054b50, 0);
  fin.writeUInt16LE(0, 4);
  fin.writeUInt16LE(0, 6);
  fin.writeUInt16LE(entrees.length, 8);
  fin.writeUInt16LE(entrees.length, 10);
  fin.writeUInt32LE(tailleCentral, 12);
  fin.writeUInt32LE(decalage, 16);
  fin.writeUInt16LE(0, 20);

  const tous = morceaux.concat(central, [fin]);
  return { morceaux: tous, taille: decalage + tailleCentral + fin.length };
}

// Lit un zip (stocké ou « deflate ») entièrement en mémoire : la mise à jour
// (maj.js) vérifie TOUT avant d'écrire le moindre fichier. Strict : une
// entrée chiffrée, une méthode inconnue, un CRC faux ou plus de « max »
// octets décompressés au total font tout refuser.
function lireZip(tampon, max) {
  const plafond = max || 300 * 1024 * 1024;
  const fin = tampon.lastIndexOf(Buffer.from([0x50, 0x4b, 0x05, 0x06]));
  if (fin < 0 || fin + 22 > tampon.length) throw new Error('Ce fichier n’est pas un zip.');
  const nb = tampon.readUInt16LE(fin + 10);
  let p = tampon.readUInt32LE(fin + 16);
  let total = 0;
  const sortie = [];
  for (let i = 0; i < nb; i += 1) {
    if (p + 46 > tampon.length || tampon.readUInt32LE(p) !== 0x02014b50) throw new Error('Zip abîmé (répertoire).');
    const drapeaux = tampon.readUInt16LE(p + 8);
    const methode = tampon.readUInt16LE(p + 10);
    const crc = tampon.readUInt32LE(p + 16);
    const tailleC = tampon.readUInt32LE(p + 20);
    const tailleD = tampon.readUInt32LE(p + 24);
    const lgNom = tampon.readUInt16LE(p + 28);
    const lgExtra = tampon.readUInt16LE(p + 30);
    const lgCom = tampon.readUInt16LE(p + 32);
    const local = tampon.readUInt32LE(p + 42);
    const nom = tampon.slice(p + 46, p + 46 + lgNom).toString('utf8');
    p += 46 + lgNom + lgExtra + lgCom;
    if (drapeaux & 0x1) throw new Error('Zip chiffré refusé : ' + nom);
    if (methode !== 0 && methode !== 8) throw new Error('Méthode de compression inconnue : ' + nom);
    if (local + 30 > tampon.length || tampon.readUInt32LE(local) !== 0x04034b50) throw new Error('Zip abîmé (entrée locale).');
    total += tailleD;
    if (total > plafond) throw new Error('Zip trop gros une fois décompressé.');
    const debut = local + 30 + tampon.readUInt16LE(local + 26) + tampon.readUInt16LE(local + 28);
    if (debut + tailleC > tampon.length) throw new Error('Zip abîmé (données).');
    const brut = tampon.slice(debut, debut + tailleC);
    const donnees = methode === 8 ? zlib.inflateRawSync(brut, { maxOutputLength: Math.max(1, tailleD) }) : Buffer.from(brut);
    if (donnees.length !== tailleD || crc32(donnees) !== crc) throw new Error('Zip abîmé (contrôle) : ' + nom);
    sortie.push({ nom, donnees });
  }
  return sortie;
}

module.exports = { creerZip, crc32, lireZip };
