// ============================================================
//  Collections de scènes d’OBS et fenêtres capturées
// ------------------------------------------------------------
//  Changer de collection sans faire planter OBS, et garder les réglages
//  propres à chaque collection.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  get CAPTURES_FENETRE() { return CAPTURES_FENETRE; },
  changerCollection,
  chargerCollections,
  debutChangementCollection,
  finChangementCollection,
  nomFenetreObs,
  reglagesDeCollection,
};

const etatRegie = require('./etat-regie.js');
const obs = require('./obs.js');
const minuterie = require('./minuterie.js');
const stockage = require('./stockage.js');
const reglagesRegie = require('./reglages-regie.js');

// ------------------------------------------------------------
// Capture de jeu / de fenêtre
// ------------------------------------------------------------
// Les deux types de source dont on peut choisir la fenêtre depuis la régie.
const CAPTURES_FENETRE = new Set(['game_capture', 'window_capture']);
// OBS range une fenêtre sous la forme « titre:classe:programme.exe », les
// « : » et « # » des noms étant codés « #3A » et « #22 ». On la présente
// comme OBS lui-même : « [programme.exe]: titre ».
function nomFenetreObs(valeur) {
  const morceaux = String(valeur || '').split(':').map((p) => p.replace(/#3A/g, ':').replace(/#22/g, '#'));
  const titre = morceaux[0] || '';
  const exe = morceaux[2] || '';
  if (!titre && !exe) return '';
  return exe ? '[' + exe + ']: ' + titre : titre;
}

// ------------------------------------------------------------
// Collections de scènes
// ------------------------------------------------------------
// Une collection, c'est tout un jeu de scènes et de sources. En changer
// remplace TOUT ce que le pont sait d'OBS : scènes, sources, pistes audio.
// Et pendant le chargement, OBS ne doit recevoir aucune requête (voir
// obsRequest) : il prévient qu'elle peut le faire planter.
async function chargerCollections() {
  try {
    const r = await obs.obsRequest('GetSceneCollectionList');
    const liste = Array.isArray(r.sceneCollections) ? r.sceneCollections.map(String) : [];
    const actuelle = String(r.currentSceneCollectionName || '');
    etatRegie.setState({ collections: liste, collection: actuelle });
    basculerReglagesVers(actuelle);
  } catch (e) { /* OBS occupé ou trop ancien : la ligne Collection reste masquée */ }
}

function debutChangementCollection(cible) {
  const dejaEnCours = obs.obsChangementCollection;
  obs.obsChangementCollection = true;
  clearTimeout(obs.minuteurChangementCollection);
  // Filet : si OBS ne signale jamais la fin (plantage, fermeture), le pont
  // ne reste pas muet pour toujours.
  obs.minuteurChangementCollection = setTimeout(() => finChangementCollection(''), 90000);
  etatRegie.setState({ collectionChargement: true, collectionCible: cible || (dejaEnCours ? etatRegie.obsState.collectionCible : '') });
}

function finChangementCollection(nouvelle) {
  clearTimeout(obs.minuteurChangementCollection);
  obs.minuteurChangementCollection = null;
  if (!obs.obsChangementCollection && !etatRegie.obsState.collectionChargement) return;
  obs.obsChangementCollection = false;
  // Tout ce que le pont savait de l'ancienne collection est périmé.
  minuterie.dernierTexteMinuteur = null;
  minuterie.erreurMinuteurOverlay = '';
  etatRegie.setState({
    collectionChargement: false, collectionCible: '',
    ...(nouvelle ? { collection: nouvelle } : {}),
    scenes: [], sceneItems: [], currentScene: '', audioInputs: [],
  });
  if (nouvelle) basculerReglagesVers(nouvelle);
  obs.loadScenes();
  obs.loadAudioInputs();
  // La liste a pu changer, et sans nom (filet de sécurité) c'est elle qui
  // dit quelle collection est active.
  chargerCollections();
}

// Lancé depuis la régie. La réponse d'OBS n'arrive qu'une fois la collection
// chargée : d'où le long délai.
async function changerCollection(nom) {
  if (!obs.obsWs || obs.obsWs.readyState !== WebSocket.OPEN) throw new Error('OBS non connecté.');
  if (obs.obsChangementCollection) throw new Error('Un changement de collection est déjà en cours.');
  if (!etatRegie.obsState.collections.includes(nom)) throw new Error('La collection « ' + nom + ' » n’existe pas dans OBS.');
  if (nom === etatRegie.obsState.collection) return;
  debutChangementCollection(nom);
  try {
    await obs.obsRequest('SetCurrentSceneCollection', { sceneCollectionName: nom }, { delai: 60000, pendantChangement: true });
  } catch (e) {
    // Refusé ou trop long : on reprend la main et on relit ce qui est actif.
    finChangementCollection('');
    throw e;
  }
  // Normalement déjà fait par l'événement « Changed » ; s'il s'est perdu,
  // la réponse d'OBS suffit à conclure.
  if (obs.obsChangementCollection) finChangementCollection(nom);
}

// Les réglages qui visent des scènes ou des sources : ils n'ont de sens que
// dans la collection pour laquelle on les a faits. Retenus par collection,
// et remis en place quand on y revient.
function reglagesDeCollection() {
  return {
    sceneShortcuts: etatRegie.obsState.sceneShortcuts,
    panique: etatRegie.obsState.panique,
    timerActionsFin: minuterie.timerState.actionsFin,
    timerTextSource: minuterie.timerState.textSource,
  };
}
function appliquerReglagesCollection(r) {
  if (Array.isArray(r.sceneShortcuts) && r.sceneShortcuts.length) etatRegie.obsState.sceneShortcuts = r.sceneShortcuts;
  if (r.panique && typeof r.panique === 'object') {
    etatRegie.obsState.panique = { scene: String(r.panique.scene || ''), micro: String(r.panique.micro || '') };
  }
  if (Array.isArray(r.timerActionsFin)) minuterie.timerState.actionsFin = minuterie.nettoyerActionsFin(r.timerActionsFin);
  if (typeof r.timerTextSource === 'string') minuterie.timerState.textSource = r.timerTextSource;
}
// Appelé dès que la collection active est connue (connexion, changement,
// y compris fait directement dans OBS pendant que le pont était fermé).
function basculerReglagesVers(collection) {
  if (!collection) return;
  const ancienne = stockage.platformTokens.reglagesCollection || '';
  if (ancienne === collection) return;
  const parCollection = (stockage.platformTokens.reglagesParCollection && typeof stockage.platformTokens.reglagesParCollection === 'object')
    ? stockage.platformTokens.reglagesParCollection : {};
  if (ancienne) parCollection[ancienne] = reglagesDeCollection();
  // Jamais configurée : elle part des réglages en place.
  if (parCollection[collection]) appliquerReglagesCollection(parCollection[collection]);
  stockage.platformTokens.reglagesParCollection = parCollection;
  stockage.platformTokens.reglagesCollection = collection;
  minuterie.dernierTexteMinuteur = null;
  reglagesRegie.persistExtras();
  etatRegie.broadcastState();
  minuterie.broadcastTimer();
  if (ancienne) console.log('[pont] Collection « ' + collection + ' » : ses raccourcis et sa fin de pause sont remis en place.');
}
