// ============================================================
//  Fabrication des certificats locaux
// ------------------------------------------------------------
//  POURQUOI DEUX CERTIFICATS ET PAS UN
//
//  Les navigateurs réservent une partie de leurs fonctions aux
//  adresses « sécurisées » : https avec un certificat reconnu, ou
//  localhost. Sur un simple http://192.168.1.20:4560, Chrome ne
//  fournit même pas « serviceWorker » — d'où l'impossibilité
//  d'avoir des notifications sur le téléphone, et l'impossibilité
//  d'installer l'appli autrement qu'en raccourci.
//
//  Un certificat auto-signé ne suffit PAS : Chrome refuse
//  d'enregistrer un service worker sur un site dont le certificat
//  n'est pas reconnu, même après avoir cliqué « Continuer ». La
//  seule voie est donc que le téléphone fasse confiance à qui a
//  signé le certificat.
//
//  D'où la paire :
//    • une AUTORITÉ locale, fabriquée une seule fois, qu'on
//      installe sur le téléphone (une manipulation, ~3 minutes) ;
//    • un certificat de SERVEUR signé par elle, couvrant les
//      adresses du PC, et réémis tout seul quand l'IP change ou
//      qu'il approche de sa fin.
//
//  L'autorité, elle, ne change jamais : sans ça il faudrait
//  réinstaller quelque chose sur le téléphone à chaque fois qu'on
//  change de réseau. C'est tout l'intérêt de la séparer.
//
//  Node sait générer des clés mais pas des certificats : la
//  structure X.509 est donc écrite ici à la main, au format DER.
//  C'est du binaire précis, d'où les commentaires sur chaque bloc.
// ============================================================
const crypto = require('crypto');

// --- Briques DER ---------------------------------------------
// Chaque valeur est écrite : un octet de type, la longueur, le contenu.
function longueur(n) {
  if (n < 0x80) return Buffer.from([n]);
  const o = [];
  let v = n;
  while (v > 0) { o.unshift(v & 0xff); v >>= 8; }
  return Buffer.from([0x80 | o.length, ...o]);
}
function bloc(type, contenu) {
  return Buffer.concat([Buffer.from([type]), longueur(contenu.length), contenu]);
}
const suite = (...p) => bloc(0x30, Buffer.concat(p));          // SEQUENCE
const ensemble = (c) => bloc(0x31, c);                          // SET
const entier = (b) => bloc(0x02, b[0] & 0x80 ? Buffer.concat([Buffer.from([0]), b]) : b);
const chaineUtf8 = (s) => bloc(0x0c, Buffer.from(s, 'utf8'));   // UTF8String
const vide = () => bloc(0x05, Buffer.alloc(0));                 // NULL
const binaire = (c) => bloc(0x03, Buffer.concat([Buffer.from([0]), c])); // BIT STRING
const octets = (c) => bloc(0x04, c);                            // OCTET STRING
const booleen = (v) => bloc(0x01, Buffer.from([v ? 0xff : 0x00]));

// Un identifiant d'objet (« 1.2.840.113549.1.1.11 ») en DER.
function oid(texte) {
  const n = texte.split('.').map(Number);
  const sortie = [n[0] * 40 + n[1]];
  for (const v of n.slice(2)) {
    const pile = [v & 0x7f];
    let r = v >> 7;
    while (r > 0) { pile.unshift((r & 0x7f) | 0x80); r >>= 7; }
    sortie.push(...pile);
  }
  return bloc(0x06, Buffer.from(sortie));
}

// Une date au format UTCTime : AAMMJJhhmmssZ
function dateUtc(d) {
  const p = (n) => String(n).padStart(2, '0');
  const t = p(d.getUTCFullYear() % 100) + p(d.getUTCMonth() + 1) + p(d.getUTCDate())
    + p(d.getUTCHours()) + p(d.getUTCMinutes()) + p(d.getUTCSeconds()) + 'Z';
  return bloc(0x17, Buffer.from(t, 'ascii'));
}

const OID_SHA256_RSA = '1.2.840.113549.1.1.11';
const OID_NOM_COMMUN = '2.5.4.3';
const OID_ORGANISATION = '2.5.4.10';
const OID_CLE_SUJET = '2.5.29.14';     // subjectKeyIdentifier
const OID_AUTRES_NOMS = '2.5.29.17';   // subjectAltName
const OID_CONTRAINTES = '2.5.29.19';   // basicConstraints
const OID_USAGE_CLE = '2.5.29.15';     // keyUsage
const OID_CLE_AUTORITE = '2.5.29.35';  // authorityKeyIdentifier
const OID_USAGE_ETENDU = '2.5.29.37';  // extKeyUsage
const OID_SERVEUR_TLS = '1.3.6.1.5.5.7.3.1'; // serverAuth

// Noms volontairement en ASCII : ils s'affichent dans les réglages du
// téléphone et dans les avertissements du navigateur, et certains écrans
// Android rendent mal les accents.
const NOM_AUTORITE = 'Regie mobile - autorite locale';
const NOM_SERVEUR = 'Regie mobile';

function nomX500(cn) {
  return suite(
    ensemble(suite(oid(OID_ORGANISATION), chaineUtf8('Regie mobile'))),
    ensemble(suite(oid(OID_NOM_COMMUN), chaineUtf8(cn))),
  );
}

const ALGO_SIGNATURE = () => suite(oid(OID_SHA256_RSA), vide());

// Identifiant d'une clé : l'empreinte SHA-1 de la clé publique, comme le
// veut la norme. Sert au navigateur à relier un certificat à son autorité
// sans avoir à essayer toutes celles qu'il connaît.
function identifiantDeCle(spkiDer) {
  return crypto.createHash('sha1').update(spkiDer).digest();
}

function extension(oidTexte, critique, contenu) {
  return critique
    ? suite(oid(oidTexte), booleen(true), octets(contenu))
    : suite(oid(oidTexte), octets(contenu));
}

// keyUsage est une BIT STRING à bits nommés : le bit 0 est le bit de poids
// fort du premier octet. digitalSignature=0, keyEncipherment=2,
// keyCertSign=5, cRLSign=6. Le premier octet du contenu dit combien de bits
// de la fin ne comptent pas.
const USAGE_AUTORITE = bloc(0x03, Buffer.from([0x01, 0x06]));   // keyCertSign + cRLSign
const USAGE_SERVEUR = bloc(0x03, Buffer.from([0x05, 0xa0]));    // digitalSignature + keyEncipherment

function pem(titre, der) {
  return `-----BEGIN ${titre}-----\n`
    + (der.toString('base64').match(/.{1,64}/g) || []).join('\n')
    + `\n-----END ${titre}-----\n`;
}

// Les noms que le certificat couvre. « type 2 » = un nom de domaine,
// « type 7 » = une adresse IP (quatre octets bruts).
function autresNoms(noms, ips) {
  const morceaux = [];
  for (const n of noms) morceaux.push(bloc(0x82, Buffer.from(n, 'ascii')));
  for (const ip of ips) {
    const o = ip.split('.').map(Number);
    if (o.length === 4 && o.every((x) => Number.isInteger(x) && x >= 0 && x <= 255)) {
      morceaux.push(bloc(0x87, Buffer.from(o)));
    }
  }
  return suite(...morceaux);
}

/**
 * L'autorité locale : à fabriquer UNE SEULE FOIS, et à installer sur le
 * téléphone. Valable dix ans — on ne veut pas refaire cette manipulation.
 */
function fabriquerAutorite(annees = 10) {
  const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  const spki = publicKey.export({ type: 'spki', format: 'der' });
  const nom = nomX500(NOM_AUTORITE);
  const debut = new Date(Date.now() - 24 * 3600 * 1000); // hier, pour tolérer une horloge en avance
  const fin = new Date(debut.getTime() + annees * 365 * 24 * 3600 * 1000);

  const corps = suite(
    bloc(0xa0, entier(Buffer.from([2]))),       // version v3
    entier(crypto.randomBytes(8)),              // numéro de série
    ALGO_SIGNATURE(),
    nom,                                        // émetteur = lui-même
    suite(dateUtc(debut), dateUtc(fin)),
    nom,                                        // sujet
    spki,
    bloc(0xa3, suite(
      extension(OID_CONTRAINTES, true, suite(booleen(true))),  // CA: oui
      extension(OID_USAGE_CLE, true, USAGE_AUTORITE),
      extension(OID_CLE_SUJET, false, octets(identifiantDeCle(spki))),
    )),
  );
  const signature = crypto.sign('sha256', corps, privateKey);
  return {
    clePem: privateKey.export({ type: 'pkcs8', format: 'pem' }),
    certificatPem: pem('CERTIFICATE', suite(corps, ALGO_SIGNATURE(), binaire(signature))),
  };
}

/**
 * Le certificat du serveur, signé par l'autorité ci-dessus. Réémis à la
 * demande : il couvre les adresses du PC à l'instant où on le fabrique, et
 * celles-là changent (nouveau réseau, box redémarrée, câble au lieu du
 * wifi). Le réémettre ne demande RIEN sur le téléphone, puisque l'autorité
 * qui le signe est la même.
 */
function fabriquerCertificatServeur({ autoriteClePem, autoriteCertPem, noms, ips, jours = 365 }) {
  const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  const spki = publicKey.export({ type: 'spki', format: 'der' });
  const cleAutorite = crypto.createPrivateKey(autoriteClePem);

  // L'identifiant de la clé de l'autorité est relu dans SON certificat :
  // le recalculer depuis la clé privée marcherait aussi, mais passer par le
  // certificat garantit qu'on désigne bien celui qui est installé sur le
  // téléphone.
  const certAutorite = new crypto.X509Certificate(autoriteCertPem);
  const spkiAutorite = certAutorite.publicKey.export({ type: 'spki', format: 'der' });

  const debut = new Date(Date.now() - 24 * 3600 * 1000);
  const fin = new Date(debut.getTime() + jours * 24 * 3600 * 1000);

  const corps = suite(
    bloc(0xa0, entier(Buffer.from([2]))),
    entier(crypto.randomBytes(8)),
    ALGO_SIGNATURE(),
    nomX500(NOM_AUTORITE),                      // émetteur : l'autorité
    suite(dateUtc(debut), dateUtc(fin)),
    nomX500(NOM_SERVEUR),                       // sujet
    spki,
    bloc(0xa3, suite(
      // Les navigateurs modernes ignorent le nom commun et ne regardent que
      // cette liste : sans elle, le certificat serait refusé.
      extension(OID_AUTRES_NOMS, false, autresNoms(noms, ips)),
      extension(OID_CONTRAINTES, true, suite()),            // CA: non
      extension(OID_USAGE_CLE, true, USAGE_SERVEUR),
      extension(OID_USAGE_ETENDU, false, suite(oid(OID_SERVEUR_TLS))),
      extension(OID_CLE_SUJET, false, octets(identifiantDeCle(spki))),
      extension(OID_CLE_AUTORITE, false, suite(bloc(0x80, identifiantDeCle(spkiAutorite)))),
    )),
  );
  const signature = crypto.sign('sha256', corps, cleAutorite);
  return {
    clePem: privateKey.export({ type: 'pkcs8', format: 'pem' }),
    certificatPem: pem('CERTIFICATE', suite(corps, ALGO_SIGNATURE(), binaire(signature))),
  };
}

// Conservé pour compatibilité : l'ancienne version ne fabriquait qu'un
// certificat auto-signé pour localhost, utilisé par la redirection
// Instagram. Il reste utile quand on ne veut rien installer sur le
// téléphone — ce chemin-là n'a pas besoin d'un certificat reconnu.
function fabriquerCertificatLocal(anneesValidite = 10) {
  const autorite = fabriquerAutorite(anneesValidite);
  const serveur = fabriquerCertificatServeur({
    autoriteClePem: autorite.clePem,
    autoriteCertPem: autorite.certificatPem,
    noms: ['localhost'],
    ips: ['127.0.0.1'],
    jours: Math.round(anneesValidite * 365),
  });
  return { cle: serveur.clePem, certificat: serveur.certificatPem };
}

module.exports = {
  fabriquerAutorite,
  fabriquerCertificatServeur,
  fabriquerCertificatLocal,
  NOM_AUTORITE,
  NOM_SERVEUR,
};
