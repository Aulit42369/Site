// ============================================================
//  Les notifications Web Push
// ------------------------------------------------------------
//  Clés VAPID, chiffrement pour chaque abonné, règles de déclenchement.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  demarrer,
  get abonnementsPush() { return abonnementsPush; },
  set abonnementsPush(valeur) { abonnementsPush = valeur; },
  assurerVapid,
  endpointPushAccepte,
  envoyerPush,
  oublierAbonnementsDe,
  notifierEvenement,
  persistPush,
  get REGLES_PUSH_DEFAUT() { return REGLES_PUSH_DEFAUT; },
  get reglesPush() { return reglesPush; },
  set reglesPush(valeur) { reglesPush = valeur; },
};

const { createECDH, createPrivateKey, sign: signerCrypto, createHmac, randomBytes, createCipheriv } = require('crypto');

const stockage = require('./stockage.js');
const discord = require('./discord.js');

function b64url(buf) {
  return Buffer.from(buf).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
function deB64url(str) {
  return Buffer.from(String(str).replace(/-/g, '+').replace(/_/g, '/'), 'base64');
}

// --- Clés VAPID : l'identité du pont auprès des services de push ---
// Générées une fois puis conservées. Les régénérer invaliderait tous
// les abonnements existants, d'où le soin à ne le faire qu'une fois.
function assurerVapid() {
  if (stockage.platformTokens.vapid && stockage.platformTokens.vapid.publique && stockage.platformTokens.vapid.privee) {
    return stockage.platformTokens.vapid;
  }
  const ec = createECDH('prime256v1');
  ec.generateKeys();
  const pub = ec.getPublicKey(); // 65 octets, point non compressé
  stockage.platformTokens.vapid = {
    publique: b64url(pub),
    privee: b64url(ec.getPrivateKey()),
    contact: 'mailto:regie@localhost',
  };
  stockage.saveTokens();
  return stockage.platformTokens.vapid;
}

// Reconstruit une clé utilisable pour signer à partir des octets bruts.
// Node sait importer une clé au format JWK, ce qui évite d'avoir à
// fabriquer une structure DER à la main.
function cleVapidPourSignature(vapid) {
  const pub = deB64url(vapid.publique);
  return createPrivateKey({
    key: {
      kty: 'EC', crv: 'P-256',
      d: vapid.privee,
      x: b64url(pub.slice(1, 33)),
      y: b64url(pub.slice(33, 65)),
    },
    format: 'jwk',
  });
}

function jetonVapid(endpoint) {
  const vapid = assurerVapid();
  const origine = new URL(endpoint).origin;
  const entete = b64url(JSON.stringify({ typ: 'JWT', alg: 'ES256' }));
  const charge = b64url(JSON.stringify({
    aud: origine,
    exp: Math.floor(Date.now() / 1000) + 12 * 3600,
    sub: vapid.contact,
  }));
  // ieee-p1363 : signature brute r||s de 64 octets, telle qu'attendue
  // par la norme. Le format DER par défaut de Node serait refusé.
  const signature = signerCrypto(
    'sha256',
    Buffer.from(`${entete}.${charge}`),
    { key: cleVapidPourSignature(vapid), dsaEncoding: 'ieee-p1363' }
  );
  return `${entete}.${charge}.${b64url(signature)}`;
}

// --- Chiffrement du contenu pour un abonné précis (RFC 8291) ---
function hmac(cle, donnees) {
  return createHmac('sha256', cle).update(donnees).digest();
}

function chiffrerPourAbonne(abonnement, texte) {
  const uaPublic = deB64url(abonnement.keys.p256dh);   // clé publique du téléphone
  const authSecret = deB64url(abonnement.keys.auth);   // secret partagé, 16 octets

  const ec = createECDH('prime256v1');
  ec.generateKeys();
  const asPublic = ec.getPublicKey();
  const secretPartage = ec.computeSecret(uaPublic);

  const prkCle = hmac(authSecret, secretPartage);
  const infoCle = Buffer.concat([
    Buffer.from('WebPush: info\0'), uaPublic, asPublic,
  ]);
  const ikm = hmac(prkCle, Buffer.concat([infoCle, Buffer.from([1])]));

  const sel = randomBytes(16);
  const prk = hmac(sel, ikm);
  const cek = hmac(prk, Buffer.concat([Buffer.from('Content-Encoding: aes128gcm\0'), Buffer.from([1])])).slice(0, 16);
  const nonce = hmac(prk, Buffer.concat([Buffer.from('Content-Encoding: nonce\0'), Buffer.from([1])])).slice(0, 12);

  // 0x02 marque le dernier (et seul) enregistrement du flux.
  const clair = Buffer.concat([Buffer.from(texte, 'utf8'), Buffer.from([2])]);
  const chiffreur = createCipheriv('aes-128-gcm', cek, nonce);
  const chiffre = Buffer.concat([chiffreur.update(clair), chiffreur.final(), chiffreur.getAuthTag()]);

  const tailleEnr = Buffer.alloc(4);
  tailleEnr.writeUInt32BE(4096, 0);
  return Buffer.concat([
    sel,                       // 16 octets
    tailleEnr,                 // 4 octets
    Buffer.from([asPublic.length]), // 1 octet
    asPublic,                  // 65 octets
    chiffre,
  ]);
}

// Les services de notification des navigateurs : Google (Chrome, Samsung,
// Opera), Mozilla (Firefox), Windows (Edge), Apple (Safari). Un abonnement
// ne vient que d'eux : une autre adresse ferait poster le PC vers une cible
// choisie par l'appareil (sa propre boucle locale, une box du Wi-Fi...).
// shortcut: liste fermée, à compléter si un navigateur passe par un autre service.
const SERVICES_PUSH = ['fcm.googleapis.com', 'android.googleapis.com', 'push.services.mozilla.com', 'notify.windows.com', 'push.apple.com'];
function endpointPushAccepte(endpoint) {
  let u;
  try { u = new URL(String(endpoint || '')); } catch (e) { return false; }
  if (u.protocol !== 'https:' || u.port || u.username || u.password) return false;
  const hote = u.hostname.toLowerCase();
  return SERVICES_PUSH.some((d) => hote === d || hote.endsWith('.' + d));
}

async function envoyerPush(abonnement, charge) {
  if (!endpointPushAccepte(abonnement.endpoint)) return { ok: false, erreur: 'Service de notification inconnu.' };
  const corps = chiffrerPourAbonne(abonnement, JSON.stringify(charge));
  const res = await fetch(abonnement.endpoint, {
    method: 'POST',
    headers: {
      TTL: '3600',
      'Content-Encoding': 'aes128gcm',
      'Content-Type': 'application/octet-stream',
      Authorization: `vapid t=${jetonVapid(abonnement.endpoint)}, k=${assurerVapid().publique}`,
    },
    body: corps,
    // Jamais de redirection suivie, et 10 s au plus : un service muet ne
    // bloque ni « Tester les notifications » ni les envois suivants.
    redirect: 'manual',
    signal: AbortSignal.timeout(10000),
  });
  // 404 / 410 : le téléphone a désinstallé l'appli ou révoqué
  // l'autorisation. On retire l'abonnement pour ne pas réessayer
  // indéfiniment à chaque événement.
  if (res.status === 404 || res.status === 410) return { ok: false, perime: true };
  if (!res.ok) return { ok: false, erreur: `${res.status} ${(await res.text()).slice(0, 120)}` };
  return { ok: true };
}

// --- Abonnements et règles de déclenchement ---
let abonnementsPush;

// Un appareil retiré ne reçoit plus rien : ses abonnements partent avec lui
// (ids : les appareils retirés ; null : tous les appareils reliés). Ceux du
// PC (par vide) restent.
function oublierAbonnementsDe(ids) {
  const reste = abonnementsPush.filter((a) => !a.par || (ids && !ids.has(a.par)));
  if (reste.length === abonnementsPush.length) return;
  abonnementsPush = reste;
  persistPush();
}

// Par défaut on ne prévient que de ce qui mérite de lever les yeux :
// un raid, un don conséquent, des abos offerts. Les follows et les
// messages de tchat arrivent trop souvent pour faire une notification.
// « sante » est allumé par défaut, contrairement aux événements sociaux :
// c'est la seule notification dont l'absence coûte quelque chose. Un follow
// manqué se rattrape dans le journal ; vingt minutes de direct diffusées en
// bouillie, non.
const REGLES_PUSH_DEFAUT = {
  raid: true, cheer: true, gift: true, sub: false, resub: false, follow: false, chat: false, bitsMini: 100,
  sante: true, santeSeuil: 3,
};
let reglesPush;

function persistPush() {
  stockage.platformTokens.abonnementsPush = abonnementsPush;
  stockage.platformTokens.reglesPush = reglesPush;
  stockage.saveTokens();
}

function texteNotification(ev) {
  const qui = ev.user || 'Quelqu’un';
  switch (ev.type) {
    case 'raid': return { titre: `🔥 Raid de ${qui}`, corps: `${ev.amount || '?'} viewers viennent d’arriver` };
    case 'cheer': return { titre: `⚡ ${ev.amount || 0} bits`, corps: `${qui}${ev.detail ? ' — ' + String(ev.detail).slice(0, 80) : ''}` };
    case 'gift': return { titre: `🎁 ${ev.amount || 1} abo(s) offert(s)`, corps: `par ${qui}` };
    case 'sub': return { titre: `⭐ Nouvel abonné`, corps: qui };
    case 'resub': return { titre: `⭐ Réabonnement`, corps: `${qui}${ev.amount ? ' — ' + ev.amount + ' mois' : ''}` };
    case 'follow': return { titre: `➕ Nouveau follow`, corps: qui };
    default: return null;
  }
}

function meriteNotification(ev) {
  if (!reglesPush[ev.type]) return false;
  if (ev.type === 'cheer' && Number(ev.amount || 0) < Number(reglesPush.bitsMini || 0)) return false;
  return true;
}

async function notifierEvenement(ev) {
  // La condition d'abonnement est testée APRÈS le webhook : elle ne
  // concerne que les notifications web. L'y laisser en premier, comme
  // avant, aurait fait taire Discord aussi tant qu'aucun téléphone n'était
  // abonné — c'est-à-dire exactement dans le cas qu'on cherche à régler.
  if (!ev || !meriteNotification(ev)) return;
  const texte = texteNotification(ev);
  if (!texte) return;

  // Discord d'abord, et sans attendre : il n'a besoin ni de certificat ni
  // d'abonnement, donc c'est le chemin qui marche à coup sûr.
  if (discord.webhookDiscord()) {
    discord.envoyerDiscord({ ...texte, type: ev.type }).then((r) => {
      if (!r.ok) console.error('[pont] Notification Discord non envoyée : ' + r.erreur);
    });
  }

  if (!abonnementsPush.length) return;
  const perimes = [];
  await Promise.all(abonnementsPush.map(async (ab) => {
    try {
      const r = await envoyerPush(ab, { ...texte, type: ev.type });
      if (r.perime) perimes.push(ab.endpoint);
    } catch (e) {
      // Pas de réseau, service injoignable : on n'insiste pas, la
      // notification est une commodité et ne doit jamais bloquer le
      // traitement de l'événement lui-même.
    }
  }));
  if (perimes.length) {
    abonnementsPush = abonnementsPush.filter((a) => !perimes.includes(a.endpoint));
    persistPush();
  }
}

// Lancé une fois, au démarrage du pont, dans l’ordre fixé par server.js.
function demarrer() {
  abonnementsPush = Array.isArray(stockage.platformTokens.abonnementsPush) ? stockage.platformTokens.abonnementsPush : [];
  reglesPush = { ...REGLES_PUSH_DEFAUT, ...(stockage.platformTokens.reglesPush || {}) };
}
