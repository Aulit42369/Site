// ============================================================
//  Appareils reliés : qui, sur le Wi-Fi, peut piloter la régie
// ------------------------------------------------------------
//  Le PC où tourne la régie a toujours accès : c'est lui qui
//  détient les comptes. Tout AUTRE appareil du réseau (le
//  téléphone, une tablette) doit être relié une fois, en tapant
//  un code que le PC affiche. Il reçoit alors un cookie : une
//  longue suite aléatoire, dont le pont ne garde que l'empreinte,
//  dans tokens.json avec les autres accès. Sans ce cookie, un
//  appareil du réseau ne voit que les pages d'installation.
//
//  Ce module ne touche ni au réseau ni aux fichiers : le pont lui
//  passe de quoi lire et enregistrer la liste, et l'horloge
//  (remplacée par une fausse dans les contrôles).
// ============================================================
'use strict';
const crypto = require('crypto');

// Ni I, L, O, 0 ni 1 : rien qui se confonde en recopiant un code.
const ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
const NOM_COOKIE = 'regie_appareil';
const DUREE_CODE_MS = 15 * 60 * 1000;
// Codes valables en même temps : chaque ouverture de la page du QR code en
// demande un, le plus ancien cède sa place au-delà.
const CODES_MAX = 10;
const APPAREILS_MAX = 20;
// Codes faux tolérés : par adresse sur une minute, et toutes adresses
// confondues sur dix minutes. Avec 31 caractères sur 8 positions, deviner un
// code au hasard est déjà hors de portée ; ces limites ferment la porte à
// qui essaierait quand même en boucle.
const ESSAIS_PAR_ADRESSE = 5;
const ESSAIS_EN_TOUT = 50;
// Chrome ne garde pas un cookie plus de 400 jours. Le pont le renvoie,
// prolongé, chaque fois que l'appli s'ouvre (voir prolongation).
const DUREE_COOKIE_S = 400 * 24 * 3600;
// Mais le pont, lui, oublie un appareil qui n'a pas ouvert la régie depuis
// 90 jours (décision d'Olivier du 23/10) : un cookie volé sur un téléphone
// perdu ou vendu ne sert pas indéfiniment. Il faudra le relier à nouveau.
const DUREE_INACTIVITE_MS = 90 * 24 * 3600 * 1000;
// « Vu il y a… » : tenu à jour en mémoire, écrit dans tokens.json au plus
// une fois par heure (l'appli fait des dizaines de requêtes par minute).
const ECRIRE_VU_APRES_MS = 3600 * 1000;

function normaliserCode(texte) {
  const s = String(texte || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (s.length !== 8) return '';
  for (const c of s) if (!ALPHABET.includes(c)) return '';
  return s;
}

function formaterCode(s) {
  return s.slice(0, 4) + '-' + s.slice(4);
}

function empreinte(secret) {
  return crypto.createHash('sha256').update(String(secret)).digest('hex');
}

function lireCookie(entete) {
  for (const morceau of String(entete || '').split(';')) {
    const i = morceau.indexOf('=');
    if (i > 0 && morceau.slice(0, i).trim() === NOM_COOKIE) return morceau.slice(i + 1).trim();
  }
  return '';
}

// SameSite=Strict : une page d'un autre site ouverte sur le téléphone ne
// peut pas se servir du cookie. Pas de « Secure » : le même cookie doit
// valoir en http (adresse :4560) et en https (:4561), sans quoi un appareil
// relié sur l'une ne pourrait plus jamais l'être sur l'autre.
function enteteCookie(secret) {
  return NOM_COOKIE + '=' + secret + '; Path=/; Max-Age=' + DUREE_COOKIE_S + '; HttpOnly; SameSite=Strict';
}

function enteteCookieEfface() {
  return NOM_COOKIE + '=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict';
}

// Un nom lisible deviné d'après le navigateur, quand la personne n'en a pas
// donné : « Téléphone Android (Chrome) », « iPhone (Safari) »...
function nomParDefaut(ua) {
  const u = String(ua || '');
  const ipad = /iPad/.test(u) || (/Macintosh/.test(u) && /Mobile\//.test(u));
  const systeme = /iPhone/.test(u) ? 'iPhone'
    : ipad ? 'iPad'
      : /Android/.test(u) ? (/Mobile/.test(u) ? 'Téléphone Android' : 'Tablette Android')
        : /Windows/.test(u) ? 'PC Windows'
          : /Macintosh|Mac OS X/.test(u) ? 'Mac'
            : /CrOS/.test(u) ? 'Chromebook'
              : /Linux/.test(u) ? 'Ordinateur Linux'
                : 'Appareil';
  const navigateur = /; wv\)/.test(u) ? 'appli Android'
    : /SamsungBrowser\//.test(u) ? 'Samsung Internet'
      : /EdgA?\//.test(u) ? 'Edge'
        : /OPR\/|Opera/.test(u) ? 'Opera'
          : /Firefox\/|FxiOS/.test(u) ? 'Firefox'
            : /CriOS|Chrome\//.test(u) ? 'Chrome'
              : /Safari\//.test(u) ? 'Safari'
                : '';
  return navigateur ? systeme + ' (' + navigateur + ')' : systeme;
}

function nettoyerNom(nom, ua) {
  const propre = String(nom || '')
    .replace(/[\u0000-\u001f\u007f<>]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 40);
  return propre || nomParDefaut(ua);
}

// lire() rend la liste enregistrée (un tableau, ou rien) ; ecrire(liste)
// l'enregistre. maintenant() rend l'heure en millisecondes. oublies(ids) :
// appelé quand le pont oublie des appareils inactifs, pour emporter ce qui
// leur est lié (comme un retrait à la main).
function creerAppareils({ lire, ecrire, maintenant = () => Date.now(), journal = () => {}, oublies = () => {} }) {
  const codes = new Map();            // code normalisé → { expireA, par } (par : id de l'appareil qui l'a demandé, '' pour le PC)
  const echecsParAdresse = new Map(); // adresse → [heures des codes faux]
  let echecsTous = [];
  const vuEnMemoire = new Map();      // id → dernière requête

  function liste() {
    const l = lire();
    return Array.isArray(l) ? l.filter((a) => a && typeof a === 'object' && a.id && a.empreinte) : [];
  }

  function purger() {
    const t = maintenant();
    for (const [c, info] of codes) if (info.expireA <= t) codes.delete(c);
    for (const [adresse, heures] of echecsParAdresse) {
      const recentes = heures.filter((h) => t - h < 60 * 1000);
      if (recentes.length) echecsParAdresse.set(adresse, recentes);
      else echecsParAdresse.delete(adresse);
    }
    echecsTous = echecsTous.filter((h) => t - h < 10 * 60 * 1000);
  }

  function vuePublique(a) {
    return { id: a.id, nom: a.nom, creeA: a.creeA || 0, vuA: Math.max(a.vuA || 0, vuEnMemoire.get(a.id) || 0) };
  }

  // Oublie les appareils qui n'ont pas ouvert la régie depuis 90 jours, avec
  // leurs codes en attente. Rend le nombre d'appareils oubliés.
  function oublierInactifs() {
    const t = maintenant();
    const l = liste();
    const actif = (a) => t - Math.max(a.vuA || 0, a.creeA || 0, vuEnMemoire.get(a.id) || 0) < DUREE_INACTIVITE_MS;
    const partis = l.filter((a) => !actif(a));
    if (!partis.length) return 0;
    const ids = new Set(partis.map((a) => a.id));
    for (const id of ids) vuEnMemoire.delete(id);
    for (const [c, info] of codes) if (ids.has(info.par)) codes.delete(c);
    ecrire(l.filter(actif));
    for (const a of partis) journal('Appareil oublié (régie pas ouverte depuis 90 jours) : ' + a.nom + '.');
    oublies(ids);
    return partis.length;
  }

  // par : l'id de l'appareil relié qui le demande (rien pour le PC) : retirer
  // cet appareil annule aussi les codes qu'il avait obtenus.
  function nouveauCode(par) {
    purger();
    let s;
    do {
      s = '';
      for (let i = 0; i < 8; i++) s += ALPHABET[crypto.randomInt(ALPHABET.length)];
    } while (codes.has(s));
    while (codes.size >= CODES_MAX) codes.delete(codes.keys().next().value);
    const expireA = maintenant() + DUREE_CODE_MS;
    codes.set(s, { expireA, par: String(par || '') });
    return { code: formaterCode(s), expireA };
  }

  // L'appareil qui présente ce cookie, ou null.
  function reconnaitre(entete) {
    const secret = lireCookie(entete);
    if (secret.length < 32 || secret.length > 128) return null;
    oublierInactifs();
    const e = empreinte(secret);
    return liste().find((a) => a.empreinte === e) || null;
  }

  // À chaque requête d'un appareil relié.
  function noterVu(appareil) {
    const t = maintenant();
    vuEnMemoire.set(appareil.id, t);
    if (t - (appareil.vuA || 0) < ECRIRE_VU_APRES_MS) return;
    const l = liste();
    const a = l.find((x) => x.id === appareil.id);
    if (!a) return;
    a.vuA = t;
    ecrire(l);
  }

  // { code, nom, ua, adresse, entete } → { ok, appareil, secret } ou
  // { ok: false, raison: 'essais' | 'code' | 'plein', error }.
  function relier({ code, nom, ua, adresse, entete }) {
    purger();
    const t = maintenant();
    // Déjà relié (deuxième onglet, retour en arrière) : rien à refaire, et
    // surtout pas une deuxième ligne pour le même appareil.
    const deja = reconnaitre(entete);
    if (deja) return { ok: true, deja: true, appareil: vuePublique(deja) };

    const heures = echecsParAdresse.get(adresse) || [];
    if (heures.length >= ESSAIS_PAR_ADRESSE) {
      return { ok: false, raison: 'essais', error: 'Trop de codes faux d’affilée : attends une minute, puis réessaie.' };
    }
    if (echecsTous.length >= ESSAIS_EN_TOUT) {
      return { ok: false, raison: 'essais', error: 'Trop de codes faux tapés sur le réseau ces dernières minutes : attends dix minutes. Si ça recommence, un appareil du Wi-Fi essaie peut-être de deviner les codes.' };
    }
    const n = normaliserCode(code);
    const info = n ? codes.get(n) : null;
    if (!info || info.expireA <= t) {
      heures.push(t);
      echecsParAdresse.set(adresse, heures);
      echecsTous.push(t);
      journal('Code de liaison refusé (faux ou expiré), depuis ' + adresse + '.');
      return { ok: false, raison: 'code', error: 'Ce code n’est pas (ou plus) valable. Demande un nouveau code sur le PC : Réglages → Appareils reliés.' };
    }
    const l = liste();
    if (l.length >= APPAREILS_MAX) {
      return { ok: false, raison: 'plein', error: APPAREILS_MAX + ' appareils sont déjà reliés : retires-en un sur le PC (Réglages → Appareils reliés), puis réessaie avec le même code.' };
    }
    codes.delete(n); // un code ne sert qu'une fois
    const secret = crypto.randomBytes(32).toString('base64url');
    const appareil = { id: crypto.randomBytes(6).toString('hex'), nom: nettoyerNom(nom, ua), empreinte: empreinte(secret), creeA: t, vuA: t };
    ecrire([...l, appareil]);
    journal('Nouvel appareil relié : ' + appareil.nom + ', depuis ' + adresse + '.');
    return { ok: true, appareil: vuePublique(appareil), secret };
  }

  function retirer(id) {
    const l = liste();
    const reste = l.filter((a) => a.id !== String(id || ''));
    if (reste.length === l.length) return null;
    const parti = l.find((a) => a.id === String(id || ''));
    vuEnMemoire.delete(parti.id);
    // Ses codes encore valables ne doivent pas lui servir à revenir.
    for (const [c, info] of codes) if (info.par === parti.id) codes.delete(c);
    ecrire(reste);
    journal('Appareil retiré : ' + parti.nom + '.');
    return vuePublique(parti);
  }

  function retirerTous() {
    const l = liste();
    if (l.length) {
      ecrire([]);
      journal('Tous les appareils ont été retirés (' + l.length + ').');
    }
    vuEnMemoire.clear();
    // Plus aucun code en attente : un appareil retiré qui en avait demandé
    // d'avance aurait sinon relié un « nouvel » appareil dans le quart d'heure.
    codes.clear();
    return l.length;
  }

  return {
    nouveauCode,
    reconnaitre,
    noterVu,
    relier,
    retirer,
    retirerTous,
    oublierInactifs,
    liste: () => { oublierInactifs(); return liste().map(vuePublique); },
  };
}

module.exports = {
  creerAppareils,
  NOM_COOKIE,
  DUREE_CODE_MS,
  DUREE_INACTIVITE_MS,
  normaliserCode,
  nomParDefaut,
  lireCookie,
  enteteCookie,
  enteteCookieEfface,
};
