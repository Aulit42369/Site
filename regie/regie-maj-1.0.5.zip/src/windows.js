// ============================================================
//  Windows : type de réseau, lancement avec la session
// ------------------------------------------------------------
//  Le piège classique de Windows 11 (un Wi-Fi rangé en « Public »
//  bloque le téléphone), et la clé « Run » que le lanceur écrit
//  aussi. Ni droits administrateur, ni raccourci à fabriquer.
// ============================================================
'use strict';

module.exports = {
  analyserExportReg,
  analyserProfilsReseau,
  cheminLanceur,
  get CLE_RUN() { return CLE_RUN; },
  ecrireDemarrageAuto,
  lireDemarrageAuto,
  get NOM_RUN() { return NOM_RUN; },
  profilsReseau,
};

const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFile } = require('child_process');

// ---------- Windows : PowerShell ----------
// Une commande PowerShell passée en « -EncodedCommand » (UTF-16 en
// base64) : aucun problème de guillemets, d'accents ou d'espaces dans
// les chemins, quel que soit le nom d'utilisateur.
function powershell(script, delaiMs) {
  return new Promise((resolve) => {
    if (process.platform !== 'win32') { resolve({ ok: false, raison: 'pas Windows' }); return; }
    const encode = Buffer.from('[Console]::OutputEncoding=[System.Text.Encoding]::UTF8;' + script, 'utf16le').toString('base64');
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encode],
      { timeout: delaiMs || 8000, windowsHide: true, maxBuffer: 1024 * 1024 },
      (err, stdout) => {
        if (err) { resolve({ ok: false, raison: err.message }); return; }
        resolve({ ok: true, sortie: String(stdout || '') });
      });
  });
}

// Le type de réseau de chaque carte. Windows 11 range un nouveau Wi-Fi en
// « Public » par défaut — et en Public, le pare-feu bloque le téléphone
// même quand on a cliqué « Autoriser » à la première question.
function analyserProfilsReseau(sortie) {
  let d;
  try { d = JSON.parse(String(sortie || '').trim() || 'null'); } catch (e) { return null; }
  if (!d) return [];
  const liste = Array.isArray(d) ? d : [d];
  const CATEGORIES = { 0: 'public', 1: 'prive', 2: 'domaine', public: 'public', private: 'prive', domainauthenticated: 'domaine' };
  return liste.map((p) => ({
    nom: String(p.nom || p.Name || ''),
    carte: String(p.carte || p.InterfaceAlias || ''),
    categorie: CATEGORIES[String(p.categorie !== undefined ? p.categorie : p.NetworkCategory).toLowerCase()] || 'inconnu',
  }));
}

let cacheProfils = { quand: 0, valeur: null };
async function profilsReseau() {
  if (process.platform !== 'win32') return { disponible: false, profils: [] };
  if (Date.now() - cacheProfils.quand < 60000 && cacheProfils.valeur) return cacheProfils.valeur;
  const r = await powershell(
    'Get-NetConnectionProfile | ForEach-Object { [pscustomobject]@{ nom = [string]$_.Name; carte = [string]$_.InterfaceAlias; categorie = [string]$_.NetworkCategory } } | ConvertTo-Json -Compress',
  );
  const profils = r.ok ? analyserProfilsReseau(r.sortie) : null;
  const valeur = profils ? { disponible: true, profils } : { disponible: false, profils: [], raison: r.raison || 'réponse illisible' };
  cacheProfils = { quand: Date.now(), valeur };
  return valeur;
}

// ---------- Windows : démarrage automatique ----------
// Une valeur dans HKCU\...\Run : la même que celle qu'écrit le lanceur
// (Regie mobile.exe, menu « Lancer avec Windows »). Ni droits
// administrateur, ni raccourci à fabriquer.
const CLE_RUN = 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run';
const NOM_RUN = 'Regie mobile';

function reg(args) {
  return new Promise((resolve) => {
    execFile('reg.exe', args, { timeout: 8000, windowsHide: true }, (err, stdout, stderr) => {
      resolve({ code: err ? (typeof err.code === 'number' ? err.code : 1) : 0, sortie: String(stdout || ''), erreur: String(stderr || (err && err.message) || '') });
    });
  });
}

function cheminLanceur(dossier) {
  const parEnv = process.env.REGIE_LANCEUR_EXE;
  if (parEnv && fs.existsSync(parEnv)) return parEnv;
  const voisin = path.join(dossier, 'Regie mobile.exe');
  return fs.existsSync(voisin) ? voisin : '';
}

// La valeur actuelle de « Regie mobile » dans la clé Run. Lue par
// « reg export », qui écrit un fichier en UTF-16 — et SURTOUT PAS par
// « reg query », qui affiche dans l'ancienne page de code de la console :
// un chemin comme C:\Users\Jérôme\… en ressortait abîmé, et l'option
// paraissait toujours désactivée chez quiconque a un accent dans son nom
// d'utilisateur. Défaut trouvé en faisant tourner la régie sous Wine.
function desechapperReg(s) { return s.replace(/\\(.)/g, '$1'); }

function analyserExportReg(texte, nom) {
  for (const ligne of String(texte).split(/\r?\n/)) {
    const m = /^"((?:[^"\\]|\\.)*)"="((?:[^"\\]|\\.)*)"\s*$/.exec(ligne);
    if (m && desechapperReg(m[1]) === nom) return desechapperReg(m[2]);
  }
  return '';
}

async function lireValeurRun() {
  const fichier = path.join(os.tmpdir(), 'regie-run-' + process.pid + '-' + Date.now() + '.reg');
  const r = await reg(['export', CLE_RUN, fichier, '/y']);
  let texte = '';
  try {
    if (r.code === 0) {
      const brut = fs.readFileSync(fichier);
      texte = brut[0] === 0xff && brut[1] === 0xfe ? brut.slice(2).toString('utf16le') : brut.toString('utf8');
    }
  } catch (e) { /* clé absente ou illisible : rien d'enregistré */ }
  try { fs.unlinkSync(fichier); } catch (e) {}
  return analyserExportReg(texte, NOM_RUN);
}

async function lireDemarrageAuto(dossier) {
  if (process.platform !== 'win32') return { disponible: false, actif: false, raison: 'Réservé à Windows.' };
  const exe = cheminLanceur(dossier);
  const valeur = await lireValeurRun();
  // Actif seulement s'il pointe vers CE dossier : une ancienne copie de la
  // régie, déplacée ou supprimée, ne compte pas.
  const actif = !!valeur && !!exe && valeur.toLowerCase().includes(exe.toLowerCase());
  return {
    disponible: !!exe,
    actif,
    valeur: valeur || '',
    raison: exe ? '' : 'Lance la régie avec « Regie mobile.exe » pour pouvoir activer cette option.',
  };
}

async function ecrireDemarrageAuto(dossier, actif) {
  if (process.platform !== 'win32') throw new Error('Réservé à Windows.');
  const exe = cheminLanceur(dossier);
  if (!exe) throw new Error('Regie mobile.exe introuvable dans le dossier de la régie.');
  const r = actif
    ? await reg(['add', CLE_RUN, '/v', NOM_RUN, '/t', 'REG_SZ', '/d', '"' + exe + '" --demarrage', '/f'])
    : await reg(['delete', CLE_RUN, '/v', NOM_RUN, '/f']);
  // Supprimer une valeur absente n'est pas un échec : le résultat voulu est atteint.
  if (r.code !== 0 && actif) throw new Error('Windows a refusé : ' + (r.erreur || 'code ' + r.code));
  return lireDemarrageAuto(dossier);
}
