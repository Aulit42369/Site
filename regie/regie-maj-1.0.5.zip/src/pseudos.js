// ============================================================
//  Le pseudo de la chaîne
// ------------------------------------------------------------
//  Affiché partout : choisi dans l’appli, sinon celui du kit, de
//  config.js ou du compte Twitch.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  demarrer,
  nettoyerPseudo,
  pseudoParDefautServeur,
  rafraichirPseudo,
};

const fs = require('fs');
const path = require('path');

const parametres = require('./parametres.js');
const etatRegie = require('./etat-regie.js');
const stockage = require('./stockage.js');

// Le pseudo à utiliser quand l'appli n'en donne pas : celui du kit, sinon le
// nom du compte Twitch relié. Il n'est plus écrit en dur : une régie donnée à
// quelqu'un d'autre affichait le pseudo de la personne qui l'avait installée.
function pseudoParDefautServeur() {
  return pseudoChaine().pseudo;
}

// ------------------------------------------------------------
// Le pseudo de la chaîne
// ------------------------------------------------------------
// Affiché en haut de la régie, dans le titre de sa fenêtre et sur l'image
// d'annonce. La personne le change elle-même (Réglages → Ton pseudo) : plus
// de fichier à modifier, ni de kit à refaire. Dans l'ordre :
//   1. celui choisi dans l'appli, gardé dans tokens.json ;
//   2. celui du kit (kit.json), tant qu'elle n'en a pas choisi d'autre ;
//   3. celui de public/config.js, l'ancien réglage par fichier ;
//   4. le nom du compte Twitch relié.
const PSEUDO_MAX = 40;
function nettoyerPseudo(texte) {
  const propre = String(texte || '')
    // Caractères de contrôle : des espaces.
    .replace(/[\u0000-\u001f\u007f-\u009f\u2028\u2029]/g, ' ')
    // Invisibles et inverseurs de sens d'écriture : un U+202E collé par
    // mégarde retournait à l'affichage tout le texte qui le suit.
    .replace(/[\u200b-\u200f\u202a-\u202e\u2060-\u2064\u2066-\u2069\ufeff]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  // Coupé par caractère, pas par moitié d'émoji.
  return Array.from(propre).slice(0, PSEUDO_MAX).join('').trim();
}

// config.js n'est relu que s'il a changé.
let cacheConfigJs = { mtime: -1, pseudo: '' };
function pseudoDeConfigJs() {
  try {
    const chemin = path.join(parametres.PUBLIC_DIR, 'config.js');
    const st = fs.statSync(chemin);
    if (st.mtimeMs !== cacheConfigJs.mtime) {
      const m = /pseudo\s*:\s*("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')/.exec(fs.readFileSync(chemin, 'utf8'));
      let pseudo = '';
      if (m) {
        try {
          pseudo = m[1][0] === '"' ? JSON.parse(m[1]) : m[1].slice(1, -1).replace(/\\(.)/g, '$1');
        } catch (e) { pseudo = ''; }
      }
      cacheConfigJs = { mtime: st.mtimeMs, pseudo: nettoyerPseudo(pseudo) };
    }
  } catch (e) {
    cacheConfigJs = { mtime: -1, pseudo: '' };
  }
  return cacheConfigJs.pseudo;
}

function pseudoChaine() {
  const choisi = nettoyerPseudo(stockage.platformTokens.pseudo);
  if (choisi) return { pseudo: choisi, source: 'appli' };
  const kit = nettoyerPseudo(etatRegie.obsState.pseudoKit);
  if (kit) return { pseudo: kit, source: 'kit' };
  const config = pseudoDeConfigJs();
  if (config) return { pseudo: config, source: 'config' };
  const profil = etatRegie.obsState.twitchListen && etatRegie.obsState.twitchListen.profile;
  const twitch = nettoyerPseudo(profil && (profil.displayName || profil.login));
  if (twitch) return { pseudo: twitch, source: 'twitch' };
  return { pseudo: '', source: '' };
}

// Appelé à chaque envoi d'état, y compris (en théorie) avant que tout soit
// en place au démarrage : une erreur ici ne doit jamais bloquer un envoi.
// « diffuser » : prévenir aussi les appareils ouverts si le pseudo a changé
// sans passer par l'appli (config.js modifié, sauvegarde restaurée) — sans
// ça, ils gardaient l'ancien jusqu'au prochain changement d'état.
function rafraichirPseudo(diffuser) {
  try {
    const p = pseudoChaine();
    const change = p.pseudo !== etatRegie.obsState.pseudo || p.source !== etatRegie.obsState.pseudoSource;
    etatRegie.obsState.pseudo = p.pseudo;
    etatRegie.obsState.pseudoSource = p.source;
    if (change && diffuser) etatRegie.broadcastPatch({ pseudo: p.pseudo, pseudoSource: p.source });
  } catch (e) { /* on garde la valeur précédente */ }
}

// Lancé une fois, au démarrage du pont, dans l’ordre fixé par server.js.
function demarrer() {
  setInterval(() => rafraichirPseudo(true), 15000).unref();
}
