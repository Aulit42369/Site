// ============================================================
//  Les adresses de ce PC sur le réseau local
// ------------------------------------------------------------
//  Pour le QR code et les pages d’installation.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  getLocalIps,
  getLocalIpsDetaillees,
};

const os = require('os');

// Les adresses du PC sur le réseau, la plus probable en premier.
// Un PC de streamer a souvent VirtualBox, VMware, Hyper-V ou Docker
// installés, qui ajoutent chacun leur adresse : tout lister sans trier
// revenait à faire deviner laquelle essayer, et la première de la liste
// est rarement la bonne.
function getLocalIps() {
  const nets = os.networkInterfaces();
  const candidats = [];
  for (const nom of Object.keys(nets)) {
    for (const net of nets[nom] || []) {
      if (net.family !== 'IPv4' || net.internal) continue;
      const n = nom.toLowerCase();
      // Les cartes virtuelles portent presque toujours ces noms-là.
      const virtuelle = /virtualbox|vmware|hyper-v|docker|wsl|vethernet|loopback|tailscale|zerotier|tap|tun/.test(n);
      // 192.168.x.x est la plage des box domestiques : la bonne, en général.
      const domestique = net.address.startsWith('192.168.');
      candidats.push({ adresse: net.address, nom, score: (virtuelle ? -2 : 0) + (domestique ? 1 : 0) });
    }
  }
  candidats.sort((a, b) => b.score - a.score);
  return candidats.map((c) => c.adresse);
}

// Même chose, mais en gardant le nom de la carte réseau pour pouvoir
// l'afficher et expliquer pourquoi telle adresse est proposée.
function getLocalIpsDetaillees() {
  const nets = os.networkInterfaces();
  const out = [];
  for (const nom of Object.keys(nets)) {
    for (const net of nets[nom] || []) {
      if (net.family !== 'IPv4' || net.internal) continue;
      const n = nom.toLowerCase();
      const virtuelle = /virtualbox|vmware|hyper-v|docker|wsl|vethernet|loopback|tailscale|zerotier|tap|tun/.test(n);
      out.push({ adresse: net.address, carte: nom, virtuelle, domestique: net.address.startsWith('192.168.') });
    }
  }
  out.sort((a, b) => (b.domestique - a.domestique) || (a.virtuelle - b.virtuelle));
  return out;
}
