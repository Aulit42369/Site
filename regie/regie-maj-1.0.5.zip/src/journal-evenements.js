// ============================================================
//  Le journal des événements du stream
// ------------------------------------------------------------
//  Un fichier par jour dans data/, compteurs de messages, et le bilan
//  chiffré d’une journée ou d’un stream.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  demarrer,
  construireRecap,
  ecrireJournal,
  evenementsEntre,
  jourLocal,
  joursDisponibles,
  joursEntre,
  lireCompteurMessages,
  lireJournal,
};

const fs = require('fs');
const path = require('path');

const parametres = require('./parametres.js');
const stockage = require('./stockage.js');
const arret = require('./arret.js');

// Date au format AAAA-MM-JJ en heure locale. Volontairement pas en UTC :
// un stream qui finit à 1 h du matin doit rester rangé avec la soirée
// à laquelle il appartient pour qui le relit.
function jourLocal(d) {
  const x = d ? new Date(d) : new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${x.getFullYear()}-${p(x.getMonth() + 1)}-${p(x.getDate())}`;
}

// ------------------------------------------------------------
// Journal persistant des événements
// ------------------------------------------------------------
// Le tampon mémoire (500 événements) repartait de zéro à chaque
// redémarrage du pont : un raid ou un gros don passé pendant un
// redémarrage était définitivement perdu. Chaque événement est
// maintenant aussi écrit sur disque, une ligne JSON par événement,
// un fichier par jour — format choisi pour qu'une ligne corrompue
// n'empêche jamais de lire les autres.
const JOURNAL_PREFIXE = 'evenements-';
function cheminJournal(jour) {
  return path.join(parametres.DATA_DIR, `${JOURNAL_PREFIXE}${jour}.jsonl`);
}

// Les messages de tchat représentent ~90 % du volume du journal : sur un
// stream de 4 h actif, ils pèsent à eux seuls plusieurs centaines de Ko,
// pour une information qu'on ne relit jamais ligne par ligne. On n'en garde
// donc que le NOMBRE, qui est tout ce dont le bilan a besoin.
// Les messages restent évidemment visibles en direct dans l'appli : c'est
// uniquement leur archivage sur disque qui est abandonné.
const compteursMessages = new Map(); // jour -> nombre
const compteursSales = new Set();    // jours modifiés depuis le dernier enregistrement

function cheminCompteurs(jour) {
  return path.join(parametres.DATA_DIR, `compteurs-${jour}.json`);
}

function lireCompteurMessages(jour) {
  if (compteursMessages.has(jour)) return compteursMessages.get(jour);
  try {
    const n = JSON.parse(fs.readFileSync(cheminCompteurs(jour), 'utf8')).messages || 0;
    compteursMessages.set(jour, n);
    return n;
  } catch (e) {
    return 0;
  }
}

function incrementerCompteurMessages(jour) {
  compteursMessages.set(jour, lireCompteurMessages(jour) + 1);
  compteursSales.add(jour); // enregistré par lots, voir plus bas
}

// Enregistrement par lots : un message de tchat peut arriver plusieurs fois
// par seconde, écrire le fichier à chaque fois serait absurde. Toutes les
// 10 secondes suffit largement, et on réenregistre aussi à l'arrêt du pont.
//
// Seuls les jours réellement modifiés sont réécrits. Avant, un seul message
// reçu faisait réécrire le fichier de CHAQUE journée consultée depuis le
// démarrage — relire le bilan d'une semaine passée suffisait à les charger
// toutes, et le pont réécrivait alors sept fichiers toutes les 10 secondes
// pour rien.
function ecrireCompteurs() {
  if (!compteursSales.size || !stockage.ensureDataDir()) return;
  for (const jour of [...compteursSales]) {
    try {
      fs.writeFileSync(cheminCompteurs(jour), JSON.stringify({ jour, messages: compteursMessages.get(jour) || 0 }));
      compteursSales.delete(jour);
    } catch (e) {
      console.error('[pont] Compteur de messages non enregistré :', e.message);
    }
  }
}

function ecrireJournal(ev) {
  if (!stockage.ensureDataDir()) return;
  const jour = jourLocal(ev && ev.timestamp);
  if (ev && ev.type === 'chat') {
    incrementerCompteurMessages(jour);
    return;
  }
  try {
    fs.appendFileSync(cheminJournal(jour), JSON.stringify(ev) + '\n');
  } catch (e) {
    console.error('[pont] Écriture du journal impossible :', e.message);
  }
}

function lireJournal(jour) {
  try {
    return fs.readFileSync(cheminJournal(jour), 'utf8')
      .split('\n')
      .filter((l) => l.trim())
      .map((l) => { try { return JSON.parse(l); } catch (e) { return null; } })
      .filter(Boolean);
  } catch (e) {
    return [];
  }
}

function joursDisponibles() {
  try {
    const jours = new Set();
    for (const f of fs.readdirSync(parametres.DATA_DIR)) {
      if (f.startsWith(JOURNAL_PREFIXE) && f.endsWith('.jsonl')) {
        jours.add(f.slice(JOURNAL_PREFIXE.length, -'.jsonl'.length));
      } else if (f.startsWith('compteurs-') && f.endsWith('.json')) {
        // Une journée où il ne s'est passé que du tchat n'a pas de fichier
        // de journal, mais elle a bien eu lieu : elle doit rester consultable.
        jours.add(f.slice('compteurs-'.length, -'.json'.length));
      }
    }
    return [...jours].sort().reverse();
  } catch (e) {
    return [];
  }
}

// « A », « A et B », « A, B et C ».
function listeEnFrancais(noms) {
  if (noms.length <= 1) return noms.join('');
  return noms.slice(0, -1).join(', ') + ' et ' + noms[noms.length - 1];
}

// ------------------------------------------------------------
// Récapitulatif de fin de stream
// ------------------------------------------------------------
// Agrège une journée de journal en quelques chiffres et en un texte
// prêt à coller. Calculé à la demande plutôt qu'entretenu en continu :
// c'est instantané sur un fichier d'un jour, et ça reste juste même si
// le pont a redémarré en cours de route.
//
// « fenetre » ({ debut, fin, messages }) : le bilan d'UN stream précis,
// celui publié tout seul à la fin (voir publierBilanFinDeStream). Ses
// événements sont pris entre son début et sa fin, même s'il passe minuit.

// Les journées (AAAA-MM-JJ) que touche un intervalle, dans l'ordre.
function joursEntre(debut, fin) {
  const jours = [];
  const d = new Date(debut);
  d.setHours(12, 0, 0, 0); // midi : à l'abri des changements d'heure
  const dernier = jourLocal(fin);
  for (let i = 0; i < 8; i++) { // un stream de plus d'une semaine n'existe pas
    const j = jourLocal(d);
    jours.push(j);
    if (j >= dernier) break;
    d.setDate(d.getDate() + 1);
  }
  return jours;
}

// Les événements du journal entre deux instants, même à cheval sur minuit.
function evenementsEntre(debut, fin) {
  return joursEntre(debut, fin)
    .flatMap((j) => lireJournal(j))
    .filter((e) => Number(e.timestamp) >= debut && Number(e.timestamp) <= fin);
}

function construireRecap(jour, dureeSecondes, fenetre) {
  const evs = fenetre ? evenementsEntre(fenetre.debut, fenetre.fin) : lireJournal(jour);
  const compte = (type) => evs.filter((e) => e.type === type).length;
  // Les événements venant de Twitch rangent leur valeur numérique dans
  // « amount », quel que soit le type : bits pour un cheer, viewers pour
  // un raid, nombre d'abos pour un don. D'où cette somme générique.
  const somme = (type) => evs
    .filter((e) => e.type === type)
    .reduce((s, e) => s + (Number(e.amount) || 0), 0);

  const raids = evs.filter((e) => e.type === 'raid');
  // Tous ceux qui ont raidé, une fois chacun, dans l'ordre d'arrivée : le
  // message du bilan les remercie tous, pas seulement le plus gros raid.
  const raideurs = [...new Map(raids.filter((e) => e.user).map((e) => [String(e.user).toLowerCase(), String(e.user)])).values()];
  const plusGrosRaid = raids.reduce(
    (meilleur, e) => ((Number(e.amount) || 0) > (Number(meilleur.amount) || 0) ? e : meilleur),
    { amount: 0 }
  );

  const recap = {
    jour,
    duree: dureeSecondes || 0,
    follows: compte('follow'),
    abonnements: compte('sub') + compte('resub'),
    abosOfferts: somme('gift') || compte('gift'),
    bits: somme('cheer'),
    raids: raids.length,
    viewersRaides: raids.reduce((s, e) => s + (Number(e.amount) || 0), 0),
    plusGrosRaid: plusGrosRaid.amount ? { de: plusGrosRaid.user || '', viewers: plusGrosRaid.amount } : null,
    raideurs,
    // Les messages ne sont plus archivés ligne par ligne (voir ecrireJournal) :
    // le compteur du jour fait foi. L'ancien comptage sert de secours pour les
    // journées enregistrées avant ce changement.
    messages: fenetre ? (Number(fenetre.messages) || 0) : (lireCompteurMessages(jour) || compte('chat')),
    total: evs.length,
  };

  // Texte prêt à poster. On ne liste que ce qui s'est réellement produit :
  // une ligne "0 bits" n'apporte rien et donne un bilan qui sonne creux.
  const h = Math.floor(recap.duree / 3600);
  const m = Math.floor((recap.duree % 3600) / 60);
  const duree = h > 0 ? (m > 0 ? `${h} h ${String(m).padStart(2, '0')}` : `${h} h`) : `${m} min`;
  const lignes = [];
  if (recap.duree > 0) lignes.push(`⏱ ${duree} de direct`);
  if (recap.follows) lignes.push(`➕ ${recap.follows} nouveau${recap.follows > 1 ? 'x' : ''} follow${recap.follows > 1 ? 's' : ''}`);
  if (recap.abonnements) lignes.push(`⭐ ${recap.abonnements} abonnement${recap.abonnements > 1 ? 's' : ''}`);
  if (recap.abosOfferts) lignes.push(`🎁 ${recap.abosOfferts} abo${recap.abosOfferts > 1 ? 's' : ''} offert${recap.abosOfferts > 1 ? 's' : ''}`);
  if (recap.bits) lignes.push(`⚡ ${recap.bits} bits`);
  if (recap.raids) {
    // Merci à chacun, sans le nombre de viewers : un petit raid compte
    // autant qu'un gros dans un message de remerciement.
    let l = `🔥 ${recap.raids} raid${recap.raids > 1 ? 's' : ''} reçu${recap.raids > 1 ? 's' : ''}`;
    if (raideurs.length) l += ` — merci à ${listeEnFrancais(raideurs)} !`;
    lignes.push(l);
  }
  if (recap.messages) lignes.push(`💬 ${recap.messages} messages dans le tchat`);

  recap.texte = lignes.length
    ? 'Merci à tous pour ce stream !\n\n' + lignes.join('\n')
    : 'Aucun événement enregistré pour le ' + jour + '.';
  return recap;
}

// Lancé une fois, au démarrage du pont, dans l’ordre fixé par server.js.
function demarrer() {
  setInterval(ecrireCompteurs, 10000);
  // Les messages comptés depuis la dernière écriture (10 s au plus) : écrits
  // aussi quand le pont s'arrête (voir src/arret.js).
  arret.avantArret('compteurs de messages du tchat', ecrireCompteurs);
}
