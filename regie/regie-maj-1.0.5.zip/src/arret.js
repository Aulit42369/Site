// ============================================================
//  L’arrêt du pont
// ------------------------------------------------------------
//  Ce qui attend d’être écrit sur le disque (compteurs du tchat,
//  suivi d’installation…) s’inscrit ici. Un arrêt demandé l’écrit,
//  puis quitte : Ctrl+C ou fenêtre de start.bat fermée, ou
//  Regie mobile.exe qui ferme l’entrée du pont (voir lanceur/pont.c).
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  arreter,
  avantArret,
  demarrer,
};

const aEcrire = []; // { nom, ecrire }
let arretEnCours = false;
// Un envoi encore en route (le bilan sur Discord) : attendu 2 s au plus.
// Regie mobile.exe en laisse 5 au pont, 3 quand Windows s'éteint.
const ATTENTE_ENVOIS_MS = 2000;

// À appeler une fois par module, à son démarrage. « ecrire » écrit de façon
// synchrone ; il peut rendre une promesse pour un envoi réseau, que l'arrêt
// attend un peu (ATTENTE_ENVOIS_MS).
function avantArret(nom, ecrire) {
  aEcrire.push({ nom, ecrire });
}

function arreter(raison) {
  if (arretEnCours) return;
  arretEnCours = true;
  console.log('[pont] Arrêt demandé (' + raison + ') : enregistrement de ce qui attend ('
    + (aEcrire.map((a) => a.nom).join(', ') || 'rien') + ').');
  const envois = [];
  for (const { nom, ecrire } of aEcrire) {
    const echec = (e) => console.error('[pont] Arrêt : ' + nom + ' non enregistré — ' + ((e && e.message) || e));
    try {
      const r = ecrire();
      if (r && typeof r.then === 'function') envois.push(Promise.resolve(r).catch(echec));
    } catch (e) { echec(e); }
  }
  const terminer = () => { console.log('[pont] Arrêt propre terminé.'); process.exit(0); };
  if (!envois.length) return terminer();
  Promise.race([Promise.allSettled(envois), new Promise((r) => setTimeout(r, ATTENTE_ENVOIS_MS))]).then(() => {
    // Ce qui est arrivé pendant l'attente (un message du tchat) : réécrit.
    for (const { ecrire } of aEcrire) {
      try { const r = ecrire(); if (r && typeof r.then === 'function') r.catch(() => {}); } catch (e) { /* déjà signalé */ }
    }
    terminer();
  });
}

// Lancé une fois, au démarrage du pont, dans l’ordre fixé par server.js.
function demarrer() {
  // SIGHUP : sous Windows, la fenêtre de start.bat qu’on ferme. SIGBREAK :
  // Ctrl+Pause. Sans ces deux-là, fermer la fenêtre perdait les compteurs.
  for (const signal of ['SIGINT', 'SIGTERM', 'SIGHUP', 'SIGBREAK']) {
    try { process.on(signal, () => arreter(signal)); } catch (e) { /* signal inconnu ici */ }
  }
  // Lancé par Regie mobile.exe : le lanceur garde l’autre bout de l’entrée
  // standard, et la ferme pour demander l’arrêt. Avant, il coupait le
  // process net (jusqu’à 10 s de compteur de tchat perdues).
  if (process.env.LANCEUR_ARRET_PAR_ENTREE === '1' && process.stdin) {
    process.stdin.on('end', () => arreter('demandé par le lanceur'));
    process.stdin.on('error', () => arreter('entrée du lanceur fermée'));
    process.stdin.on('data', () => { /* rien n’est envoyé par là : on attend la fin */ });
    process.stdin.resume();
  }
}
