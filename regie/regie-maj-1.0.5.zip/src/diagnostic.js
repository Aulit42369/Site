// ============================================================
//  « Mon installation » : les faits du diagnostic
// ------------------------------------------------------------
//  Ce que le pont sait de son installation, sans jamais un secret.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  construireVerifications,
  dateLisible,
  faitsInstallation,
  ilYa,
  masquerSecrets,
  secretsConnus,
  texteRapport,
};

const fs = require('fs');

const parametres = require('./parametres.js');
const journalTechnique = require('./journal-technique.js');
const etatRegie = require('./etat-regie.js');
const twitchJeton = require('./twitch-jeton.js');
const stockage = require('./stockage.js');
const preuves = require('./preuves.js');
const notifications = require('./notifications.js');
const discord = require('./discord.js');
const serveurHttps = require('./serveur-https.js');
const reseauLocal = require('./reseau-local.js');
const fabriqueKit = require('./kit.js');
const windows = require('./windows.js');
const wkhtml = require('./wkhtml.js');

// Tout ce qui ressemble à un secret dans tokens.json, plus le jeton Twitch :
// la liste que le diagnostic passe au crible avant de sortir quoi que ce
// soit. Par le NOM des champs, pour couvrir aussi ceux qu'on ajoutera.
function secretsConnus() {
  const secrets = [];
  const parcourir = (obj, profondeur) => {
    if (!obj || typeof obj !== 'object' || profondeur > 4) return;
    for (const [cle, val] of Object.entries(obj)) {
      if (typeof val === 'string') {
        if (/token|secret|password|pass|key|webhook|jwt|refresh|cle|motdepasse/i.test(cle) && val.length >= 6) {
          secrets.push(val);
          // Le morceau final d'un webhook Discord est la partie secrète.
          if (/webhook/i.test(cle)) secrets.push(val.split('/').pop());
        }
      } else if (typeof val === 'object') parcourir(val, profondeur + 1);
    }
  };
  parcourir(stockage.platformTokens, 0);
  if (etatRegie.obsState.twitchCreds && etatRegie.obsState.twitchCreds.token) secrets.push(String(etatRegie.obsState.twitchCreds.token));
  if (twitchJeton.twitchRafraichissement && twitchJeton.twitchRafraichissement.refreshToken) secrets.push(twitchJeton.twitchRafraichissement.refreshToken);
  return secrets;
}

function infosCertificat() {
  if (!serveurHttps.etatHttps.actif) return { actif: false, erreur: serveurHttps.etatHttps.erreur };
  try {
    const x = new (require('crypto').X509Certificate)(fs.readFileSync(serveurHttps.CHEMIN_SERVEUR_CERT));
    const ips = String(x.subjectAltName || '').split(', ').filter((e) => e.startsWith('IP Address:'))
      .map((e) => e.slice('IP Address:'.length)).filter((ip) => ip !== '127.0.0.1');
    return { actif: true, expireLe: dateLisible(new Date(x.validTo).getTime()), couvre: ips.join(', ') };
  } catch (e) {
    return { actif: true, expireLe: '', couvre: '' };
  }
}

// Les faits du diagnostic. Aucune valeur secrète n'entre ici : des états,
// des noms, des dates, des nombres.
async function faitsInstallation() {
  const ips = reseauLocal.getLocalIpsDetaillees();
  const principale = ips.length ? ips[0] : null;
  let reseau = { categorie: process.platform === 'win32' ? 'inconnu' : 'non-windows', carte: principale ? principale.carte : '' };
  if (process.platform === 'win32' && principale) {
    const profils = await windows.profilsReseau();
    const p = profils.disponible ? profils.profils.find((x) => x.carte === principale.carte) : null;
    if (p) reseau = { categorie: p.categorie, carte: p.carte, nom: p.nom };
  }
  const kit = fabriqueKit.lireKit(parametres.RACINE);
  const creds = etatRegie.obsState.twitchCreds || {};
  const profil = etatRegie.obsState.twitchListen.profile;
  const [demarrageAuto, images] = await Promise.all([
    windows.lireDemarrageAuto(parametres.RACINE).catch((e) => ({ disponible: false, actif: false, raison: e.message })),
    wkhtml.wkhtmlDisponible(),
  ]);
  return {
    genereLe: Date.now(),
    version: { node: process.version, plateforme: process.platform, lanceur: parametres.LANCE_PAR_EXE ? 'exe' : 'autre' },
    pont: {
      depuisMin: Math.round(process.uptime() / 60),
      port: Number(parametres.PORT),
      adressePrincipale: principale ? principale.adresse : '',
      autresAdresses: ips.slice(1).map((x) => x.adresse),
    },
    reseau,
    obs: {
      statut: etatRegie.obsState.status,
      erreur: etatRegie.obsState.error,
      scenes: (etatRegie.obsState.scenes || []).length,
      auto: !!(stockage.platformTokens.obs && stockage.platformTokens.obs.auto),
      detection: (etatRegie.obsState.obsDetection && etatRegie.obsState.obsDetection.etat) || 'inconnu',
    },
    twitch: {
      statut: etatRegie.obsState.twitchListen.status,
      compte: profil ? (profil.displayName || profil.login || '') : '',
      mode: creds.mode === 'code' || creds.mode === 'expire' ? 'code' : (creds.token ? 'manuel' : ''),
      renouvelable: twitchJeton.connexionParCode(),
      avertissement: etatRegie.obsState.twitchListen.warning || '',
      erreur: etatRegie.obsState.twitchListen.error || '',
      codeDisponible: !!kit.twitchClientId,
    },
    telephone: { ...etatRegie.obsState.telephone, abonnementsPush: notifications.abonnementsPush.length },
    notifications: {
      discord: !!discord.webhookDiscord(),
      push: notifications.abonnementsPush.length,
      discordDernierEchec: preuves.suiviInstallation.discordDernierEchec || '',
    },
    https: infosCertificat(),
    demarrageAuto,
    options: {
      youtube: !!(stockage.platformTokens.youtube && stockage.platformTokens.youtube.refreshToken),
      // Dans une régie reçue en kit, Instagram ne se relie pas : un vieux
      // jeton resté dans tokens.json n'est pas compté.
      instagram: !kit.dansUnKit && !!(stockage.platformTokens.instagram && stockage.platformTokens.instagram.accessToken),
      tiktok: !!(stockage.platformTokens.tiktok && stockage.platformTokens.tiktok.refreshToken),
      bluesky: !!etatRegie.obsState.blueskyConnected,
      images: images.present,
      imagesRaison: images.raison,
    },
    // Les dernières erreurs seulement : c'est ce qui sert à dépanner, et le
    // texte reste court à copier dans un message.
    journal: journalTechnique.lireJournalTechnique(400).filter((l) => /\[(ERREUR|ALERTE)\]/.test(l)).slice(-12),
    kit: { contact: kit.contact, dansUnKit: kit.dansUnKit, raidCabane: twitchJeton.raidCabaneVisible(), erreur: kit.erreur },
  };
}

// ---------- Les vérifications, en vert, orange ou rouge ----------
function ilYa(quand) {
  if (!quand) return '';
  const s = Math.max(0, Math.round((Date.now() - quand) / 1000));
  if (s < 60) return 'à l’instant';
  if (s < 3600) return 'il y a ' + Math.round(s / 60) + ' min';
  if (s < 86400) return 'il y a ' + Math.round(s / 3600) + ' h';
  return 'il y a ' + Math.round(s / 86400) + ' j';
}

// L'année n'est donnée que si ce n'est pas l'année en cours : « jusqu'au
// 8 octobre » pour un certificat qui expire l'an prochain laissait croire
// qu'il avait expiré la veille.
function dateLisible(ms) {
  if (!ms) return '';
  try {
    const d = new Date(ms);
    const options = { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' };
    if (d.getFullYear() !== new Date().getFullYear()) options.year = 'numeric';
    return d.toLocaleString('fr-FR', options);
  } catch (e) { return new Date(ms).toISOString(); }
}

// f : les faits, rassemblés par faitsInstallation() — jamais de secret dedans.
function construireVerifications(f) {
  const v = [];
  const ajouter = (id, titre, etat, resume, detail, action) => v.push({ id, titre, etat, resume, detail: detail || '', action: action || null });

  // 1. Le pont
  ajouter('pont', 'La régie (le pont)', 'ok',
    'En marche depuis ' + (f.pont.depuisMin < 1 ? 'moins d’une minute' : f.pont.depuisMin + ' min'),
    'Node ' + f.version.node + ', ' + (f.version.lanceur === 'exe' ? 'lancée par Regie mobile.exe.' : 'lancée par start.bat ou à la main.'));

  // 2. Le réseau
  if (!f.pont.adressePrincipale) {
    ajouter('reseau', 'Réseau', 'erreur', 'Ce PC n’a pas d’adresse sur le réseau local',
      'Le téléphone ne pourra pas joindre la régie. Vérifie que le PC est branché à la box (Wi-Fi ou câble).');
  } else if (f.reseau.categorie === 'public') {
    ajouter('reseau', 'Réseau', 'erreur', 'Windows classe ton réseau en « Public » : il bloque le téléphone',
      'Paramètres Windows → Réseau et Internet → ' + (f.reseau.carte || 'Wi-Fi') + ' → choisis « Réseau privé ». '
      + 'Rien d’autre à changer : la régie sera joignable tout de suite.');
  } else {
    const profil = f.reseau.categorie === 'prive' ? ', réseau « Privé »' : (f.reseau.categorie === 'domaine' ? ', réseau d’entreprise' : '');
    ajouter('reseau', 'Réseau', 'ok', 'Adresse du PC : ' + f.pont.adressePrincipale + profil,
      f.pont.autresAdresses.length ? 'Autres adresses : ' + f.pont.autresAdresses.join(', ') : '');
  }

  // 3. OBS
  if (f.obs.statut === 'connected') {
    ajouter('obs', 'OBS', 'ok', 'Relié, ' + f.obs.scenes + ' scène' + (f.obs.scenes > 1 ? 's' : ''),
      f.obs.auto ? 'Réglages lus automatiquement dans OBS.' : 'Réglages saisis à la main.');
  } else if (f.obs.detection === 'desactive') {
    ajouter('obs', 'OBS', 'attention', 'Le serveur WebSocket d’OBS est désactivé',
      'Dans OBS : Outils → Paramètres du serveur WebSocket → coche « Activer le serveur WebSocket » → OK. La régie se branche toute seule ensuite.');
  } else if (f.obs.erreur) {
    ajouter('obs', 'OBS', 'erreur', 'Pas relié', f.obs.erreur);
  } else if (f.obs.detection === 'injoignable' || f.obs.statut === 'connecting') {
    ajouter('obs', 'OBS', 'attention', 'En attente d’OBS', 'Lance OBS : la régie se branche toute seule dès qu’il répond.');
  } else if (f.obs.detection === 'introuvable') {
    ajouter('obs', 'OBS', 'attention', 'OBS introuvable sur ce PC',
      'S’il tourne sur un autre ordinateur, renseigne son adresse dans Réglages → OBS.');
  } else {
    ajouter('obs', 'OBS', 'attention', 'Pas relié', 'Réglages → OBS.');
  }

  // 4. Twitch
  if (f.twitch.statut === 'connected' && f.twitch.compte) {
    let detail = f.twitch.mode === 'code' ? 'Connecté par code' : 'Connecté par jeton (méthode manuelle)';
    if (f.twitch.mode === 'code') detail += f.twitch.renouvelable ? ', avec renouvellement automatique.' : ', sans renouvellement possible.';
    else detail += '.';
    if (f.twitch.avertissement) detail += ' ' + f.twitch.avertissement;
    ajouter('twitch', 'Twitch', f.twitch.avertissement ? 'attention' : 'ok', 'Connecté : ' + f.twitch.compte, detail);
  } else if (f.twitch.erreur) {
    ajouter('twitch', 'Twitch', 'erreur', 'Pas connecté', f.twitch.erreur);
  } else if (f.twitch.statut === 'connecting') {
    ajouter('twitch', 'Twitch', 'attention', 'Connexion en cours…', '');
  } else {
    ajouter('twitch', 'Twitch', 'attention', 'Pas connecté',
      f.twitch.codeDisponible ? 'Réglages → Twitch → « Connecter avec un code ».' : 'Réglages → Twitch.');
  }

  // 5. Le téléphone
  if (f.telephone.appliHttpsA) {
    ajouter('telephone', 'Téléphone', 'ok', 'Appli ouverte en mode sécurisé ' + ilYa(f.telephone.appliHttpsA),
      'Certificat reconnu par le téléphone.' + (f.telephone.abonnementsPush ? ' Notifications activées sur ' + f.telephone.abonnementsPush + ' appareil' + (f.telephone.abonnementsPush > 1 ? 's.' : '.') : ''));
  } else if (f.telephone.certificatOkA) {
    ajouter('telephone', 'Téléphone', 'ok', 'Certificat installé (' + ilYa(f.telephone.certificatOkA) + ')',
      'Il reste à ouvrir la régie depuis la page du téléphone et à l’installer.');
  } else if (f.telephone.vuA) {
    ajouter('telephone', 'Téléphone', 'attention', 'Le téléphone a joint la régie ' + ilYa(f.telephone.vuA),
      'Mais le certificat n’est pas encore installé : sans lui, pas d’appli installée ni de notifications de l’appli.',
      { libelle: 'Afficher le QR code', lien: '/qr' });
  } else {
    ajouter('telephone', 'Téléphone', 'attention', 'Aucun téléphone n’a encore joint la régie',
      'Ouvre le QR code sur ce PC et vise-le avec l’appareil photo du téléphone.',
      { libelle: 'Afficher le QR code', lien: '/qr' });
  }

  // 6. Notifications
  const canaux = [];
  if (f.notifications.discord) canaux.push('Discord');
  if (f.notifications.push) canaux.push('appli (' + f.notifications.push + ' appareil' + (f.notifications.push > 1 ? 's' : '') + ')');
  if (canaux.length) {
    const echec = f.notifications.discordDernierEchec;
    ajouter('notifications', 'Notifications', echec ? 'attention' : 'ok', 'Actives : ' + canaux.join(' + '),
      echec ? 'Dernier envoi Discord refusé : ' + echec : '');
  } else {
    ajouter('notifications', 'Notifications', 'neutre', 'Aucune pour l’instant',
      'Facultatif. Le plus simple : Réglages → Notifications → Par Discord.');
  }

  // 7. HTTPS
  if (f.https.actif) {
    ajouter('https', 'Adresse sécurisée (https)', 'ok', 'Active jusqu’au ' + (f.https.expireLe || '?'),
      f.https.couvre ? 'Couvre : ' + f.https.couvre : '');
  } else {
    ajouter('https', 'Adresse sécurisée (https)', 'erreur', 'Indisponible', f.https.erreur || 'Le serveur https n’a pas démarré.');
  }

  // 8. Démarrage avec Windows
  if (f.demarrageAuto.disponible) {
    ajouter('demarrage', 'Lancer avec Windows', f.demarrageAuto.actif ? 'ok' : 'neutre',
      f.demarrageAuto.actif ? 'Oui : la régie démarre à l’ouverture de la session' : 'Non',
      f.demarrageAuto.actif ? '' : 'Pratique pour ne jamais oublier de lancer la régie avant un stream.');
  }

  // 9. Images d'annonce : une ligne à part seulement quand l'outil est là
  //    mais ne démarre pas — le cas qui se répare (un composant de Windows
  //    manque). Absent tout court, c'est une option comme une autre.
  if (!f.options.images && f.options.imagesRaison) {
    ajouter('images', 'Images d’annonce', 'attention', 'L’outil d’images ne démarre pas', f.options.imagesRaison);
  }

  // 10. Options
  const options = [];
  options.push('YouTube : ' + (f.options.youtube ? 'relié' : 'non relié (option avancée)'));
  options.push('images d’annonce : ' + (f.options.images ? 'disponibles'
    : (f.options.imagesRaison ? 'en panne (voir plus haut)' : 'wkhtmltoimage non installé')));
  if (f.options.bluesky) options.push('Bluesky relié');
  if (f.options.instagram) options.push('Instagram relié');
  if (f.options.tiktok) options.push('TikTok relié');
  ajouter('options', 'Options', 'neutre', 'Facultatives', options.join(' ; ') + '.');

  // 11. Reçue en kit ? (marque « recuDansUnKit » de kit.json, voir kit.dansUnKit)
  if (f.kit.erreur) {
    ajouter('kit', 'Régie reçue en kit', 'attention', 'non (kit.json illisible)',
      f.kit.erreur + ' — Instagram y reste proposé. Répare le fichier, ou demande un kit neuf à la personne qui te l’a donné.');
  } else {
    ajouter('kit', 'Régie reçue en kit', 'neutre', f.kit.dansUnKit ? 'oui' : 'non',
      f.kit.dansUnKit ? 'Instagram : la régie fabrique l’image, tu la publies toi-même. Raid · La Cabane : '
        + (f.kit.raidCabane ? 'activé.' : 'désactivé (Réglages → Connexion Twitch pour l’afficher).') : '');
  }

  return v;
}

// ---------- Le rapport à copier ----------
const SYMBOLES = { ok: '[OK]', attention: '[!]', erreur: '[X]', neutre: '[-]' };

function texteRapport(f, verifications, secrets) {
  const l = [];
  l.push('RÉGIE MOBILE — MON INSTALLATION');
  l.push('Généré le ' + dateLisible(f.genereLe));
  l.push('Windows : ' + (f.version.plateforme === 'win32' ? 'oui' : 'non (' + f.version.plateforme + ')') + ', Node ' + f.version.node);
  l.push('');
  for (const c of verifications) {
    l.push(SYMBOLES[c.etat] + ' ' + c.titre + ' — ' + c.resume);
    if (c.detail) l.push('     ' + c.detail);
  }
  if (f.journal && f.journal.length) {
    l.push('');
    l.push('DERNIERS MESSAGES DU PONT');
    for (const ligne of f.journal) l.push('  ' + ligne);
  }
  l.push('');
  l.push('(Ce texte ne contient aucun mot de passe ni jeton.)');
  return masquerSecrets(l.join('\n'), secrets);
}

// Filet de sécurité : même si un secret s'était glissé dans un message
// d'erreur ou le journal, il ne sortira pas d'ici. Seuls les secrets
// d'au moins 6 caractères sont cherchés — en dessous, on masquerait des
// mots ordinaires.
function masquerSecrets(texte, secrets) {
  let sortie = String(texte);
  const liste = (secrets || []).filter((s) => typeof s === 'string' && s.length >= 6)
    .sort((a, b) => b.length - a.length);
  for (const s of liste) sortie = sortie.split(s).join('•••');
  return sortie;
}
