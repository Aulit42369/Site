// ============================================================
//  La santé du direct
// ------------------------------------------------------------
//  Surveille les images perdues pendant un stream et prévient.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  demarrer,
  notifierSante,
};

const parametres = require('./parametres.js');
const obs = require('./obs.js');
const notifications = require('./notifications.js');
const discord = require('./discord.js');
const bilanStream = require('./bilan-stream.js');

// ------------------------------------------------------------
// Surveillance de la santé du direct
// ------------------------------------------------------------
// L'onglet Santé ne dit rien tant qu'on ne le regarde pas, et on ne le
// regarde pas quand on est en train de jouer. C'est pourtant la seule
// notification dont l'absence coûte vraiment quelque chose : un follow
// manqué se rattrape dans le journal, vingt minutes diffusées en bouillie,
// non.
//
// La surveillance est ici et pas dans l'appli, pour la même raison que
// l'écoute Twitch : le PC reste allumé, le téléphone s'endort.
let sanaPrecedent = null;         // dernier relevé, pour la différence
let sanaMauvais = 0;              // relevés consécutifs au-dessus du seuil
let sanaAlerteDepuis = 0;         // pour ne pas répéter l'alerte toutes les 10 s
const SANTE_SILENCE = 5 * 60 * 1000;    // pas plus d'une alerte par 5 min

async function notifierSante(titre, corps) {
  // Le webhook suit la même règle que les notifications web : si la
  // surveillance de la santé est éteinte, il se tait aussi.
  if (notifications.reglesPush.sante) {
    discord.envoyerDiscord({ titre, corps, type: 'sante' }).then((r) => {
      if (!r.ok && discord.webhookDiscord()) console.error('[pont] Notification Discord non envoyée : ' + r.erreur);
    });
  }
  if (!notifications.reglesPush.sante || !notifications.abonnementsPush.length) return;
  const perimes = [];
  await Promise.all(notifications.abonnementsPush.map(async (ab) => {
    try {
      const r = await notifications.envoyerPush(ab, { titre, corps, type: 'sante' });
      if (r.perime) perimes.push(ab.endpoint);
    } catch (e) { /* une notification ratée ne doit rien bloquer */ }
  }));
  if (perimes.length) {
    notifications.abonnementsPush = notifications.abonnementsPush.filter((a) => !perimes.includes(a.endpoint));
    notifications.persistPush();
  }
}

// Lancé une fois, au démarrage du pont, dans l’ordre fixé par server.js.
function demarrer() {
  setInterval(async () => {
    if (!obs.obsWs || obs.obsWs.readyState !== WebSocket.OPEN) {
      sanaPrecedent = null;
      sanaMauvais = 0;
      return;
    }
    let st;
    try { st = await obs.obsRequest('GetStreamStatus'); } catch (e) { return; }

    // C'est la réponse d'OBS qui fait foi, pas obsState.streaming : ce dernier
    // vient d'un événement, et un événement peut se perdre (reconnexion,
    // trame avalée). Le guetteur serait alors aveugle précisément au moment
    // où on a besoin de lui. Une requête de plus toutes les dix secondes est
    // un prix dérisoire pour ne pas dépendre de ça.
    if (!st.outputActive) {
      sanaPrecedent = null;
      sanaMauvais = 0;
      return;
    }
    // OBS diffuse : un signe de vie, qui datera la fin du stream si
    // personne ne la voit (OBS fermé d'un coup, écoute Twitch coupée).
    bilanStream.suiviStream.vivant(Date.now());

    const total = Number(st.outputTotalFrames) || 0;
    const perdues = Number(st.outputSkippedFrames) || 0;
    const precedent = sanaPrecedent;
    sanaPrecedent = { total, perdues };
    // Premier relevé du direct : pas de différence calculable, donc rien à
    // conclure. C'est exactement l'erreur que faisait l'onglet Santé en
    // affichant 0 % avant d'avoir mesuré.
    if (!precedent) return;

    const dTotal = total - precedent.total;
    const dPerdues = perdues - precedent.perdues;
    // Compteurs repartis à zéro (stream relancé) : on recommence proprement.
    if (dTotal <= 0 || dPerdues < 0) { sanaMauvais = 0; return; }

    const pourcent = (dPerdues / dTotal) * 100;
    const seuil = Number(notifications.reglesPush.santeSeuil) || 3;

    if (pourcent >= seuil) {
      sanaMauvais += 1;
      // Trois relevés d'affilée avant d'alerter : un pic d'une seconde arrive
      // à tout le monde et ne mérite pas de faire vibrer un téléphone en
      // pleine partie. Trente secondes de dégradation continue, si.
      if (sanaMauvais === parametres.SANTE_RELEVES_AVANT_ALERTE && Date.now() - sanaAlerteDepuis > SANTE_SILENCE) {
        sanaAlerteDepuis = Date.now();
        const message = `${pourcent.toFixed(1)} % d'images perdues depuis 30 s`;
        console.error('[pont] Santé du direct — ' + message);
        notifierSante('⚠️ Le direct décroche', message + ' — vérifie le débit ou baisse le bitrate.');
      }
    } else if (sanaMauvais >= parametres.SANTE_RELEVES_AVANT_ALERTE) {
      // Retour à la normale : on le dit une fois, pour ne pas laisser
      // quelqu'un paniquer sur une alerte déjà résolue.
      sanaMauvais = 0;
      console.log('[pont] Santé du direct — retour à la normale (' + pourcent.toFixed(1) + ' %)');
      notifierSante('✅ Le direct est stabilisé', 'Les images perdues sont retombées sous le seuil.');
    } else {
      sanaMauvais = 0;
    }
  }, parametres.SANTE_INTERVALLE);
}
