// ============================================================
//  Pages d'installation — petits outils communs
// ------------------------------------------------------------
//  Volontairement sans bibliothèque : ces pages doivent marcher
//  même si l'appli compilée ne s'affiche plus — c'est par elles
//  qu'on dépanne.
// ============================================================
'use strict';

window.Guide = (function () {
  function $(sel, racine) { return (racine || document).querySelector(sel); }

  async function json(url, options) {
    const r = await fetch(url, options);
    let d = {};
    try { d = await r.json(); } catch (e) { d = { ok: false, error: 'Réponse illisible du pont (' + r.status + ').' }; }
    return d;
  }

  function envoyer(url, corps) {
    return json(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(corps || {}) });
  }

  // Le presse-papiers moderne n'existe que sur une adresse sécurisée. Sur le
  // téléphone, la page est en http : on passe alors par l'ancienne méthode.
  async function copier(texte) {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(texte);
        return true;
      }
    } catch (e) { /* on tente l'autre méthode */ }
    const zone = document.createElement('textarea');
    zone.value = texte;
    zone.setAttribute('readonly', '');
    zone.style.position = 'fixed';
    zone.style.opacity = '0';
    document.body.appendChild(zone);
    zone.select();
    let ok = false;
    try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
    document.body.removeChild(zone);
    return ok;
  }

  // L'état du pont en direct : le même flux que l'appli. Le premier message
  // est l'état complet, les suivants peuvent n'être que des fragments.
  function ecouterEtat(surEtat) {
    let source = null;
    function ouvrir() {
      source = new EventSource('/api/obs/events');
      source.onmessage = (evt) => {
        let d;
        try { d = JSON.parse(evt.data); } catch (e) { return; }
        surEtat(d && d.__patch ? d.__patch : d);
      };
      source.onerror = () => {
        // Le pont redémarre ou le réseau a sauté : on réessaie tout seul.
        try { source.close(); } catch (e) {}
        setTimeout(ouvrir, 3000);
      };
    }
    ouvrir();
  }

  function ilYa(quand) {
    if (!quand) return '';
    const s = Math.max(0, Math.round((Date.now() - quand) / 1000));
    if (s < 60) return 'à l’instant';
    if (s < 3600) return 'il y a ' + Math.round(s / 60) + ' min';
    if (s < 86400) return 'il y a ' + Math.round(s / 3600) + ' h';
    return 'il y a ' + Math.round(s / 86400) + ' j';
  }

  // Allume une lampe, avec le petit éclat réservé aux bonnes nouvelles
  // quand elle passe au vert pour la première fois.
  function lampe(el, etat) {
    if (!el) return;
    const avant = el.dataset.etat || '';
    el.className = 'lampe ' + (etat || '');
    el.dataset.etat = etat || '';
    if (etat === 'ok' && avant && avant !== 'ok') {
      void el.offsetWidth; // relance l'animation
      el.classList.add('allumage');
    }
  }

  return { $, json, envoyer, copier, ecouterEtat, ilYa, lampe };
})();
