// ============================================================
//  Page /telephone : installer le certificat, vérifier, ouvrir
// ------------------------------------------------------------
//  La vérification ne croit personne sur parole : elle essaie de
//  charger une image depuis l'adresse https de la régie. Une image
//  sur un certificat non reconnu échoue sans proposer de
//  « continuer » — si elle arrive, le certificat est reconnu.
// ============================================================
'use strict';
(function () {
  const { $, json, lampe } = window.Guide;
  const ua = navigator.userAgent || '';
  const iphone = /iPhone|iPad|iPod/.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1);
  const android = /Android/.test(ua);
  let systeme = iphone ? 'iphone' : 'android';

  // Le pont sert le https sur le port suivant (4560 → 4561).
  const portHttp = Number(location.port) || (location.protocol === 'https:' ? 443 : 80);
  const portHttps = location.protocol === 'https:' ? portHttp : portHttp + 1;
  const baseHttps = 'https://' + location.hostname + ':' + portHttps;
  // La régie s'ouvre en passant par la page de liaison : le code apporté
  // par le QR code du PC (« #code= », jamais envoyé au pont en http ; « ?code= »
  // pour un ancien QR code) y est tapé tout seul, et un téléphone déjà relié
  // y passe sans s'arrêter.
  const code = (new URLSearchParams(location.hash.slice(1)).get('code') || new URLSearchParams(location.search).get('code') || '').toUpperCase().replace(/[^A-Z0-9-]/g, '').slice(0, 9);
  $('#bouton-ouvrir').href = baseHttps + '/relier?' + (code ? 'code=' + encodeURIComponent(code) + '&' : '')
    + 'retour=' + encodeURIComponent('/?installer=1');

  function afficherSysteme() {
    document.querySelectorAll('.seulement-android').forEach((el) => el.classList.toggle('cache', systeme !== 'android'));
    document.querySelectorAll('.seulement-iphone').forEach((el) => el.classList.toggle('cache', systeme !== 'iphone'));
    $('#systeme-nom').textContent = systeme === 'iphone' ? 'iPhone.' : 'Téléphone Android.';
    $('#changer-systeme').textContent = systeme === 'iphone' ? 'J’ai un Android' : 'J’ai un iPhone';
  }
  $('#changer-systeme').addEventListener('click', () => {
    systeme = systeme === 'iphone' ? 'android' : 'iphone';
    afficherSysteme();
  });
  afficherSysteme();

  // Ouverte sur un ordinateur par erreur ? On le dit, sans bloquer pour
  // autant (une tablette se présente parfois comme un ordinateur).
  const surOrdinateur = !iphone && !android && !/Mobile/.test(ua);
  if (surOrdinateur) $('#pas-un-telephone').classList.remove('cache');

  // L'empreinte de l'autorité, à comparer avec celle de la page /qr du PC.
  // Cette page voyage en http : c'est la copie du PC qui fait foi.
  json('/api/certificat/empreinte').then((d) => {
    $('#empreinte-autorite').textContent = d && d.ok ? d.empreinte : 'introuvable : regarde celle du PC';
  }).catch(() => {});

  $('#bouton-certificat').addEventListener('click', () => {
    $('#e-telecharger').classList.add('faite');
  });

  let reconnu = false;
  let essais = 0;
  function marquerReconnu() {
    if (reconnu) return;
    reconnu = true;
    lampe($('#verif-lampe'), 'ok');
    $('#verif').classList.add('ok');
    $('#verif-texte').textContent = 'Certificat reconnu par ce téléphone';
    $('#astuce').classList.add('cache');
    for (const id of ['#e-telecharger', '#e-installer', '#e-verifier']) $(id).classList.add('faite');
    $('#e-ouvrir').classList.add('active');
    const ouvrir = $('#bouton-ouvrir');
    ouvrir.removeAttribute('aria-disabled');
    ouvrir.removeAttribute('tabindex');
    $('#ouvrir-attente').classList.add('cache');
    ouvrir.classList.remove('second');
    ouvrir.classList.add('vert');
    // Un seul bouton appuyé à la fois : celui de l'étape à faire.
    $('#bouton-certificat').classList.add('second');
  }

  function essayer() {
    if (reconnu) return;
    essais += 1;
    // Au bout d'une minute d'échecs, le conseil qui débloque presque toujours.
    if (essais === 24) $('#astuce').classList.remove('cache');
    const img = new Image();
    let fini = false;
    const conclure = (ok) => {
      if (fini) return;
      fini = true;
      if (ok) marquerReconnu();
      else setTimeout(essayer, 2500);
    };
    img.onload = () => conclure(true);
    img.onerror = () => conclure(false);
    setTimeout(() => conclure(false), 6000);
    img.src = baseHttps + '/ping.gif?t=' + Date.now();
  }

  // Déjà en https sans avertissement : le certificat est forcément reconnu.
  if (location.protocol === 'https:' && window.isSecureContext) marquerReconnu();
  else essayer();
})();
