// ============================================================
//  Page /mon-installation : le diagnostic, et le texte à envoyer
// ============================================================
'use strict';
(function () {
  const { $, json, envoyer, copier, lampe } = window.Guide;
  let contact = '';

  function ligne(v) {
    const li = document.createElement('li');
    li.className = v.etat;
    const l = document.createElement('span');
    l.className = 'lampe ' + v.etat;
    const titre = document.createElement('span');
    titre.className = 'titre';
    titre.textContent = v.titre;
    const resume = document.createElement('span');
    resume.className = 'resume';
    resume.textContent = v.resume;
    li.append(l, titre, resume);
    if (v.detail) {
      const d = document.createElement('span');
      d.className = 'detail';
      d.textContent = v.detail;
      li.appendChild(d);
    }
    if (v.action && v.action.lien && v.action.lien.startsWith('/')) {
      const a = document.createElement('span');
      a.className = 'action';
      const lien = document.createElement('a');
      lien.href = v.action.lien;
      lien.textContent = v.action.libelle;
      a.appendChild(lien);
      li.appendChild(a);
    }
    return li;
  }

  async function charger() {
    const d = await json('/api/installation').catch(() => null);
    if (!d || !d.ok) {
      lampe($('#bilan-lampe'), 'erreur');
      $('#bilan-texte').textContent = (d && d.error) || 'La régie ne répond pas. Est-elle lancée ?';
      return;
    }
    const rack = $('#rack');
    rack.innerHTML = '';
    for (const v of d.verifications) rack.appendChild(ligne(v));

    const erreurs = d.verifications.filter((v) => v.etat === 'erreur').length;
    const attentions = d.verifications.filter((v) => v.etat === 'attention').length;
    const aRegler = erreurs + attentions;
    lampe($('#bilan-lampe'), erreurs ? 'erreur' : (attentions ? 'attention' : 'ok'));
    $('#bilan-texte').textContent = aRegler === 0
      ? 'Tout fonctionne.'
      : (aRegler === 1 ? 'Un point à régler.' : aRegler + ' points à régler.');

    contact = d.contact || '';
    $('#aide-contact').classList.toggle('cache', !contact);
    $('#aide-contact-nom').textContent = contact;

    const da = d.demarrageAuto || {};
    $('#ligne-demarrage').classList.toggle('cache', !da.disponible);
    if (da.disponible) $('#demarrage').checked = !!da.actif;

    // Sur le téléphone, le lien vers la page du QR code n'a pas de sens.
    if (!/^(localhost|127\.0\.0\.1|\[::1\])$/.test(location.hostname)) $('#lien-qr').classList.add('cache');
  }

  $('#demarrage').addEventListener('change', async (e) => {
    const voulu = e.target.checked;
    e.target.disabled = true;
    const r = await envoyer('/api/demarrage-auto', { actif: voulu }).catch(() => null);
    e.target.disabled = false;
    if (!r || !r.ok) {
      e.target.checked = !voulu;
      $('#demarrage-texte').textContent = 'Impossible : ' + ((r && r.error) || 'la régie ne répond pas.');
      return;
    }
    e.target.checked = !!r.actif;
    $('#demarrage-texte').textContent = r.actif
      ? 'C’est fait : la régie démarrera avec Windows.'
      : 'La régie ne démarrera plus avec Windows.';
    charger();
  });

  $('#copier').addEventListener('click', async () => {
    const retour = $('#copie-retour');
    retour.style.color = '';
    const r = await fetch('/api/installation/texte').catch(() => null);
    if (!r || !r.ok) { retour.style.color = 'var(--rouge)'; retour.textContent = 'La régie ne répond pas.'; return; }
    const texte = await r.text();
    const ok = await copier(texte);
    if (ok) {
      retour.textContent = 'Rapport copié. Colle-le dans un message à la personne qui t’aide.';
    } else {
      retour.style.color = 'var(--ambre)';
      retour.textContent = 'La copie automatique a été refusée : le rapport s’ouvre dans un nouvel onglet, copie-le à la main.';
      window.open('/api/installation/texte', '_blank');
    }
  });

  $('#actualiser').addEventListener('click', charger);
  // Se tient à jour tout seul pendant qu'on règle les problèmes un par un.
  setInterval(() => { if (!document.hidden) charger(); }, 15000);
  charger();
})();
