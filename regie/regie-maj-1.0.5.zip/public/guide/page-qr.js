// ============================================================
//  Page /qr (sur le PC) : le QR code, et ce que la régie a vu
// ------------------------------------------------------------
//  Les trois voyants ne s'allument que sur une PREUVE notée par
//  le pont : une requête du téléphone, le chargement d'une image
//  en https (certificat reconnu), puis le service worker de
//  l'appli demandé en https (appli ouverte en mode sécurisé).
// ============================================================
'use strict';
(function () {
  const { $, json, envoyer, ecouterEtat, ilYa, lampe } = window.Guide;
  let telephone = { vuA: 0, certificatOkA: 0, appliHttpsA: 0 };
  let ipChoisie = '';
  // Le code de liaison porté par le QR code : le téléphone qui le vise est
  // relié à la régie à la fin de l'installation, sans rien taper. Un code ne
  // sert qu'une fois et vit un quart d'heure : la page en redemande un.
  let liaison = null; // { code, expireA }
  let appareilsMaj = null; // pas encore reçu

  function afficherQr() {
    if (!ipChoisie) return;
    $('#qr').src = '/qr/telephone.svg?ip=' + encodeURIComponent(ipChoisie) + (liaison ? '&code=' + encodeURIComponent(liaison.code) : '');
  }

  function choisirAdresse(ip, port) {
    ipChoisie = ip;
    $('#adresse').textContent = 'http://' + ip + ':' + port + '/telephone';
    afficherQr();
  }

  async function nouveauCode() {
    const d = await envoyer('/api/appareils/code').catch(() => null);
    if (d && d.ok) {
      liaison = { code: d.code, expireA: d.expireA };
      $('#code-liaison').textContent = d.code;
    }
    afficherQr();
  }

  function afficherSignal() {
    const t = telephone;
    const cases = [
      { id: '#s-vu', fait: t.vuA, ok: 'Il a joint la régie ' + ilYa(t.vuA), attente: 'En attente du téléphone…', plusTard: 'Pas encore vu' },
      { id: '#s-cert', fait: t.certificatOkA, ok: 'Reconnu par le téléphone', attente: 'À installer depuis la page du téléphone', plusTard: 'Pas encore installé' },
      { id: '#s-appli', fait: t.appliHttpsA, ok: 'Ouverte en mode sécurisé', attente: 'À ouvrir depuis la page du téléphone', plusTard: 'Pas encore ouverte' },
    ];
    // La première étape non faite clignote doucement : c'est elle qu'on attend.
    let enAttenteTrouvee = false;
    for (const c of cases) {
      const bloc = $(c.id);
      const l = bloc.querySelector('.lampe');
      if (c.fait) {
        lampe(l, 'ok');
        bloc.classList.add('ok');
        bloc.querySelector('.etat').textContent = c.ok;
      } else {
        lampe(l, enAttenteTrouvee ? '' : 'attente');
        bloc.classList.remove('ok');
        bloc.querySelector('.etat').textContent = enAttenteTrouvee ? c.plusTard : c.attente;
        enAttenteTrouvee = true;
      }
    }
    $('#fini').classList.toggle('cache', !(t.vuA && t.certificatOkA && t.appliHttpsA));
  }

  async function charger() {
    const d = await json('/api/installation').catch(() => null);
    // Le port http : le QR code mène à la page /telephone, toujours en http.
    const port = location.protocol === 'https:' ? String(Number(location.port || 443) - 1) : (location.port || '80');
    if (d && d.ok && d.adresses && d.adresses.length) {
      const liste = d.adresses;
      choisirAdresse(liste[0].adresse, port);
      if (liste.length > 1) {
        const sel = $('#choix-adresse');
        sel.innerHTML = '';
        for (const a of liste) {
          const o = document.createElement('option');
          o.value = a.adresse;
          o.textContent = a.adresse + ' — ' + a.carte + (a.virtuelle ? ' (carte virtuelle)' : '');
          sel.appendChild(o);
        }
        sel.classList.remove('cache');
        sel.addEventListener('change', () => choisirAdresse(sel.value, port));
      }
      if (d.reseau && d.reseau.categorie === 'public') {
        $('#nom-carte').textContent = d.reseau.carte || 'Wi-Fi';
        $('#alerte-reseau').classList.remove('cache');
      }
      if (d.telephone) { telephone = d.telephone; afficherSignal(); }
    } else if (d && d.ok) {
      $('#adresse').textContent = 'Ce PC n’a pas d’adresse sur le réseau local : vérifie qu’il est connecté à la box.';
    } else {
      $('#adresse').textContent = 'La régie ne répond pas. Est-elle lancée ?';
    }
  }

  // L'empreinte de l'autorité : la page du téléphone demande de la comparer.
  json('/api/certificat/empreinte').then((d) => {
    $('#empreinte-autorite').textContent = d && d.ok ? d.empreinte : 'introuvable (relance la régie)';
  }).catch(() => {});

  ecouterEtat((etat) => {
    if (etat && etat.telephone) { telephone = etat.telephone; afficherSignal(); }
    // Un appareil vient d'être relié (peut-être avec ce code) : un neuf.
    if (etat && typeof etat.appareilsMaj === 'number') {
      if (appareilsMaj !== null && etat.appareilsMaj !== appareilsMaj) nouveauCode();
      appareilsMaj = etat.appareilsMaj;
    }
  });
  setInterval(afficherSignal, 30000); // « il y a 2 min » reste juste
  setInterval(() => { if (liaison && Date.now() > liaison.expireA - 60000) nouveauCode(); }, 20000);
  afficherSignal();
  nouveauCode().then(charger);
})();
