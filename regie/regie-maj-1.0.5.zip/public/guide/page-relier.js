// ============================================================
//  Page /relier : taper le code du PC, une fois par appareil
// ------------------------------------------------------------
//  Le pont refuse tout ce que demande un appareil du Wi-Fi qu'il
//  ne connaît pas (voir src/appareils.js). Cette page est l'une
//  des rares qui lui restent ouvertes : elle envoie le code, le
//  pont répond par un cookie, et la régie s'ouvre.
//
//  Arrivée avec « ?code= » (QR code du PC, page /telephone) : le
//  code est envoyé tout seul. « ?retour= » : où aller ensuite.
// ============================================================
'use strict';
(function () {
  const { $, json, envoyer, lampe } = window.Guide;
  const params = new URLSearchParams(location.search);

  // Seulement une adresse de la régie elle-même. Lue par le navigateur, qui
  // ignore tabulations et retours à la ligne (« /<tab>/autre-site » devient
  // « //autre-site ») et simplifie les « . » (« /.//autre-site » donne le
  // chemin « //autre-site ») : un examen du texte ne suffit pas. On garde
  // l'adresse COMPLÈTE si elle reste chez nous — jamais le chemin seul, qu'un
  // navigateur relirait comme une autre adresse —, sinon on ouvre la régie.
  const retour = (() => {
    try {
      const u = new URL(params.get('retour') || '/', location.href);
      return u.origin === location.origin && !u.pathname.startsWith('//') ? u.href : '/';
    } catch (e) { return '/'; }
  })();

  const ua = navigator.userAgent || '';
  if (/iPhone|Android.*Mobile/.test(ua)) $('#titre').textContent = 'Relier ce téléphone à la régie';
  else if (/iPad|Android/.test(ua)) $('#titre').textContent = 'Relier cette tablette à la régie';

  const champ = $('#code');
  // Majuscules, seulement les caractères d'un code, et le tiret posé tout
  // seul après le quatrième : on peut taper « abcd efgh » ou « ABCDEFGH ».
  function mettreEnForme(texte) {
    const s = String(texte || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
    return s.length > 4 ? s.slice(0, 4) + '-' + s.slice(4) : s;
  }
  champ.addEventListener('input', () => {
    const avant = champ.value;
    const apres = mettreEnForme(avant);
    if (apres !== avant) champ.value = apres;
    $('#message').classList.add('cache');
  });

  function ouvrirLaRegie(delai) {
    setTimeout(() => location.replace(retour), delai);
  }

  function montrerErreur(texte) {
    const m = $('#message');
    m.textContent = texte;
    m.classList.remove('cache');
    $('#relier').disabled = false;
    $('#relier').textContent = 'Relier';
    champ.focus();
  }

  let envoiEnCours = false;
  async function relier() {
    if (envoiEnCours) return;
    const code = mettreEnForme(champ.value);
    if (code.length !== 9) { montrerErreur('Le code a huit caractères, comme ABCD-EFGH.'); return; }
    envoiEnCours = true;
    $('#relier').disabled = true;
    $('#relier').textContent = 'Vérification…';
    let d;
    try {
      d = await envoyer('/api/appareils/relier', { code, nom: $('#nom').value });
    } catch (e) {
      d = { ok: false, error: 'La régie ne répond pas. Vérifie qu’elle tourne sur le PC, puis réessaie.' };
    }
    envoiEnCours = false;
    if (!d.ok) { montrerErreur(d.error || 'Liaison refusée.'); return; }
    $('#formulaire').classList.add('cache');
    $('#relie').classList.remove('cache');
    lampe($('#lampe-relie'), 'attente');
    lampe($('#lampe-relie'), 'ok');
    ouvrirLaRegie(900);
  }

  $('#formulaire').addEventListener('submit', (e) => { e.preventDefault(); relier(); });

  (async () => {
    let moi;
    try {
      moi = await json('/api/appareils/moi', { cache: 'no-store' });
    } catch (e) {
      $('#hors-ligne').classList.remove('cache');
      return;
    }
    if (moi && moi.ok && moi.relie) {
      $('#deja').classList.remove('cache');
      if (moi.pc) $('#deja-texte').innerHTML = '<strong>Le PC n’a pas besoin d’être relié :</strong> la régie s’ouvre directement.';
      ouvrirLaRegie(1200);
      return;
    }
    $('#formulaire').classList.remove('cache');
    $('#nom').value = (moi && moi.nomPropose) || '';
    const recu = mettreEnForme(params.get('code'));
    if (recu.length === 9) {
      champ.value = recu;
      relier();
    } else {
      champ.focus();
    }
  })();
})();
