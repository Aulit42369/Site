// ============================================================
//  Service worker — notifications, et installation en vraie appli
// ------------------------------------------------------------
//  Ce fichier tourne dans le navigateur même quand l'appli est
//  fermée. Deux rôles :
//
//   1. Recevoir les notifications envoyées par le pont.
//   2. Permettre l'installation en vraie appli. Chrome n'offre
//      « Installer l'application » que si un service worker sait
//      répondre quand le réseau manque — sans quoi on n'obtient
//      qu'un raccourci qui s'ouvre dans le navigateur, avec sa
//      barre d'adresse.
//
//  LA MISE EN CACHE EST DÉLIBÉRÉMENT « RÉSEAU D'ABORD ».
//  L'appli est servie par un PC du réseau local : servir une copie
//  en cache alors que le pont répond donnerait une vieille version
//  après chaque recompilation — exactement le genre de panne qu'on
//  cherche pendant une heure. Le cache ne sert donc QUE de filet
//  quand le réseau ne répond pas, et il est rafraîchi à chaque
//  passage réussi.
// ============================================================
const CACHE = 'regie-coque-v1';
// Juste de quoi afficher quelque chose hors réseau. Pas les appels d'API :
// une réponse d'API périmée serait pire que pas de réponse.
const COQUE = ['/', '/app.js', '/config.js', '/manifest.json', '/icons/icon-192.png'];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE)
      // addAll échoue en entier si un seul fichier manque : on les prend
      // donc un par un, et l'installation réussit même si config.js est
      // absent sur une installation toute neuve.
      .then((c) => Promise.all(COQUE.map((u) => c.add(u).catch(() => {}))))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then((noms) => Promise.all(noms.filter((n) => n !== CACHE).map((n) => caches.delete(n))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  // Jamais les API ni les flux d'événements : ils doivent toujours parler au
  // pont, et un flux mis en cache ne se terminerait jamais.
  if (url.origin !== self.location.origin) return;
  if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/oauth/')) return;

  e.respondWith(
    fetch(req)
      .then((rep) => {
        // On garde une copie fraîche au passage, pour le jour où le pont
        // sera éteint quand on ouvrira l'appli.
        if (rep && rep.ok) {
          const copie = rep.clone();
          caches.open(CACHE).then((c) => c.put(req, copie)).catch(() => {});
        }
        return rep;
      })
      .catch(() => caches.match(req).then((cache) => cache || caches.match('/')))
  );
});

self.addEventListener('push', (e) => {
  let d = {};
  try { d = e.data ? e.data.json() : {}; } catch (err) { d = { titre: 'Régie mobile', corps: e.data ? e.data.text() : '' }; }
  e.waitUntil(
    self.registration.showNotification(d.titre || 'Régie mobile', {
      body: d.corps || '',
      icon: '/icons/icon-192.png',
      badge: '/icons/icon-192.png',
      // Regroupe par type : dix dons d'affilée donnent une notification
      // qui se met à jour, pas dix notifications empilées.
      tag: d.type || 'regie',
      renotify: true,
    })
  );
});

self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  // Si l'appli est déjà ouverte quelque part, on la ramène au premier
  // plan plutôt que d'en ouvrir une deuxième copie.
  e.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((liste) => {
      for (const c of liste) {
        if ('focus' in c) return c.focus();
      }
      if (self.clients.openWindow) return self.clients.openWindow('/');
    })
  );
});
