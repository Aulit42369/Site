// ============================================================
//  Routes : notifications, Discord, bilan et annonces sur Discord
// ------------------------------------------------------------
//  Appelé par src/routes/index.js, une fois les barrières passées
//  (voir src/securite.js). « acces » dit qui appelle.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  traiter,
};

const etatRegie = require('../etat-regie.js');
const outilsHttp = require('../http-outils.js');
const stockage = require('../stockage.js');
const preuves = require('../preuves.js');
const journalEvenements = require('../journal-evenements.js');
const bilanStream = require('../bilan-stream.js');
const notifications = require('../notifications.js');
const discord = require('../discord.js');
const fabriqueKit = require('../kit.js');
const imageAnnonce = require('../image-annonce.js');

// Rend vrai si la demande a été traitée ici.
async function traiter(req, res, url, acces) {
  // ---------- Notifications push ----------
  if (req.method === 'GET' && url.pathname === '/api/push/cle') {
    // La clé publique VAPID, dont le navigateur a besoin pour s'abonner.
    outilsHttp.sendJson(res, 200, {
      ok: true,
      cle: notifications.assurerVapid().publique,
      abonnes: notifications.abonnementsPush.length,
      regles: notifications.reglesPush,
    });
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/push/abonner') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      const ab = body.abonnement;
      if (!ab || !ab.endpoint || !ab.keys || !ab.keys.p256dh || !ab.keys.auth) {
        outilsHttp.sendJson(res, 400, { ok: false, error: 'Abonnement incomplet.' });
        return true;
      }
      if (!notifications.endpointPushAccepte(ab.endpoint)) {
        outilsHttp.sendJson(res, 400, { ok: false, error: 'Ce navigateur passe par un service de notification que la régie ne connaît pas. Essaie avec Chrome, Firefox, Edge ou Safari.' });
        return true;
      }
      // Un même téléphone qui se réabonne ne doit pas créer de doublon,
      // sinon il reçoit la notification deux fois.
      notifications.abonnementsPush = notifications.abonnementsPush.filter((a) => a.endpoint !== ab.endpoint);
      // « par » : l'appareil abonné (vide pour le PC), pour l'oublier quand on le retire.
      notifications.abonnementsPush.push({ endpoint: ab.endpoint, keys: { p256dh: String(ab.keys.p256dh), auth: String(ab.keys.auth) }, ajouteA: Date.now(), par: acces && acces.appareil ? acces.appareil.id : '' });
      // 30 au plus (20 appareils reliés + le PC, avec de la marge) : les plus anciens partent.
      notifications.abonnementsPush = notifications.abonnementsPush.slice(-30);
      notifications.persistPush();
      outilsHttp.sendJson(res, 200, { ok: true, abonnes: notifications.abonnementsPush.length });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false, error: 'Requête invalide.' });
    }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/push/desabonner') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      notifications.abonnementsPush = notifications.abonnementsPush.filter((a) => a.endpoint !== body.endpoint);
      notifications.persistPush();
      outilsHttp.sendJson(res, 200, { ok: true, abonnes: notifications.abonnementsPush.length });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false, error: 'Requête invalide.' });
    }
    return true;
  }

  // ---------- Notifications par Discord ----------
  if (req.method === 'POST' && url.pathname === '/api/discord/webhook') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      const propose = String(body.webhook || '').trim();
      if (!propose) {
        stockage.platformTokens.discord = null;
        stockage.saveTokens();
        etatRegie.setState({ discordConfigured: false });
        outilsHttp.sendJson(res, 200, { ok: true, configure: false });
        return true;
      }
      if (!discord.webhookDiscordValide(propose)) {
        outilsHttp.sendJson(res, 200, {
          ok: false,
          error: 'Ce n’est pas une adresse de webhook Discord. Elle ressemble à '
            + 'https://discord.com/api/webhooks/123456789/AbCdEf… — dans Discord : clic droit sur le salon '
            + '→ Modifier le salon → Intégrations → Webhooks → Nouveau webhook → Copier l’URL.',
        });
        return true;
      }
      // On ESSAIE avant d'enregistrer, et on ne remplace l'ancien qu'en cas
      // de succès : même précaution que pour Bluesky, pour la même raison.
      // Un webhook qui ne marche pas ne doit pas chasser celui qui marchait.
      const precedent = stockage.platformTokens.discord;
      stockage.platformTokens.discord = { webhook: propose };
      // Envoi « brut » : l'échec d'un ESSAI ne doit pas être noté comme une
      // panne du webhook enregistré (page Mon installation).
      const essai = await discord.envoyerDiscordBrut({
        titre: '✅ Régie mobile connectée',
        corps: 'Ce salon recevra les raids, les gros dons, et les alertes quand le direct décroche.',
        type: 'test',
      });
      if (!essai.ok) {
        stockage.platformTokens.discord = precedent;
        outilsHttp.sendJson(res, 200, { ok: false, error: essai.erreur });
        return true;
      }
      stockage.saveTokens();
      if (preuves.suiviInstallation.discordDernierEchec) { preuves.suiviInstallation.discordDernierEchec = ''; preuves.enregistrerSuivi(); }
      etatRegie.setState({ discordConfigured: true });
      outilsHttp.sendJson(res, 200, { ok: true, configure: true });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false, error: 'Requête invalide.' });
    }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/discord/test') {
    const r = await discord.envoyerDiscord({
      titre: '🔔 Test de la régie',
      corps: 'Si tu lis ça sur ton téléphone, les notifications fonctionnent.',
      type: 'test',
    });
    outilsHttp.sendJson(res, 200, { ok: r.ok, error: r.ok ? '' : r.erreur });
    return true;
  }

  // Alerte de l'Agence Aulit (mission à valider, problème) : un message sur le salon des notifications.
  if (req.method === 'POST' && url.pathname === '/api/discord/alerte') {
    let body;
    try {
      body = await outilsHttp.readJsonBody(req);
    } catch {
      outilsHttp.sendJson(res, 400, { ok: false, error: 'Requête invalide.' });
      return true;
    }
    const r = await discord.envoyerDiscord({ titre: String(body.titre || 'Agence Aulit').slice(0, 250), corps: String(body.corps || '').slice(0, 1900), type: 'test' });
    outilsHttp.sendJson(res, 200, { ok: r.ok, error: r.ok ? '' : r.erreur });
    return true;
  }

  // ---------- Bilan de fin de stream sur Discord ----------
  // { actif } allume ou éteint la publication automatique ; { webhook } choisit
  // un autre salon que celui des notifications (« » : revenir à celui-là).
  if (req.method === 'POST' && url.pathname === '/api/bilan-discord') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      const actuel = { ...(stockage.platformTokens.bilanDiscord || {}) };
      if (typeof body.webhook === 'string') {
        const propose = body.webhook.trim();
        if (propose && !discord.webhookDiscordValide(propose)) {
          outilsHttp.sendJson(res, 200, {
            ok: false,
            error: 'Ce n’est pas une adresse de webhook Discord. Elle ressemble à '
              + 'https://discord.com/api/webhooks/123456789/AbCdEf… — dans Discord : clic droit sur le salon '
              + '→ Modifier le salon → Intégrations → Webhooks → Nouveau webhook → Copier l’URL.',
          });
          return true;
        }
        // Essayé avant d'être enregistré, comme le webhook des notifications :
        // une adresse qui ne marche pas ne remplace pas celle qui marchait.
        if (propose) {
          const essai = await discord.posterDiscord(propose, {
            content: '✅ Le bilan de fin de stream de la régie sera publié dans ce salon.',
            allowed_mentions: { parse: [] },
          });
          if (!essai.ok) { outilsHttp.sendJson(res, 200, { ok: false, error: essai.erreur }); return true; }
        }
        actuel.webhook = propose;
      }
      if (typeof body.actif === 'boolean') actuel.actif = body.actif;
      if (typeof body.semaine === 'boolean') actuel.semaine = body.semaine;
      stockage.platformTokens.bilanDiscord = actuel;
      stockage.saveTokens();
      etatRegie.setState({ bilanDiscord: bilanStream.etatBilanPourAppli() });
      if (typeof body.actif === 'boolean') console.log('[bilan] Publication automatique du bilan : ' + (body.actif ? 'activée.' : 'désactivée.'));
      if (typeof body.semaine === 'boolean') console.log('[bilan] Bilan du lundi 9 h : ' + (body.semaine ? 'activé.' : 'désactivé.'));
      outilsHttp.sendJson(res, 200, { ok: true, bilanDiscord: bilanStream.etatBilanPourAppli() });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false, error: 'Requête invalide.' });
    }
    return true;
  }

  // Un essai dans le salon du bilan : le bilan du jour, annoncé comme essai,
  // pour voir à quoi il ressemblera et où il arrivera.
  if (req.method === 'POST' && url.pathname === '/api/bilan-discord/essai') {
    const cible = bilanStream.webhookBilan();
    if (!cible) {
      outilsHttp.sendJson(res, 200, { ok: false, error: 'Aucun salon Discord : relie d’abord Discord (carte Notifications), ou colle l’adresse d’un autre salon.' });
      return true;
    }
    const recap = journalEvenements.construireRecap(journalEvenements.jourLocal(), 0);
    const r = await discord.posterDiscord(cible, {
      content: ('🧪 Essai de la régie : voici à quoi ressemblera le bilan publié à la fin du stream.\n\n' + recap.texte).slice(0, 2000),
      allowed_mentions: { parse: [] },
    });
    outilsHttp.sendJson(res, 200, { ok: r.ok, error: r.ok ? '' : r.erreur });
    return true;
  }

  // ---------- Annonces de l'Agence Aulit (salon public) ----------
  // L'Agence Aulit (outil local du PC) prépare les annonces, le streamer les
  // valide, puis elle demande ici de les publier : le webhook reste dans la
  // régie (tokens.json), jamais renvoyé à l'appli ni à l'agence.
  // { webhook } : essayé avant d'être enregistré ; « » le retire.
  // Annonces Discord : outil personnel d'Olivier (Agence Aulit), absent d'une régie reçue en kit.
  if (req.method === 'POST' && url.pathname.startsWith('/api/annonces-discord') && fabriqueKit.dansUnKit()) {
    outilsHttp.sendJson(res, 403, { ok: false, dansUnKit: true, error: 'Annonces Discord indisponibles dans une régie reçue en kit.' });
    return true;
  }
  if (req.method === 'POST' && url.pathname === '/api/annonces-discord') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      const propose = String(body.webhook || '').trim();
      if (!propose) {
        delete stockage.platformTokens.annoncesDiscord;
        stockage.saveTokens();
        etatRegie.setState({ annoncesDiscord: { configure: false } });
        console.log('[annonces] Salon des annonces Discord retiré.');
        outilsHttp.sendJson(res, 200, { ok: true });
        return true;
      }
      if (!discord.webhookDiscordValide(propose)) {
        outilsHttp.sendJson(res, 200, {
          ok: false,
          error: 'Ce n’est pas une adresse de webhook Discord. Elle ressemble à '
            + 'https://discord.com/api/webhooks/123456789/AbCdEf… — dans Discord : clic droit sur le salon '
            + '→ Modifier le salon → Intégrations → Webhooks → Nouveau webhook → Copier l’URL.',
        });
        return true;
      }
      // Même précaution que pour le bilan : une adresse qui ne marche pas ne
      // remplace pas celle qui marchait.
      const essai = await discord.posterDiscord(propose, {
        content: '✅ Les annonces de l’Agence Aulit seront publiées dans ce salon.',
        allowed_mentions: { parse: [] },
      });
      if (!essai.ok) { outilsHttp.sendJson(res, 200, { ok: false, error: essai.erreur }); return true; }
      stockage.platformTokens.annoncesDiscord = { webhook: propose };
      stockage.saveTokens();
      etatRegie.setState({ annoncesDiscord: { configure: true } });
      console.log('[annonces] Salon des annonces Discord enregistré.');
      outilsHttp.sendJson(res, 200, { ok: true });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false, error: 'Requête invalide.' });
    }
    return true;
  }

  // { titre, texte, image? } : une annonce déjà validée, publiée en embed.
  // L'image (facultative) arrive en data:image/jpeg|png;base64 ; son type est
  // lu dans ses premiers octets, jamais d'après le préfixe.
  if (req.method === 'POST' && url.pathname === '/api/annonces-discord/envoyer') {
    let body;
    try {
      body = await outilsHttp.readJsonBody(req);
    } catch (e) {
      if (e.tropGros) res.setHeader('Connection', 'close'); // le reste n'est pas lu
      outilsHttp.sendJson(res, e.tropGros ? 413 : 400, { ok: false, error: e.tropGros ? 'Image trop lourde : 8 Mo au plus.' : 'Requête invalide.' });
      return true;
    }
    const cible = discord.webhookAnnonces();
    if (!cible) {
      outilsHttp.sendJson(res, 200, { ok: false, error: 'Aucun salon d’annonces Discord : règle-le dans la Régie (Réglages → Annonces Discord).' });
      return true;
    }
    const titre = String(body.titre || '').trim().slice(0, 256);
    const texte = String(body.texte || '').trim().slice(0, 4000);
    if (!titre && !texte) {
      outilsHttp.sendJson(res, 200, { ok: false, error: 'Annonce vide : il faut au moins un titre ou un texte.' });
      return true;
    }
    let fichier = null;
    if (body.image) {
      const m = /^data:image\/(?:jpeg|png);base64,([A-Za-z0-9+/=\s]*)$/.exec(String(body.image));
      if (!m) {
        outilsHttp.sendJson(res, 200, { ok: false, error: 'Image refusée : seulement du JPEG ou du PNG (data:image/jpeg;base64,… ou data:image/png;base64,…).' });
        return true;
      }
      const octets = Buffer.from(m[1], 'base64');
      if (octets.length > imageAnnonce.TAILLE_MAX_FOND) {
        outilsHttp.sendJson(res, 200, { ok: false, error: 'Image trop lourde : 8 Mo au plus.' });
        return true;
      }
      const type = imageAnnonce.typeImage(octets);
      if (type !== 'jpg' && type !== 'png') {
        outilsHttp.sendJson(res, 200, { ok: false, error: 'Image refusée : ce n’est ni un JPEG ni un PNG.' });
        return true;
      }
      fichier = type === 'png'
        ? { nom: 'annonce.png', type: 'image/png', octets }
        : { nom: 'annonce.jpg', type: 'image/jpeg', octets };
    }
    const embed = { color: 0x9b5cff };
    if (titre) embed.title = titre;
    if (texte) embed.description = texte;
    if (fichier) embed.image = { url: 'attachment://' + fichier.nom };
    const r = await discord.posterDiscord(cible, { embeds: [embed], allowed_mentions: { parse: [] } }, fichier);
    console.log('[annonces] Annonce de l’Agence Aulit ' + (r.ok ? 'publiée sur Discord.' : 'non publiée : ' + r.erreur));
    outilsHttp.sendJson(res, 200, r.ok ? { ok: true } : { ok: false, error: r.erreur });
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/push/regles') {
    try {
      const body = await outilsHttp.readJsonBody(req);
      notifications.reglesPush = { ...notifications.reglesPush, ...(body.regles || {}) };
      notifications.persistPush();
      outilsHttp.sendJson(res, 200, { ok: true, regles: notifications.reglesPush });
    } catch (e) {
      outilsHttp.sendJson(res, 400, { ok: false, error: 'Requête invalide.' });
    }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/push/test') {
    if (!notifications.abonnementsPush.length) {
      outilsHttp.sendJson(res, 200, { ok: false, error: 'Aucun appareil abonné — active les notifications sur le téléphone d\u2019abord.' });
      return true;
    }
    const resultats = [];
    for (const ab of notifications.abonnementsPush) {
      try {
        const r = await notifications.envoyerPush(ab, { titre: '✅ Régie mobile', corps: 'Les notifications fonctionnent.', type: 'test' });
        resultats.push(r);
      } catch (e) {
        resultats.push({ ok: false, erreur: e.message });
      }
    }
    const reussis = resultats.filter((r) => r.ok).length;
    outilsHttp.sendJson(res, 200, {
      ok: reussis > 0,
      envoyes: reussis,
      total: resultats.length,
      error: reussis ? '' : (resultats[0] && (resultats[0].erreur || 'Envoi refusé par le service de notification.')),
    });
    return true;
  }
  return false;
}
