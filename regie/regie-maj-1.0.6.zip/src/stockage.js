// ============================================================
//  Les accès et réglages enregistrés (tokens.json)
// ------------------------------------------------------------
//  Lecture, écriture sûre, sauvegardes tournantes, et l’état rechargé
//  au démarrage.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  demarrer,
  ensureDataDir,
  lienWebOuVide,
  listerSauvegardes,
  persistSharedState,
  get platformTokens() { return platformTokens; },
  set platformTokens(valeur) { platformTokens = valeur; },
  renommerAvecPatience,
  get SAUVEGARDES_DIR() { return SAUVEGARDES_DIR; },
  saveTokens,
  get TOKENS_FILE() { return TOKENS_FILE; },
  get tokensIllisible() { return tokensIllisible; },
  tournerSauvegardes,
};

const fs = require('fs');
const path = require('path');

const parametres = require('./parametres.js');
const etatRegie = require('./etat-regie.js');
const twitchJeton = require('./twitch-jeton.js');

// tokens.json, à côté de server.js : tous les accès (OBS, Twitch, YouTube,
// Instagram, TikTok, Bluesky, Discord...) et les appareils reliés. Fichier
// sensible, à ne jamais partager : jamais exporté, jamais dans un kit.
const TOKENS_FILE = path.join(parametres.RACINE, 'tokens.json');
let platformTokens = {};
let tokensIllisible = false;
function loadTokens() {
  try {
    const lu = JSON.parse(fs.readFileSync(TOKENS_FILE, 'utf8'));
    // « null », un tableau ou un nombre se lisent très bien en JSON mais ne
    // sont pas des objets : la suite du démarrage écrivait alors dans le vide,
    // ou plantait avant même que le pont se mette à écouter — fenêtre noire
    // avec un message incompréhensible et téléphone qui ne joint plus rien.
    if (!lu || typeof lu !== 'object' || Array.isArray(lu)) {
      throw new Error('le contenu n\u2019est pas un ensemble de réglages');
    }
    platformTokens = lu;
  } catch (e) {
    platformTokens = {};
    // Un fichier présent mais illisible ne doit surtout pas être écrasé par
    // un objet vide : ce serait la perte définitive de tous les accès.
    if (fs.existsSync(TOKENS_FILE)) {
      tokensIllisible = true;
      const copie = TOKENS_FILE + '.illisible-' + Date.now();
      try { fs.copyFileSync(TOKENS_FILE, copie); } catch (e2) {}
      console.error('');
      console.error('⚠ tokens.json est illisible (' + e.message + ').');
      console.error('  Une copie a été gardée : ' + path.basename(copie));
      console.error('  Les connexions ne seront pas réécrites tant que le');
      console.error('  fichier n\'a pas été réparé ou supprimé.');
      console.error('');
    }
  }
}
// ------------------------------------------------------------
// Sauvegardes tournantes de tokens.json
// ------------------------------------------------------------
// C'est le fichier le plus précieux du dossier — tous les accès — et il
// n'avait aucun historique : la seule copie existante était celle faite
// quand il devenait illisible, donc trop tard. Une mauvaise manipulation,
// un « effacer toutes les données » de trop, un disque qui tousse, et tout
// était à reconnecter.
//
// On garde donc les cinq versions précédentes. Volontairement dans data/ et
// pas à côté de tokens.json : data/ est le dossier qu'on peut copier ou
// archiver, et ça évite qu'une sauvegarde traîne au même endroit que
// l'original quand on envoie le dossier à quelqu'un.
const SAUVEGARDES_DIR = path.join(parametres.RACINE, 'data', 'sauvegardes');
const SAUVEGARDES_MAX = 5;

// Renvoie vrai si une copie a réellement été faite. La distinction compte :
// sur une installation neuve il n'y a encore rien à copier, et considérer
// malgré tout la sauvegarde comme « faite » privait toute la première
// session de filet — alors que c'est justement pendant celle-là qu'on
// branche ses comptes un par un.
function tournerSauvegardes() {
  // Rien à sauvegarder s'il n'y a pas encore de fichier.
  if (!fs.existsSync(TOKENS_FILE)) return false;
  try {
    fs.mkdirSync(SAUVEGARDES_DIR, { recursive: true });
    const horodatage = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const destination = path.join(SAUVEGARDES_DIR, `tokens-${horodatage}.json`);
    // Si une sauvegarde de la même seconde existe déjà, elle fait l'affaire :
    // deux enregistrements rapprochés n'apportent rien de plus.
    if (!fs.existsSync(destination)) fs.copyFileSync(TOKENS_FILE, destination);

    const anciennes = fs.readdirSync(SAUVEGARDES_DIR)
      .filter((f) => /^tokens-.*\.json$/.test(f))
      .sort()
      .reverse();
    for (const f of anciennes.slice(SAUVEGARDES_MAX)) {
      try { fs.unlinkSync(path.join(SAUVEGARDES_DIR, f)); } catch (e) {}
    }
    return true;
  } catch (e) {
    // Une sauvegarde ratée ne doit jamais empêcher l'enregistrement lui-même.
    console.error('[pont] Sauvegarde de tokens.json impossible :', e.message);
    return false;
  }
}

// Une seule sauvegarde par démarrage du pont, prise avant la première
// écriture. Sauvegarder à CHAQUE écriture noierait les cinq emplacements en
// quelques minutes — le minuteur, la check-list et les réglages écrivent
// souvent — et la plus ancienne version disponible aurait dix minutes. Avec
// une par démarrage, on garde l'état d'avant les cinq dernières sessions,
// c'est-à-dire exactement ce qu'on veut retrouver après une fausse manœuvre.
let sauvegardeFaite = false;

// Renvoie vrai si tokens.json est bien écrit : une route qui confirme un
// changement à l'écran doit pouvoir dire la vérité.
function saveTokens() {
  if (tokensIllisible) return false; // ne pas détruire ce qui reste récupérable
  // Le drapeau ne se lève que si une copie a vraiment eu lieu : sur une
  // installation neuve, la première écriture crée le fichier sans rien à
  // sauvegarder, et c'est la deuxième qui prend la première copie.
  if (!sauvegardeFaite) sauvegardeFaite = tournerSauvegardes();
  try {
    // Écriture atomique : une coupure de courant en plein enregistrement
    // laissait un fichier tronqué, donc tous les accès perdus.
    const tmp = TOKENS_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(platformTokens, null, 2));
    renommerAvecPatience(tmp, TOKENS_FILE);
    return true;
  } catch (e) {
    console.error('[pont] Enregistrement de tokens.json impossible :', e.message);
    return false;
  }
}

// Sous Windows, un antivirus ou OneDrive (le Bureau y est synchronisé par
// défaut) peut tenir le fichier une fraction de seconde : le renommage
// échoue alors avec EPERM ou EBUSY. On réessaie un peu, puis on écrit
// directement plutôt que de perdre l'enregistrement — c'est vital pour le
// jeton Twitch de la connexion par code, qui ne sert qu'une fois : le
// perdre, c'est perdre la connexion au prochain renouvellement.
function renommerAvecPatience(source, destination) {
  let derniere = null;
  for (let essai = 0; essai < 6; essai += 1) {
    try { fs.renameSync(source, destination); return; } catch (e) {
      derniere = e;
      if (e.code !== 'EPERM' && e.code !== 'EBUSY' && e.code !== 'EACCES') break;
      Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 60);
    }
  }
  try {
    fs.writeFileSync(destination, fs.readFileSync(source));
    try { fs.unlinkSync(source); } catch (e) {}
    console.error('[pont] tokens.json enregistré sans renommage (' + (derniere && derniere.code) + ').');
  } catch (e) {
    throw derniere || e;
  }
}

// Liste des sauvegardes disponibles, pour l'appli et pour qui veut
// restaurer à la main.
function listerSauvegardes() {
  try {
    return fs.readdirSync(SAUVEGARDES_DIR)
      .filter((f) => /^tokens-.*\.json$/.test(f))
      .sort()
      .reverse()
      .map((f) => {
        const p = path.join(SAUVEGARDES_DIR, f);
        let taille = 0, quand = 0;
        try { const st = fs.statSync(p); taille = st.size; quand = st.mtimeMs; } catch (e) {}
        return { fichier: f, taille, quand };
      });
  } catch (e) {
    return [];
  }
}

// Recopie les champs partagés (clips publiés, identifiants Twitch, stats de
// session, infos de stream programmées) dans tokens.json à chaque changement,
// en plus de les diffuser en direct.
function persistSharedState() {
  platformTokens.publishedClips = etatRegie.obsState.publishedClips;
  platformTokens.twitch = etatRegie.obsState.twitchCreds;
  platformTokens.sessionHistory = etatRegie.obsState.sessionHistory;
  platformTokens.preparedStreamInfo = etatRegie.obsState.preparedStreamInfo;
  platformTokens.infosStreamPrecedentes = etatRegie.obsState.infosStreamPrecedentes;
  saveTokens();
}
// Une adresse de clip publié devient un lien cliquable dans l'appli : une
// adresse web (http ou https), ou rien. « javascript:… », envoyé par un
// appareil relié, s'exécutait sinon sur le PC au clic, avec ses droits.
function lienWebOuVide(u) {
  const t = String(u || '').trim();
  try { return /^https?:$/.test(new URL(t).protocol) ? t : ''; } catch (e) { return ''; }
}
// Les clips publiés relus au démarrage, adresses vérifiées (un fichier écrit
// avant ce contrôle peut en contenir une mauvaise).
function clipsPubliesSurs(clips) {
  const propres = {};
  if (!clips || typeof clips !== 'object') return propres;
  for (const [id, parPlateforme] of Object.entries(clips)) {
    if (id === '__proto__' || !parPlateforme || typeof parPlateforme !== 'object') continue;
    propres[id] = {};
    for (const [plateforme, info] of Object.entries(parPlateforme)) {
      propres[id][plateforme] = { ...(info && typeof info === 'object' ? info : {}), url: lienWebOuVide(info && info.url) };
    }
  }
  return propres;
}

function ensureDataDir() {
  try { fs.mkdirSync(parametres.DATA_DIR, { recursive: true }); return true; }
  catch (e) { console.error('[pont] Dossier data/ impossible à créer :', e.message); return false; }
}

// Lancé une fois, au démarrage du pont, dans l’ordre fixé par server.js.
function demarrer() {
  loadTokens();
  etatRegie.obsState.publishedClips = clipsPubliesSurs(platformTokens.publishedClips);
  etatRegie.obsState.twitchCreds = platformTokens.twitch || { clientId: '', token: '' };
  // Connexion par code : le jeton de renouvellement, rangé à part (jamais
  // dans obsState, voir enregistrerJetonsTwitch).
  twitchJeton.twitchRafraichissement = (platformTokens.twitchAppareil && platformTokens.twitchAppareil.refreshToken)
    ? { refreshToken: String(platformTokens.twitchAppareil.refreshToken), clientId: String(platformTokens.twitchAppareil.clientId || '') }
    : null;
  etatRegie.obsState.youtubeConfigure = !!(platformTokens.youtube && platformTokens.youtube.refreshToken);
  twitchJeton.rafraichirKitDansEtat();
  etatRegie.obsState.blueskyConnected = !!(platformTokens.bluesky && platformTokens.bluesky.handle && platformTokens.bluesky.appPassword);
  etatRegie.obsState.blueskyHandle = (platformTokens.bluesky && (platformTokens.bluesky.pseudo || platformTokens.bluesky.handle)) || '';
  etatRegie.obsState.imgbbConfigured = !!(platformTokens.imgbb && platformTokens.imgbb.apiKey);
  etatRegie.obsState.discordConfigured = !!(platformTokens.discord && platformTokens.discord.webhook);
  etatRegie.obsState.annoncesDiscord = { configure: !!(platformTokens.annoncesDiscord && platformTokens.annoncesDiscord.webhook) };
  if (Array.isArray(platformTokens.sessionHistory)) {
    etatRegie.obsState.sessionHistory = platformTokens.sessionHistory;
  } else if (platformTokens.sessionStats) {
    // Ancien format {lastEnd, previousEnd} : on récupère ce qu'il y avait pour ne pas perdre l'historique existant.
    etatRegie.obsState.sessionHistory = [platformTokens.sessionStats.previousEnd, platformTokens.sessionStats.lastEnd].filter(Boolean);
  } else {
    etatRegie.obsState.sessionHistory = [];
  }
  etatRegie.obsState.preparedStreamInfo = platformTokens.preparedStreamInfo || { title: '', categoryId: '', categoryName: '', tags: [] };
  etatRegie.obsState.infosStreamPrecedentes = platformTokens.infosStreamPrecedentes || null;
}
