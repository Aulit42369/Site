// ============================================================
//  Connexion Twitch « par code » (Device Code Grant Flow)
// ------------------------------------------------------------
//  L'ancienne méthode demandait de créer une application sur la
//  console développeur de Twitch, de recopier un Client ID, puis
//  de copier une adresse depuis la barre du navigateur. Infaisable
//  pour quelqu'un qui n'a jamais vu une console développeur.
//
//  Ici : le pont demande un code à Twitch, la personne l'ouvre sur
//  twitch.tv/activate (le lien le contient déjà), clique sur
//  « Autoriser », et c'est fini. Le pont attend la réponse de son
//  côté.
//
//  Le Client ID vient du kit (kit.json), préparé une fois pour
//  toutes par la personne qui installe la régie. Il doit être de
//  type « Public » sur la console Twitch : c'est le type prévu par
//  Twitch pour une appli qui tourne chez quelqu'un, sans secret à
//  cacher.
//
//  Faits vérifiés dans la documentation de Twitch (oct. 2026) :
//   • POST /oauth2/device  {client_id, scopes}  → device_code,
//     user_code, verification_uri, expires_in, interval
//   • POST /oauth2/token   {client_id, scopes, device_code,
//     grant_type=urn:ietf:params:oauth:grant-type:device_code}
//     → 400 « authorization_pending » tant que la personne n'a pas
//     autorisé
//   • jeton d'accès valable 4 h ; jeton de renouvellement à usage
//     UNIQUE, valable 30 jours, renouvelable sans secret pour un
//     client public.
// ============================================================
'use strict';

// Les permissions demandées. La MÊME liste que dans
// public/src/domaines/twitch.js (ancienne méthode) : un contrôle de
// verif/ compare les deux, une divergence ferait marcher une fonction
// avec une méthode de connexion et pas avec l'autre.
const SCOPES_TWITCH = [
  'moderator:read:followers', 'channel:read:subscriptions', 'bits:read', 'user:read:chat',
  'user:write:chat', 'channel:manage:broadcast', 'channel:manage:clips', 'moderator:manage:shoutouts',
  'channel:edit:commercial', 'channel:manage:vips', 'channel:manage:moderators',
  'moderator:manage:banned_users', 'channel:read:hype_train', 'channel:manage:raids',
  'channel:manage:redemptions', 'channel:manage:polls', 'channel:manage:predictions',
  'channel:manage:schedule',
];

// Droits réservés à la régie d'Olivier (outils personnels comme l'Agence Aulit) : jamais demandés par une
// régie reçue en kit, où rien ne s'en sert. Lu à chaque connexion (kit.json peut changer).
const DROITS_HORS_KIT = ['channel:manage:schedule'];
function droitsDemandes() {
  const dansUnKit = require('./kit.js').dansUnKit();
  return dansUnKit ? SCOPES_TWITCH.filter((x) => !DROITS_HORS_KIT.includes(x)) : SCOPES_TWITCH;
}

const ENTETES_FORMULAIRE = { 'Content-Type': 'application/x-www-form-urlencoded' };

async function lireJson(r) {
  const texte = await r.text();
  if (!texte) return {};
  try { return JSON.parse(texte); } catch (e) { return { message: texte.slice(0, 200) }; }
}

// Ce que Twitch répond est souvent laconique (« invalid client »). On le
// traduit en quelque chose qui dit QUOI FAIRE, sans jargon.
function expliquerErreurTwitch(statut, d) {
  const brut = String((d && (d.message || d.error)) || '').trim();
  const m = brut.toLowerCase();
  if (m.includes('secret')) {
    return 'Le Client ID du kit est de type « Confidentiel ». La connexion par code '
      + 'demande une application Twitch de type « Public » (voir LISEZ-MOI, '
      + 'PRÉPARER UN KIT).';
  }
  if (m.includes('invalid client') || m.includes('client id') || statut === 404) {
    return 'Twitch ne reconnaît pas le Client ID du kit (kit.json). '
      + 'Demande à la personne qui t’a installé la régie de le vérifier.';
  }
  if (m.includes('scope')) return 'Twitch refuse une des permissions demandées : ' + brut;
  if (m.includes('invalid refresh token')) {
    return 'La connexion Twitch a expiré (plus de 30 jours sans servir, ou mot de passe '
      + 'Twitch changé). Reconnecte-toi avec un code : Réglages → Twitch.';
  }
  return brut ? 'Twitch : ' + brut : 'Twitch a répondu ' + statut + '.';
}

// ---------- Étape 1 : demander un code ----------
async function demanderCode({ base, clientId, scopes, fetchImpl }) {
  const f = fetchImpl || fetch;
  const corps = new URLSearchParams({ client_id: clientId, scopes: (scopes || droitsDemandes()).join(' ') });
  const r = await f(base + '/oauth2/device', { method: 'POST', headers: ENTETES_FORMULAIRE, body: corps.toString() });
  const d = await lireJson(r);
  if (!r.ok || !d.device_code || !d.user_code) {
    const e = new Error(expliquerErreurTwitch(r.status, d));
    e.statut = r.status;
    throw e;
  }
  return {
    deviceCode: String(d.device_code),
    code: String(d.user_code),
    lien: String(d.verification_uri || 'https://www.twitch.tv/activate'),
    expireDans: Math.max(60, Number(d.expires_in) || 1800),
    intervalle: Math.max(1, Number(d.interval) || 5),
  };
}

// ---------- Étape 2 : une interrogation ----------
// Renvoie { etat: 'attente' | 'ralentir' | 'ok' | 'fini', jetons?, erreur? }
async function interrogerUneFois({ base, clientId, scopes, deviceCode, fetchImpl }) {
  const f = fetchImpl || fetch;
  const corps = new URLSearchParams({
    client_id: clientId,
    scopes: (scopes || droitsDemandes()).join(' '),
    device_code: deviceCode,
    grant_type: 'urn:ietf:params:oauth:grant-type:device_code',
  });
  const r = await f(base + '/oauth2/token', { method: 'POST', headers: ENTETES_FORMULAIRE, body: corps.toString() });
  const d = await lireJson(r);
  if (r.ok && d.access_token) return { etat: 'ok', jetons: normaliserJetons(d) };
  const m = String((d && (d.message || d.error)) || '').toLowerCase();
  if (m.includes('authorization_pending')) return { etat: 'attente' };
  if (m.includes('slow_down')) return { etat: 'ralentir' };
  if (m.includes('invalid device code') || m.includes('expired')) {
    return { etat: 'fini', expire: true, erreur: 'Le code a expiré. Demande un nouveau code.' };
  }
  if (m.includes('denied')) {
    return { etat: 'fini', erreur: 'Autorisation refusée sur Twitch. Tu peux recommencer quand tu veux.' };
  }
  return { etat: 'fini', erreur: expliquerErreurTwitch(r.status, d) };
}

function normaliserJetons(d) {
  return {
    accessToken: String(d.access_token),
    refreshToken: d.refresh_token ? String(d.refresh_token) : '',
    expireA: Date.now() + Math.max(60, Number(d.expires_in) || 14400) * 1000,
    scopes: Array.isArray(d.scope) ? d.scope.map(String) : String(d.scope || '').split(' ').filter(Boolean),
  };
}

// ---------- Renouvellement ----------
// Le jeton de renouvellement d'un client public ne sert qu'UNE fois : il
// faut absolument enregistrer le nouveau, sans quoi la connexion est perdue
// au renouvellement suivant. C'est l'appelant qui enregistre (tokens.json).
async function renouveler({ base, clientId, refreshToken, fetchImpl }) {
  const f = fetchImpl || fetch;
  const corps = new URLSearchParams({ client_id: clientId, grant_type: 'refresh_token', refresh_token: refreshToken });
  const r = await f(base + '/oauth2/token', { method: 'POST', headers: ENTETES_FORMULAIRE, body: corps.toString() });
  const d = await lireJson(r);
  if (!r.ok || !d.access_token) {
    const e = new Error(expliquerErreurTwitch(r.status, d));
    e.statut = r.status;
    // 400/401 : le jeton de renouvellement est mort, inutile d'insister.
    // Le reste (5xx, réseau) est passager : on retentera.
    e.definitif = r.status === 400 || r.status === 401;
    throw e;
  }
  return normaliserJetons(d);
}

// ---------- Validation ----------
// Twitch demande aux applications de valider leurs jetons au démarrage
// puis toutes les heures, pour s'apercevoir d'une révocation. Renvoie
// { valide, login, expireDans, scopes } ou { valide: false, statut }.
async function valider({ base, token, fetchImpl }) {
  const f = fetchImpl || fetch;
  const r = await f(base + '/oauth2/validate', { headers: { Authorization: 'OAuth ' + token } });
  const d = await lireJson(r);
  if (!r.ok) return { valide: false, statut: r.status };
  return {
    valide: true,
    login: d.login || '',
    clientId: d.client_id || '',
    expireDans: Number(d.expires_in) || 0,
    scopes: Array.isArray(d.scopes) ? d.scopes : [],
  };
}

module.exports = {
  DROITS_HORS_KIT,
  SCOPES_TWITCH,
  droitsDemandes,
  demanderCode,
  interrogerUneFois,
  renouveler,
  valider,
  expliquerErreurTwitch,
};
