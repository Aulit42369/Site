// ============================================================
//  Le bilan des 7 derniers jours
// ------------------------------------------------------------
//  Calcul pur (aucun accès au disque ni aux jetons) : il se contrôle
//  seul, sans charger stockage.js.
// ============================================================

module.exports = {
  bilanSemaine,
  fenetreDepuisDates,
  heureParis,
  semaineDue,
  texteBilanSemaine,
};

// Jour (AAAA-MM-JJ), jour de la semaine (1 = lundi … 7 = dimanche) et heure à
// Paris, l'heure d'été comprise.
function heureParis(t) {
  const p = Object.fromEntries(new Intl.DateTimeFormat('en-US', {
    timeZone: 'Europe/Paris', year: 'numeric', month: '2-digit', day: '2-digit', weekday: 'short', hour: '2-digit', hourCycle: 'h23',
  }).formatToParts(new Date(t)).map((x) => [x.type, x.value]));
  return { jour: `${p.year}-${p.month}-${p.day}`, semaine: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].indexOf(p.weekday) + 1, heure: Number(p.hour) };
}

// Vrai le lundi à partir de 9 h (Paris) tant que le bilan de ce lundi n'est pas
// parti (dernierJour : le jour Paris du dernier envoi). Un pont rallumé le
// lundi après 9 h rattrape ; un autre jour, jamais.
function semaineDue(maintenant, dernierJour) {
  const p = heureParis(maintenant);
  return p.semaine === 1 && p.heure >= 9 && p.jour !== dernierJour;
}

// Deux dates AAAA-MM-JJ (heure de Paris) → de debut 0 h 00 à fin 23 h 59 min 59 s.
// Renvoie null si l'une est absente ou invalide, ou si fin < debut.
function fenetreDepuisDates(debut, fin) {
  const minuit = (jour) => {
    const r = /^(\d{4})-(\d{2})-(\d{2})$/.exec(jour || '');
    if (!r) return NaN;
    const [a, m, j] = [+r[1], +r[2], +r[3]];
    if (new Date(Date.UTC(a, m - 1, j)).getUTCDate() !== j) return NaN; // refuse le 31/02
    for (const decalage of [1, 2]) { // Paris = UTC+1 (hiver) ou +2 (été)
      const t = Date.UTC(a, m - 1, j) - decalage * 3600000;
      const p = heureParis(t);
      if (p.jour === jour && p.heure === 0) return t;
    }
    return NaN;
  };
  const d = minuit(debut);
  const f = Number.isNaN(minuit(fin)) ? NaN
    : minuit(new Date(Date.parse(fin + 'T00:00:00Z') + 86400000).toISOString().slice(0, 10)) - 1;
  return d <= f ? { debut: d, fin: f } : null; // NaN → faux → null
}

function texteBilanSemaine(b) {
  return [
    '📊 **Bilan de la semaine**',
    `🎬 ${b.streams} stream${b.streams > 1 ? 's' : ''} · ⏱️ ${b.duree}`,
    `💜 ${b.follows} follow${b.follows > 1 ? 's' : ''} · ⭐ ${b.abonnements} abonnement${b.abonnements > 1 ? 's' : ''} · 🎁 ${b.abosOfferts} abo${b.abosOfferts > 1 ? 's' : ''} offert${b.abosOfferts > 1 ? 's' : ''}`,
    `💎 ${b.bits} bits · 🚀 ${b.raids} raid${b.raids > 1 ? 's' : ''} · 💬 ${b.messages} message${b.messages > 1 ? 's' : ''}`,
  ].join('\n');
}

function dureeLisible(ms) {
  const min = Math.round(Math.max(0, ms) / 60000);
  const h = Math.floor(min / 60);
  return h ? `${h} h ${String(min % 60).padStart(2, '0')}` : `${min} min`;
}

// Le bilan des 7 derniers jours, tiré de l'historique de comparaison (qui garde
// 62 jours). Pas de pic de spectateurs ni de catégorie : le pont ne
// les note pas encore (il faudra un journal de direct).
// `fenetre` ({ debut, fin } en ms) cale le bilan sur une période précise
// (ex. lundi 0 h → dimanche 23 h 59) ; sans elle : les 7 derniers jours.
function bilanSemaine(historique, maintenant = Date.now(), fenetre = null) {
  const debut = fenetre ? fenetre.debut : maintenant - 7 * 24 * 60 * 60 * 1000;
  const fin = fenetre ? fenetre.fin : maintenant;
  const streams = (historique || []).filter((x) => Number(x.endedAt) >= debut && Number(x.endedAt) <= fin);
  const total = (f) => streams.reduce((t, x) => t + (f(x) || 0), 0);
  const compte = (type) => total((x) => Number(x.counts && x.counts[type]));
  const dureeMs = total((x) => Math.max(0, Number(x.endedAt) - Number(x.startedAt)));
  return {
    debut, fin,
    streams: streams.length,
    dureeMs,
    duree: dureeLisible(dureeMs),
    follows: compte('follow'),
    abonnements: compte('sub') + compte('resub'),
    abosOfferts: total((x) => Number(x.totalGiftSubs)) || compte('gift'),
    bits: total((x) => Number(x.totalBits)),
    raids: compte('raid'),
    messages: compte('chat'),
    pic: null,
    categories: null,
  };
}

