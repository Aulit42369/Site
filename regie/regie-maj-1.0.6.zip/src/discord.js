// ============================================================
//  Les messages Discord (webhooks)
// ------------------------------------------------------------
//  Notifications, bilan : l’adresse d’un webhook est un accès, jamais
//  affichée ni journalisée.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  envoyerDiscord,
  envoyerDiscordBrut,
  posterDiscord,
  webhookAnnonces,
  webhookDiscord,
  webhookDiscordValide,
};

const parametres = require('./parametres.js');
const stockage = require('./stockage.js');
const preuves = require('./preuves.js');

// ------------------------------------------------------------
// Notifications par webhook Discord
// ------------------------------------------------------------
// Les notifications web (Web Push) demandent un « contexte sécurisé » :
// HTTPS avec un certificat reconnu par le téléphone. Sur un simple
// http://192.168.x.x, Chrome ne fournit même pas serviceWorker — le bouton
// d'activation ne peut rien faire, et c'est la raison pour laquelle les
// notifications ne marchaient pas.
//
// Ce chemin-ci n'a besoin de rien de tout ça : le pont envoie un message à
// un webhook, et c'est Discord qui réveille le téléphone. Deux avantages
// par-dessus le marché : rien à installer ni à configurer côté téléphone,
// et une livraison plus fiable que Web Push, qu'Android retarde volontiers
// quand il économise la batterie.
const DISCORD_COULEURS = {
  raid: 0xef4444, cheer: 0xfbbf24, gift: 0xec4899,
  sub: 0xa78bfa, resub: 0xa78bfa, follow: 0x22d3ee,
  sante: 0xef4444, test: 0x34d399,
};

function webhookDiscord() {
  const d = stockage.platformTokens.discord;
  return (d && typeof d.webhook === 'string' && d.webhook.trim()) || '';
}

// Le salon PUBLIC où l'Agence Aulit publie les annonces validées par le
// streamer (Réglages → Annonces Discord). Jamais celui des notifications :
// un message public ne part que là où on l'a voulu.
function webhookAnnonces() {
  const a = stockage.platformTokens.annoncesDiscord;
  return (a && typeof a.webhook === 'string' && a.webhook.trim()) || '';
}

// Le format est vérifié avant d'enregistrer : une adresse qui n'en est pas
// une échouerait en silence au premier raid, c'est-à-dire au pire moment.
// Avec un faux service (verifier.sh), seules ses adresses sont acceptées.
function webhookDiscordValide(url) {
  const u = String(url || '').trim();
  if (parametres.DISCORD_BASE !== 'https://discord.com') return u.startsWith(parametres.DISCORD_BASE + '/api/webhooks/');
  return /^https:\/\/(?:ptb\.|canary\.)?discord(?:app)?\.com\/api\/webhooks\/\d+\/[\w-]+$/.test(u);
}

// Le dernier échec d'envoi est retenu pour la page « Mon installation » :
// un webhook supprimé côté Discord ne se voit nulle part ailleurs, les
// notifications cessent simplement d'arriver.
async function envoyerDiscord(message) {
  const r = await envoyerDiscordBrut(message);
  if (webhookDiscord()) {
    const echec = r.ok ? '' : String(r.erreur || 'échec');
    if (echec !== preuves.suiviInstallation.discordDernierEchec) {
      preuves.suiviInstallation.discordDernierEchec = echec;
      preuves.enregistrerSuivi();
    }
  }
  return r;
}

async function envoyerDiscordBrut({ titre, corps, type }) {
  const url = webhookDiscord();
  if (!url) return { ok: false, erreur: 'Aucun webhook Discord enregistré.' };
  return posterDiscord(url, {
    // Un « embed » plutôt qu'un message brut : Discord lui donne une
    // barre de couleur et un titre en gras, ce qui se lit d'un coup
    // d'œil sur l'écran de verrouillage.
    embeds: [{
      title: String(titre || '').slice(0, 250),
      description: String(corps || '').slice(0, 2000),
      color: DISCORD_COULEURS[type] || 0x8b95a7,
      timestamp: new Date().toISOString(),
      footer: { text: 'Régie mobile' },
    }],
  });
}

// L'envoi lui-même, vers un webhook donné : celui des notifications, celui
// du salon où part le bilan de fin de stream, ou celui des annonces.
// « fichier » ({ nom, type, octets }, facultatif) : une image jointe. Discord
// la veut en multipart (payload_json + files[0]) ; l'embed la cite par
// « attachment://<nom> ». FormData et Blob sont ceux de Node.
async function posterDiscord(url, contenu, fichier) {
  try {
    let options = { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(contenu) };
    if (fichier) {
      const formulaire = new FormData();
      formulaire.append('payload_json', JSON.stringify(contenu));
      formulaire.append('files[0]', new Blob([fichier.octets], { type: fichier.type }), fichier.nom);
      options = { method: 'POST', body: formulaire }; // fetch écrit lui-même l'en-tête multipart
    }
    const r = await fetch(url, options);
    if (r.status === 404 || r.status === 401) {
      return { ok: false, erreur: 'Webhook refusé par Discord — il a été supprimé ou l’adresse est fausse.' };
    }
    if (r.status === 413) return { ok: false, erreur: 'Image trop lourde pour Discord.' };
    if (!r.ok) return { ok: false, erreur: 'Discord a répondu ' + r.status + '.' };
    return { ok: true };
  } catch (e) {
    return { ok: false, erreur: 'Discord injoignable : ' + (e.message || e) };
  }
}
