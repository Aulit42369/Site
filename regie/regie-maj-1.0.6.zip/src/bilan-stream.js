// ============================================================
//  La fin d’un stream
// ------------------------------------------------------------
//  Bilan publié sur Discord (option) et historique de comparaison.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  demarrer,
  derniereFinConnue,
  etatBilanPourAppli,
  bilanSemaine: (h, m, f) => bilanSemaine(h, m, f),
  fenetreDepuisDates: (d, f) => fenetreDepuisDates(d, f),
  reglagesBilan,
  get suiviStream() { return suiviStream; },
  webhookBilan,
  publierBilanSemaine,
};

const { creerSuiviStream } = require('./suivi-stream.js');
const { bilanSemaine, fenetreDepuisDates, heureParis, semaineDue, texteBilanSemaine } = require('./bilan-semaine.js');

const parametres = require('./parametres.js');
const etatRegie = require('./etat-regie.js');
const twitchEcoute = require('./twitch-ecoute.js');
const stockage = require('./stockage.js');
const journalEvenements = require('./journal-evenements.js');
const discord = require('./discord.js');
const arret = require('./arret.js');

// Le bilan publié tout seul sur Discord (option) : le même texte que
// « Copier » dans Stats, posté dans un salon quelques minutes après la fin
// du stream. Désactivé tant qu'on ne l'a pas allumé (Réglages → Bilan sur
// Discord) : c'est un message public, il ne doit jamais partir sans qu'on
// l'ait voulu. Le salon : celui des notifications, ou un autre (son adresse
// de webhook est un accès au salon : jamais exportée, masquée dans le
// journal). Le moment est décidé par suivi-stream.js (voir suiviStream).
function reglagesBilan() {
  const b = stockage.platformTokens.bilanDiscord || {};
  return {
    actif: b.actif === true,
    webhook: (typeof b.webhook === 'string' && b.webhook.trim()) || '',
    dernier: b.dernier && typeof b.dernier === 'object' ? b.dernier : null,
    // Le bilan du lundi 9 h : éteint tant qu'on ne l'a pas allumé, lui aussi.
    semaine: b.semaine === true,
    dernierSemaine: b.dernierSemaine && typeof b.dernierSemaine === 'object' ? b.dernierSemaine : null,
  };
}
// Ce que l'appli en sait : jamais l'adresse elle-même.
function etatBilanPourAppli() {
  const r = reglagesBilan();
  return { actif: r.actif, autreSalon: !!r.webhook, dernier: r.dernier, semaine: r.semaine, dernierSemaine: r.dernierSemaine };
}
function webhookBilan() {
  return reglagesBilan().webhook || discord.webhookDiscord();
}
function dureeLisible(ms) {
  const min = Math.round(Math.max(0, ms) / 60000);
  const h = Math.floor(min / 60);
  return h ? `${h} h ${String(min % 60).padStart(2, '0')}` : `${min} min`;
}

// Les messages de tchat d'un stream : les compteurs des journées touchées,
// moins ce que le compteur du premier jour valait au début du stream (quand
// on l'a vu commencer ; sinon, pont démarré en cours de route, la journée
// entière — à peine plus que le vrai chiffre).
function messagesPendant(s) {
  const jours = journalEvenements.joursEntre(s.debut, s.fin);
  let n = jours.reduce((total, j) => total + (journalEvenements.lireCompteurMessages(j) || 0), 0);
  const avant = s.donnees && s.donnees.messagesAuDebut;
  if (avant && jours.includes(avant.jour)) n -= avant.n;
  return Math.max(0, n);
}

function noterDernierBilan(dernier) {
  stockage.platformTokens.bilanDiscord = { ...(stockage.platformTokens.bilanDiscord || {}), dernier };
  stockage.saveTokens();
  etatRegie.setState({ bilanDiscord: etatBilanPourAppli() });
}

async function publierBilanFinDeStream(s) {
  const duree = s.fin - s.debut;
  const r = reglagesBilan();
  if (!r.actif) {
    console.log(`[bilan] Stream terminé (${dureeLisible(duree)}) : publication automatique désactivée.`);
    return;
  }
  if (duree < parametres.BILAN_DUREE_MIN_MS) {
    console.log(`[bilan] Stream de ${dureeLisible(duree)} : trop court pour un bilan (un essai ?), rien n'est publié.`);
    return;
  }
  const url = webhookBilan();
  if (!url) {
    console.error('[bilan] Bilan non publié : aucun salon Discord (Réglages → Bilan sur Discord).');
    noterDernierBilan({ quand: Date.now(), ok: false, erreur: 'Aucun salon Discord relié.' });
    return;
  }
  const recap = journalEvenements.construireRecap(journalEvenements.jourLocal(s.debut), Math.round(duree / 1000), {
    debut: s.debut, fin: s.fin, messages: messagesPendant(s),
  });
  const envoi = await discord.posterDiscord(url, { content: recap.texte.slice(0, 2000), allowed_mentions: { parse: [] } });
  if (envoi.ok) console.log(`[bilan] Bilan du stream (${dureeLisible(duree)}) publié sur Discord.`);
  else console.error('[bilan] Bilan non publié sur Discord : ' + envoi.erreur);
  noterDernierBilan({ quand: Date.now(), ok: envoi.ok, erreur: envoi.ok ? '' : envoi.erreur });
}

// ------------------------------------------------------------
// Le bilan de la semaine, chaque lundi à 9 h (Paris)
// ------------------------------------------------------------
// Même salon et même règle que le bilan de fin de stream : rien ne part sans
// l'interrupteur. Un lundi = un essai, réussi ou non (pas de nouvel essai
// chaque minute si Discord refuse) ; une semaine sans stream ne publie rien.
async function publierBilanSemaine(maintenant = Date.now()) {
  const jour = heureParis(maintenant).jour;
  const noter = (ok, erreur) => {
    const b = stockage.platformTokens.bilanDiscord || {};
    stockage.platformTokens.bilanDiscord = { ...b, dernierSemaine: { quand: maintenant, jour, ok, erreur: erreur || '' } };
    stockage.saveTokens();
    etatRegie.setState({ bilanDiscord: etatBilanPourAppli() });
  };
  // Semaine calendaire précédente (lundi 0 h → dimanche 23 h 59), comme /api/bilan-semaine?debut&fin.
  const jourDe = (decalage) => new Date(Date.parse(jour + 'T00:00:00Z') - decalage * 86400000).toISOString().slice(0, 10);
  const lundi = heureParis(maintenant).semaine - 1;
  const fenetre = fenetreDepuisDates(jourDe(lundi + 7), jourDe(lundi + 1));
  const bilan = bilanSemaine(etatRegie.obsState.sessionHistory, maintenant, fenetre);
  if (!bilan.streams) {
    console.log('[bilan] Lundi : aucun stream cette semaine, rien n\'est publié.');
    return noter(true, '');
  }
  const url = webhookBilan();
  if (!url) {
    console.error('[bilan] Bilan de la semaine non publié : aucun salon Discord (Réglages → Bilan sur Discord).');
    return noter(false, 'Aucun salon Discord relié.');
  }
  const envoi = await discord.posterDiscord(url, { content: texteBilanSemaine(bilan).slice(0, 2000), allowed_mentions: { parse: [] } });
  if (envoi.ok) console.log('[bilan] Bilan de la semaine publié sur Discord.');
  else console.error('[bilan] Bilan de la semaine non publié sur Discord : ' + envoi.erreur);
  return noter(envoi.ok, envoi.ok ? '' : envoi.erreur);
}

// Une vérification par minute ; l'arrêt du pont n'attend pas ce minuteur.
function surveillerBilanSemaine() {
  const r = reglagesBilan();
  if (!r.semaine || !semaineDue(Date.now(), r.dernierSemaine && r.dernierSemaine.jour)) return;
  // Le jour est noté avant l'envoi : deux passages ne publient jamais deux fois.
  const b = stockage.platformTokens.bilanDiscord;
  stockage.platformTokens.bilanDiscord = { ...b, dernierSemaine: { quand: Date.now(), jour: heureParis(Date.now()).jour, ok: false, erreur: 'Envoi en cours.' } };
  publierBilanSemaine().catch((e) => console.error('[bilan] Bilan de la semaine : ' + (e.message || e)));
}

// ------------------------------------------------------------
// Historique de comparaison entre streams (onglet Stats)
// ------------------------------------------------------------
// C'était l'appli qui l'envoyait, à chaque arrêt du direct qu'elle voyait :
// avec le PC et le téléphone ouverts, chaque stream était noté deux fois, et
// sans appareil ouvert, pas du tout. Le pont le note maintenant lui-même, une
// fois, quand la fin du stream est confirmée, en comptant dans le journal ce
// qui s'est passé pendant CE stream. Un essai de moins de quinze minutes ne
// compte pas (même règle que le bilan sur Discord).
// 62 jours : de quoi faire le bilan du mois précédent (31 j) même en le lisant en fin de mois suivant.
const HISTORIQUE_JOURS = 62;
function enregistrerSessionHistorique(s) {
  const duree = s.fin - s.debut;
  if (duree < parametres.BILAN_DUREE_MIN_MS) return;
  const evs = journalEvenements.evenementsEntre(s.debut, s.fin);
  const counts = {};
  for (const type of ['follow', 'sub', 'resub', 'gift', 'cheer', 'raid']) counts[type] = evs.filter((e) => e.type === type).length;
  counts.chat = messagesPendant(s);
  const somme = (type) => evs.filter((e) => e.type === type).reduce((t, e) => t + (Number(e.amount) || 0), 0);
  const instantane = { counts, totalBits: somme('cheer'), totalGiftSubs: somme('gift'), startedAt: s.debut, endedAt: s.fin };
  const limite = Date.now() - HISTORIQUE_JOURS * 24 * 60 * 60 * 1000;
  etatRegie.obsState.sessionHistory = [...(etatRegie.obsState.sessionHistory || []), instantane].filter((x) => x.endedAt >= limite);
  stockage.persistSharedState();
  etatRegie.broadcastState();
  console.log(`[bilan] Stream de ${dureeLisible(duree)} ajouté à l'historique de comparaison.`);
}

const suiviStream = creerSuiviStream({
  delaiMs: parametres.BILAN_DELAI_MS,
  retardMaxMs: parametres.BILAN_RETARD_MAX_MS,
  // Vu commencer à l'instant (et pas reconstitué après un redémarrage du
  // pont) : on note où en est le compteur de messages du jour, et on vide
  // la liste des derniers événements — comme le faisait l'appli, mais une
  // fois pour toutes, même si aucun appareil n'est ouvert.
  auDebut: (s) => {
    if (Date.now() - s.debut < 60 * 1000) {
      const jour = journalEvenements.jourLocal(s.debut);
      s.donnees.messagesAuDebut = { jour, n: journalEvenements.lireCompteurMessages(jour) || 0 };
      twitchEcoute.twitchEvents.length = 0;
    }
  },
  // Rend la publication en cours : l'arrêt du pont l'attend un peu.
  aLaFin: (s) => {
    try { enregistrerSessionHistorique(s); } catch (e) { console.error('[bilan] Historique : ' + (e.message || e)); }
    // Fin que personne n'a vue, constatée bien après (au stream suivant,
    // par exemple) : un bilan publié maintenant arriverait hors de propos.
    if (s.tardive) {
      console.log(`[bilan] Stream du ${journalEvenements.jourLocal(s.debut)} (${dureeLisible(s.fin - s.debut)}) clos après coup, sa fin n'ayant pas été vue`
        + (reglagesBilan().actif ? ' : pas de bilan sur Discord, il arriverait trop tard.' : '.'));
      return undefined;
    }
    return publierBilanFinDeStream(s).catch((e) => console.error('[bilan] ' + (e.message || e)));
  },
  journal: (m) => console.log('[bilan] ' + m.charAt(0).toUpperCase() + m.slice(1) + '.'),
});

// La fin de stream la plus récente que le pont connaisse : session en cours
// de clôture, dernière close, ou dernière entrée de l'historique (gardée dans
// tokens.json : elle survit à un redémarrage du pont). Twitch liste encore
// un stream une minute après sa fin : sans ce repère, un pont relancé juste
// après le stream le reprenait et publiait un second bilan.
function derniereFinConnue() {
  const h = etatRegie.obsState.sessionHistory || [];
  const historique = h.length ? Number(h[h.length - 1].endedAt) || 0 : 0;
  return Math.max(historique, suiviStream.derniereFin());
}

// Lancé une fois, au démarrage du pont, dans l’ordre fixé par server.js.
function demarrer() {
  setInterval(surveillerBilanSemaine, 60 * 1000).unref();
  // Quitter la régie dans les 3 minutes qui suivent la fin d'un stream
  // emportait son bilan et son entrée d'historique : ils sont faits avant.
  arret.avantArret('bilan du stream qui vient de finir', () => suiviStream.cloreEnAttente({
    obsRelie: etatRegie.obsState.status === 'connected',
    obsDiffuse: !!etatRegie.obsState.streaming,
  }));
}
