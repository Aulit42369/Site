// ============================================================
//  Instagram
// ------------------------------------------------------------
//  Connexion (Instagram API with Instagram Login), Reels, stories.
// ============================================================

// Ce que ce fichier offre aux autres (lu au moment de l’appel : voir
// README.md, « Les fichiers du pont »).
module.exports = {
  adresseRetourInstagram,
  autreFormeRetour,
  conseilAdresseRetour,
  connecterInstagram,
  envoyerFichierInstagram,
  instagramAuthUrl,
  verifierDepotVideo,
  lireQuotaPublication,
  publishStoryToInstagram,
  refuserDansUnKit,
  get REFUS_KIT() { return REFUS_KIT; },
  uploadToInstagram,
};

const parametres = require('./parametres.js');
const etatRegie = require('./etat-regie.js');
const stockage = require('./stockage.js');
const oauth = require('./oauth.js');
const fabriqueKit = require('./kit.js');

// Dans une régie reçue en kit, Instagram ne sert qu'à fabriquer l'image
// (onglet Annonce) : la personne la publie elle-même (décision du 24/10).
// Le pont refuse donc la connexion et toute publication, quoi que demande
// l'appli : ceinture sous les routes de src/routes/comptes.js et annonce.js.
const REFUS_KIT = 'Dans cette régie, Instagram ne se publie pas depuis la régie : enregistre l’image (onglet Annonce), puis publie-la toi-même sur Instagram.';
function refuserDansUnKit() {
  if (!fabriqueKit.dansUnKit()) return;
  const e = new Error(REFUS_KIT);
  e.dansUnKit = true;
  throw e;
}

// ------------------------------------------------------------
// Instagram — Instagram API with Instagram Login (Reels)
// Ne nécessite pas de Page Facebook liée, juste un compte
// Instagram Pro (Créateur ou Business). Connexion sur ce PC
// via /setup, comme YouTube.
// ------------------------------------------------------------
const IG_API_VERSION = 'v23.0';

// L'adresse de retour, avec ou sans « / » final (« avec » ou « sans »).
// Instagram la compare exactement, « / » final compris : à l'autorisation
// (une adresse non déclarée chez Meta donne « Invalid redirect_uri » sur SA
// page, et rien ne revient ici), puis à l'échange du code (« Error validating
// verification code… redirect_uri… »). Un échange refusé GRILLE le code : un
// second essai répond « This authorization code has been used ». Et juste
// après un changement des adresses chez Meta, l'échange a encore été refusé
// quelques minutes (tout constaté le 17/10).
// D'où : une seule forme par autorisation, la même au départ et à l'échange ;
// « avec » d'abord ; /setup fait déclarer les deux formes ; la forme qui a
// marché est retenue (instagram.retour, dans tokens.json).
const IG_RETOUR_SANS = `https://localhost:${parametres.HTTPS_PORT}/oauth/instagram/callback`;
function adresseRetourInstagram(forme) {
  return forme === 'sans' ? IG_RETOUR_SANS : IG_RETOUR_SANS + '/';
}
function formeRetourRetenue() {
  return (stockage.platformTokens.instagram || {}).retour === 'sans' ? 'sans' : 'avec';
}
function autreFormeRetour(forme) {
  return forme === 'sans' ? 'avec' : 'sans';
}
// La clé secrète attendue, avec les libellés exacts : celui du champ de
// /setup, et celui du tableau de bord de Meta (sa page « API Instagram »).
const CONSEIL_CLE = 'Sur /setup, le champ « Clé secrète de l’app Instagram » doit contenir la « Clé secrète Instagram » affichée chez Meta à côté de l’ID d’app Instagram, pas la clé de l’app Meta.';
// Ce qu'il reste à vérifier quand Instagram a refusé les deux formes.
function conseilAdresseRetour() {
  return 'La régie a essayé l’adresse de retour avec et sans « / » final. Chez Meta, dans « Paramètres de connexion professionnelle », les URI de redirection OAuth doivent contenir '
    + adresseRetourInstagram('avec') + ' et ' + adresseRetourInstagram('sans') + ' (avec et sans « / » final). Si tu viens de les modifier, attends quelques minutes : Meta met un moment à prendre un changement en compte. '
    + CONSEIL_CLE + ' Puis relance la connexion depuis /setup.';
}

// « essai » : 2 quand la régie relance elle-même l'autorisation avec l'autre
// forme (voir src/routes/comptes.js) ; il voyage dans le « state », avec la
// forme, pour que l'échange reprenne exactement la même adresse.
function instagramAuthUrl({ forme = formeRetourRetenue(), essai = 1 } = {}) {
  const ig = stockage.platformTokens.instagram || {};
  const params = new URLSearchParams({
    client_id: ig.appId || '',
    redirect_uri: adresseRetourInstagram(forme),
    response_type: 'code',
    scope: 'instagram_business_basic,instagram_business_content_publish',
    state: oauth.creerEtatOauth('instagram', { forme, essai }),
  });
  return `https://www.instagram.com/oauth/authorize?${params.toString()}`;
}

// Le retour de l'autorisation : le code s'échange contre un jeton d'une heure,
// puis contre un jeton de 60 jours (renouvelé ensuite par
// ensureInstagramToken), et le compte pro donne l'identifiant des
// publications. Cette étape manquait : rien n'écrivait le jeton, et Instagram
// ne pouvait jamais être relié.
// Le message d'erreur d'une réponse d'Instagram, quelle que soit sa forme.
function messageInstagram(d) {
  return String((d && (d.error_message || (d.error && (d.error.message || d.error)) || d.error_description)) || '');
}

// 1. Code → jeton d'une heure. Réponse { data: [ { access_token, user_id,
//    permissions } ] } (ou, forme plus ancienne, sans le tableau).
//    UN SEUL essai par code : Instagram le grille au premier, même refusé.
//    Un refus qui vise l'adresse de retour est marqué (adresseDeRetour) :
//    une NOUVELLE autorisation avec l'autre forme peut alors aboutir.
async function echangerCode(ig, code, adresseRetour) {
  const r = await fetch(`${parametres.IG_API}/oauth/access_token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ client_id: ig.appId, client_secret: ig.appSecret, grant_type: 'authorization_code', redirect_uri: adresseRetour, code }),
  });
  const d = await r.json().catch(() => ({}));
  const court = Array.isArray(d.data) ? d.data[0] : d;
  if (r.ok && court && court.access_token) return court;
  const message = messageInstagram(d).replace(/[.\s]+$/, '');
  // Une mauvaise clé secrète : dit tout de suite laquelle mettre.
  const conseil = /client[ _-]?secret/i.test(message) ? ' ' + CONSEIL_CLE : '';
  const erreur = new Error('Instagram a refusé le code' + (message ? ' : ' + message : '') + '.' + conseil);
  erreur.adresseDeRetour = /redirect[ _-]?ur[il]/i.test(message);
  throw erreur;
}

// Les permissions qu'Instagram a vraiment accordées (chaîne « a,b,c » ou
// tableau, selon les versions).
function permissionsAccordees(court) {
  const p = court && court.permissions;
  if (Array.isArray(p)) return p.map(String);
  return String(p || '').split(',').map((x) => x.trim()).filter(Boolean);
}

// « forme » : celle de l'autorisation qui a donné ce code (rangée dans son
// « state ») ; l'échange doit reprendre exactement la même adresse.
async function connecterInstagram(code, forme) {
  refuserDansUnKit();
  const ig = stockage.platformTokens.instagram || {};
  if (!ig.appId || !ig.appSecret) throw new Error('ID et clé secrète de l’app Instagram manquants : renseigne-les sur /setup.');
  const court = await echangerCode(ig, code, adresseRetourInstagram(forme));
  // 2. Jeton d'une heure → jeton de 60 jours (le secret ne quitte jamais le PC).
  const r2 = await fetch(`${parametres.IG_GRAPH}/access_token?` + new URLSearchParams({ grant_type: 'ig_exchange_token', client_secret: ig.appSecret, access_token: court.access_token }));
  const d2 = await r2.json().catch(() => ({}));
  if (!r2.ok || !d2.access_token) {
    throw new Error('Instagram a refusé le jeton de longue durée' + (d2.error && d2.error.message ? ' : ' + d2.error.message : '') + '.');
  }
  // 3. Le compte : user_id est l'identifiant du compte pro, celui qu'attendent
  //    les publications (id n'est qu'un identifiant propre à l'application).
  const r3 = await fetch(`${parametres.IG_GRAPH}/${IG_API_VERSION}/me?` + new URLSearchParams({ fields: 'user_id,username', access_token: d2.access_token }));
  const d3 = await r3.json().catch(() => ({}));
  const moi = (Array.isArray(d3.data) ? d3.data[0] : d3) || {};
  const userId = String(moi.user_id || court.user_id || '');
  if (!userId) throw new Error('Instagram n’a pas donné l’identifiant du compte.');
  stockage.platformTokens.instagram = {
    ...ig,
    accessToken: d2.access_token,
    userId,
    username: String(moi.username || ''),
    obtainedAt: Date.now(),
    expiresAt: Date.now() + (Number(d2.expires_in) || 5184000) * 1000,
    // La forme d'adresse de retour qu'Instagram accepte : la prochaine
    // connexion part directement avec elle.
    retour: forme === 'sans' ? 'sans' : 'avec',
  };
  stockage.saveTokens();
  etatRegie.broadcastState();
  console.log('[instagram] Compte relié' + (moi.username ? ' : @' + moi.username : '') + ' (adresse de retour ' + (forme === 'sans' ? 'sans' : 'avec') + ' « / » final).');
  const compte = moi.username ? '@' + moi.username : 'compte ' + userId;
  // Relié, mais sans le droit de publier : la première annonce échouerait.
  // Mieux vaut le dire tout de suite, avec où le régler chez Meta.
  const permissions = permissionsAccordees(court);
  if (permissions.length && !permissions.includes('instagram_business_content_publish')) {
    console.warn('[instagram] Relié sans la permission de publier (accordées : ' + permissions.join(', ') + ').');
    return { compte, avertissement: 'Mais Instagram n’a pas accordé la publication : chez Meta, ajoute la permission instagram_business_content_publish (Autorisations et fonctionnalités), puis reconnecte-toi ici.' };
  }
  return { compte, avertissement: '' };
}

async function ensureInstagramToken() {
  const ig = stockage.platformTokens.instagram;
  if (!ig || !ig.accessToken) throw new Error(`Instagram non connecté — ouvre http://127.0.0.1:${parametres.PORT}/setup sur ce PC.`);
  // Jeton longue durée (60 jours) : on le rafraîchit s'il a plus de 24h et qu'il reste moins de 5 jours.
  const age = Date.now() - (ig.obtainedAt || 0);
  const remaining = (ig.expiresAt || 0) - Date.now();
  if (age > 24 * 3600 * 1000 && remaining < 5 * 24 * 3600 * 1000) {
    try {
      const params = new URLSearchParams({ grant_type: 'ig_refresh_token', access_token: ig.accessToken });
      const res = await fetch(`${parametres.IG_GRAPH}/refresh_access_token?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        ig.accessToken = data.access_token;
        ig.obtainedAt = Date.now();
        ig.expiresAt = Date.now() + (data.expires_in || 5184000) * 1000;
        stockage.saveTokens();
      }
    } catch (e) { /* on retente au prochain envoi si le rafraîchissement échoue */ }
  }
  return ig;
}

// Le quota de publications du compte sur 24 h, lu chez Instagram
// (content_publishing_limit). Le plafond (50 ou 100 selon les sources) n'est
// JAMAIS écrit ici : on affiche ce que l'API répond pour CE compte.
// Rend { utilise, total, restant, heures } ; total/restant à null si
// Instagram ne dit pas le plafond.
async function lireQuotaPublication() {
  refuserDansUnKit();
  const ig = await ensureInstagramToken();
  const r = await fetch(`${parametres.IG_GRAPH}/${IG_API_VERSION}/${ig.userId}/content_publishing_limit?` + new URLSearchParams({
    fields: 'quota_usage,config', access_token: ig.accessToken,
  }));
  const d = await r.json().catch(() => ({}));
  const ligne = Array.isArray(d.data) ? d.data[0] : null;
  if (!r.ok || !ligne) throw new Error('Instagram n’a pas donné le quota de publication' + (d.error && d.error.message ? ' : ' + d.error.message : '') + '.');
  const utilise = Number(ligne.quota_usage) || 0;
  const total = Number(ligne.config && ligne.config.quota_total) || null;
  const secondes = Number(ligne.config && ligne.config.quota_duration) || null;
  return { utilise, total, restant: total === null ? null : Math.max(0, total - utilise), heures: secondes ? Math.round(secondes / 3600) : null };
}

async function uploadToInstagram(downloadUrl, caption) {
  refuserDansUnKit();
  const ig = await ensureInstagramToken();

  const containerRes = await fetch(
    `${parametres.IG_GRAPH}/${IG_API_VERSION}/${ig.userId}/media?` + new URLSearchParams({
      media_type: 'REELS', video_url: downloadUrl, caption: caption || '', access_token: ig.accessToken,
    }),
    { method: 'POST' }
  );
  const containerData = await containerRes.json();
  if (!containerRes.ok || !containerData.id) {
    throw new Error('Instagram a refusé la création du conteneur : ' + (containerData.error ? containerData.error.message : containerRes.status));
  }
  return attendreEtPublier(ig, containerData.id);
}

// Une vidéo fabriquée sur ce PC (sous-titrée) n'a pas d'adresse publique, et
// « Instagram Login » n'accepte que video_url (l'envoi « resumable » est
// réservé aux apps « Facebook Login for Business »). Elle passe donc par le
// dépôt vidéo temporaire (serveur d'Olivier, dossier depot-video/) : déposée
// sous un id tiré au hasard, publiée par son adresse, puis supprimée du dépôt
// dans tous les cas (le dépôt l'efface de lui-même après une heure).
const DEPOT_MANQUANT = 'Le dépôt vidéo n’est pas réglé : sans lui, Instagram ne peut pas recevoir une vidéo sous-titrée. Sur le PC, suis depot-video\\README.md, « Faire pointer la Régie sur le serveur » (adresse https://depot.aulit42369.fr). Rien n’a été publié.';
// Appelé aussi AVANT de sous-titrer (routes/comptes.js) : pas de minutes de
// transcription pour rien.
function verifierDepotVideo() {
  const depot = stockage.platformTokens.depotVideo || {};
  if (!depot.adresse || !depot.cle) throw new Error(DEPOT_MANQUANT);
  return depot;
}
async function envoyerFichierInstagram(video, caption) {
  refuserDansUnKit();
  const depot = verifierDepotVideo();
  await ensureInstagramToken();
  const adresse = depot.adresse + '/v/' + require('crypto').randomBytes(24).toString('base64url');
  const cle = { Authorization: 'Bearer ' + depot.cle };
  let r;
  try {
    r = await fetch(adresse, { method: 'PUT', headers: { ...cle, 'Content-Type': 'video/mp4' }, body: video });
  } catch (e) {
    throw new Error('Le dépôt vidéo ne répond pas (' + depot.adresse + '). Rien n’a été publié.');
  }
  if (!r.ok) {
    const raison = r.status === 401 ? 'clé refusée : refais « Faire pointer la Régie sur le serveur », depot-video\\README.md'
      : r.status === 413 ? 'vidéo trop lourde (25 Mo au plus)' : 'statut ' + r.status;
    throw new Error('Le dépôt vidéo a refusé la vidéo (' + raison + '). Rien n’a été publié.');
  }
  try {
    return await uploadToInstagram(adresse, caption);
  } finally {
    await fetch(adresse, { method: 'DELETE', headers: cle }).catch(() => { /* l'expiration d'une heure rattrape */ });
  }
}

// Le conteneur est créé : Instagram traite la vidéo, on patiente jusqu'à
// FINISHED, puis on publie. Rend le lien de la publication.
async function attendreEtPublier(ig, containerId) {
  let status = 'IN_PROGRESS';
  for (let i = 0; i < 30 && status === 'IN_PROGRESS'; i++) {
    await new Promise((r) => setTimeout(r, 2000));
    const statusRes = await fetch(`${parametres.IG_GRAPH}/${IG_API_VERSION}/${containerId}?fields=status_code&access_token=${ig.accessToken}`);
    const statusData = await statusRes.json().catch(() => ({}));
    status = statusData.status_code || 'IN_PROGRESS';
    if (status === 'ERROR' || status === 'EXPIRED') throw new Error('Instagram a signalé une erreur de traitement (' + status + ').');
  }
  if (status !== 'FINISHED') throw new Error("La vidéo n'a pas fini son traitement côté Instagram (délai dépassé).");

  const publishRes = await fetch(
    `${parametres.IG_GRAPH}/${IG_API_VERSION}/${ig.userId}/media_publish?` + new URLSearchParams({ creation_id: containerId, access_token: ig.accessToken }),
    { method: 'POST' }
  );
  const publishData = await publishRes.json();
  if (!publishRes.ok || !publishData.id) {
    throw new Error('Instagram a refusé la publication : ' + (publishData.error ? publishData.error.message : publishRes.status));
  }

  try {
    const permaRes = await fetch(`${parametres.IG_GRAPH}/${IG_API_VERSION}/${publishData.id}?fields=permalink&access_token=${ig.accessToken}`);
    const permaData = await permaRes.json();
    if (permaData.permalink) return permaData.permalink;
  } catch (e) {}
  return 'https://www.instagram.com/reel/';
}

// ------------------------------------------------------------
// Publication d'une image simple (pas un Reel) sur Instagram.
// L'API Instagram va chercher elle-même l'image à une URL publique
// (aucune option d'envoi binaire direct pour une image seule) — donc
// on relaie via imgbb, qui héberge l'image le temps qu'Instagram la
// récupère. Nécessite une clé imgbb (gratuite) dans Réglages.
// ------------------------------------------------------------
async function uploadToImgbb(buffer) {
  const key = stockage.platformTokens.imgbb && stockage.platformTokens.imgbb.apiKey;
  if (!key) throw new Error("Pas de clé imgbb configurée — nécessaire pour publier une image sur Instagram (voir Réglages).");
  const form = new URLSearchParams();
  form.set('image', buffer.toString('base64'));
  const res = await fetch(`https://api.imgbb.com/1/upload?key=${encodeURIComponent(key)}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: form.toString(),
  });
  const data = await res.json();
  if (!res.ok || !data.data || !data.data.url) {
    throw new Error("imgbb a refusé l'envoi de l'image : " + (data.error ? data.error.message : res.status));
  }
  return data.data.url;
}

async function publishStoryToInstagram(buffer) {
  refuserDansUnKit();
  const ig = await ensureInstagramToken();
  const publicUrl = await uploadToImgbb(buffer);

  // Instagram va chercher l'image lui-même à cette URL — une petite
  // pause laisse le temps à imgbb de la rendre disponible, et on
  // vérifie nous-mêmes qu'elle répond avant de lancer Instagram dessus.
  // Ça permet de distinguer "imgbb n'a pas fini de la publier" (le
  // check ci-dessous échoue aussi) d'un vrai blocage du robot
  // Instagram spécifiquement (le check réussit, Instagram échoue quand
  // même) — deux causes différentes, deux messages différents.
  await new Promise((r) => setTimeout(r, 2000));
  try {
    const checkRes = await fetch(publicUrl, { method: 'GET' });
    if (!checkRes.ok) throw new Error('statut ' + checkRes.status);
  } catch (e) {
    throw new Error("L'image vient d'être mise en ligne sur imgbb mais n'est pas encore accessible (" + e.message + ") — réessaie dans quelques secondes.");
  }

  const containerRes = await fetch(
    `${parametres.IG_GRAPH}/${IG_API_VERSION}/${ig.userId}/media?` + new URLSearchParams({
      image_url: publicUrl, media_type: 'STORIES', access_token: ig.accessToken,
    }),
    { method: 'POST' }
  );
  const containerData = await containerRes.json();
  if (!containerRes.ok || !containerData.id) {
    const rawMsg = containerData.error ? containerData.error.message : String(containerRes.status);
    const hint = /media type|media could not be fetched|9004|fetch/i.test(rawMsg)
      ? " — l'image est bien accessible depuis le pont, donc ça ressemble à Instagram qui bloque spécifiquement le robot qui va chercher l'image chez imgbb (souci déjà rapporté par d'autres avec ce service précis, pas toujours systématique). Réessaie une fois ; si ça échoue à chaque fois, il faudra changer de service de relais."
      : '';
    throw new Error('Instagram a refusé la création du conteneur : ' + rawMsg + hint);
  }
  const containerId = containerData.id;

  let status = 'IN_PROGRESS';
  for (let i = 0; i < 15 && status === 'IN_PROGRESS'; i++) {
    await new Promise((r) => setTimeout(r, 1500));
    const statusRes = await fetch(`${parametres.IG_GRAPH}/${IG_API_VERSION}/${containerId}?fields=status_code&access_token=${ig.accessToken}`);
    const statusData = await statusRes.json().catch(() => ({}));
    status = statusData.status_code || 'IN_PROGRESS';
    if (status === 'ERROR' || status === 'EXPIRED') throw new Error('Instagram a signalé une erreur de traitement (' + status + ').');
  }

  const publishRes = await fetch(
    `${parametres.IG_GRAPH}/${IG_API_VERSION}/${ig.userId}/media_publish?` + new URLSearchParams({ creation_id: containerId, access_token: ig.accessToken }),
    { method: 'POST' }
  );
  const publishData = await publishRes.json();
  if (!publishRes.ok || !publishData.id) {
    throw new Error('Instagram a refusé la publication : ' + (publishData.error ? publishData.error.message : publishRes.status));
  }

  // Les stories (contenu éphémère 24h) n'ont pas toujours de permalink
  // exploitable côté API — on tente quand même, puis on retombe sur le
  // lien du profil (où la story apparaît) si Instagram n'en fournit pas.
  try {
    const permaRes = await fetch(`${parametres.IG_GRAPH}/${IG_API_VERSION}/${publishData.id}?fields=permalink&access_token=${ig.accessToken}`);
    const permaData = await permaRes.json();
    if (permaData.permalink) return { id: publishData.id, url: permaData.permalink };
  } catch (e) {}
  try {
    const meRes = await fetch(`${parametres.IG_GRAPH}/${IG_API_VERSION}/${ig.userId}?fields=username&access_token=${ig.accessToken}`);
    const meData = await meRes.json();
    if (meData.username) return { id: publishData.id, url: `https://www.instagram.com/${meData.username}/` };
  } catch (e) {}
  return { id: publishData.id, url: 'https://www.instagram.com/' };
}
